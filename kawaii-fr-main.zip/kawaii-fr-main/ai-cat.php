<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 登录检查
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];

// 权限检查：仅管理员（admin 或 devadmin）可导入训练数据
$isAdmin = false;
$adminRes = $conn->query("SELECT admin, devadmin FROM users WHERE uid = $login_uid LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $adminRow = $adminRes->fetch_assoc();
    $isAdmin = ($adminRow['admin'] == 1 || $adminRow['devadmin'] == 1);
}

// 常量定义
define('DATA_FILE', __DIR__ . '/ai-cat-data.txt');       // 原始训练句子
define('MODEL_CACHE_FILE', __DIR__ . '/ai-cat-model.cache'); // 缓存模型
define('NGRAM_N', 3); // 词级别 n-gram 的 n 值（3-gram，前缀2个词）
define('MAX_GEN_WORDS', 30); // 生成回复的最大词数

// 处理导入训练数据（仅管理员）
$importMessage = '';
if ($isAdmin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import'])) {
    $data = trim($_POST['training_data'] ?? '');
    if ($data === '') {
        $importMessage = '训练数据不能为空。';
    } else {
        // 按行分割，过滤空行，保存
        $lines = preg_split('/\r\n|\r|\n/', $data);
        $cleanLines = [];
        foreach ($lines as $line) {
            $line = trim($line);
            if ($line !== '') {
                $cleanLines[] = $line;
            }
        }
        if (empty($cleanLines)) {
            $importMessage = '没有有效句子。';
        } else {
            file_put_contents(DATA_FILE, implode("\n", $cleanLines));
            // 立即构建模型
            $buildResult = buildModel();
            if ($buildResult === true) {
                $importMessage = '导入成功，模型已更新！共 ' . count($cleanLines) . ' 条句子。';
            } else {
                $importMessage = '导入成功，但模型构建失败。';
            }
        }
    }
}

// 构建词 n-gram 模型（从 DATA_FILE 读取）
function buildModel() {
    if (!file_exists(DATA_FILE)) {
        return false;
    }
    $sentences = file(DATA_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (empty($sentences)) {
        return false;
    }

    $model = [];
    $n = NGRAM_N;

    foreach ($sentences as $sentence) {
        // 按空格分词，过滤空词
        $words = preg_split('/\s+/u', trim($sentence));
        $words = array_filter($words, function ($w) { return $w !== ''; });
        $words = array_values($words); // 重新索引
        $count = count($words);
        if ($count < $n) continue;

        for ($i = 0; $i <= $count - $n; $i++) {
            // 前缀为前 n-1 个词
            $prefixWords = array_slice($words, $i, $n - 1);
            $prefix = implode(' ', $prefixWords);
            $nextWord = $words[$i + $n - 1];
            if (!isset($model[$prefix])) {
                $model[$prefix] = [];
            }
            if (!isset($model[$prefix][$nextWord])) {
                $model[$prefix][$nextWord] = 0;
            }
            $model[$prefix][$nextWord]++;
        }
    }

    if (empty($model)) {
        return false;
    }

    file_put_contents(MODEL_CACHE_FILE, serialize($model));
    return true;
}

// 从模型生成回复
function generateReply($model, $userInput) {
    $n = NGRAM_N;
    // 将用户输入分词
    $words = preg_split('/\s+/u', trim($userInput));
    $words = array_filter($words, function ($w) { return $w !== ''; });
    $words = array_values($words);

    // 取最后 n-1 个词作为前缀（不足则随机选择前缀）
    if (count($words) >= $n - 1) {
        $prefixWords = array_slice($words, -($n - 1));
        $prefix = implode(' ', $prefixWords);
    } else {
        $prefixes = array_keys($model);
        $prefix = $prefixes[array_rand($prefixes)];
    }

    $generated = explode(' ', $prefix);
    $currentPrefix = $prefix;

    for ($i = 0; $i < MAX_GEN_WORDS; $i++) {
        if (!isset($model[$currentPrefix]) || empty($model[$currentPrefix])) {
            break;
        }
        $nextWord = pickWord($model[$currentPrefix]);
        if ($nextWord === null) break;
        $generated[] = $nextWord;

        // 更新前缀：去掉第一个词，加上新词
        $prefixWords = explode(' ', $currentPrefix);
        if (count($prefixWords) >= $n - 1) {
            array_shift($prefixWords);
        }
        $prefixWords[] = $nextWord;
        $currentPrefix = implode(' ', $prefixWords);

        // 遇到终止符号可能停止
        if (in_array($nextWord, ['。', '！', '？', '!', '?', '；', ';', '…'])) {
            if (mt_rand(0, 1) === 0) break;
        }
    }

    return implode(' ', $generated);
}

// 根据频率随机选择下一个词
function pickWord($freqMap) {
    $total = array_sum($freqMap);
    if ($total <= 0) return null;
    $rand = mt_rand(1, $total);
    $cumulative = 0;
    foreach ($freqMap as $word => $count) {
        $cumulative += $count;
        if ($rand <= $cumulative) {
            return $word;
        }
    }
    return null;
}

// 处理聊天请求（POST）
$reply = '';
$userInput = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $userInput = trim($_POST['message']);
    if ($userInput !== '') {
        if (file_exists(MODEL_CACHE_FILE)) {
            $model = @unserialize(file_get_contents(MODEL_CACHE_FILE));
            if ($model !== false && !empty($model)) {
                $reply = generateReply($model, $userInput);
            } else {
                $reply = '模型数据无效，请管理员重新导入训练数据。';
            }
        } else {
            $reply = '模型尚未训练，请等待管理员导入数据。';
        }
    }
}

// 获取模型状态
$modelExists = file_exists(MODEL_CACHE_FILE);
$modelSize = $modelExists ? filesize(MODEL_CACHE_FILE) : 0;
$dataExists = file_exists(DATA_FILE);
$sentenceCount = 0;
if ($dataExists) {
    $sentenceCount = count(file(DATA_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES));
}

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>猫娘 AI 聊天 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .main{max-width:800px;margin:28px auto 40px;padding:0 20px;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:16px;}
        .chat-box{height:400px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius-sm);padding:15px;background:#fafaf8;margin-bottom:16px;}
        .msg{display:flex;margin-bottom:12px;}
        .msg .bubble{max-width:80%;padding:10px 14px;border-radius:16px;font-size:14px;line-height:1.6;word-wrap:break-word;}
        .msg.user{justify-content:flex-end;}
        .msg.user .bubble{background:var(--accent);color:#fff;border-bottom-right-radius:4px;}
        .msg.ai{justify-content:flex-start;}
        .msg.ai .bubble{background:#fff;border:1px solid var(--border);color:var(--text);border-bottom-left-radius:4px;}
        .input-area{display:flex;gap:10px;}
        .input-area input{flex:1;padding:10px 14px;border:1.5px solid var(--border);border-radius:20px;font-size:14px;outline:none;background:#fdfdfc;font-family:var(--font);}
        .input-area input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);}
        .input-area button{padding:10px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);}
        .input-area button:hover{background:var(--accent-hover);}
        .model-info{font-size:13px;color:var(--text-muted);margin-bottom:10px;}
        textarea{width:100%;min-height:180px;padding:10px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:13px;font-family:var(--font);resize:vertical;margin-bottom:10px;}
        .btn-primary{background:var(--accent);color:#fff;padding:8px 20px;border:none;border-radius:20px;cursor:pointer;font-size:14px;}
        .btn-primary:hover{background:var(--accent-hover);}
        .alert{padding:10px 15px;border-radius:var(--radius-sm);margin-bottom:15px;font-size:14px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;}
        .alert-error{background:#fde8e8;color:#c62828;border:1px solid #ef9a9a;}
        @media(max-width:768px){.main{padding:0 12px;}.card{padding:18px 14px;}.chat-box{height:300px;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <div class="card">
        <h2>🐱 猫娘 AI 聊天</h2>
        <div class="model-info">
            模型状态：<?= $modelExists ? '已训练（' . round($modelSize/1024, 2) . ' KB）' : '未训练' ?> | 句子数：<?= $sentenceCount ?>
        </div>

        <?php if ($isAdmin): ?>
            <div style="margin-bottom:15px; border-top:1px solid var(--border-light); padding-top:15px;">
                <h3 style="font-size:16px; margin-bottom:10px;">导入训练数据（每行一句，空格分词）</h3>
                <?php if ($importMessage): ?>
                    <div class="alert <?= strpos($importMessage, '成功') !== false ? 'alert-success' : 'alert-error' ?>"><?= safeContent($importMessage) ?></div>
                <?php endif; ?>
                <form method="post">
                    <textarea name="training_data" placeholder="例如：&#10;主人 早安 喵 今天 也 要 想 人家 哦&#10;人家 饿 了 喵 想 吃 小鱼干"><?= $dataExists ? safeContent(file_get_contents(DATA_FILE)) : '' ?></textarea>
                    <button type="submit" name="import" class="btn-primary">导入并重建模型</button>
                </form>
            </div>
        <?php endif; ?>

        <div class="chat-box" id="chatBox">
            <div class="msg ai">
                <div class="bubble">喵～ 我是猫娘 AI，<?= $modelExists ? '可以和主人聊天啦' : '请等待管理员导入训练数据' ?></div>
            </div>
            <?php if ($userInput !== ''): ?>
                <div class="msg user"><div class="bubble"><?=safeContent($userInput)?></div></div>
                <div class="msg ai"><div class="bubble"><?=safeContent($reply)?></div></div>
            <?php endif; ?>
        </div>
        <form method="post" class="input-area">
            <input type="text" name="message" placeholder="输入消息..." required autocomplete="off" <?= !$modelExists ? 'disabled' : '' ?>>
            <button type="submit" <?= !$modelExists ? 'disabled' : '' ?>>发送</button>
        </form>
    </div>
</div>

<script>
    const chatBox = document.getElementById('chatBox');
    chatBox.scrollTop = chatBox.scrollHeight;
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>