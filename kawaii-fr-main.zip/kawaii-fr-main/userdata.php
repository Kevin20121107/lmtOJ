<?php
// user_manager.php - 用户密码重置工具 + 手动添加比赛估值功能
// 一级验证：登录 + sqadmin 检查
// 二级验证：FM_PASSWORD 验证
// 功能1：输入UID，重置密码为 UID+六位随机数字，返回新密码（防止刷新重复提交）
// 功能2：输入洛谷UID和分数，手动为绑定用户增加比赛估值（contest_score）

session_start();
require_once __DIR__ . '/security.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

define('FM_PASSWORD', env('FM_PASSWORD', 'admin123'));

// 退出处理
if (isset($_GET['logout'])) {
    $_SESSION['um_auth'] = 0;
    $_SESSION['fm_auth'] = 0;
    header('Location: https://lmtoj.cn/');
    exit;
}

$conn = db();
$conn->set_charset("utf8mb4");

// 确保日志表存在
$conn->query("CREATE TABLE IF NOT EXISTS pwd_reset_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    operator_uid INT NOT NULL,
    target_uid INT NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== 一级验证：登录 + sqadmin ==========
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$user = $conn->query("SELECT sqadmin FROM users WHERE uid=$login_uid LIMIT 1")->fetch_assoc();
if (!$user || !$user['sqadmin']) {
    header("Location: https://lmtoj.cn");
    exit;
}

// ========== 二级验证：FM_PASSWORD ==========
if (!isset($_SESSION['um_auth']) || $_SESSION['um_auth'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fm_password'])) {
        if ($_POST['fm_password'] === FM_PASSWORD) {
            $_SESSION['um_auth'] = true;
            $_SESSION['fm_auth'] = true;
            header("Location: https://lmtoj.cn/userdata");
            exit;
        } else {
            $error = '密码错误';
        }
    }
    ?>
    <!DOCTYPE html>
    <html><head><meta charset="utf-8"><title>二级验证</title>
    <style>
        :root{--bg:#f9f7f4;--card-bg:#fff;--nav-bg:#3d3a37;--text:#2c2a28;--accent:#6b8a74;--danger:#d9534f;--font:'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;}
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);display:flex;justify-content:center;align-items:center;height:100vh;}
        .card{background:var(--card-bg);padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.05);text-align:center;width:360px;}
        h2{font-size:20px;margin-bottom:20px;color:var(--text);}
        input{padding:10px 14px;border:1.5px solid #e6e1da;border-radius:6px;font-size:14px;width:100%;}
        .btn{padding:9px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;margin-top:16px;}
        .error{color:var(--danger);margin-top:8px;font-size:13px;}
    </style></head>
    <body>
        <div class="card">
            <h2>用户密码重置 · 二级验证</h2>
            <form method="post">
                <input type="password" name="fm_password" placeholder="请输入管理密码" required>
                <button type="submit" class="btn">验证</button>
                <?php if (isset($error)): ?><p class="error"><?=$error?></p><?php endif; ?>
            </form>
        </div>
    </body></html>
    <?php
    exit;
}

// CSRF 保护
csrf_protect_request(true);

$message = '';
$resetResult = null; // 从 Session 中读取的一次性结果

// ========== 显示上次重置结果（PRG） ==========
if (isset($_SESSION['reset_result'])) {
    $resetResult = $_SESSION['reset_result'];
    unset($_SESSION['reset_result']); // 清除，防止刷新重现
}

// 处理重置请求
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset') {
    $targetUid = (int)($_POST['uid'] ?? 0);
    if ($targetUid <= 0) {
        $message = '请输入有效的UID';
    } else {
        $exists = $conn->query("SELECT uid FROM users WHERE uid=$targetUid LIMIT 1")->fetch_assoc();
        if (!$exists) {
            $message = 'UID不存在';
        } else {
            $randomPart = sprintf('%06d', random_int(0, 999999));
            $newPassword = $targetUid . '_' . $randomPart;
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE users SET password=? WHERE uid=?");
            $stmt->bind_param("si", $newHash, $targetUid);
            $stmt->execute();
            $stmt->close();

            $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
            $logStmt = $conn->prepare("INSERT INTO pwd_reset_log (operator_uid, target_uid, ip_address) VALUES (?, ?, ?)");
            $logStmt->bind_param("iis", $login_uid, $targetUid, $ip);
            $logStmt->execute();
            $logStmt->close();

            $_SESSION['reset_result'] = $newPassword;
            header("Location: https://lmtoj.cn/userdata");
            exit;
        }
    }
}

// ========== 新增：手动添加比赛估值 ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'manual_add_contest_score') {
    $luoguUid = trim($_POST['luogu_uid'] ?? '');
    $addScore = (int)($_POST['add_score'] ?? 0);

    if (empty($luoguUid) || !is_numeric($luoguUid)) {
        $message = '请输入有效的洛谷 UID';
    } elseif ($addScore <= 0) {
        $message = '请输入大于0的分数';
    } else {
        $luoguUid = (int)$luoguUid;
        // 查找绑定了该洛谷 UID 的用户
        $bind = $conn->query("SELECT uid FROM user_bind WHERE bind_type='luogu' AND bind_value='$luoguUid' LIMIT 1")->fetch_assoc();
        if (!$bind) {
            $message = '未找到绑定该洛谷 UID 的用户';
        } else {
            $targetUid = (int)$bind['uid'];
            // 读取当前 contest_score
            $cur = $conn->query("SELECT contest_score FROM users WHERE uid=$targetUid")->fetch_assoc();
            $currentScore = (int)($cur['contest_score'] ?? 0);
            // 计算新分数，不超过20
            $newScore = min(20, $currentScore + $addScore);
            $actualAdd = $newScore - $currentScore;
            $conn->query("UPDATE users SET contest_score=$newScore WHERE uid=$targetUid");
            if ($actualAdd > 0) {
                $message = "已为用户 UID {$targetUid} 增加 {$actualAdd} 点比赛估值（原 {$currentScore}，现 {$newScore}，上限20）";
            } else {
                $message = "用户 UID {$targetUid} 的比赛估值已达到上限20，本次未增加";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户管理 · lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #fff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --accent: #6b8a74; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); min-height:100vh; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 24px; color:var(--nav-text); }
        .navbar .title { font-size:17px; font-weight:600; }
        .nav-links a { color:#e0dbd3; text-decoration:none; padding:7px 15px; border-radius:20px; font-size:13px; }
        .nav-links a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .container { max-width:500px; margin:40px auto; padding:0 20px; }
        .card { background:var(--card-bg); padding:24px 28px; border-radius:var(--radius); box-shadow:var(--shadow); margin-bottom:20px; }
        h2 { font-size:18px; margin-bottom:18px; }
        .form-group { margin-bottom:16px; }
        .form-group label { display:block; margin-bottom:6px; font-size:13px; color:var(--text-secondary); font-weight:500; }
        .form-group input { width:100%; padding:10px 14px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; }
        .btn { padding:10px 22px; border:none; border-radius:22px; cursor:pointer; font-size:14px; font-weight:600; background:var(--accent); color:#fff; }
        .btn:hover { background:#55735e; }
        .message { padding:12px; border-radius:8px; margin-bottom:16px; font-weight:500; }
        .message.error { background:#fff5f5; color:#c0392b; }
        .message.success { background:#f0f8f0; color:#2e7d32; }
        .password-box { background:#fffef5; border:2px dashed #f0d78c; border-radius:var(--radius); padding:20px; text-align:center; margin-bottom:20px; }
        .password-box .new-pwd { font-size:32px; font-weight:700; letter-spacing:3px; word-break:break-all; }
        .copy-btn { margin-top:10px; }
        .warning { color:var(--danger); font-weight:600; margin-top:12px; font-size:13px; }
    </style>
</head>
<?php include __DIR__ . '/navbar.php'; ?>
<body>
    <div class="container">
        <?php if ($message): ?>
            <div class="message <?= strpos($message, '已为') !== false || strpos($message, '已达到') !== false ? 'success' : 'error' ?>"><?=htmlspecialchars($message)?></div>
        <?php endif; ?>

        <?php if ($resetResult !== null): ?>
            <div class="password-box">
                <h3>✅ 密码已重置</h3>
                <p style="margin:10px 0; color:var(--text-secondary);">新密码为：</p>
                <div class="new-pwd" id="newPassword"><?=htmlspecialchars($resetResult)?></div>
                <button class="btn copy-btn" onclick="copyPassword()">📋 复制密码</button>
                <p class="warning">⚠️ 此密码仅显示一次，刷新页面后不会再次显示。请立即记录并告知用户！</p>
            </div>
            <script>
                function copyPassword() {
                    const pwd = document.getElementById('newPassword').textContent;
                    navigator.clipboard.writeText(pwd).then(() => {
                        const btn = event.target;
                        btn.textContent = '✅ 已复制';
                        setTimeout(() => btn.textContent = '📋 复制密码', 2500);
                    });
                }
            </script>
        <?php endif; ?>

        <!-- 密码重置卡片 -->
        <div class="card">
            <h2>重置用户密码</h2>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="reset">
                <div class="form-group">
                    <label for="uidInput">请输入要重置密码的用户UID</label>
                    <input type="number" id="uidInput" name="uid" placeholder="例如：123" required autofocus>
                </div>
                <button type="submit" class="btn">🔑 重置密码</button>
            </form>
            <p style="font-size:12px; color:var(--text-muted); margin-top:10px;">
                新密码格式：<strong>UID</strong> + <strong>六位随机数字</strong>
            </p>
        </div>

        <!-- 手动添加比赛估值卡片 -->
        <div class="card">
            <h2>手动添加比赛估值</h2>
            <p style="font-size:13px; color:var(--text-secondary); margin-bottom:15px;">
                输入洛谷 UID 和要增加的分数，系统将为绑定了该洛谷 UID 的用户增加比赛估值（contest_score，上限20）。
            </p>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="manual_add_contest_score">
                <div class="form-group">
                    <label for="luoguUidInput">洛谷 UID</label>
                    <input type="number" id="luoguUidInput" name="luogu_uid" placeholder="例如：123456" required>
                </div>
                <div class="form-group">
                    <label for="addScoreInput">要增加的分数（1~20）</label>
                    <input type="number" id="addScoreInput" name="add_score" min="1" max="20" placeholder="例如：5" required>
                </div>
                <button type="submit" class="btn">➕ 添加分数</button>
            </form>
            <p style="font-size:12px; color:var(--text-muted); margin-top:10px;">
                注意：最终比赛估值不会超过20分；若用户当前分数已为20，则不会增加。
            </p>
        </div>
    </div>
</body>
</html>