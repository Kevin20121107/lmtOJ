<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = (int)$_SESSION['uid'];

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$is_admin = 0;
$sqadmin = 0;
$adminRes = $conn->query("SELECT admin,sqadmin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $adminRes1=$adminRes->fetch_assoc();
    $is_admin = (int)$adminRes1['admin'];
    $sqadmin = (int)$adminRes1['sqadmin'];
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}

$tableCheck = $conn->query("SHOW TABLES LIKE 'user_bind'");
if (!$tableCheck || $tableCheck->num_rows == 0) {
    $conn->query("CREATE TABLE user_bind (
        id INT AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        bind_type ENUM('luogu') NOT NULL,
        bind_value VARCHAR(255) NOT NULL,
        verify_code VARCHAR(32) NOT NULL,
        verified TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        checked_at TIMESTAMP NULL,
        check_count INT DEFAULT 0,
        UNIQUE KEY unique_bind (uid, bind_type),
        INDEX idx_uid (uid),
        INDEX idx_verified (verified)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

$message = '';
$error = '';

$adminView = ($sqadmin && isset($_GET['admin_view']));

if ($sqadmin && isset($_GET['verify_id']) && is_numeric($_GET['verify_id'])) {
    $vid = (int)$_GET['verify_id'];
    $conn->query("UPDATE user_bind SET verified = 1 WHERE id = {$vid} AND verified = 0");
    header("Location: https://lmtoj.cn/bind?admin_view=1");
    exit;
}

if ($sqadmin && isset($_GET['del_bind_id']) && is_numeric($_GET['del_bind_id'])) {
    $delId = (int)$_GET['del_bind_id'];
    $conn->query("DELETE FROM user_bind WHERE id = {$delId}");
    header("Location: https://lmtoj.cn/bind?admin_view=1");
    exit;
}

$allBinds = [];
if ($adminView) {
    // 修改排序：未绑定置顶，再按 UID 升序
    $bindListRes = $conn->query("
        SELECT ub.*, u.name as username 
        FROM user_bind ub 
        LEFT JOIN users u ON ub.uid = u.uid 
        ORDER BY ub.verified ASC, ub.uid ASC
    ");
    if ($bindListRes) {
        while ($row = $bindListRes->fetch_assoc()) {
            $allBinds[] = $row;
        }
    }
}

$userBinds = [];
$bindRes = $conn->query("SELECT * FROM user_bind WHERE uid = {$login_uid} AND verified = 1 ORDER BY bind_type");
if ($bindRes) {
    while ($row = $bindRes->fetch_assoc()) {
        $userBinds[$row['bind_type']] = $row;
    }
}
$hasLuogu = isset($userBinds['luogu']);
$is_bound = $hasLuogu;

$pendingBinds = [];
$pendingRes = $conn->query("SELECT * FROM user_bind WHERE uid = {$login_uid} AND verified = 0 ORDER BY created_at DESC");
if ($pendingRes) {
    while ($row = $pendingRes->fetch_assoc()) {
        $pendingBinds[$row['bind_type']] = $row;
    }
}
$hasPending = !empty($pendingBinds);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'bind_luogu') {
        if ($hasLuogu) {
            $error = '您已绑定洛谷账号';
        } elseif (isset($pendingBinds['luogu'])) {
            $error = '已有洛谷绑定等待验证中';
        } else {
            $luogu_uid = trim($_POST['luogu_uid'] ?? '');
            if (empty($luogu_uid) || !is_numeric($luogu_uid) || $luogu_uid < 1 || $luogu_uid > 9999999) {
                $error = '请输入有效的洛谷 UID';
            } else {
                $checkExist = $conn->query("SELECT uid FROM user_bind WHERE bind_type='luogu' AND bind_value='{$luogu_uid}' AND verified=1 LIMIT 1");
                if ($checkExist && $checkExist->num_rows > 0) {
                    $error = '该洛谷账号已被其他用户绑定';
                } else {
                    $verifyCode = 'lmtoj_bind_' . bin2hex(random_bytes(4));
                    $conn->query("DELETE FROM user_bind WHERE uid = {$login_uid} AND bind_type = 'luogu' AND verified = 0");
                    $stmt = $conn->prepare("INSERT INTO user_bind (uid, bind_type, bind_value, verify_code) VALUES (?, 'luogu', ?, ?)");
                    $stmt->bind_param('iss', $login_uid, $luogu_uid, $verifyCode);
                    $stmt->execute();
                    $stmt->close();
                    $message = "请在洛谷个人签名中写入验证码，然后点击「检查验证」按钮";
                    $pendingBinds['luogu'] = ['bind_value' => $luogu_uid, 'verify_code' => $verifyCode, 'check_count' => 0];
                    $hasPending = true;
                }
            }
        }
    }
    elseif ($action === 'cancel_bind' && $hasPending) {
        $cancelType = $_POST['cancel_type'] ?? '';
        if ($cancelType && isset($pendingBinds[$cancelType])) {
            $conn->query("DELETE FROM user_bind WHERE uid = {$login_uid} AND bind_type = '{$cancelType}' AND verified = 0");
            unset($pendingBinds[$cancelType]);
            $hasPending = !empty($pendingBinds);
            $message = '已取消验证';
        }
    }
    elseif ($action === 'manual_check' && $hasPending) {
        $checkType = $_POST['check_type'] ?? '';
        if ($checkType === 'luogu' && isset($pendingBinds['luogu'])) {
            $result = checkLuogu($pendingBinds['luogu']['bind_value'], $pendingBinds['luogu']['verify_code']);
            if ($result) {
                $conn->query("UPDATE user_bind SET verified = 1 WHERE uid = {$login_uid} AND bind_type = 'luogu' AND verified = 0");
                $message = '洛谷绑定成功！';
                $newBind = $conn->query("SELECT * FROM user_bind WHERE uid = {$login_uid} AND bind_type = 'luogu' AND verified = 1 LIMIT 1")->fetch_assoc();
                if ($newBind) { $userBinds['luogu'] = $newBind; $hasLuogu = true; $is_bound = true; }
                unset($pendingBinds['luogu']);
                $hasPending = !empty($pendingBinds);
            } else {
                $error = '未在洛谷个人签名中检测到验证码，请确认后重试';
                $conn->query("UPDATE user_bind SET check_count = check_count + 1, checked_at = NOW() WHERE uid = {$login_uid} AND bind_type = 'luogu' AND verified = 0");
                $refresh = $conn->query("SELECT * FROM user_bind WHERE uid = {$login_uid} AND bind_type = 'luogu' AND verified = 0 LIMIT 1")->fetch_assoc();
                if ($refresh) $pendingBinds['luogu'] = $refresh;
            }
        }
    }
}

function checkLuogu($luogu_uid, $verifyCode) {
    $url = "https://www.luogu.com.cn/user/{$luogu_uid}";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode !== 200 || empty($response)) {
        return false;
    }
    
    // 直接检查 HTML 源码中是否包含验证码
    return (strpos($response, $verifyCode) !== false);
}
function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>账号绑定 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;min-height:100vh;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;letter-spacing:0.4px;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);white-space:nowrap;font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main-layout{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;background:var(--card-bg);color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;white-space:nowrap;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .back-btn{display:inline-flex;align-items:center;gap:4px;margin-bottom:14px;padding:7px 14px;background:var(--card-bg);color:var(--text);text-decoration:none;border-radius:20px;font-size:13px;font-weight:500;border:1px solid var(--border);box-shadow:var(--shadow-sm);}
        .back-btn:hover{background:var(--accent-light);border-color:var(--accent);color:var(--accent);text-decoration:none;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow);margin-bottom:16px;}
        .card h2{font-size:17px;font-weight:600;margin-bottom:14px;color:var(--text);}
        .alert{padding:12px 14px;border-radius:var(--radius-sm);margin-bottom:14px;font-size:14px;line-height:1.6;word-break:break-word;}
        .alert-success{background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;}
        .alert-error{background:#fce4ec;color:#c62828;border:1px solid #ef9a9a;}
        .bind-card{background:var(--card-bg);border:2px solid var(--border);border-radius:var(--radius);padding:24px;text-align:center;transition:var(--transition);max-width:400px;}
        .bind-card.bound{border-color:#a5d6a7;background:#f9fdf9;}
        .bind-card.pending{border-color:#ffcc80;background:#fffdf5;}
        .bind-card .card-type{font-size:16px;font-weight:600;margin-bottom:8px;}
        .bind-card .card-value{font-size:13px;color:var(--text-muted);word-break:break-all;margin-bottom:8px;}
        .card-badge{display:inline-block;padding:4px 12px;border-radius:12px;font-size:12px;font-weight:600;}
        .badge-bound{background:#c8e6c9;color:#2e7d32;}
        .badge-pending{background:#fff3e0;color:#e65100;}
        .badge-unbound{background:#f5f5f5;color:#999;}
        .verify-code-display{display:inline-block;font-family:'Consolas',monospace;font-size:18px;color:var(--danger);font-weight:700;background:#fce4ec;padding:8px 14px;border-radius:6px;cursor:pointer;user-select:all;border:2px dashed #ef9a9a;margin:8px 0;word-break:break-all;}
        .form-group{margin-bottom:14px;}
        .form-group label{display:block;font-weight:500;font-size:13px;color:var(--text-secondary);margin-bottom:4px;}
        .form-group input{width:100%;padding:11px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:16px;outline:none;background:#fdfdfc;font-family:var(--font);-webkit-appearance:none;}
        .form-group input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        .btn{padding:10px 18px;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;display:inline-flex;align-items:center;gap:5px;text-decoration:none;font-family:var(--font);transition:var(--transition);}
        .btn:active{transform:scale(0.97);}
        .btn-primary{background:var(--accent);color:#fff;}
        .btn-primary:hover{background:var(--accent-hover);}
        .btn-danger{background:var(--danger);color:#fff;}
        .btn-danger:hover{background:var(--danger-hover);}
        .btn-check{background:#d4a24e;color:#fff;animation:pulse-btn 2s infinite;}
        @keyframes pulse-btn{0%,100%{box-shadow:0 0 0 0 rgba(212,162,78,0.4);}50%{box-shadow:0 0 0 10px rgba(212,162,78,0);}}
        .btn-sm{padding:6px 12px;font-size:12px;}
        .btn-block{width:100%;justify-content:center;}
        .btn-row{display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;}
        .pending-box{background:#fff8e1;border:1px solid #ffcc80;border-radius:var(--radius);padding:16px;margin-top:14px;}
        .pending-box h3{font-size:15px;font-weight:600;margin-bottom:10px;}
        .external-link{display:inline-flex;align-items:center;gap:4px;padding:8px 14px;background:#fff;border:1.5px solid var(--accent);color:var(--accent);border-radius:20px;text-decoration:none;font-size:14px;font-weight:500;margin-top:8px;}
        .external-link:hover{background:var(--accent-light);}
        .admin-table{width:100%;border-collapse:collapse;font-size:13px;}
        .admin-table th{text-align:left;padding:10px 8px;background:#fafaf8;font-size:11px;font-weight:600;color:var(--text-secondary);border-bottom:2px solid var(--border);}
        .admin-table td{padding:10px 8px;border-bottom:1px solid var(--border-light);}
        .admin-table tr.unbound-row{background:#fff8e1;font-weight:500;}
        .admin-table tr.unbound-row td:first-child{border-left:3px solid #ffcc80;}
        .admin-bar{display:flex;gap:8px;margin-bottom:16px;align-items:center;flex-wrap:wrap;}
        a{color:var(--accent);text-decoration:none;font-weight:500;transition:var(--transition);}
        a:hover{color:var(--accent-hover);text-decoration:underline;}
        @media(max-width:768px){
            .main-layout{flex-direction:column;padding:0 12px;margin:18px auto 30px;gap:14px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;border-radius:var(--radius);}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .card{padding:18px 14px;}
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main-layout">
	<?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <?php if ($sqadmin): ?>
        <div class="admin-bar">
            <a href="https://lmtoj.cn/bind" class="back-btn" style="<?=$adminView?'':'font-weight:700;background:var(--accent-light);'?>">我的绑定</a>
            <a href="https://lmtoj.cn/bind?admin_view=1" class="back-btn" style="<?=$adminView?'font-weight:700;background:var(--accent-light);':''?>">管理绑定列表</a>
        </div>
        <?php else: ?>
        <a href="https://lmtoj.cn/" class="back-btn">← 返回首页</a>
        <?php endif; ?>

        <?php if ($message): ?><div class="alert alert-success"><?=$message?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?=$error?></div><?php endif; ?>

        <?php if ($adminView): ?>
            <div class="card">
                <h2>所有用户绑定列表</h2>
                <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">排序：未绑定置顶，再按 UID 升序</p>
                <?php if (empty($allBinds)): ?>
                    <p style="color:var(--text-muted);text-align:center;padding:20px;">暂无绑定记录</p>
                <?php else: ?>
                    <div style="overflow-x:auto;">
                    <table class="admin-table">
                        <thead><tr><th>UID</th><th>用户</th><th>绑定值</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
                        <tbody>
                            <?php foreach ($allBinds as $b): ?>
                            <tr class="<?=$b['verified'] ? '' : 'unbound-row'?>">
                                <td><?=$b['uid']?></td>
                                <td><a href="https://lmtoj.cn/user/<?=$b['uid']?>"><?=safeContent($b['username'] ?? 'UID:'.$b['uid'])?></a></td>
                                <td><?=safeContent($b['bind_value'])?></td>
                                <td><span class="card-badge <?=$b['verified']?'badge-bound':'badge-pending'?>"><?=$b['verified']?'已验证':'待验证'?></span></td>
                                <td><?=date('m-d H:i', strtotime($b['created_at']))?></td>
                                <td>
                                    <?php if(!$b['verified']): ?>
                                        <a href="https://lmtoj.cn/bind?admin_view=1&verify_id=<?=$b['id']?>" class="btn btn-primary btn-sm">确认</a>
                                    <?php endif; ?>
                                    <a href="https://lmtoj.cn/bind?admin_view=1&del_bind_id=<?=$b['id']?>" onclick="return confirm('确定删除？')" class="btn btn-danger btn-sm">删除</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
        
        <div class="bind-card <?=$hasLuogu?'bound':(isset($pendingBinds['luogu'])?'pending':'')?>">
            <div class="card-type">洛谷绑定</div>
            <?php if ($hasLuogu): ?>
                <div class="card-value">UID: <?=safeContent($userBinds['luogu']['bind_value'])?></div>
                <span class="card-badge badge-bound">已绑定</span>
            <?php elseif (isset($pendingBinds['luogu'])): ?>
                <div class="card-value">验证中...</div>
                <span class="card-badge badge-pending">待验证</span>
            <?php else: ?>
                <div class="card-value">未绑定</div>
                <span class="card-badge badge-unbound">—</span>
                <button class="btn btn-primary btn-sm" onclick="showBindForm()" style="margin-top:8px;">绑定洛谷账号</button>
            <?php endif; ?>
        </div>

        <div class="card" id="luoguForm" style="display:none;">
            <h2>洛谷绑定</h2>
            <p style="font-size:13px;color:var(--text-muted);margin-bottom:12px;">输入洛谷 UID，在个人签名中写入验证码后检查<a href="https://www.luogu.com.cn">（点击跳转洛谷）</a></p>
            <form method="post">
                <input type="hidden" name="action" value="bind_luogu">
                <div class="form-group"><label>洛谷 UID</label><input type="number" name="luogu_uid" placeholder="例如：123456" required min="1" inputmode="numeric"></div>
                <button type="submit" class="btn btn-primary btn-block">生成验证码</button>
            </form>
        </div>

        <?php if (isset($pendingBinds['luogu'])): ?>
        <div class="pending-box">
            <h3>洛谷待验证</h3>
            <span class="verify-code-display" onclick="copyCode(this)" data-code="<?=safeContent($pendingBinds['luogu']['verify_code'])?>"><?=safeContent($pendingBinds['luogu']['verify_code'])?></span>
            <p style="font-size:12px;color:var(--text-muted);margin-top:4px;">点击复制验证码，粘贴到洛谷个人签名</p>
            <a href="https://www.luogu.com.cn/user/<?=safeContent($pendingBinds['luogu']['bind_value'])?>" target="_blank" class="external-link">打开洛谷主页</a>
            <div class="btn-row">
                <form method="post" style="flex:1;">
                    <input type="hidden" name="action" value="manual_check">
                    <input type="hidden" name="check_type" value="luogu">
                    <button type="submit" class="btn btn-check btn-block">检查验证</button>
                </form>
                <form method="post" style="flex:1;">
                    <input type="hidden" name="action" value="cancel_bind">
                    <input type="hidden" name="cancel_type" value="luogu">
                    <button type="submit" class="btn btn-danger btn-block">取消</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
        
        <?php endif; ?>
    </div>
</div>

<script>
function showBindForm() {
    var form = document.getElementById('luoguForm');
    form.style.display = 'block';
    form.scrollIntoView({behavior:'smooth'});
}

function copyCode(el) {
    var code = el.getAttribute('data-code');
    if (navigator.clipboard) {
        navigator.clipboard.writeText(code).then(function() {
            var orig = el.textContent;
            el.textContent = '已复制！';
            el.style.background = '#c8e6c9'; el.style.color = '#2e7d32';
            setTimeout(function() { el.textContent = orig; el.style.background = '#fce4ec'; el.style.color = '#d9534f'; }, 1500);
        });
    } else {
        var textarea = document.createElement('textarea');
        textarea.value = code; textarea.style.position = 'fixed'; textarea.style.opacity = '0';
        document.body.appendChild(textarea); textarea.select();
        try { document.execCommand('copy'); } catch(e) {}
        document.body.removeChild(textarea);
        var orig = el.textContent;
        el.textContent = '已复制！';
        el.style.background = '#c8e6c9';
        setTimeout(function() { el.textContent = orig; el.style.background = '#fce4ec'; }, 1500);
    }
}
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>