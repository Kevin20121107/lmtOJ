<?php
//$current_page = basename($_SERVER['SCRIPT_NAME']);
$current_page="";
?>
<!-- Font Awesome -->
<script>
if (!document.querySelector('link[href*="font-awesome"]')) {
    var fa = document.createElement('link');
    fa.rel = 'stylesheet';
    fa.href = 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css';
    document.head.appendChild(fa);
}
</script>

<style>
/* 代码块容器 */
.code-wrapper {
    position: relative;
    margin: 1em 0;
    background: #fff;
    border: 1px solid #e6e1da;
    border-radius: 6px;
    overflow: hidden;
}
.code-wrapper pre {
    margin: 0;
    padding: 1em;
    background: #fff;
    border-radius: 0 0 6px 6px;
    color: #24292f;
}
.code-wrapper pre code {
    background: none;
    padding: 0;
    font-size: 0.9em;
    color: inherit;
}
.copy-btn {
    position: absolute;
    top: 6px;
    right: 8px;
    background: rgba(255,255,255,0.9);
    border: 1px solid #ddd;
    border-radius: 4px;
    color: #555;
    font-size: 12px;
    cursor: pointer;
    padding: 2px 8px;
    display: flex;
    align-items: center;
    gap: 4px;
    transition: all 0.2s;
    z-index: 5;
}
.code-wrapper .copy-btn,
.sample-code-block .copy-btn {
    top: 6px;
    right: 8px;
}
.copy-btn:hover {
    background: #fff;
    border-color: #aaa;
    color: #333;
}
.copy-btn i {
    font-size: 13px;
}
.copy-btn.copied {
    background: #eef4ef;
    border-color: #6b8a74;
    color: #2c2a28;
}

/* 深色模式：代码块和小代码 */
body.dark-mode .code-wrapper,
body.dark-mode .code-wrapper pre {
    background: #000;
    border-color: #444;
    color: #e6edf3;
}
body.dark-mode .code-wrapper pre code {
    color: inherit;
}
body.dark-mode .code-wrapper .hljs-comment,
body.dark-mode .code-wrapper .hljs-quote {
    color: #8b949e;
}
body.dark-mode .code-wrapper .hljs-keyword,
body.dark-mode .code-wrapper .hljs-selector-tag,
body.dark-mode .code-wrapper .hljs-subst,
body.dark-mode .code-wrapper .hljs-section {
    color: #ff7b72;
}
body.dark-mode .code-wrapper .hljs-literal,
body.dark-mode .code-wrapper .hljs-number,
body.dark-mode .code-wrapper .hljs-variable,
body.dark-mode .code-wrapper .hljs-template-variable,
body.dark-mode .code-wrapper .hljs-tag .hljs-attr,
body.dark-mode .code-wrapper .hljs-attr {
    color: #79c0ff;
}
body.dark-mode .code-wrapper .hljs-string,
body.dark-mode .code-wrapper .hljs-doctag,
body.dark-mode .code-wrapper .hljs-meta .hljs-string {
    color: #a5d6ff;
}
body.dark-mode .code-wrapper .hljs-title,
body.dark-mode .code-wrapper .hljs-title.function_,
body.dark-mode .code-wrapper .hljs-selector-id,
body.dark-mode .code-wrapper .hljs-built_in {
    color: #d2a8ff;
}
body.dark-mode .code-wrapper .hljs-type,
body.dark-mode .code-wrapper .hljs-class .hljs-title {
    color: #ffa657;
}
body.dark-mode .copy-btn {
    background: rgba(0,0,0,0.5);
    color: #ccc;
    border-color: #555;
}
body.dark-mode .copy-btn:hover {
    background: rgba(0,0,0,0.7);
    color: #fff;
}
body.dark-mode .copy-btn.copied {
    background: #2e4a3a;
    border-color: #5a8f6a;
    color: #c0e0c0;
}

/* 内联代码 `x` 深色适配 */
body.dark-mode code {
    background: #1e1e1e;
    color: #e0e0e0;
    padding: 2px 6px;
    border-radius: 3px;
}
</style>

<div class="sidebar" id="mainSidebar">
    <a href="https://lmtoj.cn/" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">
        <i class="fa fa-home icon"></i><span class="label"> 首页</span>
    </a>
    <a href="https://lmtoj.cn/problem" class="<?= $current_page == 'problem.php' ? 'active' : '' ?>">
        <i class="fa fa-list-alt icon"></i><span class="label"> 题目</span>
    </a>
    <a href="https://lmtoj.cn/contest" class="<?= $current_page == 'contest.php' ? 'active' : '' ?>">
        <i class="fa fa-trophy icon"></i><span class="label"> 比赛</span>
    </a>
    <a href="https://lmtoj.cn/discuss/cate/01" class="<?= $current_page == 'discuss.php' ? 'active' : '' ?>">
        <i class="fa fa-comments icon"></i><span class="label"> 讨论</span>
    </a>
    <a href="https://lmtoj.cn/ticket" class="<?= $current_page == 'ticket.php' ? 'active' : '' ?>">
        <i class="fa fa-ticket icon"></i><span class="label"> 工单</span>
    </a>
    <a href="https://lmtoj.cn/article" class="<?= $current_page == 'article.php' ? 'active' : '' ?>">
        <i class="fa fa-file-text icon"></i><span class="label"> 文章</span>
    </a>
    <a href="https://lmtoj.cn/benben" class="<?= $current_page == 'benben.php' ? 'active' : '' ?>">
        <i class="fa fa-bullhorn icon"></i><span class="label"> 犇犇</span>
    </a>
    <a href="https://lmtoj.cn/record" class="<?= $current_page == 'record.php' ? 'active' : '' ?>">
        <i class="fa fa-history icon"></i><span class="label"> 记录</span>
    </a>
    <a href="https://lmtoj.cn/ide" class="<?= $current_page == 'ide.php' ? 'active' : '' ?>">
        <i class="fa fa-code icon"></i><span class="label"> IDE</span>
    </a>
    <a href="https://lmtoj.cn/written" class="<?= $current_page == 'written.php' ? 'active' : '' ?>">
        <i class="fa fa-pencil icon"></i><span class="label"> 笔试</span>
    </a>
    <a href="https://lmtoj.cn/team" class="<?= in_array($current_page, ['team.php', 'team_view.php']) ? 'active' : '' ?>">
        <i class="fa fa-users icon"></i><span class="label"> 团队</span>
    </a>
    <a href="https://lmtoj.cn/task" class="<?= $current_page == 'task.php' ? 'active' : '' ?>">
        <i class="fa fa-tasks icon"></i><span class="label"> 任务</span>
    </a>
    <!-- 新增排行榜 -->
    <a href="https://lmtoj.cn/ranking" class="<?= $current_page == 'ranking.php' ? 'active' : '' ?>">
        <i class="fa fa-bar-chart icon"></i><span class="label"> 排行榜</span>
    </a>
</div>

<script>
(function() {
    function enhanceCodeBlocks() {
        document.querySelectorAll('pre code').forEach(function(codeBlock) {
            if (codeBlock.closest('.code-wrapper, .sample-code-block')) return;

            const wrapper = document.createElement('div');
            wrapper.className = 'code-wrapper';

            const pre = codeBlock.parentNode;
            pre.parentNode.insertBefore(wrapper, pre);
            wrapper.appendChild(pre);

            const copyBtn = document.createElement('button');
            copyBtn.className = 'copy-btn';
            copyBtn.type = 'button';
            copyBtn.innerHTML = '<i class="fa fa-clipboard"></i> 复制';
            wrapper.appendChild(copyBtn);
        });
    }

    function copyText(text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
            return navigator.clipboard.writeText(text);
        }

        return new Promise(function(resolve, reject) {
            const textarea = document.createElement('textarea');
            textarea.value = text;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            const copied = document.execCommand('copy');
            textarea.remove();
            copied ? resolve() : reject(new Error('Copy failed'));
        });
    }

    document.addEventListener('click', function(event) {
        const copyBtn = event.target.closest('.code-wrapper .copy-btn, .sample-code-block .copy-btn');
        if (!copyBtn) return;

        const codeBlock = copyBtn.closest('.code-wrapper, .sample-code-block').querySelector('pre code');
        if (!codeBlock) return;

        const originalHtml = copyBtn.dataset.copyOriginal || copyBtn.innerHTML;
        copyBtn.dataset.copyOriginal = originalHtml;
        copyText(codeBlock.textContent || codeBlock.innerText).then(function() {
            copyBtn.innerHTML = '<i class="fa fa-check"></i> 已复制！';
            copyBtn.classList.add('copied');
            setTimeout(function() {
                copyBtn.innerHTML = originalHtml;
                copyBtn.classList.remove('copied');
            }, 2000);
        }).catch(function() {
            copyBtn.textContent = '复制失败';
            setTimeout(function() { copyBtn.innerHTML = originalHtml; }, 2000);
        });
    });

    if (document.readyState === 'complete' || document.readyState === 'interactive') {
        enhanceCodeBlocks();
    } else {
        document.addEventListener('DOMContentLoaded', enhanceCodeBlocks);
    }

    // 动态监听
    const observer = new MutationObserver(function(mutations) {
        let shouldEnhance = false;
        for (const mutation of mutations) {
            if (mutation.addedNodes.length) {
                shouldEnhance = true;
                break;
            }
        }
        if (shouldEnhance) {
            clearTimeout(window.codeEnhanceTimer);
            window.codeEnhanceTimer = setTimeout(function() {
                enhanceCodeBlocks();
            }, 200);
        }
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();
</script>