<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
$is_admin = ($adminRes && $adminRes->num_rows > 0) ? (int)$adminRes->fetch_assoc()['admin'] : 0;

// ========== 自动建表 / 更新字段 ==========
$tableCheck = $conn->query("SHOW TABLES LIKE 'written_questions'");
if ($tableCheck->num_rows == 0) {
    $conn->query("CREATE TABLE IF NOT EXISTS written_questions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        series ENUM('gesp','cspj','csps','user') NOT NULL,
        question TEXT NOT NULL,
        options TEXT NOT NULL,
        answer CHAR(1) NOT NULL,
        explanation TEXT,
        source_uid INT DEFAULT 0,
        year VARCHAR(10) DEFAULT '',
        question_type VARCHAR(50) DEFAULT '',
        sort_order INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} else {
    $fields = [
        'source_uid'   => 'INT DEFAULT 0',
        'year'         => 'VARCHAR(10) DEFAULT ""',
        'question_type'=> 'VARCHAR(50) DEFAULT ""',
        'sort_order'   => 'INT DEFAULT 0'
    ];
    foreach ($fields as $col => $def) {
        $check = $conn->query("SHOW COLUMNS FROM written_questions LIKE '$col'");
        if ($check->num_rows == 0) {
            $conn->query("ALTER TABLE written_questions ADD COLUMN $col $def");
        }
    }
}

$seriesMap = [
    'gesp'  => 'GESP',
    'cspj'  => 'CSP-J',
    'csps'  => 'CSP-S',
    'user'  => '用户精选集'
];

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 获取所有用户（用于来源选择下拉）
$allUsers = [];
$uRes = $conn->query("SELECT uid, name FROM users ORDER BY name ASC");
while ($u = $uRes->fetch_assoc()) $allUsers[] = $u;

$action = $_GET['action'] ?? 'list';

// ========== 管理员操作 ==========
if ($is_admin) {
    // 添加
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_question'])) {
        $series = $_POST['series'] ?? '';
        $question = trim($_POST['question']);
        $options = [];
        for ($i = 0; $i < 4; $i++) {
            $opt = trim($_POST["opt_{$i}"] ?? '');
            if ($opt !== '') $options[] = chr(65 + $i) . '. ' . $opt;
        }
        $options_json = json_encode($options, JSON_UNESCAPED_UNICODE);
        $answer = strtoupper(trim($_POST['answer'] ?? ''));
        $explanation = trim($_POST['explanation']);
        // 只有系列为 'user' 时才取 source_uid，否则强制为 0
        $source_uid = ($series === 'user') ? (int)($_POST['source_uid'] ?? 0) : 0;
        $year = trim($_POST['year'] ?? '');
        $qtype = trim($_POST['question_type'] ?? '');
        $sort = isset($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;
        if (in_array($series, array_keys($seriesMap)) && !empty($question) && count($options) == 4 && in_array($answer, ['A','B','C','D'])) {
            $stmt = $conn->prepare("INSERT INTO written_questions (series, question, options, answer, explanation, source_uid, year, question_type, sort_order) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->bind_param("sssssissi", $series, $question, $options_json, $answer, $explanation, $source_uid, $year, $qtype, $sort);
            $stmt->execute();
            $stmt->close();
            header("Location: https://lmtoj.cn/written?msg=added");
            exit;
        }
    }

    // 编辑
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_question'])) {
        $id = (int)$_POST['id'];
        $series = $_POST['series'] ?? '';
        $question = trim($_POST['question']);
        $options = [];
        for ($i = 0; $i < 4; $i++) {
            $opt = trim($_POST["opt_{$i}"] ?? '');
            if ($opt !== '') $options[] = chr(65 + $i) . '. ' . $opt;
        }
        $options_json = json_encode($options, JSON_UNESCAPED_UNICODE);
        $answer = strtoupper(trim($_POST['answer'] ?? ''));
        $explanation = trim($_POST['explanation']);
        $source_uid = ($series === 'user') ? (int)($_POST['source_uid'] ?? 0) : 0;
        $year = trim($_POST['year'] ?? '');
        $qtype = trim($_POST['question_type'] ?? '');
        $sort = isset($_POST['sort_order']) ? (int)$_POST['sort_order'] : 0;
        if (in_array($series, array_keys($seriesMap)) && !empty($question) && count($options) == 4 && in_array($answer, ['A','B','C','D'])) {
            $stmt = $conn->prepare("UPDATE written_questions SET series=?, question=?, options=?, answer=?, explanation=?, source_uid=?, year=?, question_type=?, sort_order=? WHERE id=?");
            $stmt->bind_param("sssssissii", $series, $question, $options_json, $answer, $explanation, $source_uid, $year, $qtype, $sort, $id);
            $stmt->execute();
            $stmt->close();
            header("Location: https://lmtoj.cn/written?msg=updated");
            exit;
        }
    }

    // 删除
    if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
        $id = (int)$_GET['delete'];
        $conn->query("DELETE FROM written_questions WHERE id = $id");
        header("Location: https://lmtoj.cn/written?msg=deleted");
        exit;
    }

    // 获取编辑数据
    $editData = null;
    if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
        $id = (int)$_GET['edit'];
        $res = $conn->query("SELECT * FROM written_questions WHERE id = $id");
        if ($res && $res->num_rows > 0) {
            $editData = $res->fetch_assoc();
            $editData['options'] = json_decode($editData['options'], true);
        }
    }
}

// ========== 随机测试（排除自己的题目） ==========
if ($action === 'test' && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['test_count'])) {
    $count = (int)$_POST['test_count'];
    if (!in_array($count, [10, 20, 50])) $count = 10;
    // 排除当前用户自己的题目（source_uid = login_uid），但保留系统题目（source_uid = 0）
    $sql = "SELECT id, question, options, answer, explanation 
            FROM written_questions 
            WHERE source_uid = 0 OR source_uid != $login_uid
            ORDER BY RAND() 
            LIMIT $count";
    $result = $conn->query($sql);
    $questions = [];
    while ($row = $result->fetch_assoc()) {
        $row['options'] = json_decode($row['options'], true);
        $questions[] = $row;
    }
    $_SESSION['test_questions'] = $questions;
    header("Location: https://lmtoj.cn/written?action=do_test");
    exit;
}

// ========== 提交测试 ==========
if ($action === 'submit_test' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $userAnswers = $_POST['answer'] ?? [];
    $questions = $_SESSION['test_questions'] ?? [];
    $correct = 0;
    $total = count($questions);
    $results = [];
    foreach ($questions as $q) {
        $id = $q['id'];
        $userAns = strtoupper(trim($userAnswers[$id] ?? ''));
        $correctAns = $q['answer'];
        $isCorrect = ($userAns === $correctAns);
        if ($isCorrect) $correct++;
        $results[] = [
            'question' => $q['question'],
            'options' => $q['options'],
            'user_answer' => $userAns ?: '未作答',
            'correct_answer' => $correctAns,
            'is_correct' => $isCorrect,
            'explanation' => $q['explanation'] ?? ''
        ];
    }
    $score = round(($correct / max($total, 1)) * 100, 0);
    $_SESSION['test_results'] = ['score' => $score, 'results' => $results, 'total' => $total, 'correct' => $correct];
    header("Location: https://lmtoj.cn/written?action=result");
    exit;
}

// ========== 列表数据 ==========
$series_filter = isset($_GET['series']) && in_array($_GET['series'], array_keys($seriesMap)) ? $_GET['series'] : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 15;
$offset = ($page - 1) * $limit;

$where = "WHERE 1=1";
$params = [];
$types = "";
if ($series_filter) {
    $where .= " AND series = ?";
    $params[] = $series_filter;
    $types .= "s";
}

$countSql = "SELECT COUNT(*) AS total FROM written_questions $where";
$stmt = $conn->prepare($countSql);
if (!empty($params)) $stmt->bind_param($types, ...$params);
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['total'];
$totalPage = ceil($total / $limit);

$sql = "SELECT w.*, u.name as source_name 
        FROM written_questions w 
        LEFT JOIN users u ON w.source_uid = u.uid 
        $where 
        ORDER BY w.sort_order ASC, w.id DESC 
        LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$params[] = $limit;
$params[] = $offset;
$types .= "ii";
$stmt->bind_param($types, ...$params);
$stmt->execute();
$questionList = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
foreach ($questionList as &$q) {
    $q['options'] = json_decode($q['options'], true);
    $q['source_name'] = $q['source_name'] ?? '系统';
    // 虽然不再显示摘要，但保留以便可能使用
    $plain = strip_tags(str_replace(['**', '__', '`', '*', '_'], '', $q['question']));
    $q['summary'] = mb_strlen($plain) > 80 ? mb_substr($plain, 0, 80) . '...' : $plain;
}

$msg = $_GET['msg'] ?? '';
$message = '';
if ($msg === 'added') $message = '题目添加成功！';
elseif ($msg === 'updated') $message = '题目更新成功！';
elseif ($msg === 'deleted') $message = '题目已删除。';

$testResults = $_SESSION['test_results'] ?? null;
$testQuestions = $_SESSION['test_questions'] ?? [];

function seriesName($key) { global $seriesMap; return $seriesMap[$key] ?? $key; }
function safe($str) { return htmlspecialchars($str, ENT_QUOTES, 'UTF-8'); }
function beijingTime($utc) { return empty($utc) ? '' : date('Y-m-d H:i:s', strtotime($utc)); }
$current_page = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>笔试题库 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js"></script>
    <style>
        :root { --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6; --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e; --border: #e6e1da; --border-light: #f0ece6; --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef; --danger: #d9534f; --danger-hover: #c0392b; --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease; --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif; }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1200px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .sidebar a.active{background:var(--accent-light);border-left-color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2,.card h3{font-size:18px;font-weight:600;margin-bottom:16px;}
        .filter-bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:16px;}
        .filter-bar a{display:inline-block;padding:5px 16px;background:#f5f2ed;border-radius:20px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:500;transition:var(--transition);}
        .filter-bar a.active{background:var(--accent);color:#fff;}
        .filter-bar a:hover{background:var(--accent-hover);color:#fff;}
        .btn{padding:8px 18px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);display:inline-block;text-decoration:none;}
        .btn:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);}
        .btn-danger{background:var(--danger);}
        .btn-danger:hover{background:var(--danger-hover);}
        .btn-sm{padding:4px 10px;font-size:12px;}
        .btn-outline{background:transparent;border:1.5px solid var(--border);color:var(--text);}
        .btn-outline:hover{background:var(--border-light);}
        .page-bar{display:flex;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap;}
        .page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;background:#fff;transition:var(--transition);}
        .page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
        .page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);}
        .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
        .question-item{border-bottom:1px solid var(--border-light);padding:16px 0;}
        .question-item:last-child{border-bottom:none;}
        .question-meta{font-size:13px;color:var(--text-muted);margin-bottom:8px;}
        .question-meta .series-tag{display:inline-block;padding:2px 10px;border-radius:12px;background:var(--accent-light);color:var(--accent);font-weight:600;}
        .question-meta .source-tag{display:inline-block;padding:2px 10px;border-radius:12px;background:#f0e6d3;color:#8b6b4d;font-weight:600;margin-left:6px;}
        .question-meta .year-tag{display:inline-block;padding:2px 8px;border-radius:12px;background:#e3f0e8;color:#2d6a4f;font-weight:600;margin-left:6px;}
        .question-meta .type-tag{display:inline-block;padding:2px 8px;border-radius:12px;background:#e8e0f0;color:#5b3d8a;font-weight:600;margin-left:6px;}
        /* 不再使用 .question-summary */
        .question-actions{display:flex;gap:6px;margin-top:8px;}
        .md-content{line-height:1.7;}
        .md-content p{margin:6px 0;}
        .md-content blockquote{border-left:4px solid var(--accent);padding:6px 14px;margin:8px 0;background:#fafaf8;border-radius:0 4px 4px 0;}
        .md-content pre{background:#2b2a27;color:#e8e4dd;padding:10px 14px;border-radius:var(--radius-sm);overflow-x:auto;}
        .md-content code{background:#f3f0eb;padding:2px 6px;border-radius:3px;}
        .md-content pre code{background:transparent;padding:0;color:inherit;}
        .test-option{display:block;padding:8px 12px;margin:4px 0;background:#fafaf8;border-radius:var(--radius-sm);cursor:pointer;transition:var(--transition);border:1.5px solid transparent;}
        .test-option:hover{background:#f0ece6;border-color:var(--border);}
        .test-option input[type="radio"]{margin-right:10px;transform:scale(1.1);}
        .result-correct{color:#28a745;font-weight:600;}
        .result-wrong{color:#dc3545;font-weight:600;}
        .result-score{font-size:28px;font-weight:700;color:var(--accent);}
        .admin-form input,.admin-form textarea,.admin-form select{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;margin-bottom:14px;background:#fdfdfc;font-family:var(--font);transition:var(--transition);}
        .admin-form input:focus,.admin-form textarea:focus,.admin-form select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        .admin-form textarea{min-height:80px;resize:vertical;}
        .admin-form .opt-row{display:flex;gap:10px;align-items:center;margin-bottom:8px;}
        .admin-form .opt-row label{width:30px;font-weight:600;color:var(--text-secondary);}
        .admin-form .opt-row input{flex:1;margin-bottom:0;}
        .admin-form .form-row{display:flex;gap:14px;flex-wrap:wrap;}
        .admin-form .form-row > div{flex:1;min-width:150px;}
        .admin-form .btn-group{display:flex;gap:10px;margin-top:6px;}
        .admin-form .source-area{display:block;}
        .admin-form .source-area.hidden{display:none;}
        .msg-box{background:#e8f5e9;border:1px solid #c8e6c9;color:#2e7d32;padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:16px;}
        .detail-link{color:var(--accent);font-weight:500;text-decoration:none;}
        .detail-link:hover{text-decoration:underline;}
        input[list]::-webkit-calendar-picker-indicator { opacity: 0.5; }
        @media(max-width:768px){.main{flex-direction:column;padding:0 12px;}.sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}.sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}.sidebar a.active{border-left:none;border-bottom-color:var(--accent);}.card{padding:18px 14px;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <?php if ($message): ?><div class="msg-box"><?= $message ?></div><?php endif; ?>

        <?php if ($action === 'result' && $testResults): ?>
            <!-- 测试结果 -->
            <div class="card">
                <h2>测试结果</h2>
                <div style="text-align:center;padding:20px 0;">
                    <div class="result-score"><?= $testResults['score'] ?>%</div>
                    <p>正确：<?= $testResults['correct'] ?> / <?= $testResults['total'] ?></p>
                </div>
                <hr>
                <?php foreach ($testResults['results'] as $index => $r): ?>
                    <div style="padding:14px 0;border-bottom:1px solid var(--border-light);">
                        <div style="font-weight:600;">第 <?= $index+1 ?> 题</div>
                        <div class="md-content" data-md="<?= safe($r['question']) ?>"></div>
                        <div style="font-size:14px;color:var(--text-secondary);">
                            <?php foreach ($r['options'] as $opt): ?><div><?= safe($opt) ?></div><?php endforeach; ?>
                        </div>
                        <div>你的答案：<strong><?= safe($r['user_answer']) ?></strong>
                            <?php if ($r['is_correct']): ?><span class="result-correct">正确</span>
                            <?php else: ?><span class="result-wrong">错误</span>
                            <span style="margin-left:10px;">正确答案：<strong><?= $r['correct_answer'] ?></strong></span><?php endif; ?>
                        </div>
                        <?php if (!empty($r['explanation'])): ?>
                            <div style="margin-top:6px;padding:8px 12px;background:#f8f9fa;border-radius:var(--radius-sm);">
                                <strong>解析：</strong><div class="md-content" data-md="<?= safe($r['explanation']) ?>"></div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
                <div style="margin-top:16px;">
                    <a href="https://lmtoj.cn/written" class="btn">返回题库</a>
                    <a href="https://lmtoj.cn/written?action=test" class="btn btn-outline">再次测试</a>
                </div>
            </div>
            <?php unset($_SESSION['test_results']); ?>

        <?php elseif ($action === 'do_test' && !empty($testQuestions)): ?>
            <!-- 答题 -->
            <div class="card">
                <h2>📝 随机测试（<?= count($testQuestions) ?> 题）</h2>
                <form method="post" action="https://lmtoj.cn/written?action=submit_test">
                    <?php foreach ($testQuestions as $index => $q): ?>
                        <div style="padding:16px 0;border-bottom:1px solid var(--border-light);">
                            <div style="font-weight:600;">第 <?= $index+1 ?> 题</div>
                            <div class="md-content" data-md="<?= safe($q['question']) ?>"></div>
                            <div style="margin-top:8px;">
                                <?php foreach ($q['options'] as $opt): ?>
                                    <label class="test-option">
                                        <input type="radio" name="answer[<?= $q['id'] ?>]" value="<?= substr($opt,0,1) ?>" required>
                                        <?= safe($opt) ?>
                                    </label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div style="margin-top:16px;display:flex;gap:10px;">
                        <button type="submit" class="btn">提交答案</button>
                        <a href="https://lmtoj.cn/written" class="btn btn-outline">取消</a>
                    </div>
                </form>
            </div>

        <?php elseif ($action === 'test'): ?>
            <!-- 测试设置 -->
            <div class="card">
                <h2>随机测试</h2>
                <p style="color:var(--text-secondary);margin-bottom:16px;">从所有题库中随机抽取指定数量的题目（不重复）。</p>
                <form method="post" action="https://lmtoj.cn/written?action=test">
                    <div style="display:flex;gap:16px;flex-wrap:wrap;">
                        <label style="font-weight:500;"><input type="radio" name="test_count" value="10" checked> 10 题</label>
                        <label style="font-weight:500;"><input type="radio" name="test_count" value="20"> 20 题</label>
                        <label style="font-weight:500;"><input type="radio" name="test_count" value="50"> 50 题</label>
                    </div>
                    <div style="margin-top:16px;">
                        <button type="submit" class="btn">开始测试</button>
                        <a href="https://lmtoj.cn/written" class="btn btn-outline">返回题库</a>
                    </div>
                </form>
                <div style="margin-top:16px;font-size:13px;color:var(--text-muted);">
                    题库中共有 <?= $total ?> 道题目（系统题目+他人贡献），若题数不足则按实际数量出题。
                </div>
            </div>

        <?php else: ?>
            <!-- ====== 列表页 ====== -->
            <div class="card">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:16px;">
                    <h2 style="margin:0;">笔试题库</h2>
                    <div style="display:flex;gap:8px;">
                        <a href="https://lmtoj.cn/written?action=test" class="btn">随机测试</a>
                        <?php if ($is_admin): ?>
                            <a href="https://lmtoj.cn/written?action=add" class="btn">+ 添加题目</a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="filter-bar">
                    <a href="https://lmtoj.cn/written" class="<?= $series_filter==''?'active':'' ?>">全部</a>
                    <?php foreach ($seriesMap as $key => $name): ?>
                        <a href="https://lmtoj.cn/written?series=<?= $key ?>" class="<?= $series_filter==$key?'active':'' ?>"><?= $name ?></a>
                    <?php endforeach; ?>
                </div>

                <?php if (empty($questionList)): ?>
                    <p style="color:var(--text-muted);">暂无题目，<?php if ($is_admin) echo '点击 "添加题目" 创建第一道题。'; else echo '请等待管理员添加。'; ?></p>
                <?php else: ?>
                    <?php foreach ($questionList as $q): ?>
                        <div class="question-item">
                            <div class="question-meta">
                                <span class="series-tag"><?= seriesName($q['series']) ?></span>
                                <?php if (!empty($q['year'])): ?>
                                    <span class="year-tag"><?= safe($q['year']) ?></span>
                                <?php endif; ?>
                                <?php if (!empty($q['question_type'])): ?>
                                    <span class="type-tag"><?= safe($q['question_type']) ?></span>
                                <?php endif; ?>
                                <span class="source-tag"><?= safe($q['source_name']) ?></span>
                                <span style="margin-left:10px;font-size:12px;color:var(--text-muted);">编号: <?= $q['sort_order'] ?></span>
                            </div>
                            <!-- 显示题型作为标题（不显示题目内容） -->
                            <div style="font-size:16px;font-weight:600;color:var(--text);margin:6px 0;">
                                <?= !empty($q['question_type']) ? safe($q['question_type']) : '未分类' ?>
                            </div>
                            <div style="margin-top:6px;">
                                <a href="https://lmtoj.cn/written/<?= $q['id'] ?>" class="detail-link">📖 查看详情 →</a>
                            </div>
                            <?php if ($is_admin): ?>
                                <div class="question-actions">
                                    <a href="https://lmtoj.cn/written?action=edit&edit=<?= $q['id'] ?>" class="btn btn-sm btn-outline">编辑</a>
                                    <a href="https://lmtoj.cn/written?delete=<?= $q['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除此题？')">删除</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>

                    <?php if ($totalPage > 1): ?>
                        <div class="page-bar">
                            <?php if ($page > 1): ?><a href="?<?= $series_filter?'series='.$series_filter.'&':'' ?>page=<?= $page-1 ?>">上一页</a><?php endif; ?>
                            <?php
                            $shown = [1];
                            for ($i = max(2, $page-2); $i <= min($totalPage-1, $page+2); $i++) $shown[] = $i;
                            if ($totalPage > 1) $shown[] = $totalPage;
                            $shown = array_unique($shown); sort($shown); $prev = 0;
                            foreach ($shown as $i):
                                if ($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
                            ?>
                                <a href="?<?= $series_filter?'series='.$series_filter.'&':'' ?>page=<?= $i ?>" class="<?= $i==$page?'active':'' ?>"><?= $i ?></a>
                            <?php $prev = $i; endforeach; ?>
                            <?php if ($page < $totalPage): ?><a href="?<?= $series_filter?'series='.$series_filter.'&':'' ?>page=<?= $page+1 ?>">下一页</a><?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- 管理员表单 -->
            <?php if ($is_admin && ($action === 'add' || $action === 'edit')): ?>
                <div class="card">
                    <h2><?= $action === 'add' ? '添加题目' : '编辑题目' ?></h2>
                    <form method="post" class="admin-form">
                        <?php if ($action === 'edit'): ?>
                            <input type="hidden" name="id" value="<?= $editData['id'] ?? 0 ?>">
                            <input type="hidden" name="edit_question" value="1">
                        <?php else: ?>
                            <input type="hidden" name="add_question" value="1">
                        <?php endif; ?>
                        <div class="form-row">
                            <div><label>系列</label>
                                <select name="series" id="seriesSelect" required>
                                    <?php foreach ($seriesMap as $k => $n): ?>
                                        <option value="<?= $k ?>" <?= isset($editData) && $editData['series']==$k ? 'selected' : '' ?>><?= $n ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div><label>正确答案</label>
                                <select name="answer" required>
                                    <option value="A" <?= isset($editData) && $editData['answer']=='A' ? 'selected' : '' ?>>A</option>
                                    <option value="B" <?= isset($editData) && $editData['answer']=='B' ? 'selected' : '' ?>>B</option>
                                    <option value="C" <?= isset($editData) && $editData['answer']=='C' ? 'selected' : '' ?>>C</option>
                                    <option value="D" <?= isset($editData) && $editData['answer']=='D' ? 'selected' : '' ?>>D</option>
                                </select>
                            </div>
                            <div id="sourceUserArea" class="source-area <?= (isset($editData) && $editData['series'] === 'user') ? '' : 'hidden' ?>">
                                <label>来源用户（仅用户精选集）</label>
                                <input list="userList" name="source_uid" value="<?= isset($editData) ? (int)$editData['source_uid'] : 0 ?>">
                                <datalist id="userList">
                                    <option value="0">系统</option>
                                    <?php foreach ($allUsers as $u): ?>
                                        <option value="<?= $u['uid'] ?>"><?= safe($u['name']) ?></option>
                                    <?php endforeach; ?>
                                </datalist>
                                <div style="font-size:12px;color:var(--text-muted);margin-top:2px;">输入数字或用户名搜索</div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div><label>年份（如 2024）</label>
                                <input type="text" name="year" placeholder="2024" value="<?= isset($editData) ? safe($editData['year']) : '' ?>">
                            </div>
                            <div><label>题型（手填）</label>
                                <input type="text" name="question_type" placeholder="选择题/填空题/..." value="<?= isset($editData) ? safe($editData['question_type']) : '' ?>">
                            </div>
                            <div><label>排序序号（数字越小越靠前）</label>
                                <input type="number" name="sort_order" value="<?= isset($editData) ? (int)$editData['sort_order'] : 0 ?>" step="1">
                            </div>
                        </div>
                        <div><label>题目内容（Markdown / LaTeX）</label>
                            <textarea name="question" rows="3" required><?= isset($editData) ? safe($editData['question']) : '' ?></textarea>
                        </div>
                        <div><label>选项</label>
                            <?php for ($i = 0; $i < 4; $i++): $l = chr(65+$i); ?>
                                <div class="opt-row">
                                    <label><?= $l ?>.</label>
                                    <input type="text" name="opt_<?= $i ?>" placeholder="选项 <?= $l ?>" value="<?= isset($editData) && isset($editData['options'][$i]) ? safe(substr($editData['options'][$i], 3)) : '' ?>" required>
                                </div>
                            <?php endfor; ?>
                        </div>
                        <div><label>解析（选填）</label>
                            <textarea name="explanation" rows="3"><?= isset($editData) ? safe($editData['explanation']) : '' ?></textarea>
                        </div>
                        <div class="btn-group">
                            <button type="submit" class="btn"><?= $action==='add' ? '添加题目' : '保存修改' ?></button>
                            <a href="https://lmtoj.cn/written" class="btn btn-outline">取消</a>
                        </div>
                    </form>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<script>
const md = window.markdownit({html:false,linkify:true,typographer:true,breaks:true});
function renderAllMarkdown() {
    document.querySelectorAll('.md-content[data-md]').forEach(el => {
        const raw = el.dataset.md;
        if (raw) {
            let html = md.render(raw);
            html = html.replace(/\$\$([\s\S]*?)\$\$/g, (m, math) => {
                try { return '<div style="text-align:center;">' + katex.renderToString(math, {displayMode:true,throwOnError:false}) + '</div>'; } catch(e) { return m; }
            });
            html = html.replace(/\$([^$]+?)\$/g, (m, math) => {
                try { return katex.renderToString(math, {throwOnError:false}); } catch(e) { return m; }
            });
            el.innerHTML = html;
        }
    });
}
document.addEventListener('DOMContentLoaded', renderAllMarkdown);

// 控制来源用户区域显示
document.addEventListener('DOMContentLoaded', function() {
    const seriesSelect = document.getElementById('seriesSelect');
    const sourceArea = document.getElementById('sourceUserArea');
    if (!seriesSelect || !sourceArea) return;
    function toggleSource() {
        if (seriesSelect.value === 'user') {
            sourceArea.classList.remove('hidden');
        } else {
            sourceArea.classList.add('hidden');
        }
    }
    seriesSelect.addEventListener('change', toggleSource);
    toggleSource();
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>