<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

if (file_exists('visit_log.php')) require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 建表（含 skills 字段） ----------
$conn->query("CREATE TABLE IF NOT EXISTS uno_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(16) NOT NULL UNIQUE,
    host_uid INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'waiting',
    max_players INT DEFAULT 6,
    game_state LONGTEXT,
    version INT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS uno_room_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    is_ready TINYINT DEFAULT 0,
    skills VARCHAR(255) DEFAULT '[]',   -- 新增：存储玩家选择的技能ID列表 JSON
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_room_user (room_id, uid),
    INDEX (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS uno_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    msg VARCHAR(500) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (room_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, avatar FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$login_name = $userRow['name'] ?? '玩家';
$login_avatar = $userRow['avatar'] ?? '/upload/default.png';

// ---------- 技能池 ----------
function getSkillPool() {
    return [
        ['id' => 'qiangchu', 'name' => '抢出', 'desc' => '非自己回合，上家出牌后，你可打出一张同颜色或同数字/类型的牌（须与上家牌匹配）']
    ];
}

// ---------- 核心游戏函数 ----------
function generateDeck() {
    $colors = ['red', 'blue', 'green', 'yellow'];
    $deck = [];
    foreach ($colors as $color) {
        for ($num = 0; $num <= 9; $num++) {
            $count = ($num === 0) ? 1 : 2;
            for ($i = 0; $i < $count; $i++) {
                $deck[] = ['cid' => uniqid('c_'), 'color' => $color, 'type' => 'number', 'value' => $num];
            }
        }
    }
    $funcs = ['skip', 'reverse', 'draw2'];
    foreach ($colors as $color) {
        foreach ($funcs as $func) {
            for ($i = 0; $i < 2; $i++) {
                $deck[] = ['cid' => uniqid('c_'), 'color' => $color, 'type' => $func, 'value' => null];
            }
        }
    }
    for ($i = 0; $i < 4; $i++) {
        $deck[] = ['cid' => uniqid('c_'), 'color' => 'wild', 'type' => 'wild', 'value' => null];
        $deck[] = ['cid' => uniqid('c_'), 'color' => 'wild', 'type' => 'wild_draw4', 'value' => null];
    }
    $specials = ['draw6', 'draw10', 'swap_hands', 'skip_all'];
    foreach ($colors as $color) {
        foreach ($specials as $spec) {
            $deck[] = ['cid' => uniqid('c_'), 'color' => $color, 'type' => $spec, 'value' => null];
        }
    }
    shuffle($deck);
    return $deck;
}

function drawCards(&$state, $count) {
    $cards = [];
    for ($i = 0; $i < $count; $i++) {
        if (empty($state['deck'])) {
            if (!empty($state['discard'])) {
                $state['deck'] = $state['discard'];
                shuffle($state['deck']);
                $state['discard'] = [];
            } else break;
        }
        if (!empty($state['deck'])) {
            $cards[] = array_pop($state['deck']);
        }
    }
    return $cards;
}

function addLog(&$state, $msg) {
    if (!isset($state['logs'])) $state['logs'] = [];
    $time = date('H:i:s');
    $state['logs'][] = "[$time] " . $msg;
    if (count($state['logs']) > 70) array_shift($state['logs']);
}

function getPlayerIndex($state, $uid) {
    foreach ($state['players'] as $idx => $p) {
        if ((int)$p['uid'] === (int)$uid) return $idx;
    }
    return -1;
}

function getNextPlayerIndex($state, $fromIdx) {
    $n = count($state['players']);
    $dir = $state['direction'];
    $idx = ($fromIdx + $dir + $n) % $n;
    $tries = 0;
    while ($state['players'][$idx]['is_out'] && $tries < $n) {
        $idx = ($idx + $dir + $n) % $n;
        $tries++;
    }
    return $idx;
}

function canPlayCard($card, $topCard, $currentColor) {
    if ($card['type'] === 'wild' || $card['type'] === 'wild_draw4') return true;
    if ($card['color'] === $currentColor) return true;
    if ($topCard['type'] === 'number' && $card['type'] === 'number' && $card['value'] === $topCard['value']) return true;
    if ($topCard['type'] !== 'number' && $card['type'] === $topCard['type']) return true;
    return false;
}

function getDrawValue($card) {
    $map = ['draw2'=>2, 'draw4'=>4, 'draw6'=>6, 'draw10'=>10];
    return $map[$card['type']] ?? 0;
}

function handleDrawStack(&$state, $fromIdx, $stackCount) {
    $state['draw_stack'] = $stackCount;
    $nextIdx = getNextPlayerIndex($state, $fromIdx);
    $state['pending_action'] = [
        'type' => 'respond_draw',
        'player_idx' => $nextIdx,
        'draw_count' => $stackCount
    ];
    addLog($state, "【绝不留情】罚牌累计 {$stackCount} 张，等待 <strong>{$state['players'][$nextIdx]['name']}</strong> 响应");
}

function resolveDrawResponse(&$state, $responderIdx, $playCard = null) {
    $pending = $state['pending_action'];
    if ($pending['type'] !== 'respond_draw' || $pending['player_idx'] != $responderIdx) return false;
    
    if ($playCard !== null) {
        $drawVal = getDrawValue($playCard);
        if ($drawVal <= 0) return false;
        $state['draw_stack'] += $drawVal;
        $state['discard'][] = $playCard;
        $hand = &$state['players'][$responderIdx]['hand'];
        foreach ($hand as $k => $c) {
            if ($c['cid'] === $playCard['cid']) { array_splice($hand, $k, 1); break; }
        }
        addLog($state, "<strong>{$state['players'][$responderIdx]['name']}</strong> 出了【{$playCard['type']}】，罚牌累计至 {$state['draw_stack']} 张");
        $nextIdx = getNextPlayerIndex($state, $responderIdx);
        $state['pending_action']['player_idx'] = $nextIdx;
        $state['pending_action']['draw_count'] = $state['draw_stack'];
        addLog($state, "请 <strong>{$state['players'][$nextIdx]['name']}</strong> 继续响应");
        $state['players'][$responderIdx]['last_action_time'] = time();
        return true;
    } else {
        $draw = $pending['draw_count'];
        $drawn = drawCards($state, $draw);
        $state['players'][$responderIdx]['hand'] = array_merge($state['players'][$responderIdx]['hand'], $drawn);
        addLog($state, "<strong>{$state['players'][$responderIdx]['name']}</strong> 放弃了，抽了 {$draw} 张牌");
        $state['draw_stack'] = 0;
        $state['pending_action'] = null;
        $state['current_player'] = getNextPlayerIndex($state, $responderIdx);
        $state['players'][$responderIdx]['last_action_time'] = time();
        checkWin($state);
        return true;
    }
}

function checkWin(&$state) {
    foreach ($state['players'] as $idx => $p) {
        if (!$p['is_out'] && count($p['hand']) >= 25) {
            $state['players'][$idx]['is_out'] = true;
            addLog($state, "<strong>{$p['name']}</strong> 手牌达到25张，被淘汰！");
        }
    }
    $alive = array_filter($state['players'], function($p) { return !$p['is_out']; });
    if (count($alive) === 1) {
        $winner = reset($alive);
        $state['status'] = 'finished';
        addLog($state, "<strong style='color:gold;'>{$winner['name']} 获胜！</strong>");
        return true;
    } elseif (count($alive) === 0) {
        $state['status'] = 'finished';
        addLog($state, "<strong style='color:gold;'>所有玩家出局，平局！</strong>");
        return true;
    }
    return false;
}

function startGame($roomId, $players) {
    $deck = generateDeck();
    $skillPool = getSkillPool();
    $state = [
        'status' => 'playing',
        'deck' => $deck,
        'discard' => [],
        'players' => [],
        'current_player' => 0,
        'direction' => 1,
        'current_color' => null,
        'draw_stack' => 0,
        'pending_action' => null,
        'logs' => [],
        'room_id' => $roomId,
        'used_qiangchu' => []  // 记录每回合是否用过抢出
    ];
    foreach ($players as $p) {
        $hand = drawCards($state, 7);
        // 根据玩家选择的技能ID列表，赋予技能
        $selectedSkills = [];
        foreach ($p['skills'] as $skillId) {
            foreach ($skillPool as $skill) {
                if ($skill['id'] === $skillId) {
                    $selectedSkills[] = $skill;
                    break;
                }
            }
        }
        $state['players'][] = [
            'uid' => (int)$p['uid'],
            'name' => $p['name'],
            'avatar' => $p['avatar'] ?: '',
            'hand' => $hand,
            'is_out' => false,
            'called_uno' => false,
            'last_action_time' => time(),
            'skills' => $selectedSkills
        ];
    }
    do {
        $first = array_pop($state['deck']);
    } while (in_array($first['type'], ['wild', 'wild_draw4', 'draw6', 'draw10', 'swap_hands', 'skip_all']));
    $state['discard'][] = $first;
    $state['current_color'] = $first['color'];
    addLog($state, "游戏开始！首牌为 [{$first['color']} {$first['type']}]");
    if ($first['type'] === 'skip') {
        $state['current_player'] = getNextPlayerIndex($state, 0);
        addLog($state, "首牌为 Skip，跳过第一位玩家");
    } elseif ($first['type'] === 'reverse') {
        $state['direction'] = -1;
        addLog($state, "首牌为 Reverse，方向反转");
    } elseif ($first['type'] === 'draw2') {
        handleDrawStack($state, 0, 2);
    }
    return $state;
}

function processPlayCard(&$state, $playerIdx, $card, $chosenColor = null) {
    if ($state['status'] !== 'playing') return false;
    if ($state['pending_action'] !== null) return false;
    if ($state['current_player'] != $playerIdx) return false;
    
    $p = &$state['players'][$playerIdx];
    $top = end($state['discard']);
    $currentColor = $state['current_color'];
    
    if (!canPlayCard($card, $top, $currentColor)) return false;
    
    foreach ($p['hand'] as $k => $c) {
        if ($c['cid'] === $card['cid']) { array_splice($p['hand'], $k, 1); break; }
    }
    $state['discard'][] = $card;
    if ($card['type'] === 'wild' || $card['type'] === 'wild_draw4') {
        $state['current_color'] = $chosenColor ?? 'red';
    } else {
        $state['current_color'] = $card['color'];
    }
    
    // 重置抢出记录
    $state['used_qiangchu'] = [];
    
    addLog($state, "<strong>{$p['name']}</strong> 出了 [{$card['color']} {$card['type']}]" . ($card['type']==='number'?" {$card['value']}":''));
    $p['last_action_time'] = time();
    
    if (count($p['hand']) === 1 && !$p['called_uno']) {
        $penalty = drawCards($state, 2);
        $p['hand'] = array_merge($p['hand'], $penalty);
        addLog($state, "<strong>{$p['name']}</strong> 未喊 UNO，被罚抽 2 张！");
        $p['called_uno'] = false;
    }
    
    if (empty($p['hand'])) {
        $state['status'] = 'finished';
        addLog($state, "<strong style='color:gold;'>{$p['name']} 获胜！</strong>");
        return true;
    }
    
    $type = $card['type'];
    $nextIdx = getNextPlayerIndex($state, $playerIdx);
    switch ($type) {
        case 'skip':
            $state['current_player'] = getNextPlayerIndex($state, $nextIdx);
            addLog($state, "Skip 生效，跳过 <strong>{$state['players'][$nextIdx]['name']}</strong>");
            break;
        case 'reverse':
            $state['direction'] *= -1;
            $state['current_player'] = getNextPlayerIndex($state, $playerIdx);
            addLog($state, "Reverse 生效，方向反转");
            break;
        case 'draw2':
        case 'draw4':
        case 'draw6':
        case 'draw10':
            handleDrawStack($state, $playerIdx, getDrawValue($card));
            break;
        case 'skip_all':
            $state['current_player'] = $playerIdx;
            addLog($state, "Skip All 生效，跳过所有其他玩家，回到自己");
            break;
        case 'swap_hands':
            // 由前端传目标，在API中处理
            break;
        default:
            $state['current_player'] = $nextIdx;
    }
    return true;
}

// ---------- API 处理 ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['api_action'])) {
    header('Content-Type: application/json');
    $api = $_POST['api_action'];
    
    if ($api === 'get_rooms') {
        $res = $conn->query("SELECT r.*, u.name as host_name, COUNT(p.id) as current_players 
            FROM uno_rooms r 
            LEFT JOIN users u ON r.host_uid = u.uid 
            LEFT JOIN uno_room_players p ON r.id = p.room_id 
            GROUP BY r.id ORDER BY r.id DESC LIMIT 20");
        $rooms = [];
        while ($r = $res->fetch_assoc()) $rooms[] = $r;
        echo json_encode(['success' => true, 'rooms' => $rooms]);
        exit;
    }
    
    if ($api === 'create_room') {
        $title = trim($_POST['title'] ?? '') ?: ($login_name . '的UNO绝不留情');
        $max_p = max(2, min(6, (int)($_POST['max_players'] ?? 6)));
        $code = substr(md5(uniqid(mt_rand(), true)), 0, 8);
        $stmt = $conn->prepare("INSERT INTO uno_rooms (room_code, host_uid, title, max_players, status, version) VALUES (?, ?, ?, ?, 'waiting', 1)");
        $stmt->bind_param("sisi", $code, $login_uid, $title, $max_p);
        $stmt->execute();
        $roomId = $stmt->insert_id;
        $stmt->close();
        $conn->query("INSERT INTO uno_room_players (room_id, uid, is_ready) VALUES ($roomId, $login_uid, 1)");
        echo json_encode(['success' => true, 'room_id' => $roomId]);
        exit;
    }
    
    if ($api === 'join_room') {
        $roomId = (int)$_POST['room_id'];
        $chk = $conn->query("SELECT * FROM uno_rooms WHERE id = $roomId AND status = 'waiting' LIMIT 1")->fetch_assoc();
        if (!$chk) { echo json_encode(['success'=>false,'msg'=>'房间已开始或不存在']); exit; }
        $cnt = $conn->query("SELECT COUNT(*) as c FROM uno_room_players WHERE room_id = $roomId")->fetch_assoc()['c'];
        if ($cnt >= $chk['max_players']) { echo json_encode(['success'=>false,'msg'=>'房间已满员']); exit; }
        $conn->query("INSERT IGNORE INTO uno_room_players (room_id, uid, is_ready) VALUES ($roomId, $login_uid, 0)");
        $conn->query("UPDATE uno_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'leave_room') {
        $roomId = (int)$_POST['room_id'];
        $conn->query("DELETE FROM uno_room_players WHERE room_id = $roomId AND uid = $login_uid");
        $cnt = $conn->query("SELECT COUNT(*) as c FROM uno_room_players WHERE room_id = $roomId")->fetch_assoc()['c'];
        if ($cnt == 0) {
            $conn->query("DELETE FROM uno_rooms WHERE id = $roomId");
        } else {
            $newHost = $conn->query("SELECT uid FROM uno_room_players WHERE room_id = $roomId ORDER BY id ASC LIMIT 1")->fetch_assoc()['uid'];
            $conn->query("UPDATE uno_rooms SET host_uid = $newHost, version = version + 1 WHERE id = $roomId");
        }
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'kick_player') {
        $roomId = (int)$_POST['room_id'];
        $targetUid = (int)$_POST['target_uid'];
        $room = $conn->query("SELECT * FROM uno_rooms WHERE id = $roomId AND status = 'waiting' LIMIT 1")->fetch_assoc();
        if (!$room || (int)$room['host_uid'] !== $login_uid) {
            echo json_encode(['success' => false, 'msg' => '无权操作或房间状态已变更']);
            exit;
        }
        if ($targetUid === $login_uid) {
            echo json_encode(['success' => false, 'msg' => '不能踢出自己']);
            exit;
        }
        $conn->query("DELETE FROM uno_room_players WHERE room_id = $roomId AND uid = $targetUid");
        $conn->query("UPDATE uno_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'update_prep') {
        $roomId = (int)$_POST['room_id'];
        $ready = (int)($_POST['is_ready'] ?? 0);
        $conn->query("UPDATE uno_room_players SET is_ready = $ready WHERE room_id = $roomId AND uid = $login_uid");
        $conn->query("UPDATE uno_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    // ===== 新增：更新玩家技能选择 =====
    if ($api === 'update_skills') {
        $roomId = (int)$_POST['room_id'];
        $skillsJson = $_POST['skills'] ?? '[]';
        $skills = json_decode($skillsJson, true);
        if (!is_array($skills)) $skills = [];
        // 只允许 'qiangchu'（未来可扩展）
        $validSkills = array_filter($skills, function($id) {
            return in_array($id, ['qiangchu']);
        });
        $skillsStr = $conn->real_escape_string(json_encode(array_values($validSkills)));
        $conn->query("UPDATE uno_room_players SET skills = '$skillsStr' WHERE room_id = $roomId AND uid = $login_uid");
        $conn->query("UPDATE uno_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'start_game') {
        $roomId = (int)$_POST['room_id'];
        $room = $conn->query("SELECT * FROM uno_rooms WHERE id = $roomId LIMIT 1")->fetch_assoc();
        if ($room['host_uid'] != $login_uid) { echo json_encode(['success'=>false,'msg'=>'只有房主可开启']); exit; }
        $playersRes = $conn->query("SELECT p.*, u.name, u.avatar FROM uno_room_players p LEFT JOIN users u ON p.uid = u.uid WHERE p.room_id = $roomId");
        $players = [];
        $unready = false;
        while ($p = $playersRes->fetch_assoc()) {
            if ($p['uid'] != $login_uid && !$p['is_ready']) {
                $unready = true;
                break;
            }
            // 解析技能
            $skills = json_decode($p['skills'] ?? '[]', true);
            if (!is_array($skills)) $skills = [];
            $players[] = [
                'uid' => (int)$p['uid'],
                'name' => $p['name'],
                'avatar' => $p['avatar'] ?: '',
                'skills' => $skills
            ];
        }
        if (count($players) < 2) { echo json_encode(['success'=>false,'msg'=>'至少2人']); exit; }
        if ($unready) { echo json_encode(['success'=>false,'msg'=>'尚有玩家未准备']); exit; }
        
        $gameState = startGame($roomId, $players);
        $stateJson = $conn->real_escape_string(json_encode($gameState, JSON_UNESCAPED_UNICODE));
        $conn->query("UPDATE uno_rooms SET status = 'playing', game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'poll_state') {
        $roomId = (int)$_POST['room_id'];
        $clientVer = (int)($_POST['version'] ?? 0);
        $room = $conn->query("SELECT * FROM uno_rooms WHERE id = $roomId LIMIT 1")->fetch_assoc();
        if (!$room) { echo json_encode(['success'=>false,'msg'=>'房间不存在']); exit; }
        $state = json_decode($room['game_state'] ?? '{}', true);
        $stateUpdated = false;
        
        // 超时检测
        if ($room['status'] === 'playing' && !empty($state['players'])) {
            $now = time();
            $currentIdx = $state['current_player'];
            if (isset($state['players'][$currentIdx]) && !$state['players'][$currentIdx]['is_out']) {
                $last = $state['players'][$currentIdx]['last_action_time'] ?? $now;
                if ($now - $last > 60) {
                    $state['players'][$currentIdx]['is_out'] = true;
                    addLog($state, "<strong>{$state['players'][$currentIdx]['name']}</strong> 超时未响应(60秒)，自动判负！");
                    $state['pending_action'] = null;
                    $state['draw_stack'] = 0;
                    $state['current_player'] = getNextPlayerIndex($state, $currentIdx);
                    checkWin($state);
                    $stateUpdated = true;
                }
            }
        }
        
        if ($room['status'] === 'playing') {
            if (checkWin($state)) $stateUpdated = true;
        }
        
        if ($clientVer === (int)$room['version'] && !$stateUpdated) {
            echo json_encode(['success'=>true,'changed'=>false,'version'=>$clientVer]);
            exit;
        }
        
        $playersRes = $conn->query("SELECT p.*, u.name, u.avatar FROM uno_room_players p LEFT JOIN users u ON p.uid = u.uid WHERE p.room_id = $roomId");
        $roomPlayers = [];
        $isPlayer = false;
        while ($p = $playersRes->fetch_assoc()) {
            if ($p['uid'] == $login_uid) $isPlayer = true;
            // 解析技能
            $p['skills'] = json_decode($p['skills'] ?? '[]', true);
            $roomPlayers[] = $p;
        }
        
        if (!empty($state['players'])) {
            foreach ($state['players'] as &$p) {
                if ($p['uid'] != $login_uid) {
                    $p['hand_count'] = count($p['hand']);
                    $p['hand'] = [];
                } else {
                    $p['hand_count'] = count($p['hand']);
                }
            }
            unset($p);
        }
        
        $chatRes = $conn->query("SELECT uid, name, msg, created_at FROM uno_chat WHERE room_id = $roomId ORDER BY id DESC LIMIT 20");
        $chatMsgs = [];
        while ($row = $chatRes->fetch_assoc()) {
            $chatMsgs[] = [
                'uid' => (int)$row['uid'],
                'name' => htmlspecialchars($row['name']),
                'msg' => htmlspecialchars($row['msg']),
                'time' => date('H:i:s', strtotime($row['created_at']))
            ];
        }
        $chatMsgs = array_reverse($chatMsgs);
        
        if ($stateUpdated) {
            $roomStatus = $state['status'] ?? 'playing';
            $stateJson = $conn->real_escape_string(json_encode($state, JSON_UNESCAPED_UNICODE));
            $conn->query("UPDATE uno_rooms SET status = '$roomStatus', game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
            $room['version']++;
        }
        
        echo json_encode([
            'success' => true,
            'changed' => true,
            'version' => (int)$room['version'],
            'room' => $room,
            'room_players' => $roomPlayers,
            'game_state' => $state,
            'my_uid' => $login_uid,
            'is_spectator' => !$isPlayer,
            'chat_messages' => $chatMsgs
        ]);
        exit;
    }
    
    if ($api === 'game_action') {
        $roomId = (int)$_POST['room_id'];
        $action = $_POST['action_type'];
        $room = $conn->query("SELECT * FROM uno_rooms WHERE id = $roomId AND status = 'playing' LIMIT 1")->fetch_assoc();
        if (!$room) { echo json_encode(['success'=>false,'msg'=>'对局未在进行']); exit; }
        $state = json_decode($room['game_state'], true);
        $myIdx = getPlayerIndex($state, $login_uid);
        if ($myIdx === -1) { echo json_encode(['success'=>false,'msg'=>'你不在游戏中']); exit; }
        
        if ($action === 'declare_uno') {
            $state['players'][$myIdx]['called_uno'] = true;
            $state['players'][$myIdx]['last_action_time'] = time();
            addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 喊了 UNO！");
        } elseif ($action === 'report_uno') {
            $targetUid = (int)($_POST['target_uid'] ?? 0);
            $targetIdx = getPlayerIndex($state, $targetUid);
            if ($targetIdx === -1 || $state['players'][$targetIdx]['is_out']) {
                echo json_encode(['success'=>false,'msg'=>'无效目标']); exit;
            }
            $target = &$state['players'][$targetIdx];
            if (count($target['hand']) !== 1 || $target['called_uno']) {
                echo json_encode(['success'=>false,'msg'=>'该玩家已喊 UNO 或手牌不是 1 张']); exit;
            }
            $penalty = drawCards($state, 2);
            $target['hand'] = array_merge($target['hand'], $penalty);
            $target['called_uno'] = true;
            addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 举报 <strong>{$target['name']}</strong> 忘记喊 UNO，罚抽 2 张！");
            $state['players'][$myIdx]['last_action_time'] = time();
        } elseif ($action === 'play_card') {
            $cardIdx = (int)($_POST['card_index'] ?? -1);
            $chosenColor = $_POST['color'] ?? null;
            if ($cardIdx < 0 || !isset($state['players'][$myIdx]['hand'][$cardIdx])) {
                echo json_encode(['success'=>false,'msg'=>'无效手牌']); exit;
            }
            $card = $state['players'][$myIdx]['hand'][$cardIdx];
            $result = processPlayCard($state, $myIdx, $card, $chosenColor);
            if (!$result) { echo json_encode(['success'=>false,'msg'=>'该牌不可出']); exit; }
        } elseif ($action === 'draw_card') {
            $pending = $state['pending_action'];
            if ($pending && $pending['type'] === 'respond_draw' && $pending['player_idx'] == $myIdx) {
                resolveDrawResponse($state, $myIdx, null);
            } else {
                if ($state['current_player'] != $myIdx) { echo json_encode(['success'=>false,'msg'=>'未轮到你']); exit; }
                if ($state['pending_action'] !== null) { echo json_encode(['success'=>false,'msg'=>'请先响应罚牌']); exit; }
                $drawn = drawCards($state, 1);
                $state['players'][$myIdx]['hand'] = array_merge($state['players'][$myIdx]['hand'], $drawn);
                $state['players'][$myIdx]['last_action_time'] = time();
                addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 抽了一张牌");
                if (count($state['players'][$myIdx]['hand']) >= 25) {
                    $state['players'][$myIdx]['is_out'] = true;
                    addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 手牌达到25张，被淘汰！");
                    checkWin($state);
                }
                $state['current_player'] = getNextPlayerIndex($state, $myIdx);
            }
        } elseif ($action === 'respond_draw_play') {
            $pending = $state['pending_action'];
            if (!$pending || $pending['type'] !== 'respond_draw' || $pending['player_idx'] != $myIdx) {
                echo json_encode(['success'=>false,'msg'=>'当前不需要响应']); exit;
            }
            $cardIdx = (int)($_POST['card_index'] ?? -1);
            if ($cardIdx < 0 || !isset($state['players'][$myIdx]['hand'][$cardIdx])) {
                echo json_encode(['success'=>false,'msg'=>'无效手牌']); exit;
            }
            $card = $state['players'][$myIdx]['hand'][$cardIdx];
            $drawVal = getDrawValue($card);
            if ($drawVal <= 0) { echo json_encode(['success'=>false,'msg'=>'请出罚牌（+2/+4/+6/+10）']); exit; }
            resolveDrawResponse($state, $myIdx, $card);
        } elseif ($action === 'surrender') {
            $state['players'][$myIdx]['is_out'] = true;
            $state['players'][$myIdx]['last_action_time'] = time();
            addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 认输了");
            checkWin($state);
        } elseif ($action === 'swap_hands_target') {
            $targetUid = (int)($_POST['target_uid'] ?? 0);
            $targetIdx = getPlayerIndex($state, $targetUid);
            if ($targetIdx === -1 || $targetIdx == $myIdx) { echo json_encode(['success'=>false,'msg'=>'无效目标']); exit; }
            $myHand = $state['players'][$myIdx]['hand'];
            $state['players'][$myIdx]['hand'] = $state['players'][$targetIdx]['hand'];
            $state['players'][$targetIdx]['hand'] = $myHand;
            $state['players'][$myIdx]['last_action_time'] = time();
            addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 与 <strong>{$state['players'][$targetIdx]['name']}</strong> 交换了手牌");
            $state['current_player'] = getNextPlayerIndex($state, $myIdx);
        } elseif ($action === 'qiangchu_play') {
            if ($state['current_player'] == $myIdx) {
                echo json_encode(['success'=>false,'msg'=>'当前是你的回合，不能抢出']); exit;
            }
            $mySkills = $state['players'][$myIdx]['skills'] ?? [];
            $hasQiangchu = false;
            foreach ($mySkills as $s) {
                if ($s['id'] === 'qiangchu') { $hasQiangchu = true; break; }
            }
            if (!$hasQiangchu) {
                echo json_encode(['success'=>false,'msg'=>'你没有【抢出】技能']); exit;
            }
            if (isset($state['used_qiangchu'][$login_uid]) && $state['used_qiangchu'][$login_uid]) {
                echo json_encode(['success'=>false,'msg'=>'本回合已用过抢出']); exit;
            }
            $cardIdx = (int)($_POST['card_index'] ?? -1);
            if ($cardIdx < 0 || !isset($state['players'][$myIdx]['hand'][$cardIdx])) {
                echo json_encode(['success'=>false,'msg'=>'无效手牌']); exit;
            }
            $card = $state['players'][$myIdx]['hand'][$cardIdx];
            $top = end($state['discard']);
            $currentColor = $state['current_color'];
            if (!canPlayCard($card, $top, $currentColor)) {
                echo json_encode(['success'=>false,'msg'=>'该牌与上家牌不匹配']); exit;
            }
            foreach ($state['players'][$myIdx]['hand'] as $k => $c) {
                if ($c['cid'] === $card['cid']) { array_splice($state['players'][$myIdx]['hand'], $k, 1); break; }
            }
            $state['discard'][] = $card;
            if ($card['type'] === 'wild' || $card['type'] === 'wild_draw4') {
                $state['current_color'] = $_POST['color'] ?? 'red';
            } else {
                $state['current_color'] = $card['color'];
            }
            $state['used_qiangchu'][$login_uid] = true;
            $state['players'][$myIdx]['last_action_time'] = time();
            addLog($state, "<strong>{$state['players'][$myIdx]['name']}</strong> 使用【抢出】打出 [{$card['color']} {$card['type']}]");
            $state['current_player'] = $myIdx;
            if (empty($state['players'][$myIdx]['hand'])) {
                $state['status'] = 'finished';
                addLog($state, "<strong style='color:gold;'>{$state['players'][$myIdx]['name']} 获胜！</strong>");
            }
        }
        
        if ($state['status'] !== 'finished') {
            checkWin($state);
        }
        $stateJson = $conn->real_escape_string(json_encode($state, JSON_UNESCAPED_UNICODE));
        $conn->query("UPDATE uno_rooms SET game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'send_chat') {
        $roomId = (int)$_POST['room_id'];
        $msg = trim($_POST['msg'] ?? '');
        if (mb_strlen($msg) === 0 || mb_strlen($msg) > 500) { echo json_encode(['success'=>false,'msg'=>'消息长度错误']); exit; }
        $stmt = $conn->prepare("INSERT INTO uno_chat (room_id, uid, name, msg) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $roomId, $login_uid, $login_name, $msg);
        $stmt->execute();
        $stmt->close();
        $conn->query("UPDATE uno_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>UNO 绝不留情</title>
<style>
:root {
    --bg: #f9f7f4;
    --card-bg: #ffffff;
    --nav-bg: #3d3a37;
    --nav-text: #f0ece6;
    --text: #2c2a28;
    --text-secondary: #7a736b;
    --text-muted: #a0988e;
    --border: #e6e1da;
    --border-light: #f0ece6;
    --accent: #6b8a74;
    --accent-hover: #55735e;
    --accent-light: #eef4ef;
    --danger: #d9534f;
    --danger-hover: #c0392b;
    --gold: #b8860b;
    --shadow: 0 2px 10px rgba(0,0,0,0.05);
    --radius: 10px;
    --radius-sm: 6px;
    --transition: 0.18s ease;
    --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
    --font-mono: 'JetBrains Mono', 'Cascadia Code', 'Consolas', 'SF Mono', monospace;
}

* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }

.navbar {
    background:var(--nav-bg); height:54px; display:flex; align-items:center;
    justify-content:space-between; padding:0 28px; color:var(--nav-text);
    position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
}
.navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
.navbar h1 a { color:#f0ece6; text-decoration:none; }
.user-info { display:flex; align-items:center; gap:6px; }
.user-info a {
    color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
    border-radius:20px; transition:var(--transition); font-weight:500;
}
.user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }

.main { max-width:1320px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
.sidebar {
    background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
    width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0;
}
.sidebar a {
    display:block; padding:13px 22px; text-align:center; background:var(--card-bg);
    color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500;
    transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px;
}
.sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
.sidebar a.active { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }

.content { flex:1; min-width:0; }

.card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 26px 28px;
    margin-bottom: 18px;
    box-shadow: var(--shadow);
    overflow: hidden;
}
.card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }

.btn {
    padding:9px 20px; background:var(--accent); color:#fff; border:none;
    border-radius:20px; cursor:pointer; font-size:14px; font-weight:500;
    transition:var(--transition);
}
.btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
.btn:disabled { background:#bfbab0; cursor:not-allowed; }
.btn-gold { background:var(--gold); color:#fff; }
.btn-gold:hover { background:#a67a0a; }
.btn-danger { background:var(--danger); color:#fff; }
.btn-danger:hover { background:var(--danger-hover); }
.btn-info { background:#2980b9; color:#fff; }
.btn-info:hover { background:#1f6a93; }

.room-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:14px; }
.room-item {
    background:var(--bg);
    padding:14px;
    border-radius:8px;
    border:1px solid var(--border);
}
.room-item h4 { color:var(--text); margin-bottom:6px; }

/* ===== UNO 特有样式 ===== */
.uno-arena {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 16px;
    border: 1px solid var(--border);
}
.opponents-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:10px; margin-bottom:12px; }
.player-panel {
    background: var(--bg);
    border: 2px solid var(--border);
    border-radius:8px;
    padding:8px;
    display:flex;
    gap:10px;
    align-items:center;
}
.player-panel.active-turn { border-color:var(--gold); box-shadow:0 0 12px rgba(184,134,11,0.3); }
.player-panel.dead { opacity:0.3; filter:grayscale(1); }
.avatar-box { width:50px; height:70px; border-radius:6px; border:1.5px solid var(--border); overflow:hidden; background:#f0f0f0; flex-shrink:0; }
.avatar-box img { width:100%; height:100%; object-fit:cover; }

.handcards-bar { display:flex; gap:8px; overflow-x:auto; padding:6px 2px; min-height:95px; align-items:flex-end; flex-wrap:wrap; }
.uno-card {
    width:70px; height:90px; background:#fdfbf7; border-radius:6px;
    border:1.5px solid #bda885; padding:4px; cursor:pointer;
    transition:0.15s; flex-shrink:0; font-weight:bold; font-size:13px;
    display:flex; flex-direction:column; justify-content:space-between;
    color: #fff;
    text-shadow: 0 1px 2px rgba(0,0,0,0.5);
}
.uno-card:hover { transform:translateY(-10px); border-color:var(--gold); }
.uno-card.selected { transform:translateY(-14px); border-color:#2ecc71; box-shadow:0 0 10px #2ecc71; }
.uno-card.red { background:#dc3545; border-color:#b02a37; }
.uno-card.blue { background:#007bff; border-color:#0056b3; }
.uno-card.green { background:#28a745; border-color:#1e7e34; }
.uno-card.yellow { background:#ffc107; border-color:#d39e00; color:#000; text-shadow:none; }
.uno-card.wild { background:linear-gradient(135deg,#dc3545,#007bff,#28a745,#ffc107); border-color:#6c757d; }
.uno-card .card-color-label { font-size:10px; opacity:0.8; text-align:right; }

.logs-box {
    background: var(--bg);
    border-radius:6px;
    padding:8px;
    font-size:12px;
    height:140px;
    overflow-y:auto;
    color:var(--text);
    border:1px solid var(--border);
}
.logs-box p { margin:2px 0; }

.prompt-banner {
    background: var(--accent-light);
    border: 1.5px solid var(--accent);
    border-radius:6px;
    padding:8px 12px;
    margin-bottom:8px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    color:var(--text);
    flex-wrap:wrap;
}

.chat-panel {
    background: var(--bg);
    border-radius:8px;
    padding:8px;
    border:1px solid var(--border);
    margin-top:10px;
}
.chat-messages { height:120px; overflow-y:auto; font-size:13px; color:var(--text); padding:4px; }
.chat-messages div { padding:2px 0; border-bottom:1px solid var(--border-light); }
.chat-input-row { display:flex; gap:6px; margin-top:6px; }
.chat-input-row input {
    flex:1; background:var(--card-bg); border:1px solid var(--border);
    color:var(--text); padding:6px; border-radius:4px;
}
.chat-input-row input:focus { border-color:var(--accent); }

.color-picker-overlay {
    position:fixed; top:0; left:0; width:100%; height:100%;
    background:rgba(0,0,0,0.7); display:flex; justify-content:center;
    align-items:center; z-index:999;
}
.color-picker-box {
    background:var(--card-bg); padding:20px; border-radius:12px;
    border:2px solid var(--gold); text-align:center; min-width:280px;
}
.color-picker-box .color-btn {
    width:60px; height:60px; border-radius:50%; border:3px solid #fff;
    margin:8px; cursor:pointer; display:inline-block; transition:0.2s;
    color:#fff; font-weight:bold; line-height:60px;
}
.color-picker-box .color-btn:hover { transform:scale(1.1); }
.color-picker-box .color-btn.red { background:#dc3545; }
.color-picker-box .color-btn.blue { background:#007bff; }
.color-picker-box .color-btn.green { background:#28a745; }
.color-picker-box .color-btn.yellow { background:#ffc107; color:#000; }

.target-picker-overlay {
    position:fixed; top:0; left:0; width:100%; height:100%;
    background:rgba(0,0,0,0.7); display:flex; justify-content:center;
    align-items:center; z-index:999;
}
.target-picker-box {
    background:var(--card-bg); padding:20px; border-radius:12px;
    border:2px solid var(--gold); text-align:center; max-width:400px;
}
.target-picker-box .target-item {
    display:block; width:100%; padding:10px; margin:6px 0;
    background:var(--bg); border:1px solid var(--border);
    border-radius:6px; color:var(--text); cursor:pointer;
}
.target-picker-box .target-item:hover { background:var(--accent-light); }

/* ===== 新增技能卡片样式（三国杀风格） ===== */
.skill-select-wrap {
    margin: 16px 0;
    padding: 12px;
    background: var(--bg);
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
}
.skill-select-wrap .skill-title {
    font-weight: 600;
    font-size: 15px;
    margin-bottom: 8px;
    color: var(--text-secondary);
}
.skill-cards {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
}
.skill-card {
    width: 180px;
    background: var(--card-bg);
    border: 2px solid var(--border);
    border-radius: var(--radius);
    padding: 14px 12px;
    cursor: pointer;
    transition: 0.2s;
    box-shadow: var(--shadow);
    text-align: center;
    position: relative;
}
.skill-card:hover { transform: translateY(-4px); border-color: var(--accent); }
.skill-card.selected {
    border-color: var(--gold);
    background: var(--accent-light);
    box-shadow: 0 0 0 2px var(--gold);
}
.skill-card .skill-name {
    font-weight: 700;
    font-size: 18px;
    color: var(--text);
    margin-bottom: 4px;
}
.skill-card .skill-type {
    font-size: 12px;
    color: var(--text-muted);
    background: #eee;
    display: inline-block;
    padding: 0 10px;
    border-radius: 10px;
}
.skill-card .skill-desc {
    font-size: 13px;
    color: var(--text-secondary);
    margin: 8px 0;
    line-height: 1.4;
}
.skill-card .skill-badge {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    background: #eee;
    color: #666;
    font-size: 13px;
    font-weight: 600;
    transition: 0.2s;
}
.skill-card.selected .skill-badge {
    background: var(--accent);
    color: #fff;
}
.skill-card .skill-icon {
    font-size: 32px;
    margin-bottom: 4px;
}

@media (max-width:768px) {
    .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
    .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
    .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
    .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
    .navbar { padding:0 14px; height:48px; }
    .card { padding:18px 14px; }
    .skill-card { width: 100%; max-width: 280px; margin: 0 auto; }
}
</style>
</head>
<body>
<?php if (file_exists('navbar.php')) include 'navbar.php'; else { ?>
<div class="navbar">
    <h1><a href="/uno">UNO 绝不留情</a></h1>
    <div class="user-info"><span><?= htmlspecialchars($login_name) ?></span><a href="/">返回首页</a></div>
</div>
<?php } ?>
<div class="main">
    <div class="sidebar">
        <a href="/">主页</a>
        <a href="/uno" class="active">UNO</a>
    </div>
    <div class="content">
        <!-- 大厅 -->
        <div class="card" id="view-lobby">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2>🏠 大厅</h2>
                <button class="btn btn-gold" onclick="openCreateModal()">+ 创建房间</button>
            </div>
            <div class="room-grid" id="rooms-container"></div>
        </div>
        <!-- 准备 -->
        <div class="card" id="view-room" style="display:none;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2 id="room-title-text">房间准备中</h2>
                <div>
                    <button class="btn btn-danger" onclick="leaveRoom()">退出</button>
                    <button class="btn btn-gold" id="btn-start-game" style="display:none;" onclick="startGame()">开始游戏</button>
                </div>
            </div>
            <div id="spectator-join-box" style="display:none; margin-top:12px;">
                <button class="btn btn-info" onclick="joinFromSpectate()">加入此房间</button>
            </div>
            
            <!-- ===== 技能选择卡片（取代原来的 skill-select-wrap） ===== -->
            <div class="skill-select-wrap" id="skill-select-wrap">
                <div class="skill-title">⚔️ 选择你的技能（点击卡片切换选择）</div>
                <div class="skill-cards">
                    <!-- 抢出技能卡片 -->
                    <div class="skill-card" data-skill="qiangchu" onclick="toggleSkill('qiangchu')">
                        <div class="skill-icon">🏹</div>
                        <div class="skill-name">抢出</div>
                        <div class="skill-type">锁定技</div>
                        <div class="skill-desc">非自己回合，上家出牌后，你可打出一张同颜色或同数字/类型的牌（须与上家牌匹配）</div>
                        <div class="skill-badge" id="skill-badge-qiangchu">未选择</div>
                    </div>
                    <!-- 未来可扩展更多技能 -->
                </div>
                <div style="margin-top:8px; font-size:12px; color:var(--text-muted);">
                    💡 选择后自动保存，可随时切换
                </div>
            </div>

            <div style="margin-top:16px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span><strong>准备状态</strong></span>
                    <button class="btn" id="btn-ready-toggle" onclick="toggleReady()">准备</button>
                </div>
                <div id="room-players-list" style="display:flex; flex-wrap:wrap; gap:12px; margin-top:12px;"></div>
            </div>
            <div class="chat-panel" style="margin-top:20px;">
                <div class="chat-messages" id="chat-messages-prep"></div>
                <div class="chat-input-row">
                    <input type="text" id="chat-input-prep" placeholder="聊天...">
                    <button class="btn" onclick="sendChat('chat-input-prep')">发送</button>
                </div>
            </div>
        </div>
        <!-- 游戏 -->
        <div class="uno-arena" id="view-game" style="display:none;">
            <div id="spectator-indicator" style="background:#eef4ef;color:var(--text);padding:6px 14px;border-radius:6px;margin-bottom:10px;display:none;text-align:center;">您正在观战</div>
            <div class="opponents-row" id="opponents-container"></div>
            <div id="action-prompt-area"></div>
            <div style="display:grid; grid-template-columns:1fr 280px; gap:12px;">
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <span id="game-status-tip" style="color:var(--gold);font-weight:bold;">等待回合...</span>
                        <span style="font-size:12px;color:var(--text-muted);">牌堆: <span id="deck-count">0</span>张</span>
                    </div>
                    <div class="logs-box" id="battle-logs"></div>
                </div>
                <div style="background:var(--bg);border-radius:6px;padding:10px;border:1px solid var(--border);">
                    <div><strong>当前颜色</strong> <span id="current-color-display" style="display:inline-block;width:24px;height:24px;border-radius:50%;vertical-align:middle;background:#888;"></span></div>
                    <div style="margin-top:4px;font-size:13px;color:var(--text-muted);">罚牌累计: <span id="draw-stack-display">0</span></div>
                    <div id="top-card-display" style="margin-top:6px;background:var(--card-bg);padding:4px;border-radius:4px;text-align:center;font-size:14px;border:1px solid var(--border);"></div>
                </div>
            </div>
            <div style="background:var(--card-bg);border-radius:8px;padding:12px;margin-top:12px;border:1px solid var(--border);">
                <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin-bottom:6px;">
                    <button class="btn btn-gold" id="btn-play" onclick="onPlayCard()">出牌</button>
                    <button class="btn" id="btn-draw" onclick="onDrawCard()">抽牌</button>
                    <button class="btn btn-info" id="btn-uno" onclick="declareUno()">UNO!</button>
                    <button class="btn btn-danger" id="btn-report-uno" onclick="reportUno()" style="display:none;">举报 UNO</button>
                    <button class="btn btn-gold" id="btn-qiangchu" onclick="onQiangchu()" style="display:none;">抢出</button>
                    <button class="btn btn-danger" onclick="surrenderGame()">认输</button>
                    <span id="my-hand-count" style="color:var(--text-muted);font-size:13px;">手牌: 0</span>
                </div>
                <div class="handcards-bar" id="my-handcards"></div>
            </div>
            <div class="chat-panel">
                <div class="chat-messages" id="chat-messages"></div>
                <div class="chat-input-row">
                    <input type="text" id="chat-input" placeholder="聊天...">
                    <button class="btn" onclick="sendChat('chat-input')">发送</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (file_exists('footer.php')) include 'footer.php'; ?>
<script>
// ---------- 全局变量 ----------
let currentRoomId = null, currentVersion = 0, pollTimer = null;
let selectedCardIdx = null;
let isReady = 0, isSpectator = false;
let myUid = <?= $login_uid ?>;
let _gameState = null;
let _pendingColorCallback = null;
let _pendingTargetCallback = null;
let mySkills = []; // 当前玩家选择的技能ID列表

// ---------- 技能选择相关 ----------
function toggleSkill(skillId) {
    const idx = mySkills.indexOf(skillId);
    if (idx >= 0) {
        mySkills.splice(idx, 1);
    } else {
        mySkills.push(skillId);
    }
    // 更新卡片样式
    document.querySelectorAll('.skill-card').forEach(card => {
        const id = card.dataset.skill;
        const selected = mySkills.includes(id);
        card.classList.toggle('selected', selected);
        const badge = card.querySelector('.skill-badge');
        if (badge) badge.textContent = selected ? '已选择' : '未选择';
    });
    // 保存到后端
    saveSkillSelection();
}

function saveSkillSelection() {
    if (!currentRoomId) return;
    const skillsJson = JSON.stringify(mySkills);
    fetch('/uno', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `api_action=update_skills&room_id=${currentRoomId}&skills=${encodeURIComponent(skillsJson)}`
    }).then(r => r.json()).then(res => {
        if (!res.success) alert(res.msg || '保存技能失败');
    });
}

// ---------- 轮询 ----------
function doPoll() {
    if (!currentRoomId) return;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=poll_state&room_id=${currentRoomId}&version=${currentVersion}` })
    .then(r=>r.json()).then(data=>{
        if(!data.success){ alert(data.msg||'房间已结束'); exitToLobby(); return; }
        if(!data.changed) return;
        currentVersion=data.version;
        isSpectator=!!data.is_spectator;
        if(data.chat_messages) renderChat(data.chat_messages, true);
        if(data.room.status==='waiting'){
            renderWaitingRoom(data);
        }else if(data.room.status==='playing' || data.room.status==='finished'){
            _gameState=data.game_state;
            renderGame(data.game_state, isSpectator, data.room);
        }
    }).catch(console.error);
}

function loadRooms() {
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'api_action=get_rooms' })
    .then(r=>r.json()).then(res=>{
        const box=document.getElementById('rooms-container');
        box.innerHTML='';
        if(!res.rooms.length){ box.innerHTML='<div style="color:var(--text-muted);">暂无房间，创建第一个吧！</div>'; return; }
        res.rooms.forEach(rm=>{
            let div=document.createElement('div');
            div.className='room-item';
            const notWaiting=rm.status!=='waiting';
            const full=parseInt(rm.current_players)>=parseInt(rm.max_players);
            let btn= notWaiting||full ? `<button class="btn btn-info btn-sm" onclick="enterRoom(${rm.id})">观战</button>` : `<button class="btn btn-sm" onclick="joinRoom(${rm.id})">进入</button>`;
            div.innerHTML=`<h4>${escapeHtml(rm.title)}</h4>
                <div style="font-size:12px;color:var(--text-muted);">房主: ${escapeHtml(rm.host_name)} | ${rm.current_players}/${rm.max_players} ${rm.status==='playing'?'进行中':'等待中'}</div>
                <div style="margin-top:8px;">${btn}</div>`;
            box.appendChild(div);
        });
    });
}

function openCreateModal() {
    let title=prompt('房间名称：','UNO绝不留情');
    if(!title) return;
    let maxP=prompt('人数(2-6)：','6');
    if(!maxP) maxP=6;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=create_room&title=${encodeURIComponent(title)}&max_players=${maxP}` })
    .then(r=>r.json()).then(res=>{ if(res.success) enterRoom(res.room_id); else alert(res.msg); });
}

function joinRoom(id) {
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=join_room&room_id=${id}` })
    .then(r=>r.json()).then(res=>{ if(res.success) enterRoom(id); else alert(res.msg); });
}
function joinFromSpectate(){ if(currentRoomId) joinRoom(currentRoomId); }

function enterRoom(roomId) {
    currentRoomId=roomId; currentVersion=0;
    window.history.replaceState({},'',`/uno/${roomId}`);
    document.getElementById('view-lobby').style.display='none';
    startPolling();
}
function exitToLobby(){
    clearInterval(pollTimer); currentRoomId=null; currentVersion=0; isSpectator=false;
    window.history.replaceState({},'',`/uno`);
    document.getElementById('view-lobby').style.display='block';
    document.getElementById('view-room').style.display='none';
    document.getElementById('view-game').style.display='none';
    loadRooms();
}
function leaveRoom(){
    if(!currentRoomId) return;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=leave_room&room_id=${currentRoomId}` })
    .then(r=>r.json()).then(res=>{ if(res.success) exitToLobby(); else alert(res.msg); });
}

function startPolling(){
    clearInterval(pollTimer);
    const poll=doPoll;
    pollTimer=setInterval(poll, 3000);
    poll();
}

// ---------- 准备 ----------
function renderWaitingRoom(data){
    document.getElementById('view-room').style.display='block';
    document.getElementById('view-game').style.display='none';
    document.getElementById('room-title-text').innerText=`${data.room.title} (${data.room_players.length}/${data.room.max_players})`;
    const isHost=data.room.host_uid==myUid;
    document.getElementById('btn-start-game').style.display=isHost?'inline-flex':'none';
    if(isSpectator){
        document.getElementById('spectator-join-box').style.display=(data.room_players.length<data.room.max_players)?'block':'none';
        document.getElementById('btn-ready-toggle').style.display='none';
        document.getElementById('skill-select-wrap').style.display='none';
    }else{
        document.getElementById('spectator-join-box').style.display='none';
        document.getElementById('btn-ready-toggle').style.display='inline-flex';
        document.getElementById('skill-select-wrap').style.display='block';
        // 读取当前玩家的技能
        const myRec = data.room_players.find(p => p.uid == myUid);
        if(myRec){
            isReady = parseInt(myRec.is_ready);
            document.getElementById('btn-ready-toggle').innerText = isReady ? '取消准备' : '准备';
            // 恢复技能选择状态
            mySkills = myRec.skills || [];
            document.querySelectorAll('.skill-card').forEach(card => {
                const id = card.dataset.skill;
                const selected = mySkills.includes(id);
                card.classList.toggle('selected', selected);
                const badge = card.querySelector('.skill-badge');
                if (badge) badge.textContent = selected ? '已选择' : '未选择';
            });
        }
    }
    const pBox=document.getElementById('room-players-list');
    pBox.innerHTML='';
    data.room_players.forEach(p=>{
        let el=document.createElement('div');
        el.style.cssText='padding:8px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;display:flex;align-items:center;gap:12px;';
        let status=p.uid==data.room.host_uid?'<span style="color:var(--gold);">[房主]</span>':((p.is_ready === "1")?'<span style="color:#5cb85c;">已准备</span>':'<span style="color:var(--danger);">未准备</span>');
        let skillsText = '';
        if(p.skills && p.skills.length){
            const skillNames = p.skills.map(id => { if(id==='qiangchu') return '抢出'; return id; });
            skillsText = ' | 技能: ' + skillNames.join(', ');
        }
        let kick='';
        if(isHost && p.uid!=myUid) kick=`<button class="btn btn-danger btn-sm" onclick="kickPlayer(${p.uid})">踢出</button>`;
        el.innerHTML=`<span><strong>${escapeHtml(p.name)}</strong> ${status} ${skillsText}</span>${kick}`;
        pBox.appendChild(el);
    });
}

function kickPlayer(uid){
    if(!confirm('确定踢出该玩家吗？')) return;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=kick_player&room_id=${currentRoomId}&target_uid=${uid}` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function toggleReady(){
    const next=isReady?0:1;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=update_prep&room_id=${currentRoomId}&is_ready=${next}` })
    .then(r=>r.json()).then(res=>{
        if(res.success){ isReady=next; document.getElementById('btn-ready-toggle').innerText=isReady?'取消准备':'准备'; doPoll(); }
        else alert(res.msg);
    });
}

function startGame(){
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=start_game&room_id=${currentRoomId}` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

// ---------- 游戏 ----------
function renderGame(state, spectator, room){
    document.getElementById('view-room').style.display='none';
    document.getElementById('view-game').style.display='block';
    document.getElementById('spectator-indicator').style.display=spectator?'block':'none';
    const my = state.players.find(p=>p.uid===myUid);
    const isMyTurn = !spectator && state.current_player !== undefined && state.players[state.current_player] && state.players[state.current_player].uid===myUid;
    const isFinished = state.status==='finished';
    document.getElementById('deck-count').innerText = state.deck ? state.deck.length : 0;
    document.getElementById('draw-stack-display').innerText = state.draw_stack || 0;
    const colorDisplay=document.getElementById('current-color-display');
    colorDisplay.style.background=state.current_color || '#888';
    const top=state.discard[state.discard.length-1];
    let topName = top ? (top.type==='number'?top.value:top.type) : '无';
    if(top && top.type.startsWith('draw')) topName = '+' + top.type.replace('draw','');
    else if(top && top.type==='wild_draw4') topName = '+4';
    document.getElementById('top-card-display').innerHTML = top ? `<span style="background:${top.color};padding:2px 8px;border-radius:4px;color:#000;">${topName}</span>` : '无';
    const logBox=document.getElementById('battle-logs');
    logBox.innerHTML=state.logs.map(l=>`<p>${l}</p>`).join('');
    logBox.scrollTop=logBox.scrollHeight;
    let statusText=isFinished?'<strong style="color:var(--gold);">对局已结束</strong>':'';
    if(state.pending_action && state.pending_action.type==='respond_draw'){
        const p=state.pending_action;
        const target=state.players[p.player_idx];
        statusText=`<strong>${target?target.name:'玩家'}</strong> 被罚 ${p.draw_count} 张，请出罚牌或抽牌`;
    }else{
        const cur=state.players[state.current_player];
        statusText=cur ? `当前回合：<strong>${cur.name}</strong>` : '等待中';
    }
    document.getElementById('game-status-tip').innerHTML=statusText;

    // 对手
    const oppBox=document.getElementById('opponents-container');
    oppBox.innerHTML='';
    state.players.forEach((p,idx)=>{
        if(!spectator && p.uid===myUid) return;
        let div=document.createElement('div');
        div.className=`player-panel ${state.current_player===idx?'active-turn':''} ${p.is_out?'dead':''}`;
        let handCount = p.hand_count !== undefined ? p.hand_count : p.hand.length;
        div.innerHTML=`
            <div class="avatar-box"><img src="${p.avatar||'/default-avatar.png'}"></div>
            <div>
                <div><strong style="color:var(--text);">${escapeHtml(p.name)}</strong> ${p.is_out?'[出局]':''}</div>
                <div style="font-size:12px;color:var(--text-muted);">手牌: ${handCount}</div>
                ${p.skills && p.skills.length ? `<div style="font-size:10px;color:#f39c12;">技能: ${p.skills.map(s=>s.name).join(', ')}</div>` : ''}
            </div>
        `;
        oppBox.appendChild(div);
    });

    // 手牌
    const handBox=document.getElementById('my-handcards');
    handBox.innerHTML='';
    document.getElementById('my-hand-count').innerText=`手牌: ${my?my.hand.length:0}`;
    if(my && !my.is_out){
        my.hand.forEach((c,idx)=>{
            let el=document.createElement('div');
            el.className=`uno-card ${c.color}`;
            if(selectedCardIdx===idx) el.classList.add('selected');
            el.onclick=()=>{ selectedCardIdx=(selectedCardIdx===idx)?null:idx; renderGame(state,spectator,room); };
            let name = c.type==='number'?c.value:c.type;
            if(c.type.startsWith('draw')) name = '+' + c.type.replace('draw','');
            else if(c.type==='wild_draw4') name = '+4';
            el.innerHTML=`<div style="font-weight:bold;font-size:14px;">${name}</div><div class="card-color-label">${c.color}</div>`;
            handBox.appendChild(el);
        });
    }

    // 按钮状态
    const isMyAlive = my && !my.is_out && !isFinished;
    document.getElementById('btn-play').disabled = !(isMyAlive && isMyTurn && !state.pending_action);
    document.getElementById('btn-draw').disabled = !(isMyAlive && isMyTurn && !state.pending_action);
    document.getElementById('btn-uno').disabled = !(isMyAlive && my.hand.length===1);

    // 举报 UNO 按钮
    const reportBtn=document.getElementById('btn-report-uno');
    if(!spectator && isMyAlive && !isFinished){
        let canReport = false;
        for(let p of state.players){
            if(p.uid !== myUid && !p.is_out && p.hand_count === 1 && !p.called_uno){
                canReport = true;
                break;
            }
        }
        reportBtn.style.display = canReport ? 'inline-flex' : 'none';
    } else {
        reportBtn.style.display = 'none';
    }

    // 抢出按钮
    const qiangBtn=document.getElementById('btn-qiangchu');
    if(!spectator && isMyAlive && !isFinished && state.current_player !== undefined && state.players[state.current_player] && state.players[state.current_player].uid !== myUid && !state.pending_action){
        let hasSkill = my.skills && my.skills.some(s=>s.id==='qiangchu');
        let alreadyUsed = state.used_qiangchu && state.used_qiangchu[myUid];
        if(hasSkill && !alreadyUsed){
            let top = state.discard[state.discard.length-1];
            if(top){
                let canMatch = false;
                for(let c of my.hand){
                    if(canPlayCard(c, top, state.current_color)){ canMatch=true; break; }
                }
                if(canMatch) qiangBtn.style.display = 'inline-flex';
                else qiangBtn.style.display = 'none';
            } else qiangBtn.style.display = 'none';
        } else qiangBtn.style.display = 'none';
    } else {
        qiangBtn.style.display = 'none';
    }

    // 罚牌响应提示
    const promptArea=document.getElementById('action-prompt-area');
    promptArea.innerHTML='';
    if(state.pending_action && state.pending_action.type==='respond_draw' && state.pending_action.player_idx!==undefined){
        const target=state.players[state.pending_action.player_idx];
        if(target && target.uid===myUid){
            let canPlayDraw = my.hand.some(c=>['draw2','draw4','draw6','draw10'].includes(c.type));
            promptArea.innerHTML=`
                <div class="prompt-banner">
                    <div>你被罚 <strong>${state.pending_action.draw_count}</strong> 张牌！请选择：</div>
                    <div style="display:flex;gap:8px;">
                        ${canPlayDraw ? `<button class="btn btn-gold" onclick="respondDrawPlay()">出罚牌转移</button>` : ''}
                        <button class="btn btn-danger" onclick="respondDrawDraw()">抽牌</button>
                    </div>
                </div>
            `;
        }
    }
}

// ---------- 动作函数 ----------
function respondDrawPlay(){
    if(selectedCardIdx===null){ alert('请先点击选择一张罚牌（+2/+4/+6/+10）'); return; }
    sendAction('respond_draw_play', { card_index: selectedCardIdx });
    selectedCardIdx=null;
}
function respondDrawDraw(){
    sendAction('draw_card', {});
}
function onPlayCard(){
    if(selectedCardIdx===null){ alert('请先点击选择一张手牌'); return; }
    const state=_gameState;
    if(!state){ alert('无状态'); return; }
    const my=state.players.find(p=>p.uid===myUid);
    if(!my) return;
    const card=my.hand[selectedCardIdx];
    if(!card) return;
    if(card.type==='wild' || card.type==='wild_draw4'){
        showColorPicker(function(color){
            sendAction('play_card', { card_index: selectedCardIdx, color: color });
            selectedCardIdx=null;
        });
    }else if(card.type==='swap_hands'){
        showTargetPicker(state, function(targetUid){
            sendAction('swap_hands_target', { target_uid: targetUid });
            selectedCardIdx=null;
        });
    }else{
        sendAction('play_card', { card_index: selectedCardIdx });
        selectedCardIdx=null;
    }
}
function onDrawCard(){ sendAction('draw_card', {}); }
function declareUno(){ sendAction('declare_uno', {}); }
function reportUno(){
    const state=_gameState;
    if(!state) return;
    let targets = [];
    state.players.forEach(p=>{
        if(p.uid !== myUid && !p.is_out && p.hand_count === 1 && !p.called_uno){
            targets.push(p);
        }
    });
    if(targets.length===0){ alert('没有可举报的对象'); return; }
    if(targets.length===1){
        sendAction('report_uno', { target_uid: targets[0].uid });
    }else{
        let msg = '请选择要举报的玩家：\n';
        targets.forEach((p,i)=>msg+=`${i+1}. ${p.name}\n`);
        let choice = prompt(msg, '1');
        if(choice===null) return;
        let idx = parseInt(choice)-1;
        if(idx>=0 && idx<targets.length){
            sendAction('report_uno', { target_uid: targets[idx].uid });
        }else alert('无效选择');
    }
}
function onQiangchu(){
    const state=_gameState;
    if(!state) return;
    const my=state.players.find(p=>p.uid===myUid);
    if(!my) return;
    let top = state.discard[state.discard.length-1];
    if(!top){ alert('无顶牌'); return; }
    let matchCards = my.hand.filter(c=>canPlayCard(c, top, state.current_color));
    if(matchCards.length===0){ alert('没有可匹配的牌'); return; }
    let cardIdx = -1;
    if(matchCards.length===1){
        for(let i=0;i<my.hand.length;i++){
            if(my.hand[i].cid === matchCards[0].cid){ cardIdx=i; break; }
        }
    }else{
        let options = matchCards.map((c,i)=>`${i+1}. [${c.color} ${c.type}]`).join('\n');
        let choice = prompt(`选择要抢出的牌（${matchCards.length}张匹配）：\n${options}`, '1');
        if(choice===null) return;
        let idx = parseInt(choice)-1;
        if(idx>=0 && idx<matchCards.length){
            for(let i=0;i<my.hand.length;i++){
                if(my.hand[i].cid === matchCards[idx].cid){ cardIdx=i; break; }
            }
        }
    }
    if(cardIdx<0){ alert('未选到有效牌'); return; }
    const card = my.hand[cardIdx];
    if(card.type==='wild' || card.type==='wild_draw4'){
        showColorPicker(function(color){
            sendAction('qiangchu_play', { card_index: cardIdx, color: color });
            selectedCardIdx=null;
        });
    }else{
        sendAction('qiangchu_play', { card_index: cardIdx });
        selectedCardIdx=null;
    }
}
function surrenderGame(){
    if(!confirm('确定认输吗？')) return;
    sendAction('surrender', {});
}

function sendAction(type, extra={}){
    let body=`api_action=game_action&room_id=${currentRoomId}&action_type=${type}`;
    for(let k in extra) body+=`&${k}=${encodeURIComponent(extra[k])}`;
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

// ---------- 交互弹窗 ----------
function showColorPicker(callback) {
    document.querySelectorAll('.color-picker-overlay').forEach(el=>el.remove());
    let overlay = document.createElement('div');
    overlay.className = 'color-picker-overlay';
    overlay.innerHTML = `
        <div class="color-picker-box">
            <h3 style="margin-bottom:12px;">选择颜色</h3>
            <div>
                <div class="color-btn red" data-color="red">红</div>
                <div class="color-btn blue" data-color="blue">蓝</div>
                <div class="color-btn green" data-color="green">绿</div>
                <div class="color-btn yellow" data-color="yellow">黄</div>
            </div>
            <button class="btn" style="margin-top:12px;" onclick="this.closest('.color-picker-overlay').remove();">取消</button>
        </div>
    `;
    document.body.appendChild(overlay);
    overlay.querySelectorAll('.color-btn').forEach(btn=>{
        btn.addEventListener('click', function(){
            let color = this.dataset.color;
            overlay.remove();
            callback(color);
        });
    });
}
function showTargetPicker(state, callback) {
    document.querySelectorAll('.target-picker-overlay').forEach(el=>el.remove());
    let overlay = document.createElement('div');
    overlay.className = 'target-picker-overlay';
    let options = '';
    state.players.forEach(p=>{
        if(p.uid !== myUid && !p.is_out){
            options += `<div class="target-item" data-uid="${p.uid}">${escapeHtml(p.name)} (手牌: ${p.hand.length})</div>`;
        }
    });
    overlay.innerHTML = `
        <div class="target-picker-box">
            <h3 style="margin-bottom:12px;">选择目标玩家</h3>
            ${options || '<div style="color:#aaa;">没有可选目标</div>'}
            <button class="btn" style="margin-top:12px;" onclick="this.closest('.target-picker-overlay').remove();">取消</button>
        </div>
    `;
    document.body.appendChild(overlay);
    overlay.querySelectorAll('.target-item').forEach(el=>{
        el.addEventListener('click', function(){
            let uid = parseInt(this.dataset.uid);
            overlay.remove();
            callback(uid);
        });
    });
}

// ---------- 聊天 ----------
function renderChat(messages, prep=false){
    const box=prep?document.getElementById('chat-messages-prep'):document.getElementById('chat-messages');
    if(!box) return;
    box.innerHTML=messages.map(m=>`<div><span style="color:var(--accent);">${escapeHtml(m.name)}</span> ${m.time}: ${m.msg}</div>`).join('');
    box.scrollTop=box.scrollHeight;
}
function sendChat(inputId){
    const input=document.getElementById(inputId);
    if(!input) return;
    const msg=input.value.trim();
    if(!msg) return;
    const box = (inputId === 'chat-input-prep') ? document.getElementById('chat-messages-prep') : document.getElementById('chat-messages');
    if(box){
        const now = new Date();
        const timeStr = now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0')+':'+now.getSeconds().toString().padStart(2,'0');
        const myName = "<?= addslashes($login_name) ?>";
        const msgHtml = `<div><span style="color:var(--accent);">${escapeHtml(myName)}</span> ${timeStr}: ${escapeHtml(msg)}</div>`;
        box.innerHTML += msgHtml;
        box.scrollTop = box.scrollHeight;
    }
    input.value = '';
    fetch('/uno', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=send_chat&room_id=${currentRoomId}&msg=${encodeURIComponent(msg)}` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function escapeHtml(str){ let d=document.createElement('div'); d.textContent=str||''; return d.innerHTML; }

function canPlayCard(card, topCard, currentColor) {
    if (card.type === 'wild' || card.type === 'wild_draw4') return true;
    if (card.color === currentColor) return true;
    if (topCard.type === 'number' && card.type === 'number' && card.value === topCard.value) return true;
    if (topCard.type !== 'number' && card.type === topCard.type) return true;
    return false;
}

document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('chat-input').addEventListener('keypress',e=>{ if(e.key==='Enter') sendChat('chat-input'); });
    document.getElementById('chat-input-prep').addEventListener('keypress',e=>{ if(e.key==='Enter') sendChat('chat-input-prep'); });
    const path=window.location.pathname.match(/\/uno\/(\d+)/);
    if(path && parseInt(path[1])>0) enterRoom(parseInt(path[1]));
    else loadRooms();
});
</script>
</body>
</html>