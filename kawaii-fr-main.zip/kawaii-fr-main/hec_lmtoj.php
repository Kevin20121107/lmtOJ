<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type: text/html; charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

require_once __DIR__ . '/database.php';

$conn = db();
$conn->set_charset("utf8mb4");

/* =========================================================
 * 基础函数
 * ========================================================= */

function safeContent($value)
{
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function getFirstChar($name)
{
    $name = trim($name ?? '?');

    if (mb_strlen($name) > 0) {
        return mb_strtoupper(
            mb_substr($name, 0, 1)
        );
    }

    return '?';
}

function json_out($ok, $msg, $extra = [])
{
    header('Content-Type: application/json; charset=utf-8');

    echo json_encode(
        array_merge(
            [
                'success' => $ok,
                'msg' => $msg
            ],
            $extra
        ),
        JSON_UNESCAPED_UNICODE
    );

    exit;
}

/* =========================================================
 * 当前登录用户
 * ========================================================= */

$login_uid = (int)$_SESSION['uid'];

$stmt = $conn->prepare("
    SELECT
        name,
        admin,
        sqadmin,
        avatar,
        show_colorful_names,
        base_credit,
        valuation,
        username_color,
        cert_type,
        cert_level,
        practice_score,
        contribute_score,
        contest_score
    FROM users
    WHERE uid = ?
    LIMIT 1
");

$stmt->bind_param("i", $login_uid);
$stmt->execute();

$userRow = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();

if (!$userRow) {
    session_destroy();

    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_name = $userRow['name'] ?? '';

$is_admin = (int)($userRow['admin'] ?? 0);
$is_sqadmin = (int)($userRow['sqadmin'] ?? 0);

$myShowColorful =
    (int)($userRow['show_colorful_names'] ?? 1);

/* =========================================================
 * 用户颜色
 * ========================================================= */

function getAchievementScore($certType, $certLevel)
{
    if (
        empty($certType)
        ||
        $certLevel <= 0
    ) {
        return 0;
    }

    $validTypes = [
        'OI',
        'ICPC'
    ];

    if (
        !in_array(
            strtoupper($certType),
            $validTypes,
            true
        )
    ) {
        return 0;
    }

    $map = [
        3 => 2,
        4 => 3,
        5 => 5,
        6 => 10,
        7 => 13,
        8 => 15,
        9 => 18,
        10 => 20
    ];

    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore(
    $totalScore,
    $isAdmin
) {
    if ($isAdmin) {
        return '#8e44ad';
    }

    if ($totalScore < 0) {
        return '#8b6b4d';
    }

    if ($totalScore <= 10) {
        return '#b0a8a0';
    }

    if ($totalScore <= 20) {
        return '#4a90d9';
    }

    if ($totalScore <= 45) {
        return '#28a745';
    }

    if ($totalScore <= 65) {
        return '#e67e22';
    }

    return '#e74c3c';
}

function getUserColor(
    $user,
    $login_uid,
    $myShowColorful = 1
) {
    $base =
        (int)($user['base_credit'] ?? 10);

    $achieve = min(
        getAchievementScore(
            $user['cert_type'] ?? '',
            (int)($user['cert_level'] ?? 0)
        ),
        20
    );

    $practice = min(
        (int)($user['practice_score'] ?? 0),
        20
    );

    $contribute = min(
        (int)($user['contribute_score'] ?? 0),
        30
    );

    $contest = min(
        (int)($user['contest_score'] ?? 0),
        20
    );

    $valuation =
        (int)($user['valuation'] ?? 0);

    $isBrown =
        ($valuation === -1);

    $total = $isBrown
        ? -1
        : (
            $base
            + $achieve
            + $practice
            + $contribute
            + $contest
        );

    $admin =
        (int)($user['admin'] ?? 0);

    $color =
        getColorByTotalScore(
            $total,
            $admin
        );

    $targetColorful =
        ($user['username_color'] ?? 'auto') === 'beautiful'
        &&
        (
            $achieve >= 20
            ||
            $practice >= 30
            ||
            $contribute >= 30
            ||
            $contest >= 20
        );

    $isColorful = false;

    if (
        (int)$user['uid'] === $login_uid
    ) {
        $isColorful =
            $targetColorful;
    } else {
        $isColorful =
            $targetColorful
            &&
            $myShowColorful;
    }

    return [
        'color' => $color,
        'isColorful' => $isColorful
    ];
}

/* =========================================================
 * 创建抽奖相关数据表
 * ========================================================= */

$conn->query("
    CREATE TABLE IF NOT EXISTS lucky_draw (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        status ENUM('draft','finished')
            NOT NULL DEFAULT 'draft',
        created_by INT NOT NULL,
        created_at TIMESTAMP
            DEFAULT CURRENT_TIMESTAMP,
        drawn_at TIMESTAMP NULL
    )
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS lucky_draw_users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        draw_id INT NOT NULL,
        uid INT NOT NULL,
        created_at TIMESTAMP
            DEFAULT CURRENT_TIMESTAMP,

        UNIQUE KEY uniq_draw_uid
            (draw_id, uid),

        INDEX idx_draw_id
            (draw_id)
    )
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS lucky_draw_prizes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        draw_id INT NOT NULL,
        prize_name VARCHAR(255) NOT NULL,
        quantity INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP
            DEFAULT CURRENT_TIMESTAMP,

        INDEX idx_draw_id
            (draw_id)
    )
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
");

$conn->query("
    CREATE TABLE IF NOT EXISTS lucky_draw_results (
        id INT AUTO_INCREMENT PRIMARY KEY,
        draw_id INT NOT NULL,
        prize_id INT NOT NULL,
        uid INT NOT NULL,
        created_at TIMESTAMP
            DEFAULT CURRENT_TIMESTAMP,

        UNIQUE KEY uniq_draw_result_uid
            (draw_id, uid),

        INDEX idx_draw_id
            (draw_id),

        INDEX idx_prize_id
            (prize_id)
    )
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
");

/*
 * 庆典大合照
 *
 * 每个抽奖活动最多保存一张图片 URL。
 */
$conn->query("
    CREATE TABLE IF NOT EXISTS lucky_draw_photos (
        id INT AUTO_INCREMENT PRIMARY KEY,
        draw_id INT NOT NULL,
        image_url TEXT NOT NULL,
        updated_by INT NOT NULL,
        updated_at TIMESTAMP
            DEFAULT CURRENT_TIMESTAMP
            ON UPDATE CURRENT_TIMESTAMP,

        UNIQUE KEY uniq_draw_id
            (draw_id),

        INDEX idx_draw_id
            (draw_id)
    )
    ENGINE=InnoDB
    DEFAULT CHARSET=utf8mb4
");

/* =========================================================
 * 当前活动
 * ========================================================= */

$drawName =
    'HEC LMTOJ · 100 天庆典';

$draw = $conn->query("
    SELECT *
    FROM lucky_draw
    ORDER BY id ASC
    LIMIT 1
")->fetch_assoc();

if (!$draw) {

    $stmt = $conn->prepare("
        INSERT INTO lucky_draw
            (
                name,
                status,
                created_by
            )
        VALUES
            (?, 'draft', ?)
    ");

    $stmt->bind_param(
        "si",
        $drawName,
        $login_uid
    );

    $stmt->execute();

    $newId =
        $stmt->insert_id;

    $stmt->close();

    $draw = $conn->query("
        SELECT *
        FROM lucky_draw
        WHERE id = " . (int)$newId
    )->fetch_assoc();
}

$drawId =
    (int)$draw['id'];

$isFinished =
    ($draw['status'] === 'finished');

/* =========================================================
 * POST 操作
 * ========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
     * 大合照是特殊操作：
     *
     * 即使抽奖已经结束，
     * sqadmin 仍然可以上传/修改/清除大合照。
     */

    if (isset($_POST['save_photo'])) {

        if (!$is_sqadmin) {
            json_out(
                false,
                '只有 sqadmin 可以管理庆典大合照'
            );
        }

        $imageUrl =
            trim($_POST['image_url'] ?? '');

        /*
         * 清空图片
         */
        if ($imageUrl === '') {

            $stmt = $conn->prepare("
                DELETE FROM lucky_draw_photos
                WHERE draw_id = ?
            ");

            $stmt->bind_param(
                "i",
                $drawId
            );

            $stmt->execute();

            $stmt->close();

            json_out(
                true,
                '大合照已清除'
            );
        }

        /*
         * 检查 URL
         */
        if (
            !filter_var(
                $imageUrl,
                FILTER_VALIDATE_URL
            )
        ) {
            json_out(
                false,
                '请输入有效的图片 URL'
            );
        }

        /*
         * 只允许 HTTP / HTTPS
         */
        $scheme = strtolower(
            parse_url(
                $imageUrl,
                PHP_URL_SCHEME
            ) ?? ''
        );

        if (
            !in_array(
                $scheme,
                ['http', 'https'],
                true
            )
        ) {
            json_out(
                false,
                '图片 URL 必须使用 HTTP 或 HTTPS'
            );
        }

        /*
         * 检查是否已经存在
         */
        $stmt = $conn->prepare("
            SELECT id
            FROM lucky_draw_photos
            WHERE draw_id = ?
            LIMIT 1
        ");

        $stmt->bind_param(
            "i",
            $drawId
        );

        $stmt->execute();

        $exists = $stmt
            ->get_result()
            ->fetch_assoc();

        $stmt->close();

        /*
         * 更新
         */
        if ($exists) {

            $stmt = $conn->prepare("
                UPDATE lucky_draw_photos
                SET
                    image_url = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE draw_id = ?
            ");

            $stmt->bind_param(
                "sii",
                $imageUrl,
                $login_uid,
                $drawId
            );

        } else {

            /*
             * 插入
             */
            $stmt = $conn->prepare("
                INSERT INTO lucky_draw_photos
                    (
                        draw_id,
                        image_url,
                        updated_by
                    )
                VALUES
                    (?, ?, ?)
            ");

            $stmt->bind_param(
                "isi",
                $drawId,
                $imageUrl,
                $login_uid
            );
        }

        $ok =
            $stmt->execute();

        $error =
            $stmt->error;

        $stmt->close();

        json_out(
            $ok,
            $ok
                ? '大合照保存成功'
                : '大合照保存失败：' . $error
        );
    }

    /*
     * 以下操作只有 sqadmin 可以进行，
     * 并且抽奖结束以后全部锁定。
     */

    if (!$is_sqadmin) {
        json_out(
            false,
            '只有 sqadmin 可以管理抽奖'
        );
    }

    if ($isFinished) {
        json_out(
            false,
            '抽奖已经结束，配置已锁定'
        );
    }

    /* =====================================================
     * 添加参与用户
     * ===================================================== */

    if (isset($_POST['add_users'])) {

        $raw =
            trim($_POST['user_ids'] ?? '');

        $parts = preg_split(
            '/[\s,，、;；]+/u',
            $raw
        );

        $uids = [];

        foreach ($parts as $p) {

            $p = trim($p);

            if (
                preg_match(
                    '/^\d+$/',
                    $p
                )
                &&
                (int)$p > 0
            ) {
                $uids[(int)$p] = true;
            }
        }

        $uids =
            array_keys($uids);

        if (!$uids) {
            json_out(
                false,
                '没有识别到有效 UID'
            );
        }

        $check = $conn->prepare("
            SELECT uid
            FROM users
            WHERE uid = ?
            LIMIT 1
        ");

        $exists = $conn->prepare("
            SELECT id
            FROM lucky_draw_users
            WHERE draw_id = ?
              AND uid = ?
            LIMIT 1
        ");

        $insert = $conn->prepare("
            INSERT INTO lucky_draw_users
                (
                    draw_id,
                    uid
                )
            VALUES
                (?, ?)
        ");

        $added = 0;
        $duplicated = 0;
        $invalid = [];

        foreach ($uids as $uid) {

            $check->bind_param(
                "i",
                $uid
            );

            $check->execute();

            if (
                $check
                    ->get_result()
                    ->num_rows === 0
            ) {
                $invalid[] = $uid;
                continue;
            }

            $exists->bind_param(
                "ii",
                $drawId,
                $uid
            );

            $exists->execute();

            if (
                $exists
                    ->get_result()
                    ->num_rows
            ) {
                $duplicated++;
                continue;
            }

            $insert->bind_param(
                "ii",
                $drawId,
                $uid
            );

            if ($insert->execute()) {
                $added++;
            }
        }

        $check->close();
        $exists->close();
        $insert->close();

        $msg =
            "成功添加 {$added} 人";

        if ($duplicated) {
            $msg .=
                "，{$duplicated} 人已存在";
        }

        if ($invalid) {
            $msg .=
                "；不存在的 UID："
                . implode(', ', $invalid);
        }

        json_out(
            true,
            $msg
        );
    }

    /* =====================================================
     * 删除参与用户
     * ===================================================== */

    if (isset($_POST['delete_user'])) {

        $uid =
            (int)$_POST['delete_user'];

        $stmt = $conn->prepare("
            DELETE FROM lucky_draw_users
            WHERE draw_id = ?
              AND uid = ?
        ");

        $stmt->bind_param(
            "ii",
            $drawId,
            $uid
        );

        $stmt->execute();

        $n =
            $stmt->affected_rows;

        $stmt->close();

        json_out(
            $n > 0,
            $n
                ? '已删除参与用户'
                : '用户不存在'
        );
    }

    /* =====================================================
     * 添加奖品
     * ===================================================== */

    if (isset($_POST['add_prize'])) {

        $name =
            trim($_POST['prize_name'] ?? '');

        $qty =
            (int)($_POST['quantity'] ?? 0);

        if ($name === '') {
            json_out(
                false,
                '奖品名称不能为空'
            );
        }

        if (
            $qty < 1
            ||
            $qty > 10000
        ) {
            json_out(
                false,
                '奖品数量必须为 1～10000'
            );
        }

        $stmt = $conn->prepare("
            INSERT INTO lucky_draw_prizes
                (
                    draw_id,
                    prize_name,
                    quantity
                )
            VALUES
                (?, ?, ?)
        ");

        $stmt->bind_param(
            "isi",
            $drawId,
            $name,
            $qty
        );

        $ok =
            $stmt->execute();

        $err =
            $stmt->error;

        $stmt->close();

        json_out(
            $ok,
            $ok
                ? '奖品添加成功'
                : '奖品添加失败：' . $err
        );
    }

    /* =====================================================
     * 删除奖品
     * ===================================================== */

    if (isset($_POST['delete_prize'])) {

        $pid =
            (int)$_POST['delete_prize'];

        $stmt = $conn->prepare("
            DELETE FROM lucky_draw_prizes
            WHERE id = ?
              AND draw_id = ?
        ");

        $stmt->bind_param(
            "ii",
            $pid,
            $drawId
        );

        $stmt->execute();

        $n =
            $stmt->affected_rows;

        $stmt->close();

        json_out(
            $n > 0,
            $n
                ? '奖品已删除'
                : '奖品不存在'
        );
    }

    /* =====================================================
     * 开奖
     * ===================================================== */

    if (isset($_POST['draw_now'])) {

        $conn->begin_transaction();

        try {

            /*
             * 锁定活动
             */

            $stmt = $conn->prepare("
                SELECT
                    id,
                    status
                FROM lucky_draw
                WHERE id = ?
                FOR UPDATE
            ");

            $stmt->bind_param(
                "i",
                $drawId
            );

            $stmt->execute();

            $locked = $stmt
                ->get_result()
                ->fetch_assoc();

            $stmt->close();

            if (
                !$locked
                ||
                $locked['status'] !== 'draft'
            ) {
                throw new Exception(
                    '本次抽奖已经结束'
                );
            }

            /*
             * 获取参与者
             */

            $res = $conn->query("
                SELECT uid
                FROM lucky_draw_users
                WHERE draw_id = {$drawId}
                ORDER BY id
            ");

            $participantsForDraw = [];

            while (
                $r = $res->fetch_assoc()
            ) {
                $participantsForDraw[] =
                    (int)$r['uid'];
            }

            /*
             * 获取奖品
             */

            $res = $conn->query("
                SELECT
                    id,
                    prize_name,
                    quantity
                FROM lucky_draw_prizes
                WHERE draw_id = {$drawId}
                ORDER BY id
            ");

            $prizesForDraw = [];
            $total = 0;

            while (
                $r = $res->fetch_assoc()
            ) {

                $q =
                    (int)$r['quantity'];

                if ($q > 0) {

                    $prizesForDraw[] = [
                        'id' =>
                            (int)$r['id'],

                        'prize_name' =>
                            $r['prize_name'],

                        'quantity' =>
                            $q
                    ];

                    $total += $q;
                }
            }

            if (
                !$participantsForDraw
            ) {
                throw new Exception(
                    '当前没有参与用户'
                );
            }

            if (!$prizesForDraw) {
                throw new Exception(
                    '当前没有奖品'
                );
            }

            if (
                $total >
                count($participantsForDraw)
            ) {
                throw new Exception(
                    '奖品总数不能大于参与人数'
                );
            }

            /*
             * 随机洗牌
             */

            for (
                $i =
                    count($participantsForDraw) - 1;
                $i > 0;
                $i--
            ) {

                $j =
                    random_int(0, $i);

                [
                    $participantsForDraw[$i],
                    $participantsForDraw[$j]
                ] = [
                    $participantsForDraw[$j],
                    $participantsForDraw[$i]
                ];
            }

            /*
             * 保存中奖结果
             */

            $insert = $conn->prepare("
                INSERT INTO lucky_draw_results
                    (
                        draw_id,
                        prize_id,
                        uid
                    )
                VALUES
                    (?, ?, ?)
            ");

            $idx = 0;

            foreach (
                $prizesForDraw as $p
            ) {

                for (
                    $i = 0;
                    $i < $p['quantity'];
                    $i++
                ) {

                    $uid =
                        $participantsForDraw[$idx++];

                    $insert->bind_param(
                        "iii",
                        $drawId,
                        $p['id'],
                        $uid
                    );

                    if (
                        !$insert->execute()
                    ) {
                        throw new Exception(
                            '保存中奖结果失败：'
                            . $insert->error
                        );
                    }
                }
            }

            $insert->close();

            /*
             * 锁定活动
             */

            $stmt = $conn->prepare("
                UPDATE lucky_draw
                SET
                    status = 'finished',
                    drawn_at = NOW()
                WHERE id = ?
                  AND status = 'draft'
            ");

            $stmt->bind_param(
                "i",
                $drawId
            );

            $stmt->execute();

            if (
                $stmt->affected_rows !== 1
            ) {
                throw new Exception(
                    '开奖状态更新失败'
                );
            }

            $stmt->close();

            $conn->commit();

            json_out(
                true,
                '🎉 抽奖完成！'
            );

        } catch (Throwable $e) {

            $conn->rollback();

            json_out(
                false,
                '开奖失败：'
                . $e->getMessage()
            );
        }
    }

    json_out(
        false,
        '未知操作'
    );
}

/* =========================================================
 * 获取参与用户
 *
 * 注意：
 * 这里不再放在 sqadmin 判断里面。
 *
 * 所以普通用户也可以看到参与者。
 * ========================================================= */

$participants = [];

$res = $conn->query("
    SELECT
        d.uid,
        u.name,
        u.avatar,
        u.admin,
        u.practice_score,
        u.contribute_score,
        u.contest_score,
        u.base_credit,
        u.valuation,
        u.username_color,
        u.cert_type,
        u.cert_level
    FROM lucky_draw_users d
    LEFT JOIN users u
        ON d.uid = u.uid
    WHERE d.draw_id = {$drawId}
    ORDER BY d.id
");

while (
    $r = $res->fetch_assoc()
) {
    $participants[] = $r;
}

/* =========================================================
 * 获取奖品
 * ========================================================= */

$prizes = [];

$res = $conn->query("
    SELECT
        id,
        prize_name,
        quantity
    FROM lucky_draw_prizes
    WHERE draw_id = {$drawId}
    ORDER BY id
");

while (
    $r = $res->fetch_assoc()
) {
    $prizes[] = $r;
}

/* =========================================================
 * 获取中奖结果
 * ========================================================= */

$results = [];

$res = $conn->query("
    SELECT
        r.uid,
        r.prize_id,
        p.prize_name,
        u.name,
        u.avatar
    FROM lucky_draw_results r

    LEFT JOIN lucky_draw_prizes p
        ON r.prize_id = p.id

    LEFT JOIN users u
        ON r.uid = u.uid

    WHERE r.draw_id = {$drawId}

    ORDER BY
        p.id,
        r.id
");

while (
    $r = $res->fetch_assoc()
) {
    $results[] = $r;
}

/* =========================================================
 * 按奖品分组
 * ========================================================= */

$grouped = [];

foreach ($results as $r) {

    $pid =
        (int)$r['prize_id'];

    if (
        !isset($grouped[$pid])
    ) {

        $grouped[$pid] = [
            'prize_name' =>
                $r['prize_name'],

            'winners' => []
        ];
    }

    $grouped[$pid]['winners'][] =
        $r;
}

/* =========================================================
 * 获取庆典大合照
 * ========================================================= */

$photoUrl = '';

$stmt = $conn->prepare("
    SELECT image_url
    FROM lucky_draw_photos
    WHERE draw_id = ?
    LIMIT 1
");

$stmt->bind_param(
    "i",
    $drawId
);

$stmt->execute();

$photoRow = $stmt
    ->get_result()
    ->fetch_assoc();

$stmt->close();

if ($photoRow) {
    $photoUrl =
        trim($photoRow['image_url'] ?? '');
}

/* =========================================================
 * 统计
 * ========================================================= */

$totalPrizeCount = 0;

foreach ($prizes as $p) {

    $totalPrizeCount +=
        (int)$p['quantity'];
}

?>
<!DOCTYPE html>
<html lang="zh-CN">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>
    HEC LMTOJ · 100 天庆典
</title>

<link
    rel="icon"
    type="image/png"
    href="https://lmtoj.cn/logo.png"
>

<style>

/* =========================================================
 * 变量
 * ========================================================= */

:root {

    --bg:#f9f7f4;
    --card-bg:#ffffff;

    --nav-bg:#3d3a37;
    --nav-text:#f0ece6;

    --text:#2c2a28;
    --text-secondary:#7a736b;
    --text-muted:#a0988e;

    --border:#e6e1da;
    --border-light:#f0ece6;

    --accent:#6b8a74;
    --accent-hover:#55735e;
    --accent-light:#eef4ef;

    --warm-yellow-bg:#fefcf4;
    --warm-yellow-border:#f0e2b0;
    --warm-yellow-text:#8a7020;

    --danger:#d9534f;
    --danger-hover:#c0392b;

    --gold:#b7842d;
    --gold-hover:#9c6e22;

    --shadow-sm:
        0 1px 3px rgba(0,0,0,0.04);

    --shadow:
        0 2px 10px rgba(0,0,0,0.05);

    --shadow-md:
        0 4px 16px rgba(0,0,0,0.06);

    --radius:10px;
    --radius-sm:6px;

    --transition:0.18s ease;

    --font:
        'Segoe UI',
        'PingFang SC',
        'Microsoft YaHei',
        'Noto Sans SC',
        system-ui,
        sans-serif;
}

/* =========================================================
 * 基础
 * ========================================================= */

* {
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body {

    background:var(--bg);

    color:var(--text);

    font-family:var(--font);

    line-height:1.6;

    -webkit-font-smoothing:antialiased;
}

a {

    color:var(--accent);

    text-decoration:none;

    font-weight:500;

    transition:var(--transition);
}

a:hover {

    color:var(--accent-hover);

    text-decoration:underline;
}

/* =========================================================
 * 主布局
 * ========================================================= */

.main {

    max-width:1100px;

    margin:28px auto 40px;

    display:flex;

    gap:22px;

    padding:0 20px;

    align-items:flex-start;
}

/* =========================================================
 * 侧边栏
 * ========================================================= */

.sidebar {

    background:var(--card-bg);

    border-radius:var(--radius);

    box-shadow:var(--shadow);

    width:fit-content;

    min-width:110px;

    overflow:hidden;

    position:sticky;

    top:80px;

    flex-shrink:0;
}

.sidebar a {

    display:block;

    padding:13px 22px;

    text-align:center;

    background:var(--card-bg);

    color:var(--text);

    text-decoration:none;

    font-size:14.5px;

    font-weight:500;

    transition:var(--transition);

    border-left:3px solid transparent;

    letter-spacing:0.3px;
}

.sidebar a:hover {

    background:#f5f2ed;

    border-left-color:var(--accent);

    color:var(--accent);
}

/* =========================================================
 * 内容
 * ========================================================= */

.content {

    flex:1;

    min-width:0;
}

/* =========================================================
 * 卡片
 * ========================================================= */

.card {

    background:var(--card-bg);

    border-radius:var(--radius);

    padding:26px 28px;

    margin-bottom:18px;

    box-shadow:var(--shadow);

    overflow:hidden;
}

.card h2 {

    font-size:18px;

    font-weight:600;

    margin-bottom:16px;
}

/* =========================================================
 * Hero
 * ========================================================= */

.hero {

    background:
        linear-gradient(
            135deg,
            #fffdf8,
            #f8f3e9 55%,
            #eef4ef
        );

    border:1px solid var(--border);
}

.badge {

    display:inline-block;

    background:var(--accent-light);

    color:var(--accent);

    padding:4px 11px;

    border-radius:20px;

    font-size:12px;

    font-weight:600;

    margin-bottom:12px;
}

.hero h1 {

    font-size:28px;

    font-weight:650;

    margin-bottom:6px;

    color:var(--text);
}

.subtitle {

    color:var(--text-secondary);

    font-size:14px;
}

.status {

    display:inline-block;

    margin-top:14px;

    padding:4px 10px;

    border-radius:20px;

    font-size:12px;

    font-weight:600;
}

.status.draft {

    background:#fff8df;

    color:#8a7020;
}

.status.finished {

    background:var(--accent-light);

    color:var(--accent);
}

/* =========================================================
 * 统计
 * ========================================================= */

.stats {

    display:grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap:10px;

    margin-top:22px;
}

.stat {

    text-align:center;

    padding:13px;

    border:1px solid var(--border);

    border-radius:7px;

    background:#ffffffb8;
}

.num {

    font-size:23px;

    font-weight:700;

    color:var(--accent);
}

.label {

    font-size:12px;

    color:var(--text-muted);
}

/* =========================================================
 * 提示
 * ========================================================= */

.tip {

    background:var(--warm-yellow-bg);

    border:1px solid var(--warm-yellow-border);

    color:var(--warm-yellow-text);

    border-radius:var(--radius-sm);

    padding:11px 13px;

    font-size:13px;

    margin-bottom:16px;
}

/* =========================================================
 * 表单
 * ========================================================= */

textarea,
input {

    width:100%;

    border:1.5px solid var(--border);

    border-radius:var(--radius-sm);

    padding:10px 12px;

    font:inherit;

    font-size:14px;

    background:#fdfdfc;

    outline:none;

    transition:var(--transition);
}

textarea {

    min-height:105px;

    resize:vertical;
}

textarea:focus,
input:focus {

    border-color:var(--accent);

    box-shadow:
        0 0 0 3px
        rgba(107,138,116,0.08);

    background:#fff;
}

.row {

    display:flex;

    gap:9px;

    align-items:flex-end;
}

.row > div:first-child {

    flex:1;
}

.qty {

    width:130px !important;
}

/* =========================================================
 * 按钮
 * ========================================================= */

.btn {

    padding:9px 20px;

    background:var(--accent);

    color:#fff;

    border:none;

    border-radius:20px;

    cursor:pointer;

    font-size:14px;

    font-weight:500;

    transition:var(--transition);

    white-space:nowrap;
}

.btn:hover {

    background:var(--accent-hover);

    box-shadow:
        0 2px 8px
        rgba(107,138,116,0.25);
}

.btn:disabled {

    background:#bfbab0;

    cursor:not-allowed;

    box-shadow:none;
}

/* =========================================================
 * 开奖
 * ========================================================= */

.drawbox {

    text-align:center;

    margin-top:28px;

    padding-top:22px;

    border-top:1px solid var(--border-light);
}

.warning {

    font-size:13px;

    color:var(--text-secondary);

    margin-bottom:15px;
}

.draw {

    background:var(--gold);

    font-size:16px;

    font-weight:700;

    padding:12px 30px;
}

.draw:hover {

    background:var(--gold-hover);

    box-shadow:
        0 3px 10px
        rgba(183,132,45,0.22);
}

/* =========================================================
 * 删除按钮
 * ========================================================= */

.danger {

    border:0;

    background:none;

    color:var(--danger);

    cursor:pointer;

    font-size:12px;

    padding:4px 6px;

    border-radius:4px;

    transition:var(--transition);
}

.danger:hover {

    color:var(--danger-hover);

    background:#fce4ec;
}

/* =========================================================
 * 用户列表
 * ========================================================= */

.list {

    margin-top:12px;

    border-top:1px solid var(--border-light);

    max-height:420px;

    overflow:auto;
}

.item {

    display:flex;

    justify-content:space-between;

    align-items:center;

    padding:10px 0;

    border-bottom:1px solid var(--border-light);

    gap:12px;
}

.user {

    display:flex;

    gap:10px;

    align-items:center;

    min-width:0;
}

.avatar {

    width:38px;

    height:38px;

    border-radius:50%;

    background:var(--accent);

    color:#fff;

    display:flex;

    align-items:center;

    justify-content:center;

    overflow:hidden;

    font-weight:600;

    flex-shrink:0;
}

.avatar img {

    width:100%;

    height:100%;

    object-fit:cover;
}

.name {

    font-size:13.5px;

    font-weight:600;

    overflow:hidden;

    text-overflow:ellipsis;

    white-space:nowrap;
}

.uid {

    font-size:11px;

    color:var(--text-muted);
}

/* =========================================================
 * 公开参与者区域
 * ========================================================= */

.public-participants {

    display:grid;

    grid-template-columns:
        repeat(auto-fill, minmax(210px, 1fr));

    gap:10px;

    margin-top:14px;
}

.public-participant {

    display:flex;

    align-items:center;

    gap:10px;

    padding:10px 12px;

    background:#faf9f7;

    border:1px solid var(--border-light);

    border-radius:8px;

    min-width:0;
}

.public-participant .avatar {

    width:36px;

    height:36px;

    font-size:13px;
}

.public-participant-info {

    min-width:0;

    flex:1;
}

.public-participant-name {

    font-size:13px;

    font-weight:600;

    overflow:hidden;

    text-overflow:ellipsis;

    white-space:nowrap;
}

.public-participant-uid {

    font-size:11px;

    color:var(--text-muted);
}

.participant-count {

    color:var(--text-muted);

    font-size:13px;

    margin-top:-8px;

    margin-bottom:12px;
}

/* =========================================================
 * 奖品
 * ========================================================= */

.prize {

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:10px;

    padding:12px 0;

    border-bottom:1px solid var(--border-light);
}

.prize:last-child {

    border-bottom:none;
}

/* =========================================================
 * 空状态
 * ========================================================= */

.empty {

    text-align:center;

    color:var(--text-muted);

    font-size:13px;

    padding:24px 20px;
}

/* =========================================================
 * 中奖结果
 * ========================================================= */

.result {

    background:#fffdf8;

    border:1px solid var(--border);

    border-radius:var(--radius-sm);

    padding:15px;

    margin-bottom:12px;
}

.result-title {

    color:var(--warm-yellow-text);

    font-weight:700;

    margin-bottom:10px;
}

.winners {

    display:flex;

    flex-wrap:wrap;

    gap:8px;
}

.winner {

    display:inline-flex;

    align-items:center;

    gap:7px;

    background:#fff;

    border:1px solid var(--border);

    border-radius:20px;

    padding:5px 10px 5px 5px;

    font-size:13px;
}

.winner .avatar {

    width:27px;

    height:27px;

    font-size:11px;
}

/* =========================================================
 * 大合照
 * ========================================================= */

.photo-card {

    text-align:center;
}

.photo-desc {

    color:var(--text-secondary);

    font-size:13px;

    margin-top:-8px;

    margin-bottom:18px;
}

.photo-box {

    border:1px solid var(--border);

    border-radius:var(--radius);

    overflow:hidden;

    background:#faf9f7;

    box-shadow:var(--shadow-sm);
}

.photo-box img {

    display:block;

    width:100%;

    height:auto;

    max-height:700px;

    object-fit:contain;

    margin:0 auto;
}

.photo-empty {

    padding:45px 20px;

    color:var(--text-muted);

    font-size:13px;
}

.photo-admin {

    margin-top:20px;

    padding-top:20px;

    border-top:1px solid var(--border-light);

    text-align:left;
}

.photo-admin-title {

    font-size:15px;

    font-weight:600;

    margin-bottom:9px;
}

.photo-admin-tip {

    font-size:12px;

    color:var(--text-muted);

    margin-top:7px;
}

.photo-actions {

    display:flex;

    gap:8px;

    margin-top:9px;
}

.photo-clear {

    background:#f4eeee;

    color:var(--danger);
}

.photo-clear:hover {

    background:#fce4e4;

    color:var(--danger-hover);
}

/* =========================================================
 * 底部说明
 * ========================================================= */

.finished-note {

    text-align:center;

    color:var(--text-muted);

    font-size:12px;

    margin-top:16px;
}

/* =========================================================
 * Toast
 * ========================================================= */

.toast {

    position:fixed;

    top:72px;

    left:50%;

    transform:translateX(-50%);

    display:none;

    background:var(--nav-bg);

    color:#fff;

    padding:9px 18px;

    border-radius:20px;

    z-index:9999;

    box-shadow:var(--shadow-md);

    font-size:13px;
}

/* =========================================================
 * 滚动条
 * ========================================================= */

.list::-webkit-scrollbar {

    width:6px;
}

.list::-webkit-scrollbar-thumb {

    background:#d8d2ca;

    border-radius:10px;
}

.list::-webkit-scrollbar-track {

    background:transparent;
}

/* =========================================================
 * 手机
 * ========================================================= */

@media (max-width:768px) {

    .main {

        flex-direction:column;

        padding:0 12px;

        margin:18px auto 30px;

        gap:18px;
    }

    .sidebar {

        width:100%;

        position:static;

        display:flex;

        flex-wrap:wrap;
    }

    .sidebar a {

        flex:1 1 auto;

        padding:11px 10px;

        font-size:13px;

        border-left:none;

        border-bottom:2px solid transparent;
    }

    .sidebar a:hover {

        border-left-color:transparent;

        border-bottom-color:var(--accent);
    }

    .card {

        padding:18px 14px;
    }

    .hero h1 {

        font-size:23px;
    }

    .stats {

        gap:7px;
    }

    .stat {

        padding:11px 5px;
    }

    .num {

        font-size:20px;
    }

    .row {

        flex-direction:column;

        align-items:stretch;
    }

    .qty {

        width:100% !important;
    }

    .row .btn {

        width:100%;
    }

    .draw {

        width:100%;
    }

    .item {

        align-items:flex-start;
    }

    .item .danger {

        flex-shrink:0;
    }

    .public-participants {

        grid-template-columns:1fr;
    }

    .photo-actions {

        flex-direction:column;
    }

    .photo-actions .btn {

        width:100%;
    }

    .photo-box img {

        max-height:500px;
    }
}

</style>

</head>

<body>

<?php
/*
 * 主站顶部导航
 */
include 'navbar.php';
?>

<div class="main">

    <?php
    /*
     * 主站侧边栏
     */
    include 'sidebar.php';
    ?>

    <div class="content">

        <!-- =================================================
             庆典首页
        ================================================== -->

        <div class="card hero">

            <div class="badge">
                🎉 HEC LMTOJ · 100 DAYS
            </div>

            <h1>
                HEC LMTOJ 100 天庆典
            </h1>

            <div class="subtitle">
                感谢每一位陪伴 lmtOJ 走过这 100 天的用户。
                今天，来抽点好东西吧！
                也许oj不一定要刷题，而是有一群愿意一起玩的人！
            </div>

            <span
                class="status
                <?= $isFinished
                    ? 'finished'
                    : 'draft'
                ?>"
            >
                <?= $isFinished
                    ? '✓ 抽奖已结束'
                    : '● 抽奖准备中'
                ?>
            </span>

            <div class="stats">

                <div class="stat">

                    <div class="num">
                        <?= count($participants) ?>
                    </div>

                    <div class="label">
                        参与用户
                    </div>

                </div>

                <div class="stat">

                    <div class="num">
                        <?= count($prizes) ?>
                    </div>

                    <div class="label">
                        奖项
                    </div>

                </div>

                <div class="stat">

                    <div class="num">
                        <?= $totalPrizeCount ?>
                    </div>

                    <div class="label">
                        奖品总数
                    </div>

                </div>

            </div>

        </div>


        <!-- =================================================
             sqadmin 管理区域
        ================================================== -->

        <?php if ($is_sqadmin): ?>

        <div class="card">

            <h2>
                ⚙ 抽奖管理
            </h2>

            <div class="tip">

                <?= $isFinished
                    ? '本次抽奖已经完成，名单、奖池和结果均已锁定。大合照仍然可以由 sqadmin 管理。'
                    : '你拥有 sqadmin 权限，可以添加 UID、设置奖池并开始开奖。开奖后名单、奖池和结果自动锁定。'
                ?>

            </div>

            <?php if (!$isFinished): ?>

            <!-- 添加参与用户 -->

            <h3
                style="
                    font-size:15px;
                    font-weight:600;
                "
            >
                添加参与用户
            </h3>

            <form
                id="userForm"
                style="margin-top:9px;"
            >

                <textarea
                    id="user_ids"
                    placeholder="输入 UID，可一次输入多个，例如：
10001
10025
10086

也支持空格、逗号、中文逗号分隔。"
                ></textarea>

                <button
                    type="submit"
                    class="btn"
                    style="margin-top:9px;"
                >
                    添加到抽奖名单
                </button>

            </form>


            <!-- 管理参与用户 -->

            <div style="margin-top:28px;">

                <h3
                    style="
                        font-size:15px;
                        font-weight:600;
                    "
                >
                    参与用户
                    （<?= count($participants) ?> 人）
                </h3>

                <?php if (!$participants): ?>

                    <div class="empty">
                        暂时没有参与用户。
                    </div>

                <?php else: ?>

                    <div class="list">

                        <?php foreach (
                            $participants as $p
                        ): ?>

                        <div class="item">

                            <div class="user">

                                <div class="avatar">

                                    <?php if (
                                        !empty($p['avatar'])
                                    ): ?>

                                        <img
                                            src="<?= safeContent(
                                                $p['avatar']
                                            ) ?>"
                                            alt=""
                                        >

                                    <?php else: ?>

                                        <?= getFirstChar(
                                            $p['name'] ?? '?'
                                        ) ?>

                                    <?php endif; ?>

                                </div>

                                <div>

                                    <div class="name">

                                        <?= safeContent(
                                            $p['name']
                                            ?? '未知用户'
                                        ) ?>

                                    </div>

                                    <div class="uid">

                                        UID
                                        <?= (int)$p['uid'] ?>

                                    </div>

                                </div>

                            </div>

                            <button
                                type="button"
                                class="danger delete-user"
                                data-uid="<?= (int)$p['uid'] ?>"
                            >
                                删除
                            </button>

                        </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </div>


            <!-- 奖池 -->

            <div style="margin-top:30px;">

                <h3
                    style="
                        font-size:15px;
                        font-weight:600;
                    "
                >
                    奖池
                </h3>

                <form
                    id="prizeForm"
                    style="margin-top:10px;"
                >

                    <div class="row">

                        <div>

                            <input
                                type="text"
                                name="prize_name"
                                maxlength="255"
                                placeholder="奖品名称，例如：一等奖 · 100 Token"
                                required
                            >

                        </div>

                        <input
                            class="qty"
                            type="number"
                            name="quantity"
                            min="1"
                            max="10000"
                            value="1"
                            required
                        >

                        <button
                            type="submit"
                            class="btn"
                        >
                            添加奖品
                        </button>

                    </div>

                </form>

                <?php if (!$prizes): ?>

                    <div class="empty">
                        暂时没有奖品。
                    </div>

                <?php else: ?>

                    <div class="list">

                        <?php foreach (
                            $prizes as $p
                        ): ?>

                        <div class="prize">

                            <div>

                                <b>
                                    <?= safeContent(
                                        $p['prize_name']
                                    ) ?>
                                </b>

                                <div class="uid">

                                    数量 ×
                                    <?= (int)$p['quantity'] ?>

                                </div>

                            </div>

                            <button
                                type="button"
                                class="danger delete-prize"
                                data-id="<?= (int)$p['id'] ?>"
                            >
                                删除
                            </button>

                        </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </div>


            <!-- 开奖 -->

            <div class="drawbox">

                <div class="warning">

                    开奖后将立即锁定名单、奖池和开奖结果，
                    且不能再次开奖。

                </div>

                <button
                    id="drawBtn"
                    type="button"
                    class="btn draw"
                >
                    🎉 开始抽奖
                </button>

            </div>

            <?php endif; ?>

        </div>

        <?php endif; ?>


        <!-- =================================================
             所有人可见的参与者
        ================================================== -->

        <div class="card">

            <h2>
                👥 抽奖参与者
            </h2>

            <div class="participant-count">

                共
                <b><?= count($participants) ?></b>
                人参加本次抽奖

            </div>

            <?php if (!$participants): ?>

                <div class="empty">
                    暂时还没有参与用户。
                </div>

            <?php else: ?>

                <div class="public-participants">

                    <?php foreach (
                        $participants as $p
                    ): ?>

                    <div
                        class="public-participant"
                    >

                        <div class="avatar">

                            <?php if (
                                !empty($p['avatar'])
                            ): ?>

                                <img
                                    src="<?= safeContent(
                                        $p['avatar']
                                    ) ?>"
                                    alt=""
                                    loading="lazy"
                                >

                            <?php else: ?>

                                <?= getFirstChar(
                                    $p['name'] ?? '?'
                                ) ?>

                            <?php endif; ?>

                        </div>

                        <div
                            class="public-participant-info"
                        >

                            <div
                                class="public-participant-name"
                            >
                                <?= safeContent(
                                    $p['name']
                                    ?? '未知用户'
                                ) ?>
                            </div>

                            <div
                                class="public-participant-uid"
                            >
                                UID
                                <?= (int)$p['uid'] ?>
                            </div>

                        </div>

                    </div>

                    <?php endforeach; ?>

                </div>

            <?php endif; ?>

        </div>


        <!-- =================================================
             公开奖池 / 中奖名单
        ================================================== -->

        <div class="card">

            <h2>

                <?= $isFinished
                    ? '🎊 中奖名单'
                    : '🎁 本次奖池'
                ?>

            </h2>

            <?php if (!$isFinished): ?>

                <?php if (!$prizes): ?>

                    <div class="empty">
                        抽奖奖池正在准备中，敬请期待。
                    </div>

                <?php else: ?>

                    <?php foreach (
                        $prizes as $p
                    ): ?>

                    <div class="prize">

                        <b>
                            <?= safeContent(
                                $p['prize_name']
                            ) ?>
                        </b>

                        <span class="uid">

                            ×
                            <?= (int)$p['quantity'] ?>

                        </span>

                    </div>

                    <?php endforeach; ?>

                <?php endif; ?>

            <?php else: ?>

                <?php if (!$grouped): ?>

                    <div class="empty">
                        暂无中奖结果。
                    </div>

                <?php else: ?>

                    <?php foreach (
                        $grouped as $g
                    ): ?>

                    <div class="result">

                        <div class="result-title">

                            🏆
                            <?= safeContent(
                                $g['prize_name']
                            ) ?>

                        </div>

                        <div class="winners">

                            <?php foreach (
                                $g['winners'] as $w
                            ): ?>

                            <div class="winner">

                                <div class="avatar">

                                    <?php if (
                                        !empty($w['avatar'])
                                    ): ?>

                                        <img
                                            src="<?= safeContent(
                                                $w['avatar']
                                            ) ?>"
                                            alt=""
                                            loading="lazy"
                                        >

                                    <?php else: ?>

                                        <?= getFirstChar(
                                            $w['name']
                                            ?? '?'
                                        ) ?>

                                    <?php endif; ?>

                                </div>

                                <span>

                                    <?= safeContent(
                                        $w['name']
                                        ?? '未知用户'
                                    ) ?>

                                </span>

                                <span class="uid">

                                    UID
                                    <?= (int)$w['uid'] ?>

                                </span>

                            </div>

                            <?php endforeach; ?>

                        </div>

                    </div>

                    <?php endforeach; ?>

                <?php endif; ?>

                <div class="finished-note">

                    本次抽奖已经完成，
                    每位用户最多中奖一次。

                </div>

            <?php endif; ?>

        </div>


        <!-- =================================================
             庆典大合照
        ================================================== -->

        <div class="card photo-card">

            <h2>
                📸 庆典大合照
            </h2>

            <div class="photo-desc">
                HEC LMTOJ · 100 天庆典
            </div>

            <?php if ($photoUrl !== ''): ?>

                <div class="photo-box">

                    <img
                        src="<?= safeContent($photoUrl) ?>"
                        alt="HEC LMTOJ 100 天庆典大合照"
                        loading="lazy"
                        onerror="
                            this.parentElement.innerHTML =
                            '<div class=&quot;photo-empty&quot;>图片加载失败，请检查图片 URL 是否有效。</div>';
                        "
                    >

                </div>

            <?php else: ?>

                <div class="photo-box">

                    <div class="photo-empty">
                        📷 暂时还没有庆典大合照
                    </div>

                </div>

            <?php endif; ?>


            <!--
                sqadmin 始终可以管理大合照，
                即使抽奖已经结束也可以修改。
            -->

            <?php if ($is_sqadmin): ?>

                <div class="photo-admin">

                    <div class="photo-admin-title">
                        ⚙ 设置庆典大合照
                    </div>

                    <form id="photoForm">

                        <input
                            type="url"
                            id="image_url"
                            name="image_url"
                            value="<?= safeContent(
                                $photoUrl
                            ) ?>"
                            placeholder="请输入图片 URL，例如：https://example.com/photo.jpg"
                            maxlength="2000"
                        >

                        <div class="photo-actions">

                            <button
                                type="submit"
                                class="btn"
                            >
                                保存图片 URL
                            </button>

                            <?php if (
                                $photoUrl !== ''
                            ): ?>

                                <button
                                    type="button"
                                    id="clearPhoto"
                                    class="btn photo-clear"
                                >
                                    清除图片
                                </button>

                            <?php endif; ?>

                        </div>

                    </form>

                    <div class="photo-admin-tip">

                        仅 sqadmin 可以修改。
                        填写图片的完整 URL 即可。

                    </div>

                </div>

            <?php endif; ?>

        </div>

    </div>

</div>


<!-- =========================================================
     Toast
========================================================= -->

<div
    id="toast"
    class="toast"
></div>


<script>

/* =========================================================
 * Toast
 * ========================================================= */

const toast =
    document.getElementById('toast');

function msg(
    text,
    ok = true
) {

    toast.textContent = text;

    toast.style.display =
        'block';

    toast.style.background =
        ok
            ? '#3d3a37'
            : '#b83c38';

    clearTimeout(
        window.toastTimer
    );

    window.toastTimer =
        setTimeout(
            () => {

                toast.style.display =
                    'none';

            },
            2600
        );
}


/* =========================================================
 * POST
 * ========================================================= */

async function post(data) {

    const response =
        await fetch(
            location.href,
            {
                method:'POST',

                headers:{
                    'Content-Type':
                        'application/x-www-form-urlencoded;charset=UTF-8'
                },

                body:
                    new URLSearchParams(data)
            }
        );

    const text =
        await response.text();

    let json;

    try {

        json =
            JSON.parse(text);

    } catch (e) {

        console.error(text);

        throw new Error(
            '服务器返回了非 JSON 内容，请检查 PHP 错误。'
        );
    }

    return json;
}


/* =========================================================
 * 添加用户
 * ========================================================= */

const userForm =
    document.getElementById(
        'userForm'
    );

if (userForm) {

    userForm.addEventListener(
        'submit',
        async function(e) {

            e.preventDefault();

            const textarea =
                document.getElementById(
                    'user_ids'
                );

            try {

                const result =
                    await post({
                        add_users: 1,
                        user_ids:
                            textarea.value
                    });

                msg(
                    result.msg,
                    result.success
                );

                if (
                    result.success
                ) {

                    textarea.value =
                        '';

                    setTimeout(
                        () =>
                            location.reload(),
                        700
                    );
                }

            } catch (error) {

                console.error(error);

                msg(
                    error.message,
                    false
                );
            }
        }
    );
}


/* =========================================================
 * 添加奖品
 * ========================================================= */

const prizeForm =
    document.getElementById(
        'prizeForm'
    );

if (prizeForm) {

    prizeForm.addEventListener(
        'submit',
        async function(e) {

            e.preventDefault();

            try {

                const result =
                    await post({

                        add_prize: 1,

                        prize_name:
                            prizeForm
                                .prize_name
                                .value,

                        quantity:
                            prizeForm
                                .quantity
                                .value
                    });

                msg(
                    result.msg,
                    result.success
                );

                if (
                    result.success
                ) {

                    setTimeout(
                        () =>
                            location.reload(),
                        700
                    );
                }

            } catch (error) {

                console.error(error);

                msg(
                    error.message,
                    false
                );
            }
        }
    );
}


/* =========================================================
 * 删除参与用户
 * ========================================================= */

document
    .querySelectorAll(
        '.delete-user'
    )
    .forEach(
        function(button) {

            button.addEventListener(
                'click',
                async function() {

                    const uid =
                        button.dataset.uid;

                    if (
                        !confirm(
                            '确定删除 UID '
                            + uid
                            + ' 吗？'
                        )
                    ) {
                        return;
                    }

                    try {

                        const result =
                            await post({
                                delete_user:
                                    uid
                            });

                        msg(
                            result.msg,
                            result.success
                        );

                        if (
                            result.success
                        ) {

                            setTimeout(
                                () =>
                                    location.reload(),
                                500
                            );
                        }

                    } catch (error) {

                        console.error(error);

                        msg(
                            error.message,
                            false
                        );
                    }
                }
            );
        }
    );


/* =========================================================
 * 删除奖品
 * ========================================================= */

document
    .querySelectorAll(
        '.delete-prize'
    )
    .forEach(
        function(button) {

            button.addEventListener(
                'click',
                async function() {

                    const id =
                        button.dataset.id;

                    if (
                        !confirm(
                            '确定删除这个奖品吗？'
                        )
                    ) {
                        return;
                    }

                    try {

                        const result =
                            await post({
                                delete_prize:
                                    id
                            });

                        msg(
                            result.msg,
                            result.success
                        );

                        if (
                            result.success
                        ) {

                            setTimeout(
                                () =>
                                    location.reload(),
                                500
                            );
                        }

                    } catch (error) {

                        console.error(error);

                        msg(
                            error.message,
                            false
                        );
                    }
                }
            );
        }
    );


/* =========================================================
 * 开奖
 * ========================================================= */

const drawButton =
    document.getElementById(
        'drawBtn'
    );

if (drawButton) {

    drawButton.addEventListener(
        'click',
        async function() {

            if (
                !confirm(
                    '确定现在开始开奖吗？\n\n'
                    +
                    '开奖后名单、奖池和结果将永久锁定，'
                    +
                    '且不能再次开奖。'
                )
            ) {
                return;
            }

            drawButton.disabled =
                true;

            drawButton.textContent =
                '正在开奖……';

            try {

                const result =
                    await post({
                        draw_now: 1
                    });

                msg(
                    result.msg,
                    result.success
                );

                if (
                    result.success
                ) {

                    setTimeout(
                        () =>
                            location.reload(),
                        900
                    );

                } else {

                    drawButton.disabled =
                        false;

                    drawButton.textContent =
                        '🎉 开始抽奖';
                }

            } catch (error) {

                console.error(error);

                drawButton.disabled =
                    false;

                drawButton.textContent =
                    '🎉 开始抽奖';

                msg(
                    error.message,
                    false
                );
            }
        }
    );
}


/* =========================================================
 * 保存大合照
 * ========================================================= */

const photoForm =
    document.getElementById(
        'photoForm'
    );

if (photoForm) {

    photoForm.addEventListener(
        'submit',
        async function(e) {

            e.preventDefault();

            const input =
                document.getElementById(
                    'image_url'
                );

            const imageUrl =
                input.value.trim();

            if (!imageUrl) {

                msg(
                    '请输入图片 URL',
                    false
                );

                return;
            }

            try {

                const result =
                    await post({

                        save_photo: 1,

                        image_url:
                            imageUrl
                    });

                msg(
                    result.msg,
                    result.success
                );

                if (
                    result.success
                ) {

                    setTimeout(
                        () =>
                            location.reload(),
                        600
                    );
                }

            } catch (error) {

                console.error(error);

                msg(
                    error.message,
                    false
                );
            }
        }
    );
}


/* =========================================================
 * 清除大合照
 * ========================================================= */

const clearPhoto =
    document.getElementById(
        'clearPhoto'
    );

if (clearPhoto) {

    clearPhoto.addEventListener(
        'click',
        async function() {

            if (
                !confirm(
                    '确定要清除当前庆典大合照吗？'
                )
            ) {
                return;
            }

            try {

                const result =
                    await post({

                        save_photo: 1,

                        image_url: ''
                    });

                msg(
                    result.msg,
                    result.success
                );

                if (
                    result.success
                ) {

                    setTimeout(
                        () =>
                            location.reload(),
                        600
                    );
                }

            } catch (error) {

                console.error(error);

                msg(
                    error.message,
                    false
                );
            }
        }
    );
}

</script>


<?php

/*
 * 主站底部
 */
include __DIR__ . '/footer.php';

?>

</body>
</html>