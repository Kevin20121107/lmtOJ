<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 自动建表/补字段 ----------
$conn->query("CREATE TABLE IF NOT EXISTS teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    owner_uid INT NOT NULL,
    announcement TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX(owner_uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'announcement'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE teams ADD COLUMN announcement TEXT DEFAULT NULL");
}

$conn->query("CREATE TABLE IF NOT EXISTS team_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    role ENUM('member', 'admin') DEFAULT 'member',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_member (team_id, uid),
    INDEX(team_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS team_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    INDEX(team_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 登录检查 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$userInfo = $conn->query("SELECT admin, sqadmin, name FROM users WHERE uid = $login_uid")->fetch_assoc();
$is_admin = (int)($userInfo['admin'] ?? 0);
$login_name = $userInfo['name'] ?? '';

// 未读消息数
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// 搜索参数
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 20;
$offset = ($page - 1) * $limit;

$where = "1=1";
$params = [];
$types = "";
if (!empty($search)) {
    $where .= " AND (t.name LIKE ? OR u.name LIKE ?)";
    $searchLike = "%$search%";
    $params[] = $searchLike;
    $params[] = $searchLike;
    $types .= "ss";
}

// 总数
$countSql = "SELECT COUNT(*) AS c FROM teams t LEFT JOIN users u ON t.owner_uid = u.uid WHERE $where";
$countStmt = $conn->prepare($countSql);
if (!empty($params)) {
    $bindParams = array_merge([$types], $params);
    $refs = [];
    foreach ($bindParams as $key => $value) {
        $refs[$key] = &$bindParams[$key];
    }
    call_user_func_array([$countStmt, 'bind_param'], $refs);
}
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['c'];
$countStmt->close();
$totalPage = ceil($total / $limit);

// ★ 列表查询：新增 is_member 子查询（使用 $login_uid 直接嵌入，安全可靠）
$listSql = "SELECT t.*, u.name AS owner_name,
            (SELECT COUNT(*) FROM team_members WHERE team_id = t.id) AS member_count,
            (SELECT 1 FROM team_members WHERE team_id = t.id AND uid = $login_uid) AS is_member
            FROM teams t
            LEFT JOIN users u ON t.owner_uid = u.uid
            WHERE $where
            ORDER BY t.id DESC
            LIMIT ?, ?";
$listStmt = $conn->prepare($listSql);
$allParams = array_merge($params, [$offset, $limit]);
$allTypes = $types . "ii";
if (!empty($allParams)) {
    $bindParams = array_merge([$allTypes], $allParams);
    $refs = [];
    foreach ($bindParams as $key => $value) {
        $refs[$key] = &$bindParams[$key];
    }
    call_user_func_array([$listStmt, 'bind_param'], $refs);
}
$listStmt->execute();
$teamList = $listStmt->get_result();
$listStmt->close();

// 创建团队（仅管理员）
$error = '';
$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_team']) && $is_admin) {
    $name = trim($_POST['name']);
    $owner_uid = (int)($_POST['owner_uid'] ?? 0);
    $announcement = trim($_POST['announcement'] ?? '');
    if (empty($name)) {
        $error = "团队名称不能为空";
    } elseif (strlen($name) > 100) {
        $error = "团队名称过长（最大100字符）";
    } elseif ($owner_uid <= 0) {
        $error = "请输入有效的所有者 UID";
    } else {
        $check = $conn->prepare("SELECT uid FROM users WHERE uid = ?");
        $check->bind_param("i", $owner_uid);
        $check->execute();
        if ($check->get_result()->num_rows == 0) {
            $error = "该 UID 对应的用户不存在";
        } else {
            $nameCheck = $conn->prepare("SELECT id FROM teams WHERE name = ?");
            $nameCheck->bind_param("s", $name);
            $nameCheck->execute();
            if ($nameCheck->get_result()->num_rows > 0) {
                $error = "团队名称已存在，请换一个";
            } else {
                $conn->begin_transaction();
                try {
                    $ins = $conn->prepare("INSERT INTO teams (name, owner_uid, announcement) VALUES (?, ?, ?)");
                    $ins->bind_param("sis", $name, $owner_uid, $announcement);
                    $ins->execute();
                    $new_team_id = $ins->insert_id;
                    $ins->close();

                    $ins2 = $conn->prepare("INSERT INTO team_members (team_id, uid, role) VALUES (?, ?, 'admin')");
                    $ins2->bind_param("ii", $new_team_id, $owner_uid);
                    $ins2->execute();
                    $ins2->close();

                    $conn->commit();
                    $msg = "团队创建成功！";
                    header("Location: https://lmtoj.cn/team/$new_team_id");
                    exit;
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = "创建失败：" . $e->getMessage();
                }
            }
            $nameCheck->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>团队列表 - lmtOJ</title>
    <style>
        :root { --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6; --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e; --border: #e6e1da; --border-light: #f0ece6; --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef; --danger: #d9534f; --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease; --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100% { box-shadow:0 0 0 0 rgba(245,83,83,0.5); } 50% { box-shadow:0 0 0 6px rgba(245,83,83,0); } }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); font-weight:500; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:18px; border:1px solid var(--border-light); transition:var(--transition); }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .btn { padding:8px 18px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:13.5px; font-weight:500; transition:var(--transition); text-decoration:none; display:inline-block; }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); color:#fff; }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:var(--danger-hover); }
        .btn-sm { padding:4px 12px; font-size:12px; }
        .alert { padding:12px 16px; border-radius:var(--radius-sm); margin-bottom:16px; }
        .alert-success { background:#e8f5e9; color:#2e7d32; border:1px solid #a5d6a7; }
        .alert-error { background:#fce4ec; color:#c62828; border:1px solid #ef9a9a; }
        .flex-between { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; }
        .form-group { margin-bottom:12px; }
        .form-group label { display:block; font-weight:500; margin-bottom:4px; font-size:14px; color:var(--text-secondary); }
        input, select, textarea { padding:6px 12px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; outline:none; background:#fdfdfc; transition:var(--transition); width:100%; }
        input:focus, select:focus, textarea:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        textarea { min-height:100px; resize:vertical; }
        small { font-size:12px; color:var(--text-muted); }
        .search-form { display:flex; gap:8px; flex-wrap:wrap; align-items:center; }
        .search-form input[type="text"] { width:250px; margin:0; }
        .team-item { padding:14px 0; border-bottom:1px solid var(--border-light); }
        .team-item:last-child { border-bottom:0; }
        .team-title { font-size:16px; font-weight:600; }
        .team-title a { color:var(--text); }
        .team-title a:hover { color:var(--accent); }
        .team-meta { font-size:13px; color:var(--text-muted); margin-top:4px; }
        .tag { display:inline-block; padding:2px 10px; border-radius:12px; font-size:12px; font-weight:600; }
        .tag-join-allowed { background:#2e7d32; color:#fff; }
        .tag-join-closed { background:#95a5a6; color:#fff; }
        .page-bar { display:flex; gap:6px; margin-top:16px; flex-wrap:wrap; }
        .page-bar a { padding:6px 12px; border:1.5px solid var(--border); border-radius:20px; text-decoration:none; color:var(--text); font-size:13px; font-weight:500; background:#fff; }
        .page-bar a:hover { border-color:var(--accent); color:var(--accent); background:var(--accent-light); }
        .page-bar a.active { background:var(--accent); color:#fff; border-color:var(--accent); }
        .page-ellipsis { padding:6px 4px; color:var(--text-muted); font-size:13px; }
        @media(max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .navbar { padding:0 14px; height:48px; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= safeContent($msg) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= safeContent($error) ?></div>
        <?php endif; ?>

        <div class="flex-between" style="margin-bottom:16px;">
            <h2 style="margin:0;">团队列表</h2>
        </div>

        <!-- 搜索栏 -->
        <div class="card" style="padding:16px 20px;">
            <form method="get" action="team.php" class="search-form">
                <input type="text" name="search" placeholder="搜索团队名称或所有者" value="<?= safeContent($search) ?>">
                <button type="submit" class="btn btn-sm">搜索</button>
                <?php if (!empty($search)): ?>
                    <a href="https://lmtoj.cn/team" class="btn btn-sm btn-danger">清除</a>
                <?php endif; ?>
            </form>
        </div>

        <!-- 创建团队（仅管理员） -->
        <?php if ($is_admin): ?>
            <div class="card" id="createTeam">
                <h3>创建新团队</h3>
                <form method="post">
                    <div class="form-group">
                        <label>团队名称</label>
                        <input type="text" name="name" placeholder="输入团队名称" required maxlength="100">
                    </div>
                    <div class="form-group">
                        <label>所有者 UID</label>
                        <input type="number" name="owner_uid" placeholder="输入用户 UID" required min="1">
                        <small>请输入要设为团队所有者的用户 UID</small>
                    </div>
                    <div class="form-group">
                        <label>公告（可选）</label>
                        <textarea name="announcement" rows="4" placeholder="团队公告，支持 Markdown"></textarea>
                    </div>
                    <button type="submit" name="create_team" class="btn">创建</button>
                </form>
            </div>
        <?php endif; ?>

        <!-- 团队列表 -->
        <div class="card">
            <?php if ($teamList->num_rows == 0): ?>
                <p style="color:var(--text-muted);"><?= empty($search) ? '暂无团队' : '未找到匹配的团队' ?></p>
            <?php else: ?>
                <?php while ($t = $teamList->fetch_assoc()): ?>
                    <div class="team-item">
                        <div class="team-title">
                            <a href="https://lmtoj.cn/team/<?= $t['id'] ?>"><?= safeContent($t['name']) ?></a>
                            <!-- ★ 新增状态标签 -->
                            <?php if ($t['is_member']): ?>
                                <span class="tag tag-join-allowed">已加入</span>
                            <?php else: ?>
                                <span class="tag tag-join-closed">未加入</span>
                            <?php endif; ?>
                        </div>
                        <div class="team-meta">
                            所有者：<?= safeContent($t['owner_name']) ?> ｜ 成员数：<?= $t['member_count'] ?> ｜ 创建于：<?= date('Y-m-d', strtotime($t['created_at'])) ?>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
            <?php if ($totalPage > 1): ?>
                <div class="page-bar">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page-1 ?><?= !empty($search) ? '&search='.urlencode($search) : '' ?>">上一页</a>
                    <?php endif; ?>
                    <?php
                    $shown = [1];
                    for ($i = max(2, $page-2); $i <= min($totalPage-1, $page+2); $i++) $shown[] = $i;
                    if ($totalPage > 1) $shown[] = $totalPage;
                    $shown = array_unique($shown); sort($shown); $prev = 0;
                    foreach ($shown as $i):
                        if ($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
                    ?>
                        <a href="?page=<?= $i ?><?= !empty($search) ? '&search='.urlencode($search) : '' ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php $prev = $i; endforeach; ?>
                    <?php if ($page < $totalPage): ?>
                        <a href="?page=<?= $page+1 ?><?= !empty($search) ? '&search='.urlencode($search) : '' ?>">下一页</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>