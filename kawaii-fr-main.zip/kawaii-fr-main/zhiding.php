<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) { header("Location: login.php"); exit; }
if (isset($_GET['logout'])) { session_destroy(); header("Location: https://lmtoj.cn/login"); exit; }

$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) $is_admin = (int)$adminRes->fetch_assoc()['admin'];
if (!$is_admin) { header("Location: https://lmtoj.cn/"); exit; }

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

// 确保字段存在
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'zhiding'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE discuss ADD COLUMN zhiding TINYINT DEFAULT 0");
}

// 添加置顶
if (isset($_POST['add_zhiding']) && !empty($_POST['tid'])) {
    $tid = (int)$_POST['tid'];
    $conn->query("UPDATE discuss SET zhiding = 1 WHERE id = {$tid}");
    header("Location: https://lmtoj.cn/discuss/pin"); exit;
}

// 取消置顶
if (isset($_GET['unzhiding'])) {
    $tid = (int)$_GET['unzhiding'];
    $conn->query("UPDATE discuss SET zhiding = 0 WHERE id = {$tid}");
    header("Location: https://lmtoj.cn/discuss/pin"); exit;
}

// 置顶列表
$zhidingList = $conn->query("
    SELECT d.id, d.title, d.create_time, u.name 
    FROM discuss d 
    LEFT JOIN users u ON d.uid = u.uid 
    WHERE d.zhiding = 1 
    ORDER BY d.create_time DESC
");

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>置顶管理 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;font-weight:500;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;position:sticky;top:80px;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card h3{font-size:16px;font-weight:600;margin-bottom:14px;}
        .form-row{display:flex;gap:8px;align-items:center;margin-bottom:16px;}
        .form-row input{padding:8px 14px;border:1.5px solid var(--border);border-radius:20px;font-size:14px;outline:none;width:200px;}
        .form-row input:focus{border-color:var(--accent);}
        .btn{padding:8px 18px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:13px;font-weight:500;}
        .btn:hover{background:var(--accent-hover);}
        .btn-sm{padding:5px 12px;font-size:12px;border-radius:15px;}
        .btn-danger{background:var(--danger);}
        .btn-danger:hover{background:#c0392b;}
        .list-item{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);}
        .list-item a{color:var(--text);text-decoration:none;font-weight:500;}
        .list-item a:hover{color:var(--accent);}
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>
<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
			<div class="content">  
				<div class="card">
    				<h3>添加置顶</h3>
    				<form method="post" class="form-row">
        				<input type="number" name="tid" placeholder="输入帖子ID" required>
        				<button type="submit" name="add_zhiding" class="btn">置顶</button>
    				</form>
				</div>
    
				<div class="card">
    				<h3>已置顶帖子</h3>
    				<?php if($zhidingList->num_rows>0): while($z=$zhidingList->fetch_assoc()): ?>
    				<div class="list-item">
        				<span>
            				<a href="https://lmtoj.cn/discuss/<?=$z['id']?>"><?=safeContent($z['title'])?></a>
                			<span style="font-size:12px;color:var(--text-muted);margin-left:8px;"><?=safeContent($z['name'])?> · <?=date('m-d H:i',strtotime($z['create_time']))?></span>
        				</span>
        				<a href="https://lmtoj.cn/discuss/pin?unzhiding=<?=$z['id']?>" class="btn btn-sm btn-danger">取消置顶</a>
    				</div>
    				<?php endwhile; else:?>
                    <p style="color:var(--text-muted);">暂无置顶</p>
                    <?php endif;?>
				</div>
			</div>
            
    	</div>
	<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>