<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 自动检查并添加 description 字段（如果缺失） ----------
$descCheck = $conn->query("SHOW COLUMNS FROM contest LIKE 'description'");
if ($descCheck && $descCheck->num_rows == 0) {
    $alterSql = "ALTER TABLE contest ADD COLUMN description TEXT DEFAULT NULL COMMENT '比赛简介（支持Markdown）'";
    if (!$conn->query($alterSql)) {
        die("数据库表缺少 'description' 字段，且当前用户无 ALTER 权限。<br>
             请手动执行：<pre>ALTER TABLE contest ADD COLUMN description TEXT DEFAULT NULL COMMENT '比赛简介（支持Markdown）';</pre>");
    }
}

// ---------- 登录检查 ----------
$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ---------- 管理员权限 ----------
$is_admin = 0;
$conadmin = 0;
$adminStmt = $conn->prepare("SELECT admin, conadmin FROM users WHERE uid = ? LIMIT 1");
$adminStmt->bind_param("i", $login_uid);
$adminStmt->execute();
$adminRes = $adminStmt->get_result();
if ($adminRes && $adminRes->num_rows > 0) {
    $row = $adminRes->fetch_assoc();
    $is_admin = (int)$row['admin'];
    $conadmin = (int)$row['conadmin'];
}
$adminStmt->close();

// ---------- 未读消息数 ----------
$unreadCount = 0;
$msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
$msgStmt->bind_param("i", $login_uid);
$msgStmt->execute();
$msgRes = $msgStmt->get_result();
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}
$msgStmt->close();

// ---------- 获取比赛 ID ----------
$contest_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($contest_id <= 0) {
    header("Location: https://lmtoj.cn/404");
    exit;
}

// ---------- 查询比赛信息 ----------
$contestInfo = null;
$sql = "SELECT c.*, u.name AS creator_name 
        FROM contest c 
        LEFT JOIN users u ON c.creator = u.uid 
        WHERE c.id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $contest_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res && $res->num_rows > 0) {
    $contestInfo = $res->fetch_assoc();
} else {
    // header("Location: https://lmtoj.cn/404");
    exit;
}
$stmt->close();

$now = time();
$start_time = strtotime($contestInfo['start_time']);
$end_time = $contestInfo['end_time'] ? strtotime($contestInfo['end_time']) : null;
$is_started = ($now >= $start_time);

// ---------- 选项卡 ----------
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'problems';
$allowed_tabs = ['problems', 'submissions', 'standings'];
if ($conadmin || $contestInfo['creator'] == $login_uid) {
    $allowed_tabs[] = 'backstage';
}
if (!in_array($tab, $allowed_tabs)) {
    header("Location: 404.php");
    exit;
}

if (!$is_started && $contestInfo['creator'] != $login_uid) {
    header("Location: /contest.php");
    exit;
}

// ---------- 安全函数 ----------
function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
function formatTime($time) {
    if (empty($time)) return '-';
    return date('Y-m-d H:i', strtotime($time));
}

// ---------- 检查表是否存在 ----------
function tableExists($conn, $table) {
    $stmt = $conn->prepare("SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?");
    $stmt->bind_param("s", $table);
    $stmt->execute();
    $res = $stmt->get_result();
    $exists = ($res && $res->num_rows > 0);
    $stmt->close();
    return $exists;
}

$hasContestProblem = tableExists($conn, 'contest_problem');
$hasSubmissions = tableExists($conn, 'submissions');
$hasProblemDesc = tableExists($conn, 'problem_desc');

// ---------- 获取题目列表 ----------
$problems = [];
if ($tab === 'problems' || $tab === 'standings') {
    if ($hasContestProblem && $hasProblemDesc) {
        $sql_problems = "SELECT p.id, p.name 
                         FROM contest_problem cp 
                         LEFT JOIN problem_desc p ON cp.problem_id = p.id 
                         WHERE cp.contest_id = ? 
                         ORDER BY cp.display_order ASC";
        $stmt = $conn->prepare($sql_problems);
        $stmt->bind_param("i", $contest_id);
        $stmt->execute();
        $res_prob = $stmt->get_result();
        if ($res_prob) {
            while ($row = $res_prob->fetch_assoc()) {
                $problems[] = $row;
            }
        }
        $stmt->close();
    }
}

// ---------- 获取排行榜数据 ----------
$scoreboard = [];
if ($tab === 'standings') {
    if ($hasSubmissions) {
        $colStmt = $conn->prepare("SHOW COLUMNS FROM submissions LIKE 'contest_id'");
        $colStmt->execute();
        $colRes = $colStmt->get_result();
        $hasContestIdCol = ($colRes && $colRes->num_rows > 0);
        $colStmt->close();

        if ($hasContestIdCol) {
            $sql_score = "SELECT u.uid, u.name, 
                                 COUNT(DISTINCT CASE WHEN s.result = 'AC' THEN s.problem_id END) AS ac_count,
                                 COUNT(*) AS total_submit
                          FROM submissions s
                          LEFT JOIN users u ON s.uid = u.uid
                          WHERE s.contest_id = ?
                          GROUP BY u.uid
                          ORDER BY ac_count DESC, total_submit ASC";
            $stmt = $conn->prepare($sql_score);
            $stmt->bind_param("i", $contest_id);
            $stmt->execute();
            $res_score = $stmt->get_result();
            if ($res_score) {
                while ($row = $res_score->fetch_assoc()) {
                    $scoreboard[] = $row;
                }
            }
            $stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= safeContent($contestInfo['name']) ?> - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it@13.0.2/dist/markdown-it.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it-texmath@1.0.0/texmath.min.js"></script>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: var(--bg); font-family: var(--font); color: var(--text); line-height: 1.6; -webkit-font-smoothing: antialiased; }
        .navbar { background: var(--nav-bg); height: 54px; display: flex; align-items: center; justify-content: space-between; padding: 0 28px; color: var(--nav-text); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size: 17px; font-weight: 600; letter-spacing: 0.4px; color: #f0ece6; }
        .bell-wrap { position: relative; font-size: 20px; cursor: pointer; margin-right: 20px; width: 36px; height: 36px; display: flex; align-items: center; justify-content: center; border-radius: 50%; transition: var(--transition); user-select: none; }
        .bell-wrap:hover { background: rgba(255,255,255,0.08); }
        .red-dot { position: absolute; top: 5px; right: 5px; width: 9px; height: 9px; background: #f55353; border-radius: 50%; border: 1.5px solid #3d3a37; animation: pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%, 100% { box-shadow: 0 0 0 0 rgba(245,83,83,0.5); } 50% { box-shadow: 0 0 0 6px rgba(245,83,83,0); } }
        .user-info { display: flex; align-items: center; gap: 6px; }
        .user-info a { color: #e0dbd3; text-decoration: none; font-size: 13.5px; padding: 7px 13px; border-radius: 20px; transition: var(--transition); white-space: nowrap; font-weight: 500; }
        .user-info a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .user-info a.admin-link { color: #f5d76e; font-weight: 600; }
        .main { max-width: 1100px; margin: 28px auto 40px; display: flex; gap: 22px; padding: 0 20px; align-items: flex-start; }
        .sidebar { background: var(--card-bg); border-radius: var(--radius); box-shadow: var(--shadow); width: fit-content; min-width: 110px; overflow: hidden; position: sticky; top: 80px; flex-shrink: 0; }
        .sidebar a { display: block; padding: 13px 22px; text-align: center; background: var(--card-bg); color: var(--text); text-decoration: none; font-size: 14.5px; font-weight: 500; white-space: nowrap; transition: var(--transition); border-left: 3px solid transparent; letter-spacing: 0.3px; }
        .sidebar a:hover { background: #f5f2ed; border-left-color: var(--accent); color: var(--accent); }
        .sidebar a:first-child { border-radius: var(--radius) var(--radius) 0 0; }
        .sidebar a:last-child { border-radius: 0 0 var(--radius) var(--radius); }
        .content { flex: 1; display: flex; gap: 22px; align-items: flex-start; }
        .card { flex: 1; background: var(--card-bg); border-radius: var(--radius); padding: 26px 28px; box-shadow: var(--shadow); }
        .card h2 { font-size: 18px; font-weight: 600; margin-bottom: 16px; }
        .contest-title { text-align: center}
        .info-box { background: var(--card-bg); border-radius: var(--radius); padding: 20px 22px; box-shadow: var(--shadow); flex-shrink: 0; width: 220px; font-size: 14px; color: var(--text-secondary); line-height: 1.9; position: sticky; top: 80px; align-self: flex-start; }
        .tab-bar { display: flex; border-bottom: 2px solid var(--border); margin-bottom: 20px; }
        .tab-bar a { padding: 10px 24px; font-size: 15px; font-weight: 500; color: var(--text-secondary); text-decoration: none; border-bottom: 3px solid transparent; transition: var(--transition); }
        .tab-bar a:hover { color: var(--text); border-bottom-color: var(--accent); }
        .tab-bar a.active { color: var(--accent); border-bottom-color: var(--accent); }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: center; padding: 12px 10px; background: #f8f6f4; font-weight: 600; font-size: 13px; color: var(--text-secondary); border-bottom: 2px solid var(--border); }
        td { padding: 12px 10px; text-align: center; border-bottom: 1px solid var(--border); font-size: 14px; }
        .contest-link { color: var(--text); font-weight: 500; }
        .contest-link:hover { color: var(--accent); }
.card-info {
	position: relative;
	display: -ms-flexbox;
	display: flex;
	-ms-flex-direction: column;
	flex-direction: column;
	min-width: 0;
	word-wrap: break-word;
	background-color: #fff;
	background-clip: border-box;
	border: 1px solid rgba(0, 0, 0, .125);
	border-radius: .25rem;
}
.col-sm-3 {
	width: 25%;
}
.card-body {
	-ms-flex: 1 1 auto;
	flex: 1 1 auto;
	padding: 1.25rem;
}
.border-success {
	border-color: #28a745 !important;
}
        #description blockquote { border-left: 4px solid var(--accent); padding: 8px 14px; margin: 8px 0; background: #fafaf8; color: #5a5550; border-radius: 0 4px 4px 0; }
        #description pre { background: #2b2a27; color: #e8e4dd; padding: 14px 16px; border-radius: 4px; overflow-x: auto; margin: 8px 0; font-family: monospace; font-size: 13px; }
        #description code { font-family: monospace; background: #f3f0eb; padding: 2px 6px; border-radius: 3px; }
        #description pre code { background: transparent; padding: 0; color: inherit; }
        #description img { max-width: 100%; height: auto; border-radius: 4px; margin: 6px 0; }
        @media (max-width: 768px) {
            .main { flex-direction: column; padding: 0 12px; }
            .sidebar { width: 100%; position: static; display: flex; flex-wrap: wrap; }
            .sidebar a { flex: 1 1 auto; padding: 11px 10px; font-size: 13px; border-left: none; border-bottom: 2px solid transparent; }
            .card { padding: 18px 14px; }
            .content { flex-direction: column; gap: 16px; }
            .info-box { width: 100%; position: static; }
        }
        .h1,.h2,.h3,.h4,.h5,.h6,h1,h2,h3,h4,h5,h6{margin-bottom:.5rem;font-weight:500;line-height:1.2}.h1,h1{font-size:2.5rem}.h2,h2{font-size:2rem}.h3,h3{font-size:1.75rem}.h4,h4{font-size:1.5rem}.h5,h5{font-size:1.25rem}.h6,h6{font-size:1rem}
.btn {
	display: inline-block;
	font-weight: 400;
	color: #212529;
	text-align: center;
	vertical-align: middle;
	-webkit-user-select: none;
	-moz-user-select: none;
	-ms-user-select: none;
	user-select: none;
	background-color: transparent;
	border: 1px solid transparent;
	padding: .375rem .75rem;
	font-size: 1rem;
	line-height: 1.5;
	border-radius: .25rem;
	transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
	text-decoration: none;
}
.btn-success {
	color: #fff;
	background-color: #218838;
	border-color: #1e7e34;
}
.btn-block {
	display: block;
	width: 100%;
}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <h1 class="contest-title"><?= safeContent($contestInfo['name']) ?></h1>
            <div class="tab-bar">
                <a href="https://lmtoj.cn/contest/<?= $contest_id ?>" class="<?= $tab === 'problems' ? 'active' : '' ?>">比赛主页</a>
                <a href="https://lmtoj.cn/contest/<?= $contest_id ?>/submissions" class="<?= $tab === 'submissions' ? 'active' : '' ?>">提交记录</a>
                <a href="https://lmtoj.cn/contest/<?= $contest_id ?>/standings" class="<?= $tab === 'standings' ? 'active' : '' ?>">排行榜</a>
                <?php if ($conadmin || $contestInfo['creator'] == $login_uid): ?>
                    <a href="https://lmtoj.cn/contest/<?= $contest_id ?>/backstage" class="<?= $tab === 'backstage' ? 'active' : '' ?>">大后台</a>
                <?php endif ?>
            </div>
            <?php if ($tab === 'problems'): ?>
            <div id="description"></div>
            <script>
                const descRaw = <?= json_encode($contestInfo['description'] ?? '', JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
                const md = window.markdownit({ html: true, linkify: true, typographer: true });
                md.use(window.texmath.use(window.katex), { engine: window.katex, delimiters: 'dollars', katexOptions: { macros: { "\\RR": "\\mathbb{R}" } } });
                document.getElementById('description').innerHTML = md.render(descRaw);
            </script>
            <table>
                <tr><th>ID</th><th>题目名称</th></tr>
                <?php $cnt = 0;
                foreach ($problems as $idx => $prob): ?>
                <tr>
                    <td><?= chr($cnt + 65) ?></td>
                    <td>
                        <a href="https://lmtoj.cn/contest/<?= $contest_id ?>/problem/<?= $prob['id'] ?>" class="contest-link">
                            <?= safeContent($prob['name']) ?>
                        </a>
                    </td>
                </tr>
                <?php $cnt++;
                endforeach; ?>
            </table>
            <?php elseif ($tab === 'standings'): ?>
            <table>
                <tr><th>排名</th><th>用户</th><th>AC 题数</th><th>总提交</th></tr>
                <?php $rank = 1; foreach ($scoreboard as $row): ?>
                <tr>
                    <td><?= $rank++ ?></td>
                    <td><?= safeContent($row['name'] ?? '用户' . $row['uid']) ?></td>
                    <td><?= (int)$row['ac_count'] ?></td>
                    <td><?= (int)$row['total_submit'] ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php endif; ?>
        </div>
        <div class="col-sm-3">
        <div class="card-info border-success">
            <div style="padding: .75rem 1.25rem; margin-bottom: 0; background-color: rgba(0, 0, 0, .03); border-bottom: 1px solid rgba(0, 0, 0, .125); background-color: #28a745; !important;"><h4 id="countdown-title"></h4></div>
            <div class="card-body">
                 <div id="countdown" style="text-align: center"></div>
            </div>
        </div>
        <?php if ($contestInfo['format'] == 'OI'): ?>
            <p>此次比赛为OI赛制。</p>
	    <p><strong>注意：比赛时只显示测样例的结果。</strong></p>
        <?php elseif ($contestInfo['format'] == 'IOI'): ?>
            <p>此次比赛为IOI赛制。</p>
	    <p><strong>注意：比赛时显示测试所有数据的结果，但无法看到详细信息。</strong></p>
        <?php elseif ($contestInfo['format'] == 'ICPC'): ?>
            <p>此次比赛为ICPC赛制。</p>
	    <p><strong>注意：比赛时显示测试所有数据的结果，无法看到详细信息，且没有部分分；每道题目第一次AC前的提交记录个数乘20分钟加第一次AC的时间即为本题罚时，未通过的题目不算罚时。</strong></p>
        <?php endif ?>
        <a style="margin-top: .5rem" class="btn btn-success btn-block" href="/contest/<?= $_GET['id'] ?>/registrants">报名选手列表</a>
        <?php if ($conadmin || $contestInfo['creator'] == $login_uid): ?>
            <a style="margin-top: .5rem" class="btn btn-success btn-block" href="/contest/<?= $_GET['id'] ?>/manage">管理</a>
        <?php endif ?>
        </div>
    </div>
</div>
<script>
function toFilledStr(o, f, l) {
	var s = o.toString();
	while (s.length < l) {
		s = f.toString() + s;
	}
	return s;
}

function scoreToRGB(score) {
    let h, s, l;
    
    if (score == 0) {
        // HSV(0, 100, 80) -> 红色
        return { r: 204, g: 0, b: 0 };
    } else if (score == 100) {
        // HSV(120, 100, 80) -> 绿色
        return { r: 0, g: 204, b: 0 };
    } else {
        // HSV(30 + score * 60/100, 100, 90)
        h = 30 + score * 60 / 100;
        s = 100;
        v = 90;
        return hsvToRgb(h, s, v);
    }
}

function hsvToRgb(h, s, v) {
    h = h / 360;
    s = s / 100;
    v = v / 100;
    
    let r, g, b;
    const i = Math.floor(h * 6);
    const f = h * 6 - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    
    switch (i % 6) {
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        case 5: r = v; g = p; b = q; break;
    }
    
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}
function getColOfScore(score) {
    const rgb = scoreToRGB(score);
    return `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
}

const startTime = <?= strtotime($contestInfo['start_time']) * 1000 ?>;
const endTime = <?= $contestInfo['end_time'] ? strtotime($contestInfo['end_time']) * 1000 : 0 ?>;
const countdownTi = document.getElementById('countdown-title');
const countdownEl = document.getElementById('countdown');
function updateCountdown() {
    const now = Date.now();
    let target = 0, prefix = '';
    if (now < startTime) {
        target = startTime;
        prefix = '距离比赛开始';
        countdownEl.classList.remove('ended');
    } else if (endTime > 0 && now < endTime) {
        target = endTime;
        prefix = '距离比赛结束';
        countdownEl.classList.remove('ended');
    } else {
        countdownTi.textContent = '比赛已结束';
        countdownEl.classList.add('ended');
        document.querySelectorAll('.card-body')[0].remove();
        return;
    }
    const diff = target - now;
    if (diff <= 0) {
        countdownTi.textContent = '比赛已结束';
        countdownEl.classList.add('ended');
        document.querySelectorAll('.card-body')[0].remove();
        return;
    }
    countdownTi.textContent = prefix;
    var x = Math.floor(diff / 1000);
	var ss = toFilledStr(x % 60, '0', 2);
	x = Math.floor(x / 60);
	var mm = toFilledStr(x % 60, '0', 2);
	x = Math.floor(x / 60);
	var hh = x.toString();
	
	var res = '<span style="font-size:30px">';
	res += '<span style="color:' + getColOfScore(Math.min(diff / 1000 / 10800 * 100, 100)) + '">' + hh + '</span>';
	res += ':';
	res += '<span style="color:' + getColOfScore(mm / 60 * 100) + '">' + mm + '</span>';
	res += ':';
	res += '<span style="color:' + getColOfScore(ss / 60 * 100) + '">' + ss + '</span>';
	res += '</span>'
    countdownEl.innerHTML = res;
}
updateCountdown();
setInterval(updateCountdown, 1000);
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>