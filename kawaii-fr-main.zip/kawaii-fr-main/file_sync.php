<?php
declare(strict_types=1);

session_start();

error_reporting(E_ALL);
ini_set('display_errors', '1'); // 正式环境建议设为 0

date_default_timezone_set('Asia/Shanghai');

/* =========================================================
 * Authorization
 * ========================================================= */

require_once __DIR__ . '/database.php';

$conn = db();

if ($conn->connect_error) {
    http_response_code(500);
    exit('数据库连接失败');
}

$conn->set_charset('utf8mb4');

if (!isset($_SESSION['uid'])) {
    header('Location: https://lmtoj.cn/login');
    exit;
}

$loginUid = (int) $_SESSION['uid'];

$authResult = $conn->query(
    "SELECT devadmin FROM users WHERE uid={$loginUid} LIMIT 1"
);

$authUser = $authResult
    ? $authResult->fetch_assoc()
    : null;

if (
    !$authUser
    && (int) $authUser['devadmin'] !== 1
) {
    header('Location: https://lmtoj.cn');
    exit;
}

$conn->close();

if (!class_exists('ZipArchive')) {
    http_response_code(500);
    exit('服务器未启用 ZipArchive 扩展。');
}

/* =========================================================
 * Configuration
 * ========================================================= */

$root = realpath(__DIR__);

if ($root === false) {
    http_response_code(500);
    exit('无法确定网站根目录。');
}

$maxUploadBytes = 8 * 1024 * 1024;
$maxExtractedBytes = 500 * 1024 * 1024;
$maxFileCount = 20000;

/*
 * 明确排除的顶层目录。
 *
 * 这些目录不会参与同步，也不会进入递归扫描。
 */
$excludedTopLevel = [
    '.git',
    '.svn',
    '.file_sync_data',
    '.preview_backups',
    'tmp',
    '.Recycle_bin'
];

/*
 * 明确排除的文件。
 */
$excludedFiles = [];

/*
 * 当前 Session 对应的临时工作目录。
 */
$runtimeBase =
    sys_get_temp_dir()
    . DIRECTORY_SEPARATOR
    . 'lmtoj_file_sync_'
    . hash('sha256', session_id());

/*
 * CSRF Token
 */
if (empty($_SESSION['file_sync_csrf'])) {
    $_SESSION['file_sync_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf =
    (string) $_SESSION['file_sync_csrf'];


/* =========================================================
 * Helpers
 * ========================================================= */

function h(string $value): string
{
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}

function normalizePath(string $path): string
{
    $path = str_replace('\\', '/', $path);

    $path = preg_replace(
        '#/+#',
        '/',
        $path
    );

    return trim($path, '/');
}

function isSafeRelativePath(string $path): bool
{
    if (
        $path === ''
        || strpos($path, "\0") !== false
    ) {
        return false;
    }

    $path = str_replace(
        '\\',
        '/',
        $path
    );

    /*
     * 禁止绝对路径
     */
    if (
        $path[0] === '/'
        || preg_match(
            '/^[A-Za-z]:/',
            $path
        )
    ) {
        return false;
    }

    /*
     * 禁止 ..
     */
    foreach (explode('/', $path) as $part) {
        if ($part === '..') {
            return false;
        }
    }

    return true;
}

function isExcluded(
    string $relative,
    array $excludedTopLevel,
    array $excludedFiles
): bool {
    $relative = normalizePath($relative);

    if ($relative === '') {
        return false;
    }

    $parts = explode('/', $relative);

    /*
     * 顶层目录排除
     */
    if (
        in_array(
            $parts[0],
            $excludedTopLevel,
            true
        )
    ) {
        return true;
    }

    /*
     * 指定文件排除
     */
    return in_array(
        $relative,
        $excludedFiles,
        true
    );
}

function isSyncPath(string $relative): bool
{
    $relative = normalizePath($relative);

    /*
     * 所有 PHP 文件
     */
    if (
        strtolower(
            (string) pathinfo(
                $relative,
                PATHINFO_EXTENSION
            )
        ) === 'php'
    ) {
        return true;
    }

    /*
     * 指定 .htaccess
     */
    return in_array(
        $relative,
        [
            'testdata/.htaccess',
            'upload/img/.htaccess',
        ],
        true
    );
}

/**
 * 判断目录是否真的可以读取。
 *
 * 某些 Linux 权限环境下 is_readable()
 * 可能不足以完全反映实际情况，因此这里
 * 再尝试 opendir()。
 */
function canReadDirectory(string $path): bool
{
    if (!is_dir($path)) {
        return false;
    }

    if (!is_readable($path)) {
        return false;
    }

    $handle = @opendir($path);

    if ($handle === false) {
        return false;
    }

    closedir($handle);

    return true;
}

/**
 * 扫描网站文件。
 *
 * 重要：
 *
 * 1. 已知排除目录不会进入；
 * 2. 无权限目录自动跳过；
 * 3. 无权限文件自动跳过；
 * 4. 单个坏文件不会导致整个扫描失败；
 * 5. 只返回需要同步的文件。
 */
function scanFiles(
    string $base,
    array $excludedTopLevel,
    array $excludedFiles
): array {
    $result = [];

    /*
     * 创建根目录迭代器。
     *
     * 根目录本身正常情况下应该有权限。
     */
    try {
        $directoryIterator =
            new RecursiveDirectoryIterator(
                $base,
                FilesystemIterator::SKIP_DOTS
            );
    } catch (Throwable $e) {
        throw new RuntimeException(
            '无法读取网站根目录：'
            . $e->getMessage(),
            0,
            $e
        );
    }

    /*
     * 过滤器。
     *
     * 关键点：
     * 对目录进行过滤时就阻止递归进入。
     */
    $filter =
        new RecursiveCallbackFilterIterator(
            $directoryIterator,
            function (
                SplFileInfo $current
            ) use (
                $base,
                $excludedTopLevel,
                $excludedFiles
            ): bool {

                try {
                    $full =
                        $current->getPathname();

                    $relative =
                        normalizePath(
                            substr(
                                $full,
                                strlen($base)
                            )
                        );

                    /*
                     * 根目录
                     */
                    if ($relative === '') {
                        return true;
                    }

                    /*
                     * 第一层目录。
                     *
                     * 例如：
                     *
                     * .Recycle_bin/a.php
                     *
                     * 第一层就是 .Recycle_bin
                     */
                    $parts =
                        explode(
                            '/',
                            $relative
                        );

                    $topLevel =
                        $parts[0] ?? '';

                    /*
                     * 已知排除目录。
                     *
                     * 必须在这里 return false，
                     * 才能阻止 RecursiveIteratorIterator
                     * 进入这个目录。
                     */
                    if (
                        $current->isDir()
                        && in_array(
                            $topLevel,
                            $excludedTopLevel,
                            true
                        )
                    ) {
                        return false;
                    }

                    /*
                     * 已知排除路径
                     */
                    if (
                        isExcluded(
                            $relative,
                            $excludedTopLevel,
                            $excludedFiles
                        )
                    ) {
                        return false;
                    }

                    /*
                     * 如果是目录：
                     *
                     * 自动检查权限。
                     *
                     * 这样即使出现：
                     *
                     * .backup-markdown-assets-20260806T2030CST
                     *
                     * 这种我们根本不知道名字的目录，
                     * 也不会因为 Permission denied
                     * 导致整个扫描失败。
                     */
                    if ($current->isDir()) {
                        return canReadDirectory(
                            $full
                        );
                    }

                    /*
                     * 文件也检查读取权限。
                     */
                    if ($current->isFile()) {
                        return is_readable($full);
                    }

                    /*
                     * 其他特殊文件不处理。
                     */
                    return false;

                } catch (Throwable $e) {
                    /*
                     * 某个特殊目录/文件访问失败，
                     * 直接跳过。
                     */
                    return false;
                }
            }
        );

    /*
     * LEAVES_ONLY：
     * 我们最终只处理文件。
     */
    $iterator =
        new RecursiveIteratorIterator(
            $filter,
            RecursiveIteratorIterator::LEAVES_ONLY
        );

    /*
     * 即使迭代器本身出现异常，
     * 也尽量保留已经扫描出来的结果。
     */
    try {

        foreach ($iterator as $info) {

            try {

                /*
                 * 只处理普通文件。
                 */
                if (
                    !$info->isFile()
                    || $info->isLink()
                ) {
                    continue;
                }

                $full =
                    $info->getPathname();

                /*
                 * 文件不可读就跳过。
                 */
                if (!is_readable($full)) {
                    continue;
                }

                $relative =
                    normalizePath(
                        substr(
                            $full,
                            strlen($base)
                        )
                    );

                if ($relative === '') {
                    continue;
                }

                /*
                 * 再检查排除规则。
                 */
                if (
                    isExcluded(
                        $relative,
                        $excludedTopLevel,
                        $excludedFiles
                    )
                ) {
                    continue;
                }

                /*
                 * 只同步 PHP 和指定 .htaccess。
                 */
                if (!isSyncPath($relative)) {
                    continue;
                }

                /*
                 * 计算 SHA256。
                 */
                $hash =
                    @hash_file(
                        'sha256',
                        $full
                    );

                /*
                 * 单个文件读取失败：
                 * 跳过，不影响其他文件。
                 */
                if ($hash === false) {
                    continue;
                }

                $result[$relative] = [
                    'hash' => $hash,
                    'size' => (int) $info->getSize(),
                    'path' => $full,
                ];

            } catch (Throwable $e) {
                /*
                 * 单个文件异常，跳过。
                 */
                continue;
            }
        }

    } catch (Throwable $e) {
        /*
         * 迭代过程中某个特殊目录突然不可访问：
         *
         * 不让整个扫描失败。
         *
         * 已经获得的文件继续使用。
         */
    }

    ksort(
        $result,
        SORT_STRING
    );

    return $result;
}

function removeTree(string $path): void
{
    if (!file_exists($path)) {
        return;
    }

    if (
        is_file($path)
        || is_link($path)
    ) {
        @unlink($path);
        return;
    }

    try {
        $items =
            new FilesystemIterator(
                $path,
                FilesystemIterator::SKIP_DOTS
            );

        foreach ($items as $item) {
            removeTree(
                $item->getPathname()
            );
        }

    } catch (Throwable $e) {
        /*
         * 临时目录清理失败不影响主流程。
         */
    }

    @rmdir($path);
}

function ensureDirectory(string $path): void
{
    if (
        !is_dir($path)
        && !mkdir(
            $path,
            0755,
            true
        )
        && !is_dir($path)
    ) {
        throw new RuntimeException(
            '无法创建目录：' . $path
        );
    }
}

function checkCsrf(string $expected): void
{
    $given =
        $_POST['csrf'] ?? '';

    if (
        !hash_equals(
            $expected,
            (string) $given
        )
    ) {
        http_response_code(403);

        exit(
            '请求校验失败，请刷新页面后重试。'
        );
    }
}

function formatBytes(int $bytes): string
{
    $units = [
        'B',
        'KB',
        'MB',
        'GB'
    ];

    $value = (float) $bytes;

    $i = 0;

    while (
        $value >= 1024
        && $i < count($units) - 1
    ) {
        $value /= 1024;
        $i++;
    }

    return number_format(
        $value,
        $i === 0 ? 0 : 2
    )
    . ' '
    . $units[$i];
}

function dispositionName(
    string $name
): string {
    return
        "filename*=UTF-8''"
        . rawurlencode($name);
}

function sendFile(
    string $path,
    string $downloadName,
    string $contentType
): void {

    if (!is_file($path)) {
        http_response_code(404);

        exit(
            '文件不存在或已经过期。'
        );
    }

    header(
        'Content-Type: '
        . $contentType
    );

    header(
        'Content-Disposition: attachment; '
        . dispositionName($downloadName)
    );

    header(
        'Content-Length: '
        . filesize($path)
    );

    header(
        'X-Content-Type-Options: nosniff'
    );

    readfile($path);

    exit;
}


/* =========================================================
 * Download workspace
 * ========================================================= */

function downloadWorkspace(
    string $root,
    array $excludedTopLevel,
    array $excludedFiles
): void {

    $files =
        scanFiles(
            $root,
            $excludedTopLevel,
            $excludedFiles
        );

    $tmpDir =
        sys_get_temp_dir();

    $temp =
        tempnam(
            $tmpDir,
            'lmtoj_download_'
        );

    if ($temp === false) {
        throw new RuntimeException(
            '无法创建临时文件。'
        );
    }

    @unlink($temp);

    $zipPath =
        $temp . '.zip';

    $zip =
        new ZipArchive();

    if (
        $zip->open(
            $zipPath,
            ZipArchive::CREATE
            | ZipArchive::OVERWRITE
        ) !== true
    ) {
        throw new RuntimeException(
            '无法创建 ZIP 文件。'
        );
    }

    $manifestFiles = [];

    foreach ($files as $relative => $meta) {

        if (
            !$zip->addFile(
                $meta['path'],
                $relative
            )
        ) {
            $zip->close();

            @unlink($zipPath);

            throw new RuntimeException(
                '无法加入 ZIP：'
                . $relative
            );
        }

        $manifestFiles[$relative] = [
            'sha256' => $meta['hash'],
            'size' => $meta['size'],
        ];
    }

    $manifest = [
        'format' => 1,
        'created_at' => date(DATE_ATOM),
        'algorithm' => 'sha256',
        'files' => $manifestFiles,
    ];

    $json =
        json_encode(
            $manifest,
            JSON_PRETTY_PRINT
            | JSON_UNESCAPED_SLASHES
            | JSON_UNESCAPED_UNICODE
        );

    if (
        $json === false
        || !$zip->addFromString(
            '.sync/baseline.json',
            $json
        )
    ) {
        $zip->close();

        @unlink($zipPath);

        throw new RuntimeException(
            '无法写入同步基准。'
        );
    }

    $zip->close();

    register_shutdown_function(
        static function () use ($zipPath): void {
            @unlink($zipPath);
        }
    );

    sendFile(
        $zipPath,
        'lmtoj-workspace-'
        . date('Ymd-His')
        . '.zip',
        'application/zip'
    );
}


/* =========================================================
 * Extract uploaded workspace
 * ========================================================= */

function extractUploadedWorkspace(
    string $uploadedPath,
    string $runtimeBase,
    int $maxExtractedBytes,
    int $maxFileCount
): array {

    removeTree($runtimeBase);

    $rawDir =
        $runtimeBase
        . DIRECTORY_SEPARATOR
        . 'raw';

    ensureDirectory($rawDir);

    $zip =
        new ZipArchive();

    if (
        $zip->open($uploadedPath) !== true
    ) {
        throw new RuntimeException(
            '上传文件不是有效的 ZIP。'
        );
    }

    if (
        $zip->numFiles
        > $maxFileCount
    ) {
        $zip->close();

        throw new RuntimeException(
            'ZIP 内文件数量超过限制。'
        );
    }

    $total = 0;

    $manifestEntries = [];

    for (
        $i = 0;
        $i < $zip->numFiles;
        $i++
    ) {

        $stat =
            $zip->statIndex($i);

        if (
            !$stat
            || !isset($stat['name'])
        ) {
            $zip->close();

            throw new RuntimeException(
                'ZIP 目录损坏。'
            );
        }

        $entry =
            str_replace(
                '\\',
                '/',
                (string) $stat['name']
            );

        if (
            !isSafeRelativePath(
                rtrim(
                    $entry,
                    '/'
                )
            )
        ) {
            $zip->close();

            throw new RuntimeException(
                'ZIP 包含不安全路径：'
                . $entry
            );
        }

        $total +=
            isset($stat['size'])
            ? (int) $stat['size']
            : 0;

        if (
            $total
            > $maxExtractedBytes
        ) {
            $zip->close();

            throw new RuntimeException(
                'ZIP 解压后大小超过限制。'
            );
        }

        if (
            substr(
                $entry,
                -strlen(
                    '.sync/baseline.json'
                )
            )
            === '.sync/baseline.json'
        ) {
            $manifestEntries[] =
                rtrim(
                    $entry,
                    '/'
                );
        }
    }

    if (
        count($manifestEntries) !== 1
    ) {
        $zip->close();

        throw new RuntimeException(
            'ZIP 中必须包含且只能包含一个 .sync/baseline.json。'
        );
    }

    $manifestEntry =
        $manifestEntries[0];

    $marker =
        '.sync/baseline.json';

    $prefix =
        substr(
            $manifestEntry,
            0,
            strlen($manifestEntry)
            - strlen($marker)
        );

    for (
        $i = 0;
        $i < $zip->numFiles;
        $i++
    ) {

        $stat =
            $zip->statIndex($i);

        $entry =
            str_replace(
                '\\',
                '/',
                (string) $stat['name']
            );

        if (
            $prefix !== ''
            && strpos(
                $entry,
                $prefix
            ) !== 0
        ) {
            continue;
        }

        $relative =
            $prefix === ''
            ? $entry
            : substr(
                $entry,
                strlen($prefix)
            );

        $relative =
            normalizePath($relative);

        if ($relative === '') {
            continue;
        }

        $destination =
            $rawDir
            . DIRECTORY_SEPARATOR
            . str_replace(
                '/',
                DIRECTORY_SEPARATOR,
                $relative
            );

        if (
            substr($entry, -1) === '/'
        ) {
            ensureDirectory(
                $destination
            );

            continue;
        }

        ensureDirectory(
            dirname($destination)
        );

        $source =
            $zip->getStream(
                (string) $stat['name']
            );

        if ($source === false) {
            $zip->close();

            throw new RuntimeException(
                '无法读取 ZIP 文件：'
                . $relative
            );
        }

        $target =
            fopen(
                $destination,
                'wb'
            );

        if ($target === false) {
            fclose($source);
            $zip->close();

            throw new RuntimeException(
                '无法解压文件：'
                . $relative
            );
        }

        stream_copy_to_stream(
            $source,
            $target
        );

        fclose($source);
        fclose($target);
    }

    $zip->close();

    $manifestPath =
        $rawDir
        . DIRECTORY_SEPARATOR
        . '.sync'
        . DIRECTORY_SEPARATOR
        . 'baseline.json';

    $manifestRaw =
        @file_get_contents(
            $manifestPath
        );

    $manifest =
        $manifestRaw === false
        ? null
        : json_decode(
            $manifestRaw,
            true
        );

    if (
        !is_array($manifest)
        || (int) (
            $manifest['format']
            ?? 0
        ) !== 1
        || !is_array(
            $manifest['files']
            ?? null
        )
    ) {
        throw new RuntimeException(
            'baseline.json 格式无效。'
        );
    }

    $baseline = [];

    foreach (
        $manifest['files']
        as $relative => $meta
    ) {

        $relative =
            normalizePath(
                (string) $relative
            );

        $hash =
            is_array($meta)
            ? (string) (
                $meta['sha256']
                ?? ''
            )
            : '';

        if (
            !isSafeRelativePath($relative)
            || !preg_match(
                '/^[a-f0-9]{64}$/',
                $hash
            )
        ) {
            throw new RuntimeException(
                'baseline.json 包含无效条目。'
            );
        }

        if (
            !isSyncPath($relative)
        ) {
            continue;
        }

        $baseline[$relative] =
            $hash;
    }

    return [
        $rawDir,
        $baseline,
        (string) (
            $manifest['created_at']
            ?? '未知'
        )
    ];
}


/* =========================================================
 * Build three-way synchronization plan
 * ========================================================= */

function buildPlan(
    array $baseline,
    array $local,
    array $server
): array {

    $paths =
        array_unique(
            array_merge(
                array_keys($baseline),
                array_keys($local),
                array_keys($server)
            )
        );

    sort(
        $paths,
        SORT_STRING
    );

    $plan = [];

    foreach ($paths as $path) {

        $b =
            $baseline[$path]
            ?? null;

        $l =
            isset($local[$path])
            ? $local[$path]['hash']
            : null;

        $s =
            isset($server[$path])
            ? $server[$path]['hash']
            : null;

        $action = 'keep';
        $reason = '未变化';

        /*
         * 基准中不存在：
         * 说明文件是在基准之后新增的。
         */
        if ($b === null) {

            if (
                $l !== null
                && $s === null
            ) {
                $action = 'upload';
                $reason = '本地新增';

            } elseif (
                $l === null
                && $s !== null
            ) {
                $action = 'server';
                $reason = '服务器新增';

            } elseif (
                $l !== null
                && $s !== null
                && $l !== $s
            ) {
                $action = 'conflict';

                $reason =
                    '双方新增同名文件，保留服务器版本';
            }

        } else {

            $localChanged =
                $l !== $b;

            $serverChanged =
                $s !== $b;

            /*
             * 双方都没有修改
             */
            if (
                !$localChanged
                && !$serverChanged
            ) {
                $action = 'keep';
                $reason = '未变化';

            /*
             * 只有本地修改
             */
            } elseif (
                $localChanged
                && !$serverChanged
            ) {

                if ($l === null) {
                    $action = 'delete';
                    $reason =
                        '本地删除，服务器未修改';
                } else {
                    $action = 'upload';
                    $reason =
                        '本地修改，服务器未修改';
                }

            /*
             * 只有服务器修改
             */
            } elseif (
                !$localChanged
                && $serverChanged
            ) {

                $action = 'server';

                $reason =
                    $s === null
                    ? '服务器已删除，本地未修改'
                    : '服务器修改，本地未修改';

            /*
             * 双方都修改
             */
            } else {

                if ($l === $s) {
                    $action = 'keep';

                    $reason =
                        '双方修改后的内容相同';

                } else {
                    $action = 'conflict';

                    $reason =
                        '服务器和本地均有修改，保留服务器版本';
                }
            }
        }

        $plan[] = [
            'path' => $path,
            'action' => $action,
            'reason' => $reason
        ];
    }

    return $plan;
}

function planCounts(
    array $plan
): array {

    $counts = [
        'upload' => 0,
        'delete' => 0,
        'server' => 0,
        'conflict' => 0,
        'keep' => 0
    ];

    foreach ($plan as $item) {
        if (
            isset(
                $counts[$item['action']]
            )
        ) {
            $counts[
                $item['action']
            ]++;
        }
    }

    return $counts;
}


/* =========================================================
 * Backup
 * ========================================================= */

function createBackup(
    string $runtimeBase,
    array $plan,
    array $server
): ?string {

    $affected = [];

    foreach ($plan as $item) {

        if (
            (
                $item['action'] === 'upload'
                || $item['action'] === 'delete'
            )
            && isset(
                $server[$item['path']]
            )
        ) {
            $affected[
                $item['path']
            ] =
                $server[$item['path']];
        }
    }

    if (!$affected) {
        return null;
    }

    ensureDirectory(
        $runtimeBase
    );

    $backup =
        $runtimeBase
        . DIRECTORY_SEPARATOR
        . 'server-backup-'
        . date('Ymd-His')
        . '.zip';

    $zip =
        new ZipArchive();

    if (
        $zip->open(
            $backup,
            ZipArchive::CREATE
            | ZipArchive::OVERWRITE
        ) !== true
    ) {
        throw new RuntimeException(
            '无法创建服务器备份。'
        );
    }

    foreach (
        $affected
        as $relative => $meta
    ) {

        if (
            !$zip->addFile(
                $meta['path'],
                $relative
            )
        ) {
            $zip->close();

            throw new RuntimeException(
                '无法备份：'
                . $relative
            );
        }
    }

    $zip->close();

    return $backup;
}


/* =========================================================
 * Apply plan
 * ========================================================= */

function applyPlan(
    string $root,
    string $localRoot,
    array $plan,
    array $local
): array {

    $applied = [];

    foreach ($plan as $item) {

        $relative =
            $item['path'];

        $destination =
            $root
            . DIRECTORY_SEPARATOR
            . str_replace(
                '/',
                DIRECTORY_SEPARATOR,
                $relative
            );

        /*
         * 上传本地版本
         */
        if (
            $item['action']
            === 'upload'
        ) {

            if (
                !isset(
                    $local[$relative]
                )
            ) {
                throw new RuntimeException(
                    '本地暂存文件缺失：'
                    . $relative
                );
            }

            ensureDirectory(
                dirname($destination)
            );

            $temp =
                $destination
                . '.file-sync-'
                . bin2hex(
                    random_bytes(5)
                )
                . '.tmp';

            if (
                !copy(
                    $local[$relative]['path'],
                    $temp
                )
            ) {
                throw new RuntimeException(
                    '无法暂存文件：'
                    . $relative
                );
            }

            /*
             * 保留原文件权限。
             */
            if (
                is_file($destination)
            ) {
                @chmod(
                    $temp,
                    fileperms(
                        $destination
                    ) & 0777
                );
            }

            /*
             * 原子替换。
             */
            if (
                !rename(
                    $temp,
                    $destination
                )
            ) {
                @unlink($temp);

                throw new RuntimeException(
                    '无法替换服务器文件：'
                    . $relative
                );
            }

            $applied[] = [
                'path' => $relative,
                'result' =>
                    '已上传本地版本'
            ];

        /*
         * 删除服务器文件
         */
        } elseif (
            $item['action']
            === 'delete'
        ) {

            if (
                is_file($destination)
                && !unlink($destination)
            ) {
                throw new RuntimeException(
                    '无法删除服务器文件：'
                    . $relative
                );
            }

            $applied[] = [
                'path' => $relative,
                'result' =>
                    '已按本地状态删除'
            ];
        }
    }

    return $applied;
}


/* =========================================================
 * Request handling
 * ========================================================= */

$action =
    $_GET['action'] ?? '';

$error = '';
$notice = '';

$preview = null;
$report = null;

try {

    /* -----------------------------------------------------
     * Download
     * ----------------------------------------------------- */

    if (
        $action === 'download'
        && $_SERVER['REQUEST_METHOD']
            === 'POST'
    ) {

        checkCsrf($csrf);

        downloadWorkspace(
            $root,
            $excludedTopLevel,
            $excludedFiles
        );
    }

    /* -----------------------------------------------------
     * Upload
     * ----------------------------------------------------- */

    if (
        $action === 'upload'
        && $_SERVER['REQUEST_METHOD']
            === 'POST'
    ) {

        checkCsrf($csrf);

        if (
            empty(
                $_FILES['workspace']
            )
        ) {
            throw new RuntimeException(
                '请选择工作区 ZIP。'
            );
        }

        $upload =
            $_FILES['workspace'];

        if (
            (int) (
                $upload['error']
                ?? UPLOAD_ERR_NO_FILE
            )
            !== UPLOAD_ERR_OK
        ) {
            throw new RuntimeException(
                'ZIP 上传失败，错误代码：'
                . (int) (
                    $upload['error']
                    ?? -1
                )
            );
        }

        if (
            (int) (
                $upload['size']
                ?? 0
            )
            > $maxUploadBytes
        ) {
            throw new RuntimeException(
                '上传文件超过 '
                . formatBytes(
                    $maxUploadBytes
                )
                . ' 限制。'
            );
        }

        [
            $localRoot,
            $baseline,
            $baselineTime
        ] =
            extractUploadedWorkspace(
                (string)
                    $upload['tmp_name'],
                $runtimeBase,
                $maxExtractedBytes,
                $maxFileCount
            );

        /*
         * 扫描上传的工作区。
         */
        $local =
            scanFiles(
                $localRoot,
                array_unique(
                    array_merge(
                        ['.sync'],
                        $excludedTopLevel
                    )
                ),
                []
            );

        /*
         * 扫描服务器。
         */
        $server =
            scanFiles(
                $root,
                $excludedTopLevel,
                $excludedFiles
            );

        /*
         * 三方比较。
         */
        $plan =
            buildPlan(
                $baseline,
                $local,
                $server
            );

        /*
         * 保存待确认任务。
         */
        $_SESSION[
            'file_sync_pending'
        ] = [
            'runtime' =>
                $runtimeBase,

            'local_root' =>
                $localRoot,

            'baseline' =>
                $baseline,

            'baseline_time' =>
                $baselineTime,

            'created_at' =>
                time(),
        ];

        $preview = [
            'plan' =>
                $plan,

            'counts' =>
                planCounts($plan),

            'baseline_time' =>
                $baselineTime,
        ];
    }

    /* -----------------------------------------------------
     * Apply
     * ----------------------------------------------------- */

    if (
        $action === 'apply'
        && $_SERVER['REQUEST_METHOD']
            === 'POST'
    ) {

        checkCsrf($csrf);

        $pending =
            $_SESSION[
                'file_sync_pending'
            ] ?? null;

        if (
            !is_array($pending)
            || !isset(
                $pending['local_root'],
                $pending['baseline'],
                $pending['created_at']
            )
        ) {
            throw new RuntimeException(
                '没有待确认的同步任务，请重新上传 ZIP。'
            );
        }

        /*
         * 预览最多保留一小时。
         */
        if (
            (int)
                $pending['created_at']
            < time() - 3600
            || !is_dir(
                (string)
                    $pending['local_root']
            )
        ) {

            unset(
                $_SESSION[
                    'file_sync_pending'
                ]
            );

            throw new RuntimeException(
                '同步预览已过期，请重新上传 ZIP。'
            );
        }

        /*
         * 再次扫描本地。
         */
        $local =
            scanFiles(
                (string)
                    $pending['local_root'],
                array_unique(
                    array_merge(
                        ['.sync'],
                        $excludedTopLevel
                    )
                ),
                []
            );

        /*
         * 再次扫描服务器。
         *
         * 这是为了避免：
         *
         * 上传 ZIP
         * ↓
         * 等了一会儿
         * ↓
         * 管理员修改服务器文件
         * ↓
         * 点击确认
         *
         * 时覆盖管理员刚修改的内容。
         */
        $server =
            scanFiles(
                $root,
                $excludedTopLevel,
                $excludedFiles
            );

        /*
         * 重新计算 Diff。
         */
        $plan =
            buildPlan(
                (array)
                    $pending['baseline'],
                $local,
                $server
            );

        /*
         * 先备份。
         */
        $backup =
            createBackup(
                $runtimeBase,
                $plan,
                $server
            );

        $_SESSION[
            'file_sync_backup'
        ] = $backup;

        /*
         * 执行。
         */
        $applied =
            applyPlan(
                $root,
                (string)
                    $pending['local_root'],
                $plan,
                $local
            );

        unset(
            $_SESSION[
                'file_sync_pending'
            ]
        );

        $report = [
            'plan' =>
                $plan,

            'counts' =>
                planCounts($plan),

            'applied' =>
                $applied,

            'backup' =>
                $backup,
        ];

        $notice =
            '同步完成。请查看下方报告，并重新下载工作区以建立新的基准。';
    }

    /* -----------------------------------------------------
     * Download backup
     * ----------------------------------------------------- */

    if (
        $action === 'backup'
        && $_SERVER['REQUEST_METHOD']
            === 'POST'
    ) {

        checkCsrf($csrf);

        $backup =
            $_SESSION[
                'file_sync_backup'
            ] ?? null;

        if (
            !is_string($backup)
            || !is_file($backup)
        ) {
            throw new RuntimeException(
                '没有可下载的备份，或备份已经过期。'
            );
        }

        sendFile(
            $backup,
            basename($backup),
            'application/zip'
        );
    }

} catch (Throwable $e) {

    /*
     * 所有异常最终显示在页面上。
     */
    $error =
        $e->getMessage();
}


/* =========================================================
 * Page data
 * ========================================================= */

$shown =
    $report ?: $preview;

$labels = [

    'upload' => [
        '本地版本',
        'green'
    ],

    'delete' => [
        '删除',
        'orange'
    ],

    'server' => [
        '服务器版本',
        'blue'
    ],

    'conflict' => [
        '冲突：服务器优先',
        'red'
    ],

    'keep' => [
        '不变',
        'gray'
    ],
];

?>

<!doctype html>

<html lang="zh-CN">

<head>

    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width,initial-scale=1"
    >

    <title>文件三方同步</title>

    <style>

        :root {
            --bg:#f6f7f9;
            --card:#fff;
            --text:#20242a;
            --muted:#69717d;
            --line:#e3e6ea;
            --primary:#3867d6;
            --danger:#c0392b;
            --green:#238636;
            --orange:#b45f06;
            --blue:#2457a6;
            --red:#b42318;
            --gray:#667085;
        }

        * {
            box-sizing:border-box;
        }

        body {
            margin:0;
            background:var(--bg);
            color:var(--text);
            font-family:
                system-ui,
                -apple-system,
                "Segoe UI",
                "Microsoft YaHei",
                sans-serif;
            line-height:1.55;
        }

        .wrap {
            max-width:1100px;
            margin:36px auto;
            padding:0 18px;
        }

        .top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            gap:16px;
            margin-bottom:22px;
        }

        .top h1 {
            font-size:25px;
            margin:0;
        }

        .top a {
            color:var(--primary);
            text-decoration:none;
        }

        .card {
            background:var(--card);
            border:1px solid var(--line);
            border-radius:12px;
            padding:22px;
            margin-bottom:18px;
            box-shadow:
                0 2px 10px rgba(0,0,0,.035);
        }

        h2 {
            font-size:18px;
            margin:0 0 10px;
        }

        .muted {
            color:var(--muted);
            font-size:14px;
        }

        .steps {
            display:grid;
            grid-template-columns:
                repeat(2,minmax(0,1fr));
            gap:18px;
        }

        .btn {
            display:inline-block;
            border:0;
            border-radius:7px;
            padding:10px 16px;
            background:#edf0f4;
            color:#20242a;
            font-size:14px;
            font-weight:600;
            cursor:pointer;
            text-decoration:none;
        }

        .btn-primary {
            background:var(--primary);
            color:#fff;
        }

        .btn-danger {
            background:var(--danger);
            color:#fff;
        }

        .btn:disabled {
            opacity:.6;
            cursor:not-allowed;
        }

        input[type=file] {
            display:block;
            width:100%;
            padding:12px;
            border:1px dashed #b9c0ca;
            border-radius:8px;
            margin:12px 0;
            background:#fafbfc;
        }

        .alert {
            padding:13px 15px;
            border-radius:8px;
            margin-bottom:18px;
        }

        .alert.error {
            background:#fff0ef;
            color:#9d2118;
            border:1px solid #f0c1bc;
        }

        .alert.ok {
            background:#edf8ef;
            color:#176b2b;
            border:1px solid #b9dfc1;
        }

        .warning {
            background:#fff8e7;
            border:1px solid #f0d79b;
            padding:12px 14px;
            border-radius:8px;
            color:#72510c;
            font-size:14px;
        }

        .counts {
            display:flex;
            gap:9px;
            flex-wrap:wrap;
            margin:14px 0;
        }

        .pill,
        .tag {
            display:inline-block;
            border-radius:999px;
            padding:4px 10px;
            font-size:12px;
            font-weight:700;
        }

        .pill {
            background:#f0f2f5;
        }

        .tag.green {
            background:#e8f5eb;
            color:var(--green);
        }

        .tag.orange {
            background:#fff1df;
            color:var(--orange);
        }

        .tag.blue {
            background:#eaf1ff;
            color:var(--blue);
        }

        .tag.red {
            background:#ffebe9;
            color:var(--red);
        }

        .tag.gray {
            background:#f0f2f5;
            color:var(--gray);
        }

        .table-wrap {
            overflow:auto;
            max-height:520px;
            border:1px solid var(--line);
            border-radius:8px;
        }

        table {
            width:100%;
            border-collapse:collapse;
            font-size:13px;
        }

        th,
        td {
            text-align:left;
            padding:10px 12px;
            border-bottom:1px solid var(--line);
            vertical-align:top;
        }

        th {
            position:sticky;
            top:0;
            background:#f8f9fb;
            z-index:1;
        }

        td.path {
            font-family:
                ui-monospace,
                SFMono-Regular,
                Consolas,
                monospace;
            word-break:break-all;
        }

        tr:last-child td {
            border-bottom:0;
        }

        .actions {
            display:flex;
            gap:10px;
            flex-wrap:wrap;
            margin-top:16px;
        }

        code {
            background:#f0f2f5;
            padding:2px 5px;
            border-radius:4px;
        }

        @media(max-width:720px) {

            .steps {
                grid-template-columns:1fr;
            }

            .top {
                align-items:flex-start;
                flex-direction:column;
            }
        }

    </style>

</head>

<body>

<main class="wrap">

    <div class="top">

        <h1>
            文件三方同步
        </h1>

        <a
            href="https://lmtoj.cn/admin/file"
        >
            返回文件管理器
        </a>

    </div>


    <?php if ($error !== ''): ?>

        <div class="alert error">
            <?= h($error) ?>
        </div>

    <?php endif; ?>


    <?php if ($notice !== ''): ?>

        <div class="alert ok">
            <?= h($notice) ?>
        </div>

    <?php endif; ?>


    <div class="steps">

        <section class="card">

            <h2>
                1. 下载完整工作区
            </h2>

            <p class="muted">

                ZIP 内包含服务器中的
                <code>*.php</code>、
                安全目录的
                <code>.htaccess</code>，
                以及
                <code>.sync/baseline.json</code>。

                请保留基准文件，
                它用于判断双方是否发生修改。

            </p>

            <form
                method="post"
                action="?action=download"
            >

                <input
                    type="hidden"
                    name="csrf"
                    value="<?= h($csrf) ?>"
                >

                <button
                    class="btn btn-primary"
                    type="submit"
                >
                    下载服务器 PHP 与安全配置
                </button>

            </form>

        </section>


        <section class="card">

            <h2>
                2. 上传修改后的工作区
            </h2>

            <p class="muted">

                修改完成后，将工作区重新压缩成 ZIP。
                可以包含一个外层文件夹，
                但必须保留
                <code>.sync/baseline.json</code>；
                ZIP 不能超过 8 MB。

            </p>

            <form
                method="post"
                action="?action=upload"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="csrf"
                    value="<?= h($csrf) ?>"
                >

                <input
                    type="file"
                    name="workspace"
                    accept=".zip,application/zip"
                    required
                >

                <button
                    class="btn btn-primary"
                    type="submit"
                >
                    上传并预览 Diff
                </button>

            </form>

        </section>

    </div>


    <section class="card">

        <h2>
            同步规则
        </h2>

        <p class="muted">

            仅处理扩展名为
            <code>.php</code>
            （不区分大小写）的文件，
            以及
            <code>testdata/.htaccess</code>、
            <code>upload/img/.htaccess</code>
            安全配置；

            <code>tmp</code>
            目录、CSS、JS、图片等其他文件完全忽略。

            服务器变、本地不变：服务器优先；

            服务器不变、本地变：本地优先；

            双方都变：服务器优先并报告冲突。

            本地删除且服务器未变时，
            会删除服务器文件。

            执行前会备份所有将被覆盖或删除的服务器文件。

        </p>

        <div class="warning">

            数据库不在此工具的处理范围内。
            同步期间请避免其他管理员同时修改文件。

        </div>

    </section>


    <?php if ($shown): ?>

        <section class="card">

            <h2>
                <?= $report
                    ? '同步结果'
                    : 'Diff 预览'
                ?>
            </h2>


            <?php if (!$report): ?>

                <p class="muted">

                    基准创建时间：
                    <?= h(
                        (string)
                        $shown['baseline_time']
                    ) ?>。

                    确认时会重新检查服务器，
                    防止预览后发生的修改被覆盖。

                </p>

            <?php endif; ?>


            <div class="counts">

                <span class="pill">
                    本地上传
                    <?= $shown['counts']['upload'] ?>
                </span>

                <span class="pill">
                    服务器删除
                    <?= $shown['counts']['delete'] ?>
                </span>

                <span class="pill">
                    采用服务器
                    <?= $shown['counts']['server'] ?>
                </span>

                <span class="pill">
                    冲突
                    <?= $shown['counts']['conflict'] ?>
                </span>

                <span class="pill">
                    不变
                    <?= $shown['counts']['keep'] ?>
                </span>

            </div>


            <div class="table-wrap">

                <table>

                    <thead>

                        <tr>
                            <th>文件</th>
                            <th>决定</th>
                            <th>原因</th>
                        </tr>

                    </thead>

                    <tbody>

                    <?php
                    foreach (
                        $shown['plan']
                        as $item
                    ):
                        $label =
                            $labels[
                                $item['action']
                            ];
                    ?>

                        <tr>

                            <td class="path">
                                <?= h(
                                    $item['path']
                                ) ?>
                            </td>

                            <td>

                                <span
                                    class="tag
                                    <?= h(
                                        $label[1]
                                    ) ?>"
                                >
                                    <?= h(
                                        $label[0]
                                    ) ?>
                                </span>

                            </td>

                            <td>
                                <?= h(
                                    $item['reason']
                                ) ?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>


            <div class="actions">

                <?php if (!$report): ?>

                    <form
                        method="post"
                        action="?action=apply"
                        onsubmit="return confirm('确定按照预览规则同步？服务器文件可能被覆盖或删除。');"
                    >

                        <input
                            type="hidden"
                            name="csrf"
                            value="<?= h($csrf) ?>"
                        >

                        <button
                            class="btn btn-danger"
                            type="submit"
                        >
                            确认并执行同步
                        </button>

                    </form>

                <?php elseif (
                    !empty($report['backup'])
                ): ?>

                    <form
                        method="post"
                        action="?action=backup"
                    >

                        <input
                            type="hidden"
                            name="csrf"
                            value="<?= h($csrf) ?>"
                        >

                        <button
                            class="btn"
                            type="submit"
                        >
                            下载同步前服务器备份
                        </button>

                    </form>

                <?php endif; ?>

            </div>

        </section>

    <?php endif; ?>

</main>


<?php
include __DIR__ . '/footer.php';
?>

</body>

</html>