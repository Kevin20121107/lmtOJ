<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) { header("Location: https://lmtoj.cn/login"); exit; }

if (isset($_GET['logout'])) { session_destroy(); header("Location: https://lmtoj.cn/login"); exit; }

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) $is_admin = (int)$adminRes->fetch_assoc()['admin'];

$message = ''; $error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['join_code'])) {
    $code = trim($_POST['join_code']);
    $result = $conn->query("SELECT id, name FROM chat_conversations WHERE invite_code = '{$conn->real_escape_string($code)}' AND type = 'group'");

    if ($result->num_rows > 0) {
        $group = $result->fetch_assoc();
        $checkMember = $conn->query("SELECT 1 FROM chat_members WHERE conversation_id = {$group['id']} AND uid = {$login_uid}");
        if ($checkMember->num_rows == 0) {
            $conn->query("INSERT INTO chat_members (conversation_id, uid) VALUES ({$group['id']}, {$login_uid})");
            header("Location: https://lmtoj.cn/message/{$group['id']}");
            exit;
        } else {
            $error = "你已经是该群聊的成员了";
        }
    } else {
        $error = "无效的邀请码";
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>加入群聊 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --border: #e6e1da;
            --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --shadow-md: 0 4px 16px rgba(0,0,0,0.06);
            --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);min-height:100vh;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;background:var(--card-bg);color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .sidebar a:first-child{border-radius:var(--radius) var(--radius) 0 0;}
        .sidebar a:last-child{border-radius:0 0 var(--radius) var(--radius);}
        .content{flex:1;min-width:0;display:flex;justify-content:center;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:40px;box-shadow:var(--shadow-md);width:100%;max-width:960px;text-align:center;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:6px;}
        .card p{font-size:13px;color:var(--text-secondary);margin-bottom:20px;}
        input{width:100%;padding:12px 16px;border:1.5px solid var(--border);border-radius:20px;font-size:15px;outline:none;text-align:center;margin-bottom:14px;font-family:var(--font);}
        input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);}
        button{width:100%;padding:12px;background:var(--accent);color:#fff;border:none;border-radius:20px;font-size:15px;cursor:pointer;font-weight:500;font-family:var(--font);}
        button:hover{background:var(--accent-hover);}
        .alert{padding:12px;border-radius:var(--radius-sm);margin-bottom:14px;font-size:13px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;}
        .alert-error{background:#fce4ec;color:#c62828;}
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="card">
            <h2>加入群聊</h2>
            <p>输入群聊邀请码即可加入</p>
            <?php if($message):?><div class="alert alert-success"><?=htmlspecialchars($message)?></div><?php endif;?>
            <?php if($error):?><div class="alert alert-error"><?=htmlspecialchars($error)?></div><?php endif;?>
            <form method="post">
                <input type="text" name="join_code" placeholder="请输入8位邀请码" required>
                <button type="submit">加入群聊</button>
            </form>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>