# lmtOJ

A copy of [lmtOJ](https://lmtoj.cn/)'s source code.

THIS IS NOT THE NEWEST CODE.

I was one of the devs of lmtOJ, a part of code is created by me.
