<?php
// collect.php - 接收前端加密数据并存入数据库，自动查询IP地理位置
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 自动创建表（如果不存在）包含新字段
$tableCheck = $conn->query("SHOW TABLES LIKE 'collect_log'");
if ($tableCheck->num_rows == 0) {
    $createTableSQL = "CREATE TABLE IF NOT EXISTS collect_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        server_remote_addr VARCHAR(45) NOT NULL COMMENT '服务端看到的出口IP',
        server_x_forwarded_for VARCHAR(255) DEFAULT NULL COMMENT 'X-Forwarded-For头',
        server_cf_connecting_ip VARCHAR(45) DEFAULT NULL COMMENT 'Cloudflare真实IP',
        webrtc_ipv4 VARCHAR(255) DEFAULT NULL COMMENT 'WebRTC IPv4地址',
        webrtc_ipv6 VARCHAR(255) DEFAULT NULL COMMENT 'WebRTC IPv6地址',
        user_agent TEXT DEFAULT NULL COMMENT '浏览器UA',
        referrer TEXT DEFAULT NULL COMMENT '来源页面',
        page_url TEXT DEFAULT NULL COMMENT '触发收集的页面URL',
        country VARCHAR(100) DEFAULT NULL COMMENT '国家',
        region VARCHAR(100) DEFAULT NULL COMMENT '地区',
        city VARCHAR(100) DEFAULT NULL COMMENT '城市',
        isp VARCHAR(200) DEFAULT NULL COMMENT '运营商',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
        INDEX idx_server_ip (server_remote_addr),
        INDEX idx_created_at (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='前端收集的IP和指纹数据'";
    $conn->query($createTableSQL);
}

header('Content-Type: text/plain');

$key = '1234567890abcdef';

$encrypted = file_get_contents('php://input');
if (empty($encrypted)) {
    http_response_code(400);
    exit('No data');
}

function simpleDecrypt($base64Data, $key) {
    $data = base64_decode($base64Data);
    $result = '';
    for ($i = 0; $i < strlen($data); $i++) {
        $result .= chr(ord($data[$i]) ^ ord($key[$i % strlen($key)]));
    }
    return $result;
}

$json = simpleDecrypt($encrypted, $key);
$data = json_decode($json, true);
if (!$data) {
    http_response_code(400);
    exit('Invalid data');
}

$server_remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';
$server_x_forwarded_for = $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '';
$server_cf_connecting_ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';

$webrtc_ipv4 = isset($data['webrtcIPv4']) && is_array($data['webrtcIPv4']) ? implode(',', $data['webrtcIPv4']) : null;
$webrtc_ipv6 = isset($data['webrtcIPv6']) && is_array($data['webrtcIPv6']) ? implode(',', $data['webrtcIPv6']) : null;

$user_agent = $data['userAgent'] ?? null;
$referrer = $data['referrer'] ?? null;
$page_url = $data['location'] ?? null;

// ========== 查询IP地理位置（使用 ip-api.com 免费API） ==========
function getIpInfo($ip) {
    // 跳过内网IP（不查询）
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
    }
    // 缓存文件（避免重复查询）
    $cacheFile = __DIR__ . '/ip_cache/' . md5($ip) . '.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) { // 缓存24小时
        $cached = json_decode(file_get_contents($cacheFile), true);
        if ($cached) return $cached;
    }
    // 调用API
    $url = "http://ip-api.com/json/{$ip}?lang=zh-CN";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    $response = curl_exec($ch);
    curl_close($ch);
    if ($response === false) {
        return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
    }
    $info = json_decode($response, true);
    if ($info && $info['status'] === 'success') {
        $result = [
            'country' => $info['country'] ?? null,
            'region'  => $info['regionName'] ?? null,
            'city'    => $info['city'] ?? null,
            'isp'     => $info['isp'] ?? null
        ];
        // 写入缓存目录（确保目录存在）
        if (!is_dir(__DIR__ . '/ip_cache')) mkdir(__DIR__ . '/ip_cache', 0755, true);
        file_put_contents($cacheFile, json_encode($result));
        return $result;
    }
    return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
}

// 获取出口IP的地理信息（如果CF有真实IP，优先用那个）
$ipToQuery = $server_cf_connecting_ip ?: $server_remote_addr;
$geo = getIpInfo($ipToQuery);

// 预处理插入（增加四个地理字段）
$stmt = $conn->prepare("INSERT INTO collect_log (
    server_remote_addr,
    server_x_forwarded_for,
    server_cf_connecting_ip,
    webrtc_ipv4,
    webrtc_ipv6,
    user_agent,
    referrer,
    page_url,
    country,
    region,
    city,
    isp
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param(
    "ssssssssssss",
    $server_remote_addr,
    $server_x_forwarded_for,
    $server_cf_connecting_ip,
    $webrtc_ipv4,
    $webrtc_ipv6,
    $user_agent,
    $referrer,
    $page_url,
    $geo['country'],
    $geo['region'],
    $geo['city'],
    $geo['isp']
);

$stmt->execute();
$stmt->close();

echo 'OK';
?>