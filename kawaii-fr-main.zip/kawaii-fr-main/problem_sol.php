<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
set_time_limit(30);

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

// 加载.env
if (file_exists(__DIR__ . '/.env')) {
    $lines = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            $value = trim($value, '"\'');

            // 兼容 putenv 被禁用的情况
            $_ENV[$key] = $value;
            if (function_exists('putenv')) {
                @putenv("$key=$value");
            }
        }
    }
}

$servername = $_ENV['DB_HOST'] ?? getenv('DB_HOST');
$dbuser = $_ENV['DB_USER'] ?? getenv('DB_USER');
$dbpass = $_ENV['DB_PASSWORD'] ?? getenv('DB_PASSWORD');
$dbname = $_ENV['DB_NAME'] ?? getenv('DB_NAME');

$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
$conn->set_charset("utf8mb4");

// ====================== 自动创建【多题解】绑定表 ======================
$createSql = "CREATE TABLE IF NOT EXISTS problem_solution (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pid INT NOT NULL,
    article_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uk_pid_article (pid, article_id),
    INDEX idx_pid (pid),
    INDEX idx_article (article_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
$conn->query($createSql);
// =================================================================

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 获取用户权限 proadmin（仅 proadmin === 1 才具有题解绑定/解绑权限）
$is_proadmin = 0;
$userStmt = $conn->prepare("SELECT proadmin FROM users WHERE uid = ? LIMIT 1");
$userStmt->bind_param("i", $login_uid);
$userStmt->execute();
$userRes = $userStmt->get_result();
if ($row = $userRes->fetch_assoc()) {
    // 严格判断：必须等于 1
    $is_proadmin = ((int)$row['proadmin'] === 1) ? 1 : 0;
}
$userStmt->close();

// 未读通知
$unreadCount = 0;
$msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
$msgStmt->bind_param("i", $login_uid);
$msgStmt->execute();
$msgRes = $msgStmt->get_result();
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
$msgStmt->close();

$pid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($pid <= 0) {
    header("Location: https://lmtoj.cn/404");
    exit;
}

$message = '';
$error = '';

// ========== ProAdmin：新增题解绑定 ==========
if ($is_proadmin && $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['add_article_id'])) {
    $addAid = (int)$_POST['add_article_id'];
    if ($addAid <= 0) {
        $error = "请输入合法文章ID";
    } else {
        $artCheck = $conn->prepare("SELECT id FROM articles WHERE id = ? LIMIT 1");
        $artCheck->bind_param("i", $addAid);
        $artCheck->execute();
        $exist = $artCheck->get_result()->num_rows > 0;
        $artCheck->close();
        if (!$exist) {
            $error = "文章 #{$addAid} 不存在";
        } else {
            $ins = $conn->prepare("INSERT IGNORE INTO problem_solution (pid, article_id) VALUES (?, ?)");
            $ins->bind_param("ii", $pid, $addAid);
            if ($ins->execute()) {
                if ($ins->affected_rows > 0) {
                    $message = "成功添加题解绑定";
                } else {
                    $error = "该文章已经绑定为本题目题解";
                }
            } else {
                $error = "数据库错误：" . $ins->error;
            }
            $ins->close();
        }
    }
}

// ========== ProAdmin：删除单条题解绑定（改为 POST，防 CSRF/预取） ==========
if ($is_proadmin && $_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['del_sol_id'])) {
    $delSid = (int)$_POST['del_sol_id'];
    $del = $conn->prepare("DELETE FROM problem_solution WHERE id = ? AND pid = ? LIMIT 1");
    if ($del) {
        $del->bind_param("ii", $delSid, $pid);
        $deleted = $del->execute() && $del->affected_rows > 0;
        $del->close();
        if ($deleted) {
            header("Location: https://lmtoj.cn/problem/solution/{$pid}");
            exit;
        }
    }
    $error = "删除失败";
}

// ========== 查询本题所有绑定题解（联查文章+作者昵称） ==========
$sql = "
SELECT ps.id sol_id, ps.article_id, a.title, a.content, a.uid author_uid, u.name
FROM problem_solution ps
LEFT JOIN articles a ON ps.article_id = a.id
LEFT JOIN users u ON a.uid = u.uid
WHERE ps.pid = ?
ORDER BY ps.created_at DESC
";
$solList = [];
$q = $conn->prepare($sql);
$q->bind_param("i", $pid);
$q->execute();
$res = $q->get_result();
while ($row = $res->fetch_assoc()) {
    $solList[] = $row;
}
$q->close();
function safeContent($str)
{
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>#<?= $pid ?> 题解 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', 'Consolas', monospace;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; letter-spacing:0.4px; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);} 50%{box-shadow:0 0 0 6px rgba(245,83,83,0);} }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); font-weight:500; white-space:nowrap; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:20px; }
        .card h2,.card h3 { font-size:18px; font-weight:600; margin-bottom:12px; color:var(--text); }
        .alert { padding:12px 14px; border-radius:var(--radius-sm); margin-bottom:16px; font-size:14px; }
        .alert-success { background:#e8f5e9; color:#2e7d32; border:1px solid #a5d6a7; }
        .alert-error { background:#fce4ec; color:#c62828; border:1px solid #ef9a9a; }
        .back-btn { display:inline-flex; align-items:center; gap:6px; margin-bottom:20px; padding:8px 20px; background:var(--card-bg); color:var(--text); border-radius:30px; font-size:14px; font-weight:500; border:1px solid var(--border); text-decoration:none; transition:var(--transition); }
        .back-btn:hover { background:var(--accent-light); border-color:var(--accent); color:var(--accent); }
        .md-content { line-height:1.8; font-size:14px; }
        .md-content p { margin:6px 0; }
        .md-content pre { background:#2b2a27; color:#e8e4dd; padding:14px 16px; border-radius:var(--radius-sm); overflow-x:auto; font-family:var(--font-mono); font-size:13px; margin:8px 0; }
        .md-content code { font-family:var(--font-mono); background:#f3f0eb; padding:2px 6px; border-radius:3px; font-size:0.9em; }
        .md-content pre code { background:transparent; padding:0; }
        .md-content img { max-width:100%; height:auto; border-radius:4px; margin:6px 0; }
        .btn { padding:10px 22px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:14px; font-weight:500; transition:var(--transition); font-family:var(--font); }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-sm { padding:6px 14px; font-size:12px; }
        .btn-outline { background:transparent; color:var(--text-secondary); border:1.5px solid var(--border); }
        .btn-outline:hover { background:#f5f2ed; border-color:var(--text-muted); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:var(--danger-hover); }
        input[type="number"] { width:100%; padding:10px 14px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; outline:none; background:#fdfdfc; font-family:var(--font); margin-bottom:10px; }
        input:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        .form-label { display:block; font-size:13px; font-weight:500; color:var(--text-secondary); margin-bottom:5px; margin-top:10px; }

        /* 每条题解独立折叠 */
        .sol-item { margin-bottom:24px; border-bottom:1px dashed var(--border-light); padding-bottom:20px; }
        .sol-head { display:flex; align-items:center; flex-wrap:wrap; gap:12px; margin-bottom:10px; }
        .sol-title { font-size:16px; font-weight:600; }
        .sol-author { font-size:13px; color:var(--text-muted); }
        .sol-toggle-wrap { margin:8px 0; }
        .sol-body {
            max-height:0;
            overflow:hidden;
            transition:max-height 0.4s ease;
        }
        .sol-link-note {
            margin-top:8px;
            font-size:13px;
            color:var(--text-muted);
        }
        .inline-form { display:inline; }
        @media(max-width:768px) {
            .main{flex-direction:column;padding:0 12px;margin:18px auto 30px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .card{padding:18px 14px;}
        }
    </style>
    <link rel="stylesheet" href="/css/problem-theme.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <a href="https://lmtoj.cn/problem/<?= $pid ?>" class="back-btn">← 返回题目 #<?= $pid ?></a>

        <?php if ($message): ?><div class="alert alert-success"><?= safeContent($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= safeContent($error) ?></div><?php endif; ?>

        <div class="card">
            <h2>题目 #<?= $pid ?> 题解列表</h2>
            <?php if (!empty($solList)): ?>
                <?php foreach ($solList as $sol): ?>
                <?php
                    $sid = $sol['sol_id'];
                    $aid = $sol['article_id'];
                    $title = $sol['title'] ?? '无标题';
                    if (!empty($sol['name'])) {
                        $author = $sol['name'];
                    } elseif (!empty($sol['author_uid'])) {
                        $author = 'UID：' . $sol['author_uid'];
                    } else {
                        $author = '未知作者';
                    }
                    $content = $sol['content'] ?? '';
                ?>
                <div class="sol-item">
                    <div class="sol-head">
                        <span class="sol-title"><?= safeContent($title) ?></span>
                        <span class="sol-author">作者：<?= safeContent($author) ?></span>
                        <?php if ($is_proadmin): ?>
                            <form method="post" class="inline-form" onsubmit="return confirm('确定删除该题解绑定？');">
                                <input type="hidden" name="del_sol_id" value="<?= (int)$sid ?>">
                                <button type="submit" class="btn btn-sm btn-danger">删除绑定</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="sol-toggle-wrap">
                        <button class="btn btn-sm btn-outline sol-toggle" data-target="sol-<?=$sid?>">展开题解</button>
                    </div>
                    <div class="sol-body" id="sol-<?=$sid?>">
                        <div class="md-content" data-md="<?= safeContent($content) ?>"></div>
                        <div class="sol-link-note">
                            原文链接：
                            <a target="_blank" href="https://lmtoj.cn/article/<?= $aid ?>">#<?= $aid ?> <?= safeContent($title) ?></a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p style="color:var(--text-muted);font-size:15px;">暂无题解。</p>
            <?php endif; ?>
        </div>

        <?php if ($is_proadmin): ?>
        <div class="card">
            <h3>添加题解绑定</h3>
            <form method="post">
                <span class="form-label">输入文章ID</span>
                <input type="number" name="add_article_id" min="1" required placeholder="文章ID">
                <p style="font-size:12px;color:var(--text-muted);margin-bottom:12px;">
                    前往文章广场创建文章，复制文章编号填入，支持多个题解。
                </p>
                <button class="btn" type="submit">新增绑定</button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const solutionMarkdownRenderer = MarkdownRenderer.create({
    markdownOptions: {html: false, linkify: true, typographer: false, breaks: true},
    katexOptions: {macros: {"\\RR": "\\mathbb{R}"}}
});
solutionMarkdownRenderer.renderAll({selector: '.md-content', sourceAttribute: 'md'});

// 多条题解独立展开/收起
document.querySelectorAll('.sol-toggle').forEach(btn => {
    btn.addEventListener('click', function(){
        const targetId = this.getAttribute('data-target');
        const box = document.getElementById(targetId);
        const isOpen = box.classList.toggle('open');
        box.style.maxHeight = isOpen ? box.scrollHeight + 'px' : '0px';
        this.textContent = isOpen ? '收起题解' : '展开题解';
    });
});

window.addEventListener('resize', function() {
    document.querySelectorAll('.sol-body.open').forEach(function(box) {
        box.style.maxHeight = box.scrollHeight + 'px';
    });
});
</script>
</body>
</html>