<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$difficultyColumn = $conn->query("SHOW COLUMNS FROM problem_desc LIKE 'difficulty'");
if ($difficultyColumn && $difficultyColumn->num_rows === 0) {
    $conn->query("ALTER TABLE problem_desc ADD COLUMN difficulty TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER name");
}
if ($difficultyColumn) {
    $difficultyColumn->free();
}

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}

$probList = $conn->query("SELECT id, name, difficulty FROM problem_desc ORDER BY id ASC");

$acProblems = [];
if ($login_uid > 0) {
    $acRes = $conn->query("SELECT DISTINCT problem_id FROM submissions WHERE uid = {$login_uid} AND result = 'AC'");
    while ($row = $acRes->fetch_assoc()) {
        $acProblems[$row['problem_id']] = true;
    }
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>题库 - lmtOJ</title>
    <style>
        :root {
            --bg: linear-gradient(135deg, #dcefe3 0%, #edf4ed 42%, #d8e9df 100%);
            --card-bg: rgba(255, 255, 255, 0.42);
            --nav-bg: rgba(22, 67, 48, 0.64);
            --nav-text: #f3fff7;
            --text: #17392a;
            --text-secondary: #587365;
            --text-muted: #82998b;
            --border: rgba(255, 255, 255, 0.58);
            --border-light: rgba(42, 105, 72, 0.14);
            --accent: #258453;
            --accent-hover: #176b40;
            --accent-light: rgba(67, 160, 106, 0.12);
            --pass-color: #2e7d32;
            --none-color: #a0988e;
            --shadow: 0 18px 48px rgba(28, 77, 52, 0.12);
            --radius: 8px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background:
                repeating-linear-gradient(0deg, transparent 0 35px, rgba(255, 255, 255, 0.2) 36px),
                repeating-linear-gradient(90deg, transparent 0 35px, rgba(255, 255, 255, 0.2) 36px),
                var(--bg);
            background-attachment: fixed;
            font-family: var(--font);
            color: var(--text);
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        .navbar {
            background: var(--nav-bg);
            height: 54px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            color: var(--nav-text);
            position: sticky;
            top: 0;
            z-index: 100;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            box-shadow: 0 8px 30px rgba(19, 59, 39, 0.14), inset 0 1px 0 rgba(255, 255, 255, 0.16);
            backdrop-filter: blur(26px) saturate(165%);
            -webkit-backdrop-filter: blur(26px) saturate(165%);
        }
        .navbar h1 {
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 0.4px;
            color: #f3fff7;
        }
        .bell-wrap {
            position: relative;
            font-size: 20px;
            cursor: pointer;
            margin-right: 20px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
            user-select: none;
        }
        .bell-wrap:hover { background: rgba(255,255,255,0.08); }
        .red-dot {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 9px;
            height: 9px;
            background: #f55353;
            border-radius: 50%;
            border: 1.5px solid #3d3a37;
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%, 100% { box-shadow: 0 0 0 0 rgba(245,83,83,0.5); }
            50% { box-shadow: 0 0 0 6px rgba(245,83,83,0); }
        }
        .user-info { display: flex; align-items: center; gap: 6px; }
        .user-info a {
            color: #e0dbd3;
            text-decoration: none;
            font-size: 13.5px;
            padding: 7px 13px;
            border-radius: 20px;
            transition: var(--transition);
            white-space: nowrap;
            font-weight: 500;
        }
        .user-info a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .user-info a.admin-link { color: #f5d76e; font-weight: 600; }

        .main {
            max-width: 1100px;
            margin: 28px auto 40px;
            display: flex;
            gap: 22px;
            padding: 0 20px;
            align-items: flex-start;
        }
        .sidebar {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            box-shadow: 0 18px 48px rgba(28, 77, 52, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.72), inset 0 -1px 0 rgba(255, 255, 255, 0.14);
            backdrop-filter: blur(28px) saturate(160%);
            -webkit-backdrop-filter: blur(28px) saturate(160%);
            width: fit-content;
            min-width: 110px;
            overflow: hidden;
            position: sticky;
            top: 80px;
            flex-shrink: 0;
        }
        .sidebar a {
            display: block;
            padding: 13px 22px;
            text-align: center;
            background: rgba(255, 255, 255, 0.08);
            color: var(--text);
            text-decoration: none;
            font-size: 14.5px;
            font-weight: 500;
            white-space: nowrap;
            transition: var(--transition);
            border-left: 3px solid transparent;
            letter-spacing: 0.3px;
        }
        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.52);
            border-left-color: var(--accent);
            color: var(--accent);
        }
        .sidebar a:first-child { border-radius: var(--radius) var(--radius) 0 0; }
        .sidebar a:last-child { border-radius: 0 0 var(--radius) var(--radius); }

        .content { flex: 1; min-width: 0; }

        .card {
            background: var(--card-bg);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            padding: 26px 28px;
            box-shadow: 0 18px 48px rgba(28, 77, 52, 0.1), inset 0 1px 0 rgba(255, 255, 255, 0.72), inset 0 -1px 0 rgba(255, 255, 255, 0.14);
            backdrop-filter: blur(28px) saturate(160%);
            -webkit-backdrop-filter: blur(28px) saturate(160%);
        }
        .card h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            letter-spacing: 0.3px;
        }
        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        a { text-decoration: none; color: var(--accent); transition: var(--transition); }
        a:hover { color: var(--accent-hover); }

        .btn {
            display: inline-block;
            padding: 8px 18px;
            background: linear-gradient(135deg, #329763, #21794b);
            border: 1px solid rgba(255, 255, 255, 0.42);
            color: #fff;
            border-radius: 20px;
            font-size: 13.5px;
            font-weight: 500;
            transition: var(--transition);
        }
        .btn:hover {
            background: linear-gradient(135deg, #258453, #176b40);
            box-shadow: 0 8px 20px rgba(37, 132, 83, 0.25);
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: center;
            padding: 12px 10px;
            background: rgba(236, 247, 239, 0.72);
            font-weight: 600;
            font-size: 13px;
            color: var(--text-secondary);
            border-bottom: 1px solid rgba(255, 255, 255, 0.64);
        }
        td {
            padding: 12px 10px;
            text-align: center;
            border-bottom: 1px solid var(--border-light);
            font-size: 14px;
        }
        tr:hover td { background: rgba(255, 255, 255, 0.34); }

        .prob-link {
            color: var(--text);
            font-weight: 500;
        }
        .prob-link:hover { color: var(--accent); }
        .difficulty-badge {
            display: inline-block;
            min-width: 72px;
            padding: 3px 9px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 600;
            text-align: center;
        }
        .difficulty-undefined { background:#41464b; color:#fff; }
        .difficulty-green { background:#d8f1df; color:#176b32; }
        .difficulty-yellow { background:#fff1b8; color:#785900; }
        .difficulty-orange { background:#ffe0c2; color:#914400; }
        .difficulty-red { background:#f8d0d0; color:#982d2d; }

        .status-ac {
            color: var(--pass-color);
            font-size: 18px;
            font-weight: bold;
        }
        .status-none {
            color: var(--none-color);
            font-size: 18px;
            font-weight: bold;
        }

        @media (max-width: 768px) {
            .main {
                flex-direction: column;
                padding: 0 12px;
                margin: 18px auto 30px;
            }
            .sidebar {
                width: 100%;
                position: static;
                display: flex;
            }
            .sidebar a {
                flex: 1 1 auto;
                padding: 11px 10px;
                font-size: 13px;
                border-left: none;
                border-bottom: 2px solid transparent;
            }
            .sidebar a:hover {
                border-left-color: transparent;
                border-bottom-color: var(--accent);
            }
            .card { padding: 18px 14px; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="card">
            <div class="top">
                <h2>题目列表</h2>
                <?php if ($is_admin): ?>
                    <a href="/problem/edit" class="btn">管理题目</a>
                <?php endif; ?>
            </div>

            <table>
                <tr>
                    <th>ID</th>
                    <th>题目名称</th>
                    <th>难度</th>
                </tr>
                <?php if ($probList && $probList->num_rows > 0): ?>
                    <?php while ($row = $probList->fetch_assoc()): ?>
                    <?php $pid = (int)$row['id']; ?>
                    <?php
                        $difficulty = max(0, min(10, (int)($row['difficulty'] ?? 0)));
                        $difficultyClass = $difficulty === 0 ? 'difficulty-undefined' : ($difficulty <= 3 ? 'difficulty-green' : ($difficulty <= 5 ? 'difficulty-yellow' : ($difficulty <= 8 ? 'difficulty-orange' : 'difficulty-red')));
                        $difficultyLabel = $difficulty === 0 ? '未定义' : $difficulty . ' 级';
                    ?>
                    <tr>
                        <td<?php if (isset($acProblems[$pid])): ?> style="background: #d1e7dd"<?php endif; ?>>#<?= $pid ?></td>
                        <td>
                            <a href="https://lmtoj.cn/problem/<?= $pid ?>" class="prob-link">
                                <?= safeContent(mb_substr($row['name'] ?: '未命名', 0, 50)) ?>
                            </a>
                        </td>
                        <td><span class="difficulty-badge <?= $difficultyClass ?>"><?= safeContent($difficultyLabel) ?></span></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" style="padding: 30px; color: var(--text-muted);">暂无题目</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>