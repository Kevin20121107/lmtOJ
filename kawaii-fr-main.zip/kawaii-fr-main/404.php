<?php
require_once 'visit_log.php';
session_start();

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
$unreadCount = 0;
$is_admin = 0;

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

if ($login_uid > 0) {
require_once __DIR__ . '/database.php';
$conn = db();
    $conn->set_charset("utf8");
    
    $adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
    if ($adminRes && $adminRes->num_rows > 0) {
        $is_admin = (int)$adminRes->fetch_assoc()['admin'];
    }
    $msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
    if ($msgRes) {
        $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
    }
}

$current_page = basename($_SERVER['SCRIPT_NAME']);

http_response_code(404);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.06);
            --radius: 10px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);min-height:100vh;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;letter-spacing:0.4px;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);white-space:nowrap;font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;background:var(--card-bg);color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;white-space:nowrap;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .sidebar a:first-child{border-radius:var(--radius) var(--radius) 0 0;}
        .sidebar a:last-child{border-radius:0 0 var(--radius) var(--radius);}
        /* 修改：主容器为全屏居中，去掉侧边栏 */
        .main {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 70vh;   /* 垂直居中，留出导航栏空间 */
            padding: 0 20px;
            margin: 0 auto;
            max-width: 1100px;   /* 保持与原来一致，但非必需 */
        }
        .content {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
        }
        .error-card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 60px 48px;
            box-shadow: var(--shadow-md);
            text-align: center;
            max-width: 500px;
            width: 100%;
        }
        .error-code{font-size:80px;font-weight:700;color:var(--accent);line-height:1;margin-bottom:16px;letter-spacing:-2px;}
        .error-title{font-size:20px;font-weight:600;color:var(--text);margin-bottom:8px;}
        .error-desc{font-size:14px;color:var(--text-muted);line-height:1.6;margin-bottom:28px;}
        .btn{display:inline-block;padding:10px 24px;background:var(--accent);color:#fff;text-decoration:none;border-radius:20px;font-size:14px;font-weight:500;transition:var(--transition);}
        .btn:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);transform:translateY(-1px);}
        @media(max-width:768px){
            .main{min-height:60vh;padding:0 12px;}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .error-card{padding:40px 24px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}
            .sidebar a{flex:1 1 auto;padding:12px 12px;font-size:13px;border-left:none;border-bottom:2px solid transparent;border-radius:0;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>
<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="error-card">
            <div class="error-code">404</div>
            <div class="error-title">无法访问此页面</div>
            <div class="error-desc">此页面不存在或被删除</div>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>