<?php
header("Content-Type:text/html;charset=utf-8");
$code = $_GET['code'] ?? '';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Markdown / LaTeX 渲染测试</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/markdown-it-texmath@0.9.0/texmath.min.js"></script>
<style>
body {
    font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
    padding: 20px;
    max-width: 800px;
    margin: auto;
    background: #f9f7f4;
    color: #2c2a28;
}
pre {
    background: #2b2a27;
    color: #e8e4dd;
    padding: 14px 16px;
    border-radius: 8px;
    overflow-x: auto;
}
code {
    font-family: 'JetBrains Mono', 'Consolas', monospace;
}
.input-area {
    margin-bottom: 20px;
}
textarea {
    width: 100%;
    height: 120px;
    padding: 10px;
    border: 1.5px solid #ddd;
    border-radius: 6px;
    font-family: monospace;
    font-size: 14px;
    resize: vertical;
}
button {
    margin-top: 8px;
    padding: 8px 20px;
    border: none;
    border-radius: 20px;
    background: #6b8a74;
    color: #fff;
    font-size: 14px;
    cursor: pointer;
}
.output {
    border: 1px solid #e6e1da;
    border-radius: 10px;
    padding: 20px;
    background: #fff;
    min-height: 100px;
}
</style>
</head>
<body>
<h1>Markdown / LaTeX 渲染测试</h1>
<div class="input-area">
    <form method="get" action="">
        <textarea name="code" placeholder="输入 Markdown + LaTeX，例如：# h1\n$333$"><?= htmlspecialchars($code) ?></textarea>
        <button type="submit">渲染</button>
    </form>
</div>

<?php if ($code !== ''): ?>
    <h2>渲染结果</h2>
    <div class="output" id="renderedOutput"></div>
    <script>
    (function () {
        var source = <?= json_encode($code, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
        var renderer = window.markdownit({html: false, linkify: true, breaks: true});
        if (window.texmath && window.katex) {
            renderer.use(window.texmath.use(window.katex), {
                engine: window.katex,
                delimiters: 'dollars',
                katexOptions: {throwOnError: false}
            });
        }
        document.getElementById('renderedOutput').innerHTML = renderer.render(source);
    })();
    </script>
    <h2>原始文本</h2>
    <pre><?= htmlspecialchars($code) ?></pre>
<?php endif; ?>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
