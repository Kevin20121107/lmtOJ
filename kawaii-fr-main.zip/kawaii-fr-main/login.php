<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once __DIR__ . '/database.php';
session_start();
header("Content-Type:text/html;charset=utf-8");

/* ================== 数据库连接与自动建表 ================== */
$conn = db();
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// 自动创建/更新 users 表字段
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'banned'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN banned TINYINT DEFAULT 0");
}
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'original_name'");
if ($check && $check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN original_name VARCHAR(255) DEFAULT NULL");
    $conn->query("UPDATE users SET original_name = name WHERE original_name IS NULL OR original_name = ''");
}
$tableCheck = $conn->query("SHOW TABLES LIKE 'user_bind'");
if ($tableCheck && $tableCheck->num_rows == 0) {
    $conn->query("
        CREATE TABLE user_bind (
            id INT AUTO_INCREMENT PRIMARY KEY,
            uid INT NOT NULL,
            bind_type VARCHAR(20) NOT NULL,
            bind_value VARCHAR(255) NOT NULL,
            verified TINYINT DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY (uid, bind_type)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
}
// 自动创建找回密码尝试记录表
$conn->query("CREATE TABLE IF NOT EXISTS password_reset_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    ip_segment VARCHAR(20) NOT NULL,
    attempt_time DATETIME NOT NULL,
    success TINYINT DEFAULT 0,
    INDEX idx_ip_segment_time (ip_segment, attempt_time),
    INDEX idx_attempt_time (attempt_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

/* ================== 基础函数 ================== */
function csrf_field() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return '<input type="hidden" name="csrf_token" value="' . $_SESSION['csrf_token'] . '">';
}
function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function get_client_ip() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    }
    return trim($ip);
}
function get_ip_segment($ip) {
    $parts = explode('.', $ip);
    if (count($parts) == 4) {
        return $parts[0] . '.' . $parts[1] . '.' . $parts[2] . '.*';
    }
    return $ip; // IPv6 简化处理
}

/* ================== 洛谷签名检查函数 ================== */
function checkLuoguSignature($luogu_uid, $verifyCode) {
    $url = "https://www.luogu.com.cn/user/{$luogu_uid}";
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        CURLOPT_TIMEOUT => 15,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($httpCode !== 200 || empty($response)) {
        return false;
    }
    return (strpos($response, $verifyCode) !== false);
}

/* ================== 限制检查 ================== */
function check_global_limit($conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM password_reset_attempts WHERE attempt_time >= NOW() - INTERVAL 1 HOUR");
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count >= 50;
}
function check_ip_segment_limit($conn, $ip_segment) {
    $stmt = $conn->prepare("SELECT COUNT(*) FROM password_reset_attempts WHERE ip_segment = ? AND attempt_time >= NOW() - INTERVAL 1 MONTH");
    $stmt->bind_param("s", $ip_segment);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    return $count >= 10;
}
function check_interval($conn, $ip) {
    $stmt = $conn->prepare("SELECT MAX(attempt_time) FROM password_reset_attempts WHERE ip = ?");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    $stmt->bind_result($last_time);
    $stmt->fetch();
    $stmt->close();
    if ($last_time) {
        if (time() - strtotime($last_time) < 60) {
            return false;
        }
    }
    return true;
}
function record_attempt($conn, $ip, $ip_segment, $success) {
    $stmt = $conn->prepare("INSERT INTO password_reset_attempts (ip, ip_segment, attempt_time, success) VALUES (?, ?, NOW(), ?)");
    $stmt->bind_param("ssi", $ip, $ip_segment, $success);
    $stmt->execute();
    $stmt->close();
}

/* ================== 处理 AJAX 请求：忘记密码（两步） ================== */
$is_ajax = (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest')
           || (isset($_POST['ajax']) && $_POST['ajax'] == '1');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $is_ajax && ($_POST['form_type'] ?? '') === 'forgot') {
    header('Content-Type: application/json');
    $response = ['success' => false, 'error' => ''];

    // CSRF 验证
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        $response['error'] = 'CSRF token mismatch';
        echo json_encode($response);
        exit;
    }

    $ip = get_client_ip();
    $ip_segment = get_ip_segment($ip);

    // 频率限制
    if (check_global_limit($conn)) {
        $response['error'] = '当前服务器请求过于频繁，请稍后再试。';
        echo json_encode($response);
        exit;
    }
    if (check_ip_segment_limit($conn, $ip_segment)) {
        $response['error'] = '您所在的 IP 段本月请求次数已达上限。';
        echo json_encode($response);
        exit;
    }
    if (!check_interval($conn, $ip)) {
        $response['error'] = '请等待 1 分钟后再尝试。';
        echo json_encode($response);
        exit;
    }

    $sub_action = $_POST['sub_action'] ?? '';

    if ($sub_action === 'generate_reset_code') {
        // 第一步：生成验证码
        $luogu_uid = trim($_POST['luogu_uid'] ?? '');
        if (empty($luogu_uid) || !is_numeric($luogu_uid) || $luogu_uid < 1) {
            $response['error'] = '请输入有效的洛谷 UID';
            echo json_encode($response);
            exit;
        }

        // 查询该洛谷 UID 是否已绑定
        $stmt = $conn->prepare("SELECT uid FROM user_bind WHERE bind_type='luogu' AND verified=1 AND bind_value=? LIMIT 1");
        $stmt->bind_param("s", $luogu_uid);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) {
            $response['error'] = '该洛谷账号未绑定任何本站账号，无法通过此方式找回。';
            $stmt->close();
            echo json_encode($response);
            exit;
        }
        $row = $result->fetch_assoc();
        $target_uid = $row['uid'];
        $stmt->close();

        // 生成验证码并存入 session
        $verify_code = 'lmtoj_reset_' . bin2hex(random_bytes(4));
        $_SESSION['reset_verify'] = [
            'luogu_uid' => $luogu_uid,
            'target_uid' => $target_uid,
            'code' => $verify_code,
            'created' => time()
        ];

        $response['success'] = true;
        $response['verify_code'] = $verify_code;
        echo json_encode($response);
        exit;
    }
    elseif ($sub_action === 'verify_reset_code') {
        // 第二步：验证签名并重置密码
        if (empty($_SESSION['reset_verify'])) {
            $response['error'] = '验证码已过期，请重新生成。';
            echo json_encode($response);
            exit;
        }

        $reset = $_SESSION['reset_verify'];
        if (time() - $reset['created'] > 1800) { // 30分钟过期
            unset($_SESSION['reset_verify']);
            $response['error'] = '验证码已过期，请重新生成。';
            echo json_encode($response);
            exit;
        }

        $luogu_uid = $reset['luogu_uid'];
        $target_uid = $reset['target_uid'];
        $verify_code = $reset['code'];

        $new_password = $_POST['new_password'] ?? '';
        $new_password_confirm = $_POST['new_password_confirm'] ?? '';

        if (empty($new_password) || empty($new_password_confirm)) {
            $response['error'] = '请填写新密码。';
            echo json_encode($response);
            exit;
        }
        if ($new_password !== $new_password_confirm) {
            $response['error'] = '两次输入的新密码不一致。';
            echo json_encode($response);
            exit;
        }
        if (strlen($new_password) < 6) {
            $response['error'] = '新密码长度至少 6 位。';
            echo json_encode($response);
            exit;
        }

        // 检查洛谷签名
        if (!checkLuoguSignature($luogu_uid, $verify_code)) {
            $response['error'] = '未在洛谷个人签名中检测到验证码，请确认后重试。';
            record_attempt($conn, $ip, $ip_segment, 0); // 记录失败
            echo json_encode($response);
            exit;
        }

        // 更新密码
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE uid = ?");
        $stmt->bind_param("si", $hashed, $target_uid);
        $stmt->execute();
        $stmt->close();

        unset($_SESSION['reset_verify']);
        record_attempt($conn, $ip, $ip_segment, 1); // 记录成功
        $response['success'] = true;
        $response['message'] = '密码重置成功，请使用新密码登录。';
        echo json_encode($response);
        exit;
    }
    else {
        $response['error'] = '无效的请求。';
        echo json_encode($response);
        exit;
    }
}

/* ================== 处理普通 POST：登录逻辑 ================== */
$error_login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$is_ajax) {
    // CSRF 验证
    if (!verify_csrf($_POST['csrf_token'] ?? '')) {
        die("CSRF token mismatch");
    }

    $form_type = $_POST['form_type'] ?? 'login';

    if ($form_type === 'login') {
        $username = trim($_POST['username'] ?? '');
        $pwd = trim($_POST['pwd'] ?? '');
        $mode = $_POST['mode'] ?? 'password'; // password 或 luogu
        $autologin = isset($_POST['autologin']) && $_POST['autologin'] == '1';

        error_log("登录尝试: 模式=$mode, 输入=" . $username);

        if ($mode === 'luogu') {
            $stmt = $conn->prepare("
                SELECT uid FROM user_bind
                WHERE bind_type = 'luogu' AND verified = 1 AND bind_value = ?
                LIMIT 1
            ");
            if (!$stmt) {
                error_log("SQL 预处理失败: " . $conn->error);
                die("数据库错误，请查看日志");
            }
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                $error_login = "未找到已绑定此洛谷的账号";
            } else {
                $row = $result->fetch_assoc();
                $uid = $row['uid'];
                $userStmt = $conn->prepare("
                    SELECT uid, name, original_name, password, banned
                    FROM users WHERE uid = ? LIMIT 1
                ");
                $userStmt->bind_param("i", $uid);
                $userStmt->execute();
                $userResult = $userStmt->get_result();
                if ($userResult->num_rows === 0) {
                    $error_login = "账号异常，请联系管理员";
                } else {
                    $userRow = $userResult->fetch_assoc();
                    if ($userRow['banned'] == 1) {
                        $error_login = "该账号已被封禁，如有疑问请联系管理员";
                    } elseif (password_verify($pwd, $userRow['password'])) {
                        session_regenerate_id(true);
                        $_SESSION['uid'] = $userRow['uid'];
                        $_SESSION['name'] = $userRow['original_name'] ?: $userRow['name'];

                        // 设置自动登录 cookie
                        if ($autologin) {
                            setcookie('lmtoj_username', base64_encode($username), time() + 30*86400, '/', '', false, true);
                            setcookie('lmtoj_password', base64_encode($pwd), time() + 30*86400, '/', '', false, true);
                        } else {
                            // 如果用户取消勾选，清除已有的自动登录cookie
                            setcookie('lmtoj_username', '', time() - 3600, '/');
                            setcookie('lmtoj_password', '', time() - 3600, '/');
                        }

                        header("Location: https://lmtoj.cn/");
                        exit;
                    } else {
                        $error_login = "密码错误";
                    }
                }
                $userStmt->close();
            }
            $stmt->close();
        } else {
            // 密码登录
            $uidFromBanName = null;
            if (preg_match('/^封禁用户(\d+)$/u', $username, $matches)) {
                $uidFromBanName = intval($matches[1]);
            }
            if ($uidFromBanName !== null) {
                $stmt = $conn->prepare("
                    SELECT uid, name, original_name, password, banned
                    FROM users WHERE uid = ? OR name = ? LIMIT 1
                ");
                if (!$stmt) {
                    error_log("SQL 预处理失败: " . $conn->error);
                    die("数据库错误，请查看日志");
                }
                $banName = "封禁用户" . $uidFromBanName;
                $stmt->bind_param("is", $uidFromBanName, $banName);
            } elseif (preg_match('/^\d+$/', $username)) {
                $uid = intval($username);
                $stmt = $conn->prepare("
                    SELECT uid, name, original_name, password, banned
                    FROM users WHERE uid = ? LIMIT 1
                ");
                if (!$stmt) {
                    error_log("SQL 预处理失败: " . $conn->error);
                    die("数据库错误，请查看日志");
                }
                $stmt->bind_param("i", $uid);
            } else {
                $stmt = $conn->prepare("
                    SELECT uid, name, original_name, password, banned
                    FROM users WHERE name = ? OR original_name = ? LIMIT 1
                ");
                if (!$stmt) {
                    error_log("SQL 预处理失败: " . $conn->error);
                    die("数据库错误，请查看日志");
                }
                $stmt->bind_param("ss", $username, $username);
            }

            $stmt->execute();
            $result = $stmt->get_result();
            if ($result->num_rows === 0) {
                $error_login = "用户名不存在";
            } else {
                $row = $result->fetch_assoc();
                if ($row['banned'] == 1) {
                    $error_login = "该账号已被封禁，如有疑问请联系管理员";
                } elseif (password_verify($pwd, $row['password'])) {
                    session_regenerate_id(true);
                    $_SESSION['uid'] = $row['uid'];
                    $_SESSION['name'] = $row['original_name'] ?: $row['name'];

                    // 设置自动登录 cookie
                    if ($autologin) {
                        setcookie('lmtoj_username', base64_encode($username), time() + 30*86400, '/', '', false, true);
                        setcookie('lmtoj_password', base64_encode($pwd), time() + 30*86400, '/', '', false, true);
                    } else {
                        // 清除已有的自动登录cookie
                        setcookie('lmtoj_username', '', time() - 3600, '/');
                        setcookie('lmtoj_password', '', time() - 3600, '/');
                    }

                    header("Location: https://lmtoj.cn/");
                    exit;
                } else {
                    $error_login = "密码错误";
                }
            }
            $stmt->close();
        }
    }
}

// 如果用户已登录，直接跳转到首页
if (isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/");
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>登录 - lmtOJ</title>
    <style>
        :root {
            --text: #26332f;
            --text-secondary: #64726c;
            --text-muted: #93a09a;
            --accent: #5f806d;
            --accent-strong: #466656;
            --accent-soft: rgba(95, 128, 109, 0.16);
            --danger: #b44743;
            --danger-soft: rgba(180, 71, 67, 0.10);
            --success: #2e7d32;
            --success-soft: #e8f5e9;
            --glass: rgba(255, 255, 255, 0.58);
            --glass-strong: rgba(255, 255, 255, 0.74);
            --stroke: rgba(255, 255, 255, 0.72);
            --nav-glass: rgba(42, 48, 46, 0.74);
            --shadow: 0 24px 70px rgba(53, 64, 61, 0.18);
            --shadow-soft: 0 8px 24px rgba(53, 64, 61, 0.10);
            --radius: 8px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: Segoe\ UI, PingFang\ SC, Microsoft\ YaHei, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--text);
            font-family: var(--font);
            background:
                linear-gradient(120deg, rgba(255, 255, 255, 0.42), transparent 42%),
                linear-gradient(135deg, #dcebe0 0%, #f2ecdf 48%, #d8e5ed 100%);
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 84px 20px 24px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(255, 255, 255, 0.28) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.28) 1px, transparent 1px);
            background-size: 32px 32px;
            opacity: 0.22;
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--nav-glass);
            border-bottom: 1px solid rgba(255, 255, 255, 0.16);
            box-shadow: 0 1px 16px rgba(0, 0, 0, 0.08);
            backdrop-filter: blur(16px) saturate(130%);
            -webkit-backdrop-filter: blur(16px) saturate(130%);
            z-index: 10;
        }

        .brand {
            color: #ffffff;
            font-size: 17px;
            font-weight: 600;
        }

        .page-shell {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .glass-card {
            position: relative;
            width: min(440px, 100%);
            padding: 36px 34px;
            background: var(--glass);
            border: 1px solid var(--stroke);
            border-radius: var(--radius);
            box-shadow: var(--shadow), inset 0 1px 0 rgba(255, 255, 255, 0.72);
            backdrop-filter: blur(20px) saturate(150%);
            -webkit-backdrop-filter: blur(20px) saturate(150%);
            animation: float-card 7s ease-in-out infinite;
        }

        @keyframes float-card {
            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-6px);
            }
        }

        .title {
            margin: 0 0 24px;
            text-align: center;
            font-size: 23px;
            font-weight: 650;
        }

        .mode-switch {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 22px;
            margin-bottom: 20px;
            padding: 12px 10px;
            border: 1px solid rgba(82, 98, 90, 0.12);
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.42);
        }

        .mode-switch label {
            display: inline-flex;
            align-items: center;
            gap: 7px;
            color: var(--text-secondary);
            font-size: 14px;
            cursor: pointer;
            white-space: nowrap;
        }

        .mode-switch input[type="radio"] {
            width: 16px;
            height: 16px;
            margin: 0;
            accent-color: var(--accent);
            cursor: pointer;
        }

        .field {
            margin-bottom: 16px;
        }

        .field:last-of-type {
            margin-bottom: 20px;
        }

        .field input {
            width: 100%;
            height: 48px;
            padding: 0 14px;
            border: 1px solid rgba(82, 98, 90, 0.18);
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.68);
            color: var(--text);
            font-family: inherit;
            font-size: 14px;
            outline: none;
            transition: var(--transition);
        }

        .field input::placeholder {
            color: var(--text-muted);
        }

        .field input:focus {
            border-color: var(--accent);
            background: var(--glass-strong);
            box-shadow: 0 0 0 3px var(--accent-soft);
        }

        button {
            width: 100%;
            height: 46px;
            border: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
            color: #ffffff;
            font-family: inherit;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(79, 111, 91, 0.25);
            transition: var(--transition);
        }

        button:hover {
            box-shadow: 0 11px 26px rgba(79, 111, 91, 0.30);
            filter: brightness(1.04);
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0);
        }

        button:disabled {
            cursor: wait;
            filter: grayscale(0.2);
            opacity: 0.82;
        }

        .error,
        .success {
            margin: -4px 0 18px;
            padding: 10px 12px;
            border-radius: var(--radius-sm);
            text-align: center;
            font-size: 14px;
            line-height: 1.5;
        }

        .error {
            border: 1px solid rgba(180, 71, 67, 0.25);
            background: var(--danger-soft);
            color: var(--danger);
        }

        .success {
            border: 1px solid rgba(46, 125, 50, 0.22);
            background: var(--success-soft);
            color: var(--success);
        }

        .tip,
        .form-switch {
            text-align: center;
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.6;
        }

        .tip {
            margin-top: 18px;
        }

        .form-switch {
            margin-top: 15px;
        }

        .tip a,
        .form-switch a {
            color: var(--accent);
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
        }

        .tip a:hover,
        .form-switch a:hover {
            color: var(--accent-strong);
            text-decoration: underline;
        }

        .tip-divider {
            margin: 0 8px;
            color: var(--text-muted);
        }

        .hidden {
            display: none !important;
        }

        .verify-code-display {
            display: block;
            width: fit-content;
            max-width: 100%;
            margin: 8px auto 10px;
            padding: 8px 14px;
            border: 2px dashed rgba(180, 71, 67, 0.42);
            border-radius: var(--radius-sm);
            background: var(--danger-soft);
            color: var(--danger);
            font-family: "Consolas", monospace;
            font-size: 18px;
            font-weight: 700;
            text-align: center;
            cursor: pointer;
            user-select: all;
            word-break: break-all;
        }

        .forgot-hint {
            margin: 0 0 16px;
            color: var(--text-secondary);
            font-size: 13px;
            line-height: 1.6;
            text-align: center;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        @media (max-width: 520px) {
            body {
                padding: 78px 16px 20px;
            }

            .glass-card {
                padding: 30px 22px;
            }

            .title {
                font-size: 21px;
            }

            .mode-switch {
                gap: 14px;
            }

            .field input,
            button {
                height: 46px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .glass-card {
                animation: none;
            }

            button,
            .field input {
                transition: none;
            }
        }
    </style>
</head>
<body>
    <header class="navbar">
        <span class="brand">lmtOJ</span>
    </header>

    <main class="page-shell">
        <section class="glass-card" aria-label="登录与找回密码">
            <!-- 登录表单区域 -->
            <div id="loginFormDiv">
                <h1 class="title" id="login-title">登录</h1>
                <?php if ($error_login): ?>
                    <div class="error" role="alert"><?= htmlspecialchars($error_login, ENT_QUOTES, 'UTF-8') ?></div>
                <?php endif; ?>

                <form action="login.php" method="post" id="loginForm">
                    <?= csrf_field() ?>
                    <input type="hidden" name="form_type" value="login">

                    <div class="mode-switch" role="radiogroup" aria-label="登录方式">
                        <label>
                            <input type="radio" name="mode" value="password" checked onchange="switchMode()"> 账号密码登录
                        </label>
                        <label>
                            <input type="radio" name="mode" value="luogu" onchange="switchMode()"> 洛谷登录
                        </label>
                    </div>

                    <div class="field">
                        <label class="sr-only" for="usernameInput">用户名或 UID</label>
                        <input type="text" name="username" id="usernameInput" placeholder="用户名或 UID" required autocomplete="username">
                    </div>

                    <div class="field">
                        <label class="sr-only" for="passwordInput">密码</label>
                        <input type="password" name="pwd" id="passwordInput" placeholder="密码" required autocomplete="current-password">
                    </div>

                    <!-- <input type="checkbox" name="autologin" value="1" id="autologin"> -->
                    <!-- <label for="autologin">自动登录（30天有效）</label> -->

                    <button type="submit">登录</button>
                </form>

                <div class="tip">
                    没有账号？<a href="https://lmtoj.cn/register">立即注册</a>
                    <span class="tip-divider">|</span>
                    <a onclick="showForgotForm()">忘记密码？</a>
                </div>
            </div>

            <!-- 忘记密码表单区域（两步） -->
            <div id="forgotFormDiv" class="hidden">
                <h1 class="title" id="forgot-title">找回密码</h1>
                <div id="forgotMessage" class="hidden" aria-live="polite"></div>
                <?= csrf_field() ?> <!-- 提供 CSRF token 给 JS -->

                <!-- 第一步：输入洛谷 UID 生成验证码 -->
                <div id="forgotStep1">
                    <div class="field">
                        <label class="sr-only" for="forgotLuoguUid">洛谷 UID</label>
                        <input type="text" id="forgotLuoguUid" placeholder="洛谷 UID（数字）" autocomplete="off">
                    </div>
                    <button type="button" id="generateCodeBtn" onclick="generateResetCode()">生成验证码</button>
                </div>

                <!-- 第二步：显示验证码并重置密码 -->
                <div id="forgotStep2" class="hidden">
                    <div class="verify-code-display" id="resetCodeDisplay" onclick="copyResetCode()" title="点击复制验证码"></div>
                    <p class="forgot-hint">
                        请将验证码复制到洛谷个人签名中，然后填写新密码并点击验证。
                    </p>
                    <div class="field">
                        <label class="sr-only" for="newPassword">新密码</label>
                        <input type="password" id="newPassword" placeholder="新密码（至少6位）" autocomplete="new-password">
                    </div>
                    <div class="field">
                        <label class="sr-only" for="newPasswordConfirm">确认新密码</label>
                        <input type="password" id="newPasswordConfirm" placeholder="确认新密码" autocomplete="new-password">
                    </div>
                    <button type="button" id="verifyResetBtn" onclick="verifyResetCode()">检查验证并重置密码</button>
                </div>

                <div class="form-switch">
                    <a onclick="showLoginForm()">返回登录</a>
                </div>
            </div>
        </section>
    </main>
<script>
    function switchMode() {
        const mode = document.querySelector('input[name="mode"]:checked').value;
        const input = document.getElementById('usernameInput');
        if (mode === 'luogu') {
            input.placeholder = '绑定的洛谷 UID';
        } else {
            input.placeholder = '用户名或 UID';
        }
    }

    function showForgotForm() {
        document.getElementById('loginFormDiv').classList.add('hidden');
        document.getElementById('forgotFormDiv').classList.remove('hidden');
        // 重置为第一步
        document.getElementById('forgotStep1').classList.remove('hidden');
        document.getElementById('forgotStep2').classList.add('hidden');
        document.getElementById('forgotMessage').classList.add('hidden');
        document.getElementById('forgotLuoguUid').value = '';
        document.getElementById('newPassword').value = '';
        document.getElementById('newPasswordConfirm').value = '';
        resetCode = '';
    }

    function showLoginForm() {
        document.getElementById('forgotFormDiv').classList.add('hidden');
        document.getElementById('loginFormDiv').classList.remove('hidden');
        document.getElementById('forgotMessage').classList.add('hidden');
    }

    function getCsrfToken() {
        const input = document.querySelector('#forgotFormDiv input[name="csrf_token"]');
        return input ? input.value : '';
    }

    function generateResetCode() {
        const luoguUid = document.getElementById('forgotLuoguUid').value.trim();
        if (!luoguUid) {
            showForgotError('请输入洛谷 UID');
            return;
        }
        const messageDiv = document.getElementById('forgotMessage');
        messageDiv.classList.add('hidden');
        const btn = document.getElementById('generateCodeBtn');
        btn.disabled = true;
        btn.textContent = '生成中...';

        fetch('login.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: new URLSearchParams({
                form_type: 'forgot',
                sub_action: 'generate_reset_code',
                luogu_uid: luoguUid,
                csrf_token: getCsrfToken()
            })
        })
        .then(response => response.json())
        .then(data => {
            btn.disabled = false;
            btn.textContent = '生成验证码';
            if (data.success) {
                resetCode = data.verify_code;
                const display = document.getElementById('resetCodeDisplay');
                display.textContent = data.verify_code;
                // 切换到第二步
                document.getElementById('forgotStep1').classList.add('hidden');
                document.getElementById('forgotStep2').classList.remove('hidden');
            } else {
                showForgotError(data.error || '生成验证码失败');
            }
        })
        .catch(error => {
            btn.disabled = false;
            btn.textContent = '生成验证码';
            showForgotError('网络错误，请稍后重试');
        });
    }

    function verifyResetCode() {
        const newPassword = document.getElementById('newPassword').value;
        const newPasswordConfirm = document.getElementById('newPasswordConfirm').value;
        if (!newPassword || !newPasswordConfirm) {
            showForgotError('请填写新密码');
            return;
        }
        if (newPassword !== newPasswordConfirm) {
            showForgotError('两次输入的新密码不一致');
            return;
        }
        if (newPassword.length < 6) {
            showForgotError('新密码长度至少 6 位');
            return;
        }
        const messageDiv = document.getElementById('forgotMessage');
        messageDiv.classList.add('hidden');
        const btn = document.getElementById('verifyResetBtn');
        btn.disabled = true;
        btn.textContent = '验证中...';

        fetch('login.php', {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest' },
            body: new URLSearchParams({
                form_type: 'forgot',
                sub_action: 'verify_reset_code',
                new_password: newPassword,
                new_password_confirm: newPasswordConfirm,
                csrf_token: getCsrfToken()
            })
        })
        .then(response => response.json())
        .then(data => {
            btn.disabled = false;
            btn.textContent = '检查验证并重置密码';
            if (data.success) {
                showForgotSuccess(data.message || '密码重置成功');
                setTimeout(() => showLoginForm(), 2000);
            } else {
                showForgotError(data.error || '验证失败');
            }
        })
        .catch(error => {
            btn.disabled = false;
            btn.textContent = '检查验证并重置密码';
            showForgotError('网络错误，请稍后重试');
        });
    }

    function showForgotError(msg) {
        const div = document.getElementById('forgotMessage');
        div.className = 'error';
        div.textContent = msg;
        div.classList.remove('hidden');
    }

    function showForgotSuccess(msg) {
        const div = document.getElementById('forgotMessage');
        div.className = 'success';
        div.textContent = msg;
        div.classList.remove('hidden');
    }

    function copyResetCode() {
        const code = resetCode || document.getElementById('resetCodeDisplay').textContent;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(code).then(() => {
                const el = document.getElementById('resetCodeDisplay');
                const orig = el.textContent;
                el.textContent = '已复制！';
                setTimeout(() => { el.textContent = orig; }, 1500);
            });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = code;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try { document.execCommand('copy'); } catch(e) {}
            document.body.removeChild(textarea);
            const el = document.getElementById('resetCodeDisplay');
            const orig = el.textContent;
            el.textContent = '已复制！';
            setTimeout(() => { el.textContent = orig; }, 1500);
        }
    }

    // ========== 自动登录：检查 cookie 并自动提交 ==========
    (function autoLogin() {
        // 仅在未登录状态下执行（服务端已重定向，但以防万一）
        // 检查 cookie 中是否有自动登录信息
        function getCookie(name) {
            const match = document.cookie.match(new RegExp('(^| )' + name + '=([^;]+)'));
            return match ? decodeURIComponent(match[2]) : null;
        }

        const encUser = getCookie('lmtoj_username');
        const encPass = getCookie('lmtoj_password');
        if (encUser && encPass) {
            try {
                const username = atob(encUser);
                const password = atob(encPass);
                // 填充表单
                const usernameInput = document.getElementById('usernameInput');
                const passwordInput = document.getElementById('passwordInput');
                if (usernameInput && passwordInput) {
                    usernameInput.value = username;
                    passwordInput.value = password;
                    // 模拟点击登录按钮（提交表单）
                    const form = document.getElementById('loginForm');
                    if (form) {
                        // 为了避免可能出现的重复提交，提交后清除 cookie（或者保留，但服务端登录后 session 已存在，再次访问会重定向）
                        // 但登录成功后 cookie 仍会保留（因为服务端重新设置），所以下次访问页面时已登录会被重定向，不会执行到这里。
                        // 因此直接提交即可。
                        // 但为防止用户手动清除 session 后，仍保留 cookie，让用户免输入。
                        form.submit();
                    }
                }
            } catch (e) {
                // 解码失败，忽略
            }
        }
    })();
</script>
</body>
</html>
