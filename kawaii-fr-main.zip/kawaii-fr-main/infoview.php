<?php
session_start();
date_default_timezone_set('Asia/Shanghai');

// ---------- 密码验证 ----------
$correct_password = "asoshirena/ll/bx";
$auth_key = 'infoview_auth';
$expire_key = 'infoview_expire';
$expire_seconds = 48 * 3600; // 48小时

$authenticated = false;
if (isset($_SESSION[$auth_key]) && $_SESSION[$auth_key] === true) {
    $expire_time = $_SESSION[$expire_key] ?? 0;
    if (time() < $expire_time) {
        $authenticated = true;
    } else {
        unset($_SESSION[$auth_key]);
        unset($_SESSION[$expire_key]);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['password'])) {
    $input = trim($_POST['password']);
    if ($input === $correct_password) {
        $_SESSION[$auth_key] = true;
        $_SESSION[$expire_key] = time() + $expire_seconds;
        $authenticated = true;
        header('Location: ' . $_SERVER['REQUEST_URI']);
        exit;
    } else {
        $error = '密码错误，请重试。';
    }
}

if (!$authenticated) {
    ?>
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>访问验证</title>
    <style>
        body{font-family:'Segoe UI',sans-serif;background:#f9f7f4;display:flex;justify-content:center;align-items:center;height:100vh;margin:0;}
        .login-box{background:#fff;padding:40px 50px;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,0.08);text-align:center;}
        .login-box h2{margin-top:0;color:#2c2a28;}
        .login-box input[type="password"]{padding:10px 16px;width:220px;border:1px solid #ddd;border-radius:6px;font-size:16px;}
        .login-box button{padding:10px 30px;background:#6b8a74;color:#fff;border:none;border-radius:6px;font-size:16px;cursor:pointer;margin-top:12px;}
        .login-box button:hover{background:#55735e;}
        .error{color:#d9534f;margin-top:10px;}
    </style>
    </head>
    <body>
        <div class="login-box">
            <h2>请输入访问密码</h2>
            <form method="post">
                <input type="password" name="password" placeholder="请输入密码" autofocus required><br>
                <button type="submit">确认</button>
                <?php if (isset($error)): ?><div class="error"><?= htmlspecialchars($error) ?></div><?php endif; ?>
            </form>
            <p style="font-size:13px;color:#999;margin-top:20px;">密码有效期48小时</p>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------- 通过验证，处理删除请求 ----------
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");
// 强制MySQL返回东八区时间
$conn->query("SET time_zone = '+08:00'");

// ---------- 创建 del_log 表（如果不存在） ----------
$conn->query("CREATE TABLE IF NOT EXISTS del_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    page_visits_id INT NOT NULL,
    info_log2_ids TEXT,
    operator_uid INT DEFAULT 0,
    operator_username VARCHAR(255) DEFAULT '',
    operator_ip VARCHAR(45) DEFAULT '',
    delete_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(page_visits_id),
    INDEX(operator_uid),
    INDEX(delete_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 获取操作者信息 ----------
$operator_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
$operator_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$operator_username = '';
if ($operator_uid > 0) {
    $stmt = $conn->prepare("SELECT name FROM users WHERE uid = ? LIMIT 1");
    $stmt->bind_param('i', $operator_uid);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $operator_username = $res['name'] ?? '';
    $stmt->close();
}
if (empty($operator_username)) {
    $operator_username = '未登录';
}

// ---------- 执行删除（先记录日志，再删除） ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_ids'])) {
    $ids = $_POST['delete_ids'];
    if (!is_array($ids)) {
        $ids = [$ids];
    }
    $ids = array_map('intval', $ids);
    if (!empty($ids)) {
        // 开启事务
        $conn->begin_transaction();
        try {
            foreach ($ids as $del_id) {
                // 1. 查询该 page_visits 记录的详细信息（用于匹配 info_log2）
                $stmt = $conn->prepare("SELECT uid, ip, user_agent, page_url, created_at FROM page_visits WHERE id = ?");
                $stmt->bind_param('i', $del_id);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if (!$row) {
                    continue; // 记录不存在则跳过
                }
                // 2. 在 info_log2 中查找匹配的记录 ID（可能多个）
                $stmt2 = $conn->prepare("SELECT GROUP_CONCAT(id ORDER BY id) AS ids FROM info_log2 
                                         WHERE uid = ? AND ip = ? AND user_agent = ? AND page_url = ? AND created_at = ?");
                $stmt2->bind_param('issss', $row['uid'], $row['ip'], $row['user_agent'], $row['page_url'], $row['created_at']);
                $stmt2->execute();
                $res2 = $stmt2->get_result()->fetch_assoc();
                $info_log2_ids = $res2['ids'] ?? '';
                $stmt2->close();

                // 3. 记录删除日志
                $stmt3 = $conn->prepare("INSERT INTO del_log (page_visits_id, info_log2_ids, operator_uid, operator_username, operator_ip) 
                                         VALUES (?, ?, ?, ?, ?)");
                $stmt3->bind_param('isiss', $del_id, $info_log2_ids, $operator_uid, $operator_username, $operator_ip);
                $stmt3->execute();
                $stmt3->close();

                // 4. 删除 page_visits 记录
                $stmt4 = $conn->prepare("DELETE FROM page_visits WHERE id = ?");
                $stmt4->bind_param('i', $del_id);
                $stmt4->execute();
                $stmt4->close();
            }
            $conn->commit();
            header('Location: ' . $_SERVER['REQUEST_URI']);
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            // 可记录错误日志，但不中断显示
            // 简单处理：重定向并显示错误信息（可增加消息传递）
            header('Location: ' . $_SERVER['REQUEST_URI'] . '?error=delete_failed');
            exit;
        }
    }
}

// ---------- 查询参数 ----------
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$filterUid = isset($_GET['filter_uid']) ? (int)$_GET['filter_uid'] : 0;
$filterDate = isset($_GET['filter_date']) ? trim($_GET['filter_date']) : '';
$filterPage = isset($_GET['filter_page']) ? trim($_GET['filter_page']) : '';
$filterUsername = isset($_GET['filter_username']) ? trim($_GET['filter_username']) : '';

$where = [];
$params = [];
$types = '';

if ($filterUid > 0) {
    $where[] = "v.uid = ?";
    $params[] = $filterUid;
    $types .= 'i';
}
if (!empty($filterDate)) {
    $where[] = "DATE(v.created_at) = ?";
    $params[] = $filterDate;
    $types .= 's';
}
if (!empty($filterPage)) {
    $where[] = "v.page_url LIKE ?";
    $params[] = '%' . $filterPage . '%';
    $types .= 's';
}
if (!empty($filterUsername)) {
    $where[] = "u.name LIKE ?";
    $params[] = '%' . $filterUsername . '%';
    $types .= 's';
}

$whereClause = empty($where) ? '' : 'WHERE ' . implode(' AND ', $where);

// 统计总数
$countSql = "SELECT COUNT(*) AS total 
             FROM page_visits v 
             LEFT JOIN users u ON v.uid = u.uid 
             $whereClause";
$stmt = $conn->prepare($countSql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$total = $stmt->get_result()->fetch_assoc()['total'] ?? 0;
$stmt->close();
$totalPages = ceil($total / $perPage);

// 查询数据
$sql = "SELECT v.id, v.uid, u.name AS username, v.ip, v.user_agent, v.page_url, v.created_at 
        FROM page_visits v
        LEFT JOIN users u ON v.uid = u.uid
        $whereClause 
        ORDER BY v.created_at DESC 
        LIMIT ?, ?";
$params[] = $offset;
$params[] = $perPage;
$types .= 'ii';
$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$records = $stmt->get_result();
$stmt->close();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>访问数据查看 - lmtOJ</title>
    <style>
        body { font-family: 'Segoe UI', 'PingFang SC', sans-serif; background: #f9f7f4; margin: 0; padding: 20px; }
        .container { max-width: 1400px; margin: 0 auto; background: #fff; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); padding: 24px; }
        h1 { font-size: 22px; margin-top: 0; }
        .filter-bar { display: flex; gap: 12px; flex-wrap: wrap; margin-bottom: 20px; align-items: center; }
        .filter-bar input, .filter-bar button { padding: 6px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; }
        .filter-bar button { background: #6b8a74; color: #fff; border: none; cursor: pointer; }
        .filter-bar button:hover { background: #55735e; }
        .filter-bar .del-btn { background: #d9534f; }
        .filter-bar .del-btn:hover { background: #c0392b; }
        table { width: 100%; border-collapse: collapse; font-size: 14px; }
        th { text-align: left; padding: 10px 12px; background: #fafaf8; border-bottom: 2px solid #e6e1da; }
        td { padding: 10px 12px; border-bottom: 1px solid #f0ece6; vertical-align: top; word-break: break-word; }
        tr:hover { background: #fdfcf9; }
        .pagination { margin-top: 20px; display: flex; gap: 6px; flex-wrap: wrap; }
        .pagination a, .pagination span { padding: 6px 12px; border: 1px solid #ddd; border-radius: 20px; text-decoration: none; color: #333; }
        .pagination a.active { background: #6b8a74; color: #fff; border-color: #6b8a74; }
        .pagination a:hover { background: #f5f2ed; }
        .empty { color: #999; text-align: center; padding: 40px 0; }
        .badge { background: #eef4ef; color: #55735e; padding: 2px 8px; border-radius: 12px; font-size: 12px; }
        .del-checkbox { width: 18px; height: 18px; cursor: pointer; }
        .btn-del-single { background: none; border: none; color: #d9534f; cursor: pointer; font-size: 14px; padding: 2px 6px; }
        .btn-del-single:hover { text-decoration: underline; }
        .username-link { color: #6b8a74; text-decoration: none; }
        .username-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
<div class="container">
    <h1>用户访问记录</h1>

    <form method="get" class="filter-bar">
        <input type="number" name="filter_uid" placeholder="UID" value="<?= htmlspecialchars($filterUid ?: '') ?>">
        <input type="text" name="filter_username" placeholder="用户名关键词" value="<?= htmlspecialchars($filterUsername) ?>">
        <input type="date" name="filter_date" value="<?= htmlspecialchars($filterDate) ?>">
        <input type="text" name="filter_page" placeholder="页面关键词" value="<?= htmlspecialchars($filterPage) ?>">
        <button type="submit">筛选</button>
        <span style="margin-left:auto; color:#777;">共 <?= $total ?> 条记录</span>
    </form>

    <!-- 批量删除表单 -->
    <form method="post" onsubmit="return confirm('确定删除选中的记录吗？');">
        <div style="margin-bottom:12px;">
            <button type="submit" class="filter-bar del-btn" style="padding:6px 16px;">删除选中</button>
        </div>
        <table>
            <thead>
                <tr>
                    <th width="40"><input type="checkbox" id="checkAll" class="del-checkbox"></th>
                    <th>ID</th>
                    <th>UID</th>
                    <th>用户名</th>
                    <th>IP</th>
                    <th>设备信息</th>
                    <th>访问页面</th>
                    <th>访问时间</th>
                    <th width="60">操作</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($records && $records->num_rows > 0): ?>
                    <?php while ($row = $records->fetch_assoc()): 
                        $displayTime = date('Y-m-d H:i:s', strtotime($row['created_at']));
                        $uid = (int)$row['uid'];
                        $username = $row['username'] ?? '';
                        if ($uid === 0) {
                            $displayName = '<span class="badge">未登录</span>';
                        } elseif (empty($username)) {
                            $displayName = '<span class="badge">用户已删除</span>';
                        } else {
                            $displayName = '<a href="https://lmtoj.cn/user/' . $uid . '" class="username-link">' . htmlspecialchars($username) . '</a>';
                        }
                    ?>
                    <tr>
                        <td><input type="checkbox" name="delete_ids[]" value="<?= $row['id'] ?>" class="del-checkbox item-check"></td>
                        <td><?= $row['id'] ?></td>
                        <td><?= $uid ?: '<span class="badge">未登录</span>' ?></td>
                        <td><?= $displayName ?></td>
                        <td><?= htmlspecialchars($row['ip']) ?></td>
                        <td style="max-width:300px;"><?= htmlspecialchars($row['user_agent']) ?></td>
                        <td style="max-width:350px;"><?= htmlspecialchars($row['page_url']) ?></td>
                        <td><?= $displayTime ?></td>
                        <td>
                            <button type="submit" name="delete_ids[]" value="<?= $row['id'] ?>" class="btn-del-single" onclick="return confirm('确定删除这条记录吗？');">删除</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="9" class="empty">暂无记录</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </form>

    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?= $page-1 ?>&filter_uid=<?= $filterUid ?>&filter_username=<?= urlencode($filterUsername) ?>&filter_date=<?= urlencode($filterDate) ?>&filter_page=<?= urlencode($filterPage) ?>">上一页</a>
        <?php endif; ?>
        <?php
        $range = 3;
        $start = max(1, $page - $range);
        $end = min($totalPages, $page + $range);
        if ($start > 1) echo '<span>…</span>';
        for ($i = $start; $i <= $end; $i++): ?>
            <a href="?page=<?= $i ?>&filter_uid=<?= $filterUid ?>&filter_username=<?= urlencode($filterUsername) ?>&filter_date=<?= urlencode($filterDate) ?>&filter_page=<?= urlencode($filterPage) ?>" class="<?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor;
        if ($end < $totalPages) echo '<span>…</span>'; ?>
        <?php if ($page < $totalPages): ?>
            <a href="?page=<?= $page+1 ?>&filter_uid=<?= $filterUid ?>&filter_username=<?= urlencode($filterUsername) ?>&filter_date=<?= urlencode($filterDate) ?>&filter_page=<?= urlencode($filterPage) ?>">下一页</a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<script>
document.getElementById('checkAll')?.addEventListener('change', function() {
    document.querySelectorAll('.item-check').forEach(cb => cb.checked = this.checked);
});
</script>
</body>
</html>