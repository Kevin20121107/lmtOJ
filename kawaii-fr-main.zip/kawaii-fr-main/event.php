<?php
/**
 * LMTOJ · 最后一次提交
 * /event.php
 * 全站事件状态（mysqli）
 *
 * 任何页面都可以：
 *     require_once __DIR__ . '/event.php';
 * 然后拿到 $decrypt5_state
 *
 * 也可以 AJAX POST：
 *     action=status / page_view
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['uid'])) {
    return [
        'uid'    => 0,
        'status' => 'guest',
        'csrf'   => '',
    ];
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset('utf8mb4');

$uid = (int)$_SESSION['uid'];


/* =========================================================
   活动时间（与 qwq.php 保持一致）
   ========================================================= */

$DECRYPT5_PREHEAT = '2026-09-15 00:00:00';
$DECRYPT5_START   = '2026-09-15 00:00:00';
$DECRYPT5_END     = '2026-09-20 20:00:00';

$now   = new DateTimeImmutable('now');
$start = new DateTimeImmutable($DECRYPT5_START);
$end   = new DateTimeImmutable($DECRYPT5_END);

if ($now < $start) {
    $decrypt5_status = 'preheat';
} elseif ($now < $end) {
    $decrypt5_status = 'active';
} else {
    $decrypt5_status = 'ended';
}


/* =========================================================
   CSRF
   ========================================================= */

if (empty($_SESSION['decrypt5_csrf'])) {
    $_SESSION['decrypt5_csrf'] = bin2hex(random_bytes(32));
}
$decrypt5_csrf = $_SESSION['decrypt5_csrf'];


/* =========================================================
   事件日志（函数与 qwq.php 内的一致）
   ========================================================= */

if (!function_exists('decrypt5_log_event')) {
    function decrypt5_log_event(
        mysqli $conn,
        int $uid,
        string $eventType,
        string $eventCode = '',
        string $page = '',
        array $metadata = []
    ): void {
        $metaJson = json_encode(
            $metadata,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );

        $stmt = $conn->prepare("
            INSERT INTO decrypt5_event_log
            (uid, event_type, event_code, page, metadata, created_at)
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param(
            'issss',
            $uid,
            $eventType,
            $eventCode,
            $page,
            $metaJson
        );
        $stmt->execute();
        $stmt->close();
    }
}


/* =========================================================
   读取用户事件状态
   ========================================================= */

$stmt = $conn->prepare("
    INSERT IGNORE INTO decrypt5_event_state
    (uid, created_at, updated_at)
    VALUES (?, NOW(), NOW())
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$stmt->close();

$stmt = $conn->prepare("
    SELECT *
    FROM decrypt5_event_state
    WHERE uid = ?
    LIMIT 1
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
$decrypt5_state = $res ? $res->fetch_assoc() : null;
$stmt->close();

if (!$decrypt5_state) {
    $decrypt5_state = [
        'collapse_triggered' => 0,
        'collapse_count'     => 0,
        'collapse_first_at'  => null,
        'rebirth_triggered'  => 0,
        'rebirth_count'      => 0,
        'rebirth_first_at'   => null,
        'last_event'         => '',
        'last_event_at'      => null,
    ];
}


/* =========================================================
   是否通关第五章
   ========================================================= */

$decrypt5_final = 0;

$stmt = $conn->prepare("
    SELECT COUNT(*) AS c
    FROM decrypt5_submissions
    WHERE uid = ?
      AND chapter = 5
      AND is_correct = 1
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$r = $stmt->get_result();
$decrypt5_final = $r ? (int)$r->fetch_assoc()['c'] : 0;
$stmt->close();


/* =========================================================
   AJAX
   ========================================================= */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['action'])
    && in_array($_POST['action'], ['status', 'page_view'], true)
) {
    header('Content-Type: application/json; charset=utf-8');

    $csrf = $_POST['csrf'] ?? '';
    if (!hash_equals($decrypt5_csrf, $csrf)) {
        echo json_encode(['success' => false, 'message' => 'CSRF_ERROR'], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $action = $_POST['action'];

    if ($action === 'status') {
        echo json_encode([
            'success' => true,
            'status'  => $decrypt5_status,
            'state'   => $decrypt5_state,
            'final'   => (bool)$decrypt5_final,
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'page_view') {
        $page = trim($_POST['page'] ?? '');
        decrypt5_log_event(
            $conn,
            $uid,
            'PAGE_VIEW',
            strtoupper(preg_replace('/[^A-Za-z0-9_\-]/', '_', $page)),
            $page
        );
        echo json_encode(['success' => true], JSON_UNESCAPED_UNICODE);
        exit;
    }
}


/* =========================================================
   返回给其它 PHP 页面
   ========================================================= */

return [
    'uid'    => $uid,
    'status' => $decrypt5_status,
    'preheat'=> $DECRYPT5_PREHEAT,
    'start'  => $DECRYPT5_START,
    'end'    => $DECRYPT5_END,

    'collapse' =>
        (bool)$decrypt5_state['collapse_triggered'],
    'collapse_count' =>
        (int)$decrypt5_state['collapse_count'],
    'collapse_first_at' =>
        $decrypt5_state['collapse_first_at'],

    'rebirth' =>
        (bool)$decrypt5_state['rebirth_triggered'],
    'rebirth_count' =>
        (int)$decrypt5_state['rebirth_count'],
    'rebirth_first_at' =>
        $decrypt5_state['rebirth_first_at'],

    'final' => (bool)$decrypt5_final,

    'last_event' =>
        $decrypt5_state['last_event'],
    'last_event_at' =>
        $decrypt5_state['last_event_at'],

    'csrf' => $decrypt5_csrf,
];