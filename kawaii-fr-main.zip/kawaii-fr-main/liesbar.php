<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

if (file_exists('visit_log.php')) require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ===== 权限拦截：非管理员禁止访问 =====
if (!$is_admin && !$is_sqadmin) {
    header("Location: https://lmtoj.cn/");
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 建表 ----------
$conn->query("CREATE TABLE IF NOT EXISTS liesbar_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(16) NOT NULL UNIQUE,
    host_uid INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'waiting',
    max_players INT DEFAULT 6,
    game_state LONGTEXT,
    version INT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS liesbar_room_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    is_ready TINYINT DEFAULT 0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_room_user (room_id, uid),
    INDEX (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS liesbar_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    msg VARCHAR(500) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (room_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$login_uid = (int)$_SESSION['uid'];
// 增加查询 admin 和 sqadmin 字段
$userRow = $conn->query("SELECT name, avatar, admin, sqadmin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$login_name = $userRow['name'] ?? '玩家';
$login_avatar = $userRow['avatar'] ?? '/upload/default.png';
$is_admin = (int)($userRow['admin'] ?? 0);
$is_sqadmin = (int)($userRow['sqadmin'] ?? 0);

// ---------- 核心游戏函数 ----------
function generateDeck(&$mainRank, &$hasDevil) {
    $ranks = ['Q', 'K', 'A'];
    $mainRank = $ranks[array_rand($ranks)];
    $deck = [];
    foreach ($ranks as $r) {
        for ($i = 0; $i < 6; $i++) {
            $isDevil = ($r === $mainRank && $i === 0 && rand(0, 1) === 1);
            $deck[] = [
                'cid' => uniqid('c_'),
                'rank' => $r,
                'is_devil' => $isDevil,
                'is_joker' => false
            ];
        }
    }
    for ($i = 0; $i < 2; $i++) {
        $deck[] = [
            'cid' => uniqid('c_'),
            'rank' => 'Joker',
            'is_devil' => false,
            'is_joker' => true
        ];
    }
    shuffle($deck);
    return $deck;
}

function drawCards(&$state, $count) {
    $cards = [];
    for ($i = 0; $i < $count; $i++) {
        if (empty($state['deck'])) break;
        $cards[] = array_pop($state['deck']);
    }
    return $cards;
}

function addLog(&$state, $msg) {
    if (!isset($state['logs'])) $state['logs'] = [];
    $time = date('H:i:s');
    $state['logs'][] = "[$time] " . $msg;
    if (count($state['logs']) > 70) array_shift($state['logs']);
}

function getPlayerIndex($state, $uid) {
    foreach ($state['players'] as $idx => $p) {
        if ((int)$p['uid'] === (int)$uid) return $idx;
    }
    return -1;
}

function getNextAlivePlayer($state, $fromIdx) {
    $n = count($state['players']);
    $idx = ($fromIdx + 1) % $n;
    $tries = 0;
    while ($state['players'][$idx]['out'] && $tries < $n) {
        $idx = ($idx + 1) % $n;
        $tries++;
    }
    return ($state['players'][$idx]['out']) ? -1 : $idx;
}

function fireGun(&$state, $targetIdx) {
    $shot = rand(1, 6);
    $hit = ($shot === 1);
    $player = &$state['players'][$targetIdx];
    if ($hit) {
        $player['out'] = true;
        addLog($state, "💥 <strong>{$player['name']}</strong> 中弹！被淘汰。");
    } else {
        addLog($state, "🔫 <strong>{$player['name']}</strong> 空枪，继续存活。");
    }
    return $hit;
}

function checkGameOver(&$state) {
    $alive = array_filter($state['players'], function($p) { return !$p['out']; });
    if (count($alive) === 1) {
        $winner = reset($alive);
        $state['status'] = 'finished';
        addLog($state, "🏆 <strong>{$winner['name']}</strong> 获胜！");
        return true;
    } elseif (count($alive) === 0) {
        $state['status'] = 'finished';
        addLog($state, "所有玩家出局，平局！");
        return true;
    }
    return false;
}

function startGame($roomId, $players) {
    $mainRank = 'Q';
    $hasDevil = false;
    $deck = generateDeck($mainRank, $hasDevil);
    $state = [
        'status' => 'playing',
        'deck' => $deck,
        'discard' => [],
        'main_rank' => $mainRank,
        'has_devil' => $hasDevil,
        'players' => [],
        'current_player' => 0,
        'phase' => 'play',
        'pending' => null,
        'turn_count' => 0,
        'logs' => [],
        'room_id' => $roomId
    ];
    foreach ($players as $p) {
        $hand = drawCards($state, 5);
        $state['players'][] = [
            'uid' => (int)$p['uid'],
            'name' => $p['name'],
            'avatar' => $p['avatar'] ?: '',
            'hand' => $hand,
            'out' => false,
            'last_action_time' => time()
        ];
    }
    addLog($state, "游戏开始！主牌为 <strong>{$mainRank}</strong>，每人5张牌。");
    addLog($state, "轮到 <strong>{$state['players'][0]['name']}</strong> 出牌。");
    return $state;
}

function processPlay(&$state, $playerIdx, $cardIndices) {
    if ($state['status'] !== 'playing') return false;
    if ($state['phase'] !== 'play') return false;
    if ($state['current_player'] != $playerIdx) return false;
    $p = &$state['players'][$playerIdx];
    if (empty($cardIndices) || count($cardIndices) > 3) return false;
    $cards = [];
    $hasDevil = false;
    foreach ($cardIndices as $idx) {
        if (!isset($p['hand'][$idx])) return false;
        $card = $p['hand'][$idx];
        if ($card['is_devil']) {
            if ($hasDevil) return false;
            $hasDevil = true;
        }
        $cards[] = $card;
    }
    rsort($cardIndices);
    foreach ($cardIndices as $idx) {
        array_splice($p['hand'], $idx, 1);
    }
    $state['pending'] = [
        'player_idx' => $playerIdx,
        'cards' => $cards,
        'declared_rank' => $state['main_rank'],
        'has_devil' => $hasDevil,
        'believe_count' => 0,
        'all_believed' => false
    ];
    $state['phase'] = 'waiting_challenge';
    $p['last_action_time'] = time();
    addLog($state, "<strong>{$p['name']}</strong> 打出了 " . count($cards) . " 张牌，声明为 <strong>{$state['main_rank']}</strong>。等待质疑。");
    return true;
}

function processChallenge(&$state, $challengerIdx) {
    if ($state['phase'] !== 'waiting_challenge') return false;
    $pending = $state['pending'];
    if (!$pending) return false;
    $next = getNextAlivePlayer($state, $pending['player_idx']);
    if ($next != $challengerIdx) return false;
    $player = &$state['players'][$pending['player_idx']];
    $challenger = &$state['players'][$challengerIdx];
    $state['phase'] = 'resolving';
    
    $allTrue = true;
    foreach ($pending['cards'] as $c) {
        if (!$c['is_joker'] && $c['rank'] !== $state['main_rank']) {
            $allTrue = false;
            break;
        }
    }
    $isLie = !$allTrue;
    addLog($state, "🔍 翻开牌验证...");
    
    if ($pending['has_devil']) {
        addLog($state, "💀 恶魔牌被触发！除出牌者外所有玩家必须开枪！");
        foreach ($state['players'] as $idx => $p) {
            if ($idx != $pending['player_idx'] && !$p['out']) {
                fireGun($state, $idx);
            }
        }
        $state['pending'] = null;
        $state['phase'] = 'play';
        if (checkGameOver($state)) return true;
        if (!$player['out'] && empty($player['hand'])) {
            $state['status'] = 'finished';
            addLog($state, "🏆 <strong>{$player['name']}</strong> 出完所有手牌，获胜！");
            return true;
        }
        $nextPlayer = getNextAlivePlayer($state, $pending['player_idx']);
        if ($nextPlayer === -1) { $state['status'] = 'finished'; return true; }
        $state['current_player'] = $nextPlayer;
        addLog($state, "轮到 <strong>{$state['players'][$nextPlayer]['name']}</strong> 出牌。");
        return true;
    } else {
        if ($isLie) {
            addLog($state, "❌ <strong>{$player['name']}</strong> 撒谎！");
            fireGun($state, $pending['player_idx']);
        } else {
            addLog($state, "✅ <strong>{$player['name']}</strong> 说真话，质疑者 <strong>{$challenger['name']}</strong> 开枪！");
            fireGun($state, $challengerIdx);
        }
        $state['pending'] = null;
        $state['phase'] = 'play';
        if (checkGameOver($state)) return true;
        if (!$player['out'] && empty($player['hand'])) {
            $state['status'] = 'finished';
            addLog($state, "🏆 <strong>{$player['name']}</strong> 出完所有手牌，获胜！");
            return true;
        }
        $nextPlayer = getNextAlivePlayer($state, $pending['player_idx']);
        if ($nextPlayer === -1) { $state['status'] = 'finished'; return true; }
        $state['current_player'] = $nextPlayer;
        addLog($state, "轮到 <strong>{$state['players'][$nextPlayer]['name']}</strong> 出牌。");
        return true;
    }
}

function processBelieve(&$state, $believerIdx) {
    if ($state['phase'] !== 'waiting_challenge') return false;
    $pending = $state['pending'];
    if (!$pending) return false;
    $next = getNextAlivePlayer($state, $pending['player_idx']);
    if ($next != $believerIdx) return false;
    
    $pending['believe_count']++;
    $state['pending'] = $pending;
    addLog($state, "<strong>{$state['players'][$believerIdx]['name']}</strong> 选择相信。");
    
    $alive = array_filter($state['players'], function($p) { return !$p['out']; });
    $aliveCount = count($alive);
    if ($pending['believe_count'] >= $aliveCount - 1) {
        addLog($state, "📢 所有其他玩家都已相信，自动开牌验证！");
        $player = &$state['players'][$pending['player_idx']];
        $allTrue = true;
        foreach ($pending['cards'] as $c) {
            if (!$c['is_joker'] && $c['rank'] !== $state['main_rank']) {
                $allTrue = false;
                break;
            }
        }
        $isLie = !$allTrue;
        addLog($state, "🔍 翻开牌验证...");
        if ($isLie) {
            addLog($state, "⚠️ <strong>{$player['name']}</strong> 撒谎！但无人质疑，本局不惩罚，仅记录。");
        } else {
            addLog($state, "✅ <strong>{$player['name']}</strong> 说真话。");
        }
        foreach ($pending['cards'] as $c) {
            $state['discard'][] = $c;
        }
        $state['pending'] = null;
        $state['phase'] = 'play';
        if (empty($player['hand']) && !$player['out']) {
            $state['status'] = 'finished';
            addLog($state, "🏆 <strong>{$player['name']}</strong> 出完所有手牌，获胜！");
            return true;
        }
        $nextPlayer = getNextAlivePlayer($state, $pending['player_idx']);
        if ($nextPlayer === -1) { $state['status'] = 'finished'; return true; }
        $state['current_player'] = $nextPlayer;
        addLog($state, "轮到 <strong>{$state['players'][$nextPlayer]['name']}</strong> 出牌。");
        return true;
    }
    $nextNext = getNextAlivePlayer($state, $believerIdx);
    if ($nextNext === -1) {
        $state['pending'] = null;
        $state['phase'] = 'play';
        return true;
    }
    addLog($state, "轮到 <strong>{$state['players'][$nextNext]['name']}</strong> 决定（相信或质疑）。");
    return true;
}

// ---------- API 处理 ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['api_action'])) {
    header('Content-Type: application/json');
    $api = $_POST['api_action'];
    
    if ($api === 'get_rooms') {
        $res = $conn->query("SELECT r.*, u.name as host_name, COUNT(p.id) as current_players 
            FROM liesbar_rooms r 
            LEFT JOIN users u ON r.host_uid = u.uid 
            LEFT JOIN liesbar_room_players p ON r.id = p.room_id 
            GROUP BY r.id ORDER BY r.id DESC LIMIT 20");
        $rooms = [];
        while ($r = $res->fetch_assoc()) $rooms[] = $r;
        echo json_encode(['success' => true, 'rooms' => $rooms]);
        exit;
    }
    
    if ($api === 'create_room') {
        $title = trim($_POST['title'] ?? '') ?: ($login_name . '的骗子酒馆');
        $max_p = max(2, min(6, (int)($_POST['max_players'] ?? 6)));
        $code = substr(md5(uniqid(mt_rand(), true)), 0, 8);
        $stmt = $conn->prepare("INSERT INTO liesbar_rooms (room_code, host_uid, title, max_players, status, version) VALUES (?, ?, ?, ?, 'waiting', 1)");
        $stmt->bind_param("sisi", $code, $login_uid, $title, $max_p);
        $stmt->execute();
        $roomId = $stmt->insert_id;
        $stmt->close();
        $conn->query("INSERT INTO liesbar_room_players (room_id, uid, is_ready) VALUES ($roomId, $login_uid, 1)");
        echo json_encode(['success' => true, 'room_id' => $roomId]);
        exit;
    }
    
    if ($api === 'join_room') {
        $roomId = (int)$_POST['room_id'];
        $chk = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId AND status = 'waiting' LIMIT 1")->fetch_assoc();
        if (!$chk) { echo json_encode(['success'=>false,'msg'=>'房间已开始或不存在']); exit; }
        $cnt = $conn->query("SELECT COUNT(*) as c FROM liesbar_room_players WHERE room_id = $roomId")->fetch_assoc()['c'];
        if ($cnt >= $chk['max_players']) { echo json_encode(['success'=>false,'msg'=>'房间已满员']); exit; }
        $conn->query("INSERT IGNORE INTO liesbar_room_players (room_id, uid, is_ready) VALUES ($roomId, $login_uid, 0)");
        $conn->query("UPDATE liesbar_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    // 删除房间：房主或 sqadmin 均可
    if ($api === 'delete_room') {
        $roomId = (int)$_POST['room_id'];
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId AND status = 'waiting' LIMIT 1")->fetch_assoc();
        if (!$room) {
            echo json_encode(['success' => false, 'msg' => '房间不存在']);
            exit;
        }
        if ((int)$room['host_uid'] !== $login_uid && !$is_sqadmin) {
            echo json_encode(['success' => false, 'msg' => '无权操作（仅房主或超级管理员可删除）']);
            exit;
        }
        $conn->query("DELETE FROM liesbar_room_players WHERE room_id = $roomId");
        $conn->query("DELETE FROM liesbar_rooms WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'leave_room') {
        $roomId = (int)$_POST['room_id'];
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId LIMIT 1")->fetch_assoc();
        if ($room && $room['status'] !== 'waiting') {
            $state = json_decode($room['game_state'] ?? '{}', true);
            if (!empty($state['players'])) {
                $myInGame = false;
                foreach ($state['players'] as $p) {
                    if ($p['uid'] == $login_uid && !$p['out']) {
                        $myInGame = true;
                        break;
                    }
                }
                if ($myInGame) {
                    echo json_encode(['success' => false, 'msg' => '对局进行中，不能退出']);
                    exit;
                }
            }
        }
        $conn->query("DELETE FROM liesbar_room_players WHERE room_id = $roomId AND uid = $login_uid");
        $cnt = $conn->query("SELECT COUNT(*) as c FROM liesbar_room_players WHERE room_id = $roomId")->fetch_assoc()['c'];
        if ($cnt == 0) {
            $conn->query("DELETE FROM liesbar_rooms WHERE id = $roomId");
        } else {
            $newHost = $conn->query("SELECT uid FROM liesbar_room_players WHERE room_id = $roomId ORDER BY id ASC LIMIT 1")->fetch_assoc()['uid'];
            $conn->query("UPDATE liesbar_rooms SET host_uid = $newHost, version = version + 1 WHERE id = $roomId");
        }
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'kick_player') {
        $roomId = (int)$_POST['room_id'];
        $targetUid = (int)$_POST['target_uid'];
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId AND status = 'waiting' LIMIT 1")->fetch_assoc();
        if (!$room || (int)$room['host_uid'] !== $login_uid) {
            echo json_encode(['success' => false, 'msg' => '无权操作或房间状态已变更']);
            exit;
        }
        if ($targetUid === $login_uid) {
            echo json_encode(['success' => false, 'msg' => '不能踢出自己']);
            exit;
        }
        $conn->query("DELETE FROM liesbar_room_players WHERE room_id = $roomId AND uid = $targetUid");
        $conn->query("UPDATE liesbar_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'update_prep') {
        $roomId = (int)$_POST['room_id'];
        $ready = (int)($_POST['is_ready'] ?? 0);
        $conn->query("UPDATE liesbar_room_players SET is_ready = $ready WHERE room_id = $roomId AND uid = $login_uid");
        $conn->query("UPDATE liesbar_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'start_game') {
        $roomId = (int)$_POST['room_id'];
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId LIMIT 1")->fetch_assoc();
        if ($room['host_uid'] != $login_uid) { echo json_encode(['success'=>false,'msg'=>'只有房主可开启']); exit; }
        $playersRes = $conn->query("SELECT p.*, u.name, u.avatar FROM liesbar_room_players p LEFT JOIN users u ON p.uid = u.uid WHERE p.room_id = $roomId");
        $players = [];
        $unready = false;
        while ($p = $playersRes->fetch_assoc()) {
            if ($p['uid'] != $login_uid && !$p['is_ready']) {
                $unready = true;
                break;
            }
            $players[] = $p;
        }
        if (count($players) < 2) { echo json_encode(['success'=>false,'msg'=>'至少2人']); exit; }
        if ($unready) { echo json_encode(['success'=>false,'msg'=>'尚有玩家未准备']); exit; }
        $gameState = startGame($roomId, $players);
        $stateJson = $conn->real_escape_string(json_encode($gameState, JSON_UNESCAPED_UNICODE));
        $conn->query("UPDATE liesbar_rooms SET status = 'playing', game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'poll_state') {
        $roomId = (int)$_POST['room_id'];
        $clientVer = (int)($_POST['version'] ?? 0);
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId LIMIT 1")->fetch_assoc();
        if (!$room) { echo json_encode(['success'=>false,'msg'=>'房间不存在']); exit; }
        $state = json_decode($room['game_state'] ?? '{}', true);
        $stateUpdated = false;
        
        if ($room['status'] === 'playing' && !empty($state['players'])) {
            $now = time();
            $currentIdx = $state['current_player'];
            if (isset($state['players'][$currentIdx]) && !$state['players'][$currentIdx]['out']) {
                $last = $state['players'][$currentIdx]['last_action_time'] ?? $now;
                if ($now - $last > 60) {
                    $state['players'][$currentIdx]['out'] = true;
                    addLog($state, "⏰ <strong>{$state['players'][$currentIdx]['name']}</strong> 超时，自动淘汰！");
                    $state['pending'] = null;
                    $state['phase'] = 'play';
                    $next = getNextAlivePlayer($state, $currentIdx);
                    if ($next !== -1) {
                        $state['current_player'] = $next;
                        addLog($state, "轮到 <strong>{$state['players'][$next]['name']}</strong> 出牌。");
                    } else {
                        $state['status'] = 'finished';
                        addLog($state, "游戏结束，没有存活玩家。");
                    }
                    $stateUpdated = true;
                }
            }
        }
        
        if ($clientVer === (int)$room['version'] && !$stateUpdated) {
            echo json_encode(['success'=>true,'changed'=>false,'version'=>$clientVer]);
            exit;
        }
        
        $playersRes = $conn->query("SELECT p.*, u.name, u.avatar FROM liesbar_room_players p LEFT JOIN users u ON p.uid = u.uid WHERE p.room_id = $roomId");
        $roomPlayers = [];
        $isPlayer = false;
        while ($p = $playersRes->fetch_assoc()) {
            if ($p['uid'] == $login_uid) $isPlayer = true;
            $roomPlayers[] = $p;
        }
        
        if (!empty($state['players'])) {
            foreach ($state['players'] as &$p) {
                if ($p['uid'] != $login_uid) {
                    $p['hand_count'] = count($p['hand']);
                    $p['hand'] = [];
                } else {
                    $p['hand_count'] = count($p['hand']);
                }
            }
            unset($p);
        }
        
        $chatRes = $conn->query("SELECT uid, name, msg, created_at FROM liesbar_chat WHERE room_id = $roomId ORDER BY id DESC LIMIT 20");
        $chatMsgs = [];
        while ($row = $chatRes->fetch_assoc()) {
            $chatMsgs[] = [
                'uid' => (int)$row['uid'],
                'name' => htmlspecialchars($row['name']),
                'msg' => htmlspecialchars($row['msg']),
                'time' => date('H:i:s', strtotime($row['created_at']))
            ];
        }
        $chatMsgs = array_reverse($chatMsgs);
        
        if ($stateUpdated) {
            $roomStatus = $state['status'] ?? 'playing';
            $stateJson = $conn->real_escape_string(json_encode($state, JSON_UNESCAPED_UNICODE));
            $conn->query("UPDATE liesbar_rooms SET status = '$roomStatus', game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
            $room['version']++;
        }
        
        echo json_encode([
            'success' => true,
            'changed' => true,
            'version' => (int)$room['version'],
            'room' => $room,
            'room_players' => $roomPlayers,
            'game_state' => $state,
            'my_uid' => $login_uid,
            'is_spectator' => !$isPlayer,
            'chat_messages' => $chatMsgs
        ]);
        exit;
    }
    
    if ($api === 'game_action') {
        $roomId = (int)$_POST['room_id'];
        $action = $_POST['action_type'];
        $room = $conn->query("SELECT * FROM liesbar_rooms WHERE id = $roomId AND status = 'playing' LIMIT 1")->fetch_assoc();
        if (!$room) { echo json_encode(['success'=>false,'msg'=>'对局未在进行']); exit; }
        $state = json_decode($room['game_state'], true);
        $myIdx = getPlayerIndex($state, $login_uid);
        if ($myIdx === -1) { echo json_encode(['success'=>false,'msg'=>'你不在游戏中']); exit; }
        $player = &$state['players'][$myIdx];
        if ($player['out']) { echo json_encode(['success'=>false,'msg'=>'你已经出局']); exit; }
        
        if ($action === 'play_cards') {
            $indices = json_decode($_POST['card_indices'] ?? '[]', true);
            if (!is_array($indices) || empty($indices)) {
                echo json_encode(['success'=>false,'msg'=>'请选择至少一张牌']); exit;
            }
            $result = processPlay($state, $myIdx, $indices);
            if (!$result) { echo json_encode(['success'=>false,'msg'=>'无法出牌，请检查规则']); exit; }
            $player['last_action_time'] = time();
        } elseif ($action === 'challenge') {
            $result = processChallenge($state, $myIdx);
            if (!$result) { echo json_encode(['success'=>false,'msg'=>'无法质疑']); exit; }
            $player['last_action_time'] = time();
        } elseif ($action === 'believe') {
            $result = processBelieve($state, $myIdx);
            if (!$result) { echo json_encode(['success'=>false,'msg'=>'无法相信']); exit; }
            $player['last_action_time'] = time();
        } elseif ($action === 'surrender') {
            $player['out'] = true;
            addLog($state, "🏳️ <strong>{$player['name']}</strong> 认输出局。");
            checkGameOver($state);
            if ($state['status'] !== 'finished') {
                $next = getNextAlivePlayer($state, $myIdx);
                if ($next !== -1) {
                    $state['current_player'] = $next;
                    $state['phase'] = 'play';
                    addLog($state, "轮到 <strong>{$state['players'][$next]['name']}</strong> 出牌。");
                }
            }
            $player['last_action_time'] = time();
        }
        
        if ($state['status'] !== 'finished') {
            $cur = &$state['players'][$state['current_player']];
            if (empty($cur['hand']) && !$cur['out']) {
                $drawn = drawCards($state, 1);
                if (!empty($drawn)) {
                    $cur['hand'] = array_merge($cur['hand'], $drawn);
                    addLog($state, "<strong>{$cur['name']}</strong> 补了一张牌。");
                }
            }
        }
        $stateJson = $conn->real_escape_string(json_encode($state, JSON_UNESCAPED_UNICODE));
        $conn->query("UPDATE liesbar_rooms SET game_state = '$stateJson', version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
    
    if ($api === 'send_chat') {
        $roomId = (int)$_POST['room_id'];
        $msg = trim($_POST['msg'] ?? '');
        if (mb_strlen($msg) === 0 || mb_strlen($msg) > 500) {
            echo json_encode(['success'=>false,'msg'=>'消息不能为空且不超过500字']);
            exit;
        }
        // 频率限制：每人每3秒最多发5条（宽松）
        $recent = $conn->query("SELECT COUNT(*) as cnt FROM liesbar_chat WHERE uid = $login_uid AND created_at > NOW() - INTERVAL 3 SECOND")->fetch_assoc()['cnt'];
        if ($recent >= 5) {
            echo json_encode(['success'=>false,'msg'=>'发送过于频繁，请稍后再试']);
            exit;
        }
        $stmt = $conn->prepare("INSERT INTO liesbar_chat (room_id, uid, name, msg) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $roomId, $login_uid, $login_name, $msg);
        $stmt->execute();
        $stmt->close();
        $conn->query("UPDATE liesbar_rooms SET version = version + 1 WHERE id = $roomId");
        echo json_encode(['success' => true]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>骗子酒馆</title>
<style>
/* ===== 全局样式（完全采用首页风格） ===== */
:root {
    --bg: #f9f7f4;
    --card-bg: #ffffff;
    --nav-bg: #3d3a37;
    --nav-text: #f0ece6;
    --text: #2c2a28;
    --text-secondary: #7a736b;
    --text-muted: #a0988e;
    --border: #e6e1da;
    --border-light: #f0ece6;
    --accent: #6b8a74;
    --accent-hover: #55735e;
    --accent-light: #eef4ef;
    --danger: #d9534f;
    --danger-hover: #c0392b;
    --gold: #b8860b;
    --shadow: 0 2px 10px rgba(0,0,0,0.05);
    --radius: 10px;
    --radius-sm: 6px;
    --transition: 0.18s ease;
    --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
    --font-mono: 'JetBrains Mono', 'Cascadia Code', 'Consolas', 'SF Mono', monospace;
}

* { margin:0; padding:0; box-sizing:border-box; }
body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }

.navbar {
    background:var(--nav-bg); height:54px; display:flex; align-items:center;
    justify-content:space-between; padding:0 28px; color:var(--nav-text);
    position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
}
.navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
.navbar h1 a { color:#f0ece6; text-decoration:none; }
.user-info { display:flex; align-items:center; gap:6px; }
.user-info a {
    color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
    border-radius:20px; transition:var(--transition); font-weight:500;
}
.user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }

.main { max-width:1320px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
.sidebar {
    background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
    width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0;
}
.sidebar a {
    display:block; padding:13px 22px; text-align:center; background:var(--card-bg);
    color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500;
    transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px;
}
.sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
.sidebar a.active { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }

.content { flex:1; min-width:0; }

.card {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 26px 28px;
    margin-bottom: 18px;
    box-shadow: var(--shadow);
    overflow: hidden;
}
.card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }

.btn {
    padding:9px 20px; background:var(--accent); color:#fff; border:none;
    border-radius:20px; cursor:pointer; font-size:14px; font-weight:500;
    transition:var(--transition);
}
.btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
.btn:disabled { background:#bfbab0; cursor:not-allowed; }
.btn-gold { background:var(--gold); color:#fff; }
.btn-gold:hover { background:#a67a0a; }
.btn-danger { background:var(--danger); color:#fff; }
.btn-danger:hover { background:var(--danger-hover); }
.btn-info { background:#2980b9; color:#fff; }
.btn-info:hover { background:#1f6a93; }

.room-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:14px; }
.room-item {
    background:var(--bg);
    padding:14px;
    border-radius:8px;
    border:1px solid var(--border);
}
.room-item h4 { color:var(--text); margin-bottom:6px; }

/* ===== 骗子酒馆特有样式（适配浅色主题） ===== */
.lies-arena {
    background: var(--card-bg);
    border-radius: var(--radius);
    padding: 16px;
    border: 1px solid var(--border);
}
.opponents-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:10px; margin-bottom:12px; }
.player-panel {
    background: var(--bg);
    border: 2px solid var(--border);
    border-radius:8px;
    padding:8px;
    display:flex;
    gap:10px;
    align-items:center;
}
.player-panel.active-turn { border-color:var(--gold); box-shadow:0 0 12px rgba(184,134,11,0.3); }
.player-panel.dead { opacity:0.3; filter:grayscale(1); }
.avatar-box { width:50px; height:70px; border-radius:6px; border:1.5px solid var(--border); overflow:hidden; background:#f0f0f0; flex-shrink:0; }
.avatar-box img { width:100%; height:100%; object-fit:cover; }

.handcards-bar { display:flex; gap:8px; overflow-x:auto; padding:6px 2px; min-height:95px; align-items:flex-end; flex-wrap:wrap; }
.lies-card {
    width:70px; height:90px; background:#fdfbf7; border-radius:6px;
    border:1.5px solid #bda885; padding:4px; cursor:pointer;
    transition:0.15s; flex-shrink:0; font-weight:bold; font-size:20px;
    display:flex; align-items:center; justify-content:center; color:#000;
}
.lies-card:hover { transform:translateY(-10px); border-color:var(--gold); }
.lies-card.selected { transform:translateY(-14px); border-color:#2ecc71; box-shadow:0 0 10px #2ecc71; }
.lies-card.joker { background:linear-gradient(135deg,#ff6b6b,#feca57); color:#000; }
.lies-card.devil { background:#e74c3c; color:#fff; border-color:#c0392b; }

.logs-box {
    background: var(--bg);
    border-radius:6px;
    padding:8px;
    font-size:12px;
    height:140px;
    overflow-y:auto;
    color:var(--text);
    border:1px solid var(--border);
}
.logs-box p { margin:2px 0; }

.prompt-banner {
    background: var(--accent-light);
    border: 1.5px solid var(--accent);
    border-radius:6px;
    padding:8px 12px;
    margin-bottom:8px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    color:var(--text);
    flex-wrap:wrap;
}

.chat-panel {
    background: var(--bg);
    border-radius:8px;
    padding:8px;
    border:1px solid var(--border);
    margin-top:10px;
}
.chat-messages { height:120px; overflow-y:auto; font-size:13px; color:var(--text); padding:4px; }
.chat-messages div { padding:2px 0; border-bottom:1px solid var(--border-light); }
.chat-input-row { display:flex; gap:6px; margin-top:6px; }
.chat-input-row input {
    flex:1; background:var(--card-bg); border:1px solid var(--border);
    color:var(--text); padding:6px; border-radius:4px;
}
.chat-input-row input:focus { border-color:var(--accent); }

.declare-modal {
    position:fixed; top:0; left:0; width:100%; height:100%;
    background:rgba(0,0,0,0.7); display:flex; justify-content:center;
    align-items:center; z-index:999;
}
.declare-box {
    background:var(--card-bg); padding:20px; border-radius:12px;
    border:2px solid var(--gold); text-align:center; min-width:280px;
}
.declare-box .rank-btn {
    width:60px; height:60px; margin:8px; border-radius:8px;
    font-size:24px; font-weight:bold; border:2px solid var(--text);
    cursor:pointer; background:var(--bg); color:var(--text);
}
.declare-box .rank-btn:hover { background:var(--accent-light); }

@media (max-width:768px) {
    .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
    .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
    .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
    .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
    .navbar { padding:0 14px; height:48px; }
    .card { padding:18px 14px; }
}
</style>
</head>
<body>
<?php if (file_exists('navbar.php')) include 'navbar.php'; else { ?>
<div class="navbar">
    <h1><a href="/liesbar">骗子酒馆</a></h1>
    <div class="user-info"><span><?= htmlspecialchars($login_name) ?></span><a href="/">返回首页</a></div>
</div>
<?php } ?>
<div class="main">
    <div class="sidebar">
        <a href="/">主页</a>
        <a href="/liesbar" class="active">骗子酒馆</a>
    </div>
    <div class="content">
        <!-- 大厅 -->
        <div class="card" id="view-lobby">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2>🏠 大厅</h2>
                <button class="btn btn-gold" onclick="openCreateModal()">+ 创建房间</button>
            </div>
            <div class="room-grid" id="rooms-container"></div>
        </div>
        <!-- 准备 -->
        <div class="card" id="view-room" style="display:none;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <h2 id="room-title-text">房间准备中</h2>
                <div>
                    <button class="btn btn-danger" id="btn-delete-room" style="display:none;" onclick="deleteRoom()">解散房间</button>
                    <button class="btn btn-danger" onclick="leaveRoom()">退出</button>
                    <button class="btn btn-gold" id="btn-start-game" style="display:none;" onclick="startGame()">开始游戏</button>
                </div>
            </div>
            <div id="spectator-join-box" style="display:none; margin-top:12px;">
                <button class="btn btn-info" onclick="joinFromSpectate()">加入此房间</button>
            </div>
            <div style="margin-top:16px;">
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <span><strong>准备状态</strong></span>
                    <button class="btn" id="btn-ready-toggle" onclick="toggleReady()">准备</button>
                </div>
                <div id="room-players-list" style="display:flex; flex-wrap:wrap; gap:12px; margin-top:12px;"></div>
            </div>
            <div class="chat-panel" style="margin-top:20px;">
                <div class="chat-messages" id="chat-messages-prep"></div>
                <div class="chat-input-row">
                    <input type="text" id="chat-input-prep" placeholder="聊天...">
                    <button class="btn" onclick="sendChat('chat-input-prep')">发送</button>
                </div>
            </div>
        </div>
        <!-- 游戏 -->
        <div class="lies-arena" id="view-game" style="display:none;">
            <div id="spectator-indicator" style="background:#eef4ef;color:var(--text);padding:6px 14px;border-radius:6px;margin-bottom:10px;display:none;text-align:center;">您正在观战</div>
            <div class="opponents-row" id="opponents-container"></div>
            <div id="action-prompt-area"></div>
            <div style="display:grid; grid-template-columns:1fr 280px; gap:12px;">
                <div>
                    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                        <span id="game-status-tip" style="color:var(--gold);font-weight:bold;">等待回合...</span>
                        <span style="font-size:12px;color:var(--text-muted);">主牌: <strong id="main-rank-display">-</strong> | 牌堆: <span id="deck-count">0</span></span>
                    </div>
                    <div class="logs-box" id="battle-logs"></div>
                </div>
                <div style="background:var(--bg);border-radius:6px;padding:10px;border:1px solid var(--border);">
                    <div><strong>当前回合</strong> <span id="turn-number">0</span></div>
                    <div style="margin-top:4px;font-size:13px;color:var(--text-muted);">下家: <span id="next-player-name">-</span></div>
                    <div id="pending-info" style="margin-top:6px;background:var(--card-bg);padding:4px;border-radius:4px;text-align:center;font-size:13px;"></div>
                </div>
            </div>
            <div style="background:var(--card-bg);border-radius:8px;padding:12px;margin-top:12px;border:1px solid var(--border);">
                <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center; margin-bottom:6px;">
                    <button class="btn btn-gold" id="btn-play" onclick="playCards()">出牌</button>
                    <button class="btn btn-danger" id="btn-challenge" onclick="challenge()" style="display:none;">质疑</button>
                    <button class="btn" id="btn-believe" onclick="believe()" style="display:none;">相信</button>
                    <button class="btn btn-danger" onclick="surrenderGame()">认输</button>
                    <span id="my-hand-count" style="color:var(--text-muted);font-size:13px;">手牌: 0</span>
                </div>
                <div class="handcards-bar" id="my-handcards"></div>
            </div>
            <div class="chat-panel">
                <div class="chat-messages" id="chat-messages"></div>
                <div class="chat-input-row">
                    <input type="text" id="chat-input" placeholder="聊天...">
                    <button class="btn" onclick="sendChat('chat-input')">发送</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (file_exists('footer.php')) include 'footer.php'; ?>
<script>
let currentRoomId = null, currentVersion = 0, pollTimer = null;
let selectedIndices = [];
let isReady = 0, isSpectator = false;
let myUid = <?= $login_uid ?>;
let _gameState = null;
let myIdx = -1;

function escapeHtml(str) { let d=document.createElement('div'); d.textContent=str||''; return d.innerHTML; }

function doPoll() {
    if (!currentRoomId) return;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=poll_state&room_id=${currentRoomId}&version=${currentVersion}` })
    .then(r=>r.json()).then(data=>{
        if(!data.success){ alert(data.msg||'房间已结束'); exitToLobby(); return; }
        if(!data.changed) return;
        currentVersion=data.version;
        isSpectator=!!data.is_spectator;
        if(data.chat_messages) renderChat(data.chat_messages, true);
        if(data.room.status==='waiting'){
            renderWaitingRoom(data);
        }else if(data.room.status==='playing' || data.room.status==='finished'){
            _gameState=data.game_state;
            renderGame(data.game_state, isSpectator, data.room);
        }
    }).catch(console.error);
}

function loadRooms() {
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:'api_action=get_rooms' })
    .then(r=>r.json()).then(res=>{
        const box=document.getElementById('rooms-container');
        box.innerHTML='';
        if(!res.rooms.length){ box.innerHTML='<div style="color:var(--text-muted);">暂无房间，创建第一个吧！</div>'; return; }
        res.rooms.forEach(rm=>{
            let div=document.createElement('div');
            div.className='room-item';
            const notWaiting=rm.status!=='waiting';
            const full=parseInt(rm.current_players)>=parseInt(rm.max_players);
            let btn= notWaiting||full ? `<button class="btn btn-info btn-sm" onclick="enterRoom(${rm.id})">观战</button>` : `<button class="btn btn-sm" onclick="joinRoom(${rm.id})">进入</button>`;
            div.innerHTML=`<h4>${escapeHtml(rm.title)}</h4>
                <div style="font-size:12px;color:var(--text-muted);">房主: ${escapeHtml(rm.host_name)} | ${rm.current_players}/${rm.max_players} ${rm.status==='playing'?'进行中':'等待中'}</div>
                <div style="margin-top:8px;">${btn}</div>`;
            box.appendChild(div);
        });
    });
}

function openCreateModal() {
    let title=prompt('房间名称：','骗子酒馆');
    if(!title) return;
    let maxP=prompt('人数(2-6)：','6');
    if(!maxP) maxP=6;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=create_room&title=${encodeURIComponent(title)}&max_players=${maxP}` })
    .then(r=>r.json()).then(res=>{ if(res.success) enterRoom(res.room_id); else alert(res.msg); });
}

function joinRoom(id) {
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=join_room&room_id=${id}` })
    .then(r=>r.json()).then(res=>{ if(res.success) enterRoom(id); else alert(res.msg); });
}
function joinFromSpectate(){ if(currentRoomId) joinRoom(currentRoomId); }

function enterRoom(roomId) {
    currentRoomId=roomId; currentVersion=0;
    window.history.replaceState({},'',`/liesbar/${roomId}`);
    document.getElementById('view-lobby').style.display='none';
    startPolling();
}
function exitToLobby(){
    clearInterval(pollTimer); currentRoomId=null; currentVersion=0; isSpectator=false;
    window.history.replaceState({},'',`/liesbar`);
    document.getElementById('view-lobby').style.display='block';
    document.getElementById('view-room').style.display='none';
    document.getElementById('view-game').style.display='none';
    loadRooms();
}
function leaveRoom(){
    if(!currentRoomId) return;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=leave_room&room_id=${currentRoomId}` })
    .then(r=>r.json()).then(res=>{ if(res.success) exitToLobby(); else alert(res.msg); });
}
function deleteRoom(){
    if(!currentRoomId) return;
    if(!confirm('确定解散此房间吗？所有玩家将被移出。')) return;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=delete_room&room_id=${currentRoomId}` })
    .then(r=>r.json()).then(res=>{ if(res.success) exitToLobby(); else alert(res.msg); });
}

function startPolling(){
    clearInterval(pollTimer);
    const poll=doPoll;
    pollTimer=setInterval(poll, 3000);
    poll();
}

function renderWaitingRoom(data){
    document.getElementById('view-room').style.display='block';
    document.getElementById('view-game').style.display='none';
    document.getElementById('room-title-text').innerText=`${data.room.title} (${data.room_players.length}/${data.room.max_players})`;
    const isHost=data.room.host_uid==myUid;
    document.getElementById('btn-start-game').style.display=isHost?'inline-flex':'none';
    // 若当前用户是 sqadmin 或房主，显示解散按钮
    const isSqadmin = <?= json_encode($is_sqadmin) ?>;
    document.getElementById('btn-delete-room').style.display=(isHost || isSqadmin)?'inline-flex':'none';
    if(isSpectator){
        document.getElementById('spectator-join-box').style.display=(data.room_players.length<data.room.max_players)?'block':'none';
        document.getElementById('btn-ready-toggle').style.display='none';
    }else{
        document.getElementById('spectator-join-box').style.display='none';
        document.getElementById('btn-ready-toggle').style.display='inline-flex';
        const myRec=data.room_players.find(p=>p.uid==myUid);
        if(myRec){ isReady=parseInt(myRec.is_ready); document.getElementById('btn-ready-toggle').innerText=isReady?'取消准备':'准备'; }
    }
    const pBox=document.getElementById('room-players-list');
    pBox.innerHTML='';
    data.room_players.forEach(p=>{
        let el=document.createElement('div');
        el.style.cssText='padding:8px 14px;background:var(--bg);border:1px solid var(--border);border-radius:6px;display:flex;align-items:center;gap:12px;';
        let status=p.uid==data.room.host_uid?'<span style="color:var(--gold);">[房主]</span>':(p.is_ready?'<span style="color:#5cb85c;">已准备</span>':'<span style="color:var(--danger);">未准备</span>');
        let kick='';
        if(isHost && p.uid!=myUid) kick=`<button class="btn btn-danger btn-sm" onclick="kickPlayer(${p.uid})">踢出</button>`;
        el.innerHTML=`<span><strong>${escapeHtml(p.name)}</strong> ${status}</span>${kick}`;
        pBox.appendChild(el);
    });
}

function kickPlayer(uid){
    if(!confirm('确定踢出该玩家吗？')) return;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=kick_player&room_id=${currentRoomId}&target_uid=${uid}` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function renderGame(state, spectator, room){
    document.getElementById('view-room').style.display='none';
    document.getElementById('view-game').style.display='block';
    document.getElementById('spectator-indicator').style.display=spectator?'block':'none';
    const my = state.players.find(p=>p.uid===myUid);
    myIdx = -1;
    if(my) {
        for(let i=0;i<state.players.length;i++){
            if(state.players[i].uid===myUid){ myIdx=i; break; }
        }
    }
    const isMyTurn = !spectator && state.current_player !== undefined && state.players[state.current_player] && state.players[state.current_player].uid===myUid;
    const isFinished = state.status==='finished';
    document.getElementById('deck-count').innerText = state.deck ? state.deck.length : 0;
    document.getElementById('main-rank-display').innerText = state.main_rank || '-';
    document.getElementById('turn-number').innerText = state.turn_count || 0;
    let nextIdx = -1;
    if (state.current_player !== undefined) {
        nextIdx = getNextAlivePlayerJs(state, state.current_player);
    }
    document.getElementById('next-player-name').innerText = nextIdx !== -1 ? state.players[nextIdx].name : '无';
    const logBox=document.getElementById('battle-logs');
    logBox.innerHTML=state.logs.map(l=>`<p>${l}</p>`).join('');
    logBox.scrollTop=logBox.scrollHeight;
    let statusText=isFinished?'<strong style="color:var(--gold);">对局已结束</strong>':'';
    if(state.phase==='waiting_challenge'){
        statusText='等待质疑...';
    }else if(state.phase==='play'){
        const cur=state.players[state.current_player];
        statusText=cur ? `轮到 <strong>${cur.name}</strong> 出牌` : '等待中';
    }
    document.getElementById('game-status-tip').innerHTML=statusText;
    const oppBox=document.getElementById('opponents-container');
    oppBox.innerHTML='';
    state.players.forEach((p,idx)=>{
        if(!spectator && p.uid===myUid) return;
        let div=document.createElement('div');
        div.className=`player-panel ${state.current_player===idx?'active-turn':''} ${p.out?'dead':''}`;
        let handCount = p.hand_count !== undefined ? p.hand_count : p.hand.length;
        div.innerHTML=`
            <div class="avatar-box"><img src="${p.avatar||'/default-avatar.png'}"></div>
            <div>
                <div><strong style="color:var(--text);">${escapeHtml(p.name)}</strong> ${p.out?'[出局]':''}</div>
                <div style="font-size:12px;color:var(--text-muted);">手牌: ${handCount}</div>
            </div>
        `;
        oppBox.appendChild(div);
    });
    const handBox=document.getElementById('my-handcards');
    handBox.innerHTML='';
    document.getElementById('my-hand-count').innerText=`手牌: ${my?my.hand.length:0}`;
    if(my && !my.out){
        my.hand.forEach((c,idx)=>{
            let el=document.createElement('div');
            let cls='lies-card';
            if(c.is_joker) cls+=' joker';
            if(c.is_devil) cls+=' devil';
            el.className=cls;
            if(selectedIndices.includes(idx)) el.classList.add('selected');
            el.onclick=()=>{
                const i=selectedIndices.indexOf(idx);
                if(i>=0) selectedIndices.splice(i,1);
                else if(selectedIndices.length<3) selectedIndices.push(idx);
                renderGame(state,spectator,room);
            };
            let label = c.is_devil ? '👿' : (c.is_joker ? '🃏' : c.rank);
            el.innerText=label;
            handBox.appendChild(el);
        });
    }
    const isMyAlive = my && !my.out && !isFinished;
    const canAct = isMyAlive && isMyTurn && state.phase==='play';
    document.getElementById('btn-play').style.display = canAct ? 'inline-flex' : 'none';
    document.getElementById('btn-challenge').style.display = 'none';
    document.getElementById('btn-believe').style.display = 'none';
    if(state.phase==='waiting_challenge' && !isFinished && state.pending && !spectator){
        const next = getNextAlivePlayerJs(state, state.pending.player_idx);
        if(next !== -1 && state.players[next] && state.players[next].uid === myUid){
            document.getElementById('btn-challenge').style.display = 'inline-flex';
            document.getElementById('btn-believe').style.display = 'inline-flex';
        }
    }
    const promptArea=document.getElementById('action-prompt-area');
    promptArea.innerHTML='';
    if(state.phase==='waiting_challenge' && state.pending){
        const p=state.pending;
        let info = `出牌者: ${state.players[p.player_idx].name}，已出 ${p.cards.length} 张`;
        if(p.has_devil) info += ' ⚠️ 含恶魔牌';
        promptArea.innerHTML=`<div class="prompt-banner"><span>${info}</span></div>`;
    }
    const pendingDiv=document.getElementById('pending-info');
    if(state.pending){
        pendingDiv.innerHTML=`出牌: ${state.pending.cards.length}张 | 声明: ${state.pending.declared_rank}`;
    }else{
        pendingDiv.innerHTML='无待处理出牌';
    }
}

function getNextAlivePlayerJs(state, fromIdx) {
    const n=state.players.length;
    let idx=(fromIdx+1)%n;
    let tries=0;
    while(state.players[idx].out && tries<n){ idx=(idx+1)%n; tries++; }
    return state.players[idx].out ? -1 : idx;
}

function playCards(){
    if(selectedIndices.length===0){ alert('请至少选择一张牌'); return; }
    const state=_gameState;
    if(!state){ alert('无状态'); return; }
    const my=state.players.find(p=>p.uid===myUid);
    let devilCount=0;
    selectedIndices.forEach(i=>{
        if(my.hand[i].is_devil) devilCount++;
    });
    if(devilCount>1){ alert('恶魔牌只能单独打出'); return; }
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=game_action&room_id=${currentRoomId}&action_type=play_cards&card_indices=${encodeURIComponent(JSON.stringify(selectedIndices))}` })
    .then(r=>r.json()).then(res=>{
        if(!res.success) alert(res.msg);
        selectedIndices=[];
    });
}

function challenge(){
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=game_action&room_id=${currentRoomId}&action_type=challenge` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function believe(){
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=game_action&room_id=${currentRoomId}&action_type=believe` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function surrenderGame(){
    if(!confirm('确定认输吗？')) return;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=game_action&room_id=${currentRoomId}&action_type=surrender` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

function toggleReady(){
    const next=isReady?0:1;
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=update_prep&room_id=${currentRoomId}&is_ready=${next}` })
    .then(r=>r.json()).then(res=>{
        if(res.success){ isReady=next; document.getElementById('btn-ready-toggle').innerText=isReady?'取消准备':'准备'; doPoll(); }
        else alert(res.msg);
    });
}

function startGame(){
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=start_game&room_id=${currentRoomId}` })
    .then(r=>r.json()).then(res=>{ if(!res.success) alert(res.msg); });
}

// ===== 增强聊天功能：乐观更新 =====
function renderChat(messages, prep=false){
    const box=prep?document.getElementById('chat-messages-prep'):document.getElementById('chat-messages');
    if(!box) return;
    box.innerHTML=messages.map(m=>`<div><span style="color:var(--accent);">${escapeHtml(m.name)}</span> ${m.time}: ${m.msg}</div>`).join('');
    box.scrollTop=box.scrollHeight;
}

function sendChat(inputId){
    const input=document.getElementById(inputId);
    if(!input) return;
    const msg=input.value.trim();
    if(!msg) return;
    // 乐观更新：立即显示在聊天框中
    const box = (inputId === 'chat-input-prep') ? document.getElementById('chat-messages-prep') : document.getElementById('chat-messages');
    if(box){
        const now = new Date();
        const timeStr = now.getHours().toString().padStart(2,'0')+':'+now.getMinutes().toString().padStart(2,'0')+':'+now.getSeconds().toString().padStart(2,'0');
        const myName = "<?= addslashes($login_name) ?>";
        const msgHtml = `<div><span style="color:var(--accent);">${escapeHtml(myName)}</span> ${timeStr}: ${escapeHtml(msg)}</div>`;
        box.innerHTML += msgHtml;
        box.scrollTop = box.scrollHeight;
    }
    input.value = '';
    fetch('/liesbar', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:`api_action=send_chat&room_id=${currentRoomId}&msg=${encodeURIComponent(msg)}` })
    .then(r=>r.json()).then(res=>{
        if(!res.success) {
            alert(res.msg || '发送失败');
            // 若失败可考虑回滚，但简单处理
        }
    }).catch(()=>{});
}

document.addEventListener('DOMContentLoaded', function(){
    document.getElementById('chat-input').addEventListener('keypress',e=>{ if(e.key==='Enter') sendChat('chat-input'); });
    document.getElementById('chat-input-prep').addEventListener('keypress',e=>{ if(e.key==='Enter') sendChat('chat-input-prep'); });
    const path=window.location.pathname.match(/\/liesbar\/(\d+)/);
    if(path && parseInt(path[1])>0) enterRoom(parseInt(path[1]));
    else loadRooms();
});
</script>
</body>
</html>