<?php
// register_rules.php —— 注册时查看用户协议（rules），公开访问
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
header("Content-Type:text/html;charset=utf-8");

// 数据库连接
// require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 只查询 rules 页面内容
$pageKey = 'rules';
$stmt = $conn->prepare("SELECT content FROM help_pages WHERE page_key = ? LIMIT 1");
$stmt->bind_param('s', $pageKey);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$stmt->close();

$mainRaw = $row['content'] ?? '用户协议暂未发布。';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>用户协议 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{
            background:#f9f7f4;
            font-family:'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
            color:#2c2a28;
            line-height:1.6;
            -webkit-font-smoothing:antialiased;
            padding:30px 20px;
        }
        .container{
            max-width:900px;
            margin:0 auto;
            background:#ffffff;
            border-radius:10px;
            box-shadow:0 2px 10px rgba(0,0,0,0.05);
            padding:26px 28px;
        }
        h1{font-size:22px;font-weight:600;margin-bottom:18px;}
        h2{font-size:18px;font-weight:600;margin:20px 0 10px;}
        h3{font-size:16px;font-weight:600;margin:16px 0 8px;}
        p{margin:8px 0;font-size:15px;}
        ul{margin:10px 0 10px 22px;}
        li{margin:6px 0;}
        blockquote{
            border-left:4px solid #6b8a74;
            padding:8px 14px;
            margin:8px 0;
            background:#fafaf8;
            color:#5a5550;
            border-radius:0 4px 4px 0;
        }
        pre{
            background:#2b2a27;
            color:#e8e4dd;
            padding:14px 16px;
            border-radius:6px;
            overflow-x:auto;
            margin:8px 0;
            font-family:Consolas,monospace;
            font-size:13px;
        }
        code{
            font-family:Consolas,monospace;
            background:#f3f0eb;
            padding:2px 6px;
            border-radius:3px;
        }
        pre code{
            background:transparent;
            padding:0;
            color:inherit;
        }
        img{max-width:100%;height:auto;border-radius:4px;margin:6px 0;}
        a{color:#6b8a74;text-decoration:none;}
        a:hover{text-decoration:underline;}
        @media(max-width:768px){
            .container{padding:18px 16px;}
        }
    </style>
</head>
<body>
    <div class="container">
        <div id="help-content"></div>
    </div>

    <!-- 引入 Markdown 渲染相关 JS（与主站一致） -->
    <script src="/js/markdown-it.min.js"></script>
    <script src="/js/katex.min.js"></script>
    <script src="/js/texmath.min.js"></script>
    <script>
        const md = window.markdownit({});
        md.use(window.texmath.use(window.katex), {
            engine: window.katex,
            delimiters: 'dollars',
            katexOptions: { macros: {"\\RR":"\\mathbb{R}"} }
        });

        function renderMarkdownTo(elId, rawText) {
            const el = document.getElementById(elId);
            if (!el || rawText === null) return;
            el.innerHTML = md.render(rawText);
        }

        // 渲染 rules 内容
        renderMarkdownTo('help-content', <?=json_encode($mainRaw, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT)?>);
    </script>
</body>
</html>