<?php
// admin_collect.php - 可疑IP检测（默认今天，支持时间段筛选）
session_start();

// ========== 权限验证 ==========
if (!isset($_SESSION['uid'])) {
    die('请先登录');
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$uid = (int)$_SESSION['uid'];
$devCheck = $conn->query("SELECT devadmin FROM users WHERE uid = $uid");
$devRow = $devCheck->fetch_assoc();
if (!$devRow || $devRow['devadmin'] != 1) {
    die('您没有管理员权限');
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: /login');
    exit;
}

// ========== 获取时间范围参数（默认今天） ==========
$date_from = isset($_GET['date_from']) ? trim($_GET['date_from']) : date('Y-m-d');
$date_to   = isset($_GET['date_to']) ? trim($_GET['date_to']) : date('Y-m-d');
// 如果只填了开始日期，结束日期默认为开始日期
if (empty($date_to)) $date_to = $date_from;
// 防止日期范围过大（最多30天）
$start_ts = strtotime($date_from);
$end_ts   = strtotime($date_to);
if ($end_ts - $start_ts > 30 * 86400) {
    $date_to = date('Y-m-d', $start_ts + 30 * 86400);
}

// ========== 辅助函数 ==========
function getIpInfo($ip) {
    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) === false) {
        return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
    }
    $cacheDir = __DIR__ . '/ip_cache';
    if (!is_dir($cacheDir)) mkdir($cacheDir, 0755, true);
    $cacheFile = $cacheDir . '/' . md5($ip) . '.json';
    if (file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
        $cached = json_decode(file_get_contents($cacheFile), true);
        if ($cached) return $cached;
    }
    $url = "http://ip-api.com/json/{$ip}?lang=zh-CN";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 3);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);
    if ($response === false) {
        file_put_contents(__DIR__ . '/error.log', date('Y-m-d H:i:s') . " - IP查询失败: $ip - $error\n", FILE_APPEND);
        return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
    }
    $info = json_decode($response, true);
    if ($info && $info['status'] === 'success') {
        $result = [
            'country' => $info['country'] ?? null,
            'region'  => $info['regionName'] ?? null,
            'city'    => $info['city'] ?? null,
            'isp'     => $info['isp'] ?? null
        ];
        file_put_contents($cacheFile, json_encode($result));
        return $result;
    }
    return ['country' => null, 'region' => null, 'city' => null, 'isp' => null];
}

function extractRealIPs($webrtc_string) {
    $ips = array_map('trim', explode(',', $webrtc_string));
    $real_ips = array();
    foreach ($ips as $ip) {
        if (filter_var($ip, FILTER_VALIDATE_IP) === false) continue;
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            $real_ips[] = $ip;
        }
    }
    return array_unique($real_ips);
}

function getCseg($ip) {
    return implode('.', array_slice(explode('.', $ip), 0, 3));
}

// 获取IP关联的用户（含count和last_seen）
function getUsersByIP($conn, $ip) {
    $stmt = $conn->prepare("
        SELECT u.uid, u.name, h.count, h.last_seen
        FROM user_ip_history h
        JOIN users u ON h.uid = u.uid
        WHERE h.ip = ?
        ORDER BY h.last_seen DESC
    ");
    $stmt->bind_param("s", $ip);
    $stmt->execute();
    $result = $stmt->get_result();
    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
    $stmt->close();
    return $users;
}

// 获取某个用户的所有IP
function getIPsByUser($conn, $uid) {
    $stmt = $conn->prepare("SELECT DISTINCT ip FROM user_ip_history WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $ips = [];
    while ($row = $result->fetch_assoc()) {
        $ips[] = $row['ip'];
    }
    $stmt->close();
    return $ips;
}

// ========== 关联分析（无限递归直到收敛） ==========
function analyzeRelation($conn, $startUid) {
    $userSet = [$startUid => true];
    $ipSet = [];
    $ipToUsers = [];

    $initialIPs = getIPsByUser($conn, $startUid);
    foreach ($initialIPs as $ip) {
        $ipSet[$ip] = true;
        if (!isset($ipToUsers[$ip])) $ipToUsers[$ip] = [];
        if (!in_array($startUid, $ipToUsers[$ip])) $ipToUsers[$ip][] = $startUid;
    }

    $maxIter = 100;
    $iter = 0;
    do {
        $iter++;
        $newUsers = false;
        $newIPs = false;

        $currentIPs = array_keys($ipSet);
        foreach ($currentIPs as $ip) {
            $cseg = getCseg($ip);
            $sql = "SELECT DISTINCT uid FROM user_ip_history WHERE ip LIKE ?";
            $stmt = $conn->prepare($sql);
            $like = $cseg . '.%';
            $stmt->bind_param("s", $like);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($row = $res->fetch_assoc()) {
                $u = $row['uid'];
                if (!isset($userSet[$u])) {
                    $userSet[$u] = true;
                    $newUsers = true;
                }
            }
            $stmt->close();
        }

        $currentUsers = array_keys($userSet);
        foreach ($currentUsers as $u) {
            $ips = getIPsByUser($conn, $u);
            foreach ($ips as $ip) {
                if (!isset($ipSet[$ip])) {
                    $ipSet[$ip] = true;
                    $newIPs = true;
                }
                if (!isset($ipToUsers[$ip])) $ipToUsers[$ip] = [];
                if (!in_array($u, $ipToUsers[$ip])) {
                    $ipToUsers[$ip][] = $u;
                }
            }
        }

        if (!$newUsers && !$newIPs) break;
    } while ($iter < $maxIter);

    $userDetails = [];
    foreach (array_keys($userSet) as $uid) {
        $stmt = $conn->prepare("SELECT name FROM users WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $res = $stmt->get_result();
        $name = $res->fetch_assoc()['name'] ?? '未知';
        $stmt->close();
        $userDetails[$uid] = $name;
    }

    $ipList = [];
    foreach (array_keys($ipSet) as $ip) {
        $users = $ipToUsers[$ip] ?? [];
        $ipList[$ip] = [
            'cseg' => getCseg($ip),
            'users' => $users,
            'user_count' => count($users)
        ];
    }

    return [
        'users' => $userDetails,
        'ips'   => $ipList
    ];
}

// ========== AJAX 详情（可疑IP检测，带时间范围） ==========
if (isset($_GET['action']) && $_GET['action'] === 'detail') {
    if (!isset($_SESSION['uid'])) {
        http_response_code(403);
        exit('Unauthorized');
    }
    $segment = isset($_GET['segment']) ? trim($_GET['segment']) : '';
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $date_from = isset($_GET['date_from']) ? trim($_GET['date_from']) : date('Y-m-d');
    $date_to   = isset($_GET['date_to']) ? trim($_GET['date_to']) : date('Y-m-d');
    if (empty($segment)) {
        http_response_code(400);
        exit('Missing segment');
    }

    $base_where = "webrtc_ipv4 IS NOT NULL AND webrtc_ipv4 != '' AND webrtc_ipv4 NOT LIKE '%ca%' AND DATE(created_at) BETWEEN ? AND ?";
    if ($search !== '') {
        $detail_sql = "SELECT id, server_remote_addr, webrtc_ipv4, user_agent, referrer, page_url, created_at,
                              country, region, city, isp
                       FROM collect_log
                       WHERE $base_where 
                         AND server_remote_addr LIKE ?
                         AND server_remote_addr LIKE ?
                       ORDER BY created_at DESC";
        $stmt = $conn->prepare($detail_sql);
        $like_segment = $segment . '.%';
        $like_search = '%' . $search . '%';
        $stmt->bind_param("ssss", $date_from, $date_to, $like_segment, $like_search);
    } else {
        $detail_sql = "SELECT id, server_remote_addr, webrtc_ipv4, user_agent, referrer, page_url, created_at,
                              country, region, city, isp
                       FROM collect_log
                       WHERE $base_where 
                         AND server_remote_addr LIKE ?
                       ORDER BY created_at DESC";
        $stmt = $conn->prepare($detail_sql);
        $like_segment = $segment . '.%';
        $stmt->bind_param("sss", $date_from, $date_to, $like_segment);
    }
    $stmt->execute();
    $detail_result = $stmt->get_result();

    $rows = array();
    $risk_counts = ['跨国'=>0, '跨省'=>0, '跨市'=>0, '同城'=>0, '未知'=>0];

    while ($row = $detail_result->fetch_assoc()) {
        $exitIp = $row['server_remote_addr'];
        if (empty($row['country']) && empty($row['region']) && empty($row['city']) && empty($row['isp'])) {
            $geo = getIpInfo($exitIp);
            if ($geo['country'] !== null || $geo['region'] !== null || $geo['city'] !== null || $geo['isp'] !== null) {
                $updateStmt = $conn->prepare("UPDATE collect_log SET country=?, region=?, city=?, isp=? WHERE id=?");
                $updateStmt->bind_param("ssssi", $geo['country'], $geo['region'], $geo['city'], $geo['isp'], $row['id']);
                $updateStmt->execute();
                $updateStmt->close();
                $row['country'] = $geo['country'];
                $row['region']  = $geo['region'];
                $row['city']    = $geo['city'];
                $row['isp']     = $geo['isp'];
            }
        }
        $exitParts = array_filter([$row['country'], $row['region'], $row['city'], $row['isp']]);
        $exitGeoDisplay = empty($exitParts) ? '未知' : implode(' ', $exitParts);
        $exitCountry = $row['country'] ?? null;
        $exitRegion = $row['region'] ?? null;
        $exitCity = $row['city'] ?? null;

        $real_ips = extractRealIPs($row['webrtc_ipv4']);
        $firstRealIp = !empty($real_ips) ? $real_ips[0] : null;
        $realIpDisplay = $firstRealIp ?: '（无）';

        if ($firstRealIp && ($firstRealIp === $exitIp || getCseg($exitIp) === getCseg($firstRealIp))) {
            continue;
        }

        $realCountry = null; $realRegion = null; $realCity = null;
        $realGeoDisplay = '—';
        if ($firstRealIp) {
            $realGeo = getIpInfo($firstRealIp);
            $realCountry = $realGeo['country'] ?? null;
            $realRegion = $realGeo['region'] ?? null;
            $realCity = $realGeo['city'] ?? null;
            $realParts = array_filter([$realCountry, $realRegion, $realCity, $realGeo['isp'] ?? null]);
            $realGeoDisplay = empty($realParts) ? '未知' : implode(' ', $realParts);
        }

        if (empty($exitCountry) || empty($realCountry) || $realGeoDisplay === '—' || $realGeoDisplay === '未知') {
            $risk = '未知';
        } elseif ($exitCountry !== $realCountry) {
            $risk = '跨国';
        } elseif ($exitRegion !== $realRegion) {
            $risk = '跨省';
        } elseif ($exitCity !== $realCity) {
            $risk = '跨市';
        } else {
            $risk = '同城';
        }
        $risk_counts[$risk]++;

        $exitUsers = getUsersByIP($conn, $exitIp);
        $realUsers = ($firstRealIp && $firstRealIp !== $exitIp) ? getUsersByIP($conn, $firstRealIp) : [];
        $allUsers = [];
        foreach (array_merge($exitUsers, $realUsers) as $u) {
            $allUsers[$u['uid']] = $u;
        }
        $userLinks = [];
        foreach ($allUsers as $u) {
            $userLinks[] = '<a href="/user/' . $u['uid'] . '" target="_blank">' . htmlspecialchars($u['name']) . '</a>'
                . ' (' . $u['count'] . ', ' . date('m-d H:i', strtotime($u['last_seen'])) . ')';
        }
        $userDisplay = empty($userLinks) ? '—' : implode('<br>', $userLinks);

        $row['exit_geo_display'] = $exitGeoDisplay;
        $row['real_ip_display'] = $realIpDisplay;
        $row['real_geo_display'] = $realGeoDisplay;
        $row['risk'] = $risk;
        $row['users'] = $userDisplay;
        $row['created_at_formatted'] = date('Y年m月d日 H:i:s', strtotime($row['created_at']));
        $rows[] = $row;
    }

    $order = ['跨国'=>1, '跨省'=>2, '跨市'=>3, '同城'=>4, '未知'=>5];
    usort($rows, function($a, $b) use ($order) {
        return ($order[$a['risk']] ?? 5) - ($order[$b['risk']] ?? 5);
    });

    header('Content-Type: application/json');
    echo json_encode([
        'total' => count($rows),
        'risk_counts' => $risk_counts,
        'data' => $rows
    ]);
    exit;
}

// ========== 主页面 ==========
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$uid_search = isset($_GET['uid_search']) ? intval($_GET['uid_search']) : 0;
$date_from = isset($_GET['date_from']) ? trim($_GET['date_from']) : date('Y-m-d');
$date_to   = isset($_GET['date_to']) ? trim($_GET['date_to']) : date('Y-m-d');
if (empty($date_to)) $date_to = $date_from;

// 如果 uid_search > 0，执行关联分析（关联分析不限制时间范围）
if ($uid_search > 0) {
    $relation = analyzeRelation($conn, $uid_search);
    $users = $relation['users'];
    $ips = $relation['ips'];
    $uidList = array_keys($users);
    $ipList = array_keys($ips);
    $totalUsers = count($users);
    $totalIPs = count($ips);
    $uidCSV = implode(',', $uidList);
    $ipCSV = implode(',', $ipList);
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>关联分析 - UID <?= $uid_search ?></title>
        <style>
            body { font-family: "Microsoft YaHei", Arial, sans-serif; background: #f5f5f5; padding: 20px; }
            .container { max-width: 1400px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
            .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
            .header h2 { margin: 0; }
            .header .logout { font-size: 14px; }
            .stats { margin: 15px 0; color: #555; }
            .copy-area { background: #f8f9fa; padding: 10px; border-radius: 4px; margin: 10px 0; border-left: 4px solid #007bff; }
            .copy-area .label { font-weight: bold; }
            .copy-area .value { font-family: monospace; background: white; padding: 4px 8px; border-radius: 3px; }
            .copy-btn { background: #28a745; color: white; border: none; padding: 4px 12px; border-radius: 4px; cursor: pointer; }
            .copy-btn:hover { background: #218838; }
            table { width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 15px; }
            th, td { border: 1px solid #ddd; padding: 6px 8px; text-align: left; vertical-align: top; }
            th { background: #f0f0f0; }
            .user-link a { color: #6f42c1; text-decoration: none; }
            .user-link a:hover { text-decoration: underline; }
            .ip-cell { font-family: monospace; }
            .back-link { display: inline-block; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h2>🔗 关联分析（基于 UID <?= $uid_search ?>，无限递归）</h2>
                <span class="logout"><a href="?logout=1">退出</a></span>
            </div>
            <div class="back-link"><a href="admin_collect.php">&laquo; 返回可疑IP检测</a></div>

            <div class="stats">
                找到 <strong><?= $totalUsers ?></strong> 个关联用户，<strong><?= $totalIPs ?></strong> 个关联 IP（已递归收敛）
            </div>

            <div class="copy-area">
                <div><span class="label">UID 列表（逗号分隔）：</span>
                    <span class="value" id="uid-list"><?= htmlspecialchars($uidCSV) ?></span>
                    <button class="copy-btn" onclick="copyText('uid-list')">复制</button>
                </div>
                <div style="margin-top:6px;"><span class="label">IP 列表（逗号分隔）：</span>
                    <span class="value" id="ip-list"><?= htmlspecialchars($ipCSV) ?></span>
                    <button class="copy-btn" onclick="copyText('ip-list')">复制</button>
                </div>
            </div>

            <h3>关联用户</h3>
            <table>
                <thead><tr><th>UID</th><th>用户名</th><th>关联IP数</th></tr></thead>
                <tbody>
                <?php foreach ($users as $uid => $name): ?>
                    <tr>
                        <td><?= $uid ?></td>
                        <td class="user-link"><a href="/user/<?= $uid ?>" target="_blank"><?= htmlspecialchars($name) ?></a></td>
                        <td><?= count(getIPsByUser($conn, $uid)) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h3 style="margin-top:20px;">关联 IP</h3>
            <table>
                <thead><tr><th>IP</th><th>C段</th><th>关联用户数</th><th>关联用户</th></tr></thead>
                <tbody>
                <?php foreach ($ips as $ip => $info): ?>
                    <tr>
                        <td class="ip-cell"><?= htmlspecialchars($ip) ?></td>
                        <td><?= htmlspecialchars($info['cseg']) ?></td>
                        <td><?= $info['user_count'] ?></td>
                        <td>
                            <?php
                            $userLinks = [];
                            foreach ($info['users'] as $uid) {
                                $name = $users[$uid] ?? '未知';
                                $userLinks[] = '<a href="/user/' . $uid . '" target="_blank">' . htmlspecialchars($name) . '</a>';
                            }
                            echo implode(', ', $userLinks);
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <script>
            function copyText(elementId) {
                const text = document.getElementById(elementId).innerText;
                navigator.clipboard.writeText(text).then(() => {
                    alert('已复制到剪贴板');
                }).catch(err => {
                    alert('复制失败，请手动复制');
                });
            }
            </script>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ========== 常规可疑IP检测（带时间范围） ==========
$base_where = "webrtc_ipv4 IS NOT NULL AND webrtc_ipv4 != '' AND webrtc_ipv4 NOT LIKE '%ca%' AND DATE(created_at) BETWEEN ? AND ?";

// 查询分组时带上时间条件
if ($search !== '') {
    $sql = "SELECT SUBSTRING_INDEX(server_remote_addr, '.', 3) AS c_segment,
                   COUNT(*) AS cnt,
                   GROUP_CONCAT(DISTINCT server_remote_addr) AS ips,
                   MIN(created_at) AS first_time,
                   MAX(created_at) AS last_time
            FROM collect_log
            WHERE $base_where AND server_remote_addr LIKE ?
            GROUP BY c_segment
            ORDER BY last_time DESC";
    $stmt = $conn->prepare($sql);
    $like_search = '%' . $search . '%';
    $stmt->bind_param("sss", $date_from, $date_to, $like_search);
} else {
    $sql = "SELECT SUBSTRING_INDEX(server_remote_addr, '.', 3) AS c_segment,
                   COUNT(*) AS cnt,
                   GROUP_CONCAT(DISTINCT server_remote_addr) AS ips,
                   MIN(created_at) AS first_time,
                   MAX(created_at) AS last_time
            FROM collect_log
            WHERE $base_where
            GROUP BY c_segment
            ORDER BY last_time DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $date_from, $date_to);
}
$stmt->execute();
$all_groups = $stmt->get_result();

$valid_groups = [];
while ($group = $all_groups->fetch_assoc()) {
    $segment = $group['c_segment'];
    // 检查该段是否有可疑记录（同样带时间范围）
    $check_sql = "SELECT server_remote_addr, webrtc_ipv4
                  FROM collect_log
                  WHERE $base_where AND server_remote_addr LIKE ?
                  LIMIT 1";
    $chk_stmt = $conn->prepare($check_sql);
    $like_seg = $segment . '.%';
    $chk_stmt->bind_param("sss", $date_from, $date_to, $like_seg);
    $chk_stmt->execute();
    $chk_res = $chk_stmt->get_result();
    $has_valid = false;
    if ($row = $chk_res->fetch_assoc()) {
        $exitIp = $row['server_remote_addr'];
        $real_ips = extractRealIPs($row['webrtc_ipv4']);
        $firstReal = !empty($real_ips) ? $real_ips[0] : null;
        if ($firstReal && $firstReal !== $exitIp && getCseg($exitIp) !== getCseg($firstReal)) {
            $has_valid = true;
        }
    }
    $chk_stmt->close();
    if ($has_valid) {
        $valid_groups[] = $group;
    }
}
$stmt->close();
$total_groups = count($valid_groups);

$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$limit = 20;
$total_pages = ceil($total_groups / $limit);
if ($page < 1) $page = 1;
if ($page > $total_pages && $total_pages > 0) $page = $total_pages;
$offset = ($page - 1) * $limit;
$page_groups = array_slice($valid_groups, $offset, $limit);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>可疑IP检测（默认今天）</title>
    <style>
        body { font-family: "Microsoft YaHei", Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .header h2 { margin: 0; }
        .header .logout { font-size: 14px; }
        .search-form { margin: 15px 0; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .search-form input[type="text"], .search-form input[type="number"] { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .search-form input[type="text"] { width: 200px; }
        .search-form input[type="number"] { width: 120px; }
        .search-form input[type="date"] { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        .search-form button { padding: 8px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
        .search-form button:hover { background: #0056b3; }
        .stats { color: #666; margin: 10px 0; }
        .group-card { border: 1px solid #ddd; border-radius: 6px; margin-bottom: 10px; overflow: hidden; }
        .group-header {
            background: #f8f9fa;
            padding: 12px 16px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            transition: background 0.2s;
            flex-wrap: wrap;
        }
        .group-header:hover { background: #e9ecef; }
        .group-header .segment { font-weight: bold; font-size: 16px; color: #007bff; }
        .group-header .info { font-size: 14px; color: #555; }
        .group-header .badge { background: #28a745; color: white; border-radius: 20px; padding: 2px 10px; font-size: 12px; margin-left: 10px; }
        .group-detail {
            padding: 0 16px 16px;
            display: none;
            overflow-x: auto;
        }
        .group-detail.open { display: block; }
        .group-detail table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 10px; }
        .group-detail th, .group-detail td { padding: 5px 6px; border: 1px solid #ddd; text-align: left; vertical-align: top; }
        .group-detail th { background: #f0f0f0; white-space: nowrap; }
        .pagination { margin: 20px 0; }
        .pagination a, .pagination span { padding: 5px 12px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; margin: 0 3px; }
        .pagination span.current { background: #6c757d; }
        .pagination a:hover { background: #0056b3; }
        .no-data { color: green; font-size: 18px; }
        .toggle-icon { font-size: 18px; transition: transform 0.3s; display: inline-block; }
        .toggle-icon.open { transform: rotate(90deg); }
        .loading { color: #888; padding: 10px; text-align: center; }
        .error-msg { color: #d32f2f; padding: 10px; }
        .exit-geo { color: #007bff; font-size: 12px; }
        .real-geo { color: #d32f2f; font-size: 12px; font-weight: bold; }
        .ip-text { font-weight: bold; }
        .summary-bar { background: #f8f9fa; padding: 8px 12px; border-radius: 4px; margin-bottom: 10px; border-left: 4px solid #6c757d; }
        .user-link a { color: #6f42c1; text-decoration: none; }
        .user-link a:hover { text-decoration: underline; }
        .risk-tag { display: inline-block; padding: 0 6px; border-radius: 3px; font-size: 11px; font-weight: bold; color: white; }
        .risk-跨国 { background: #d32f2f; }
        .risk-跨省 { background: #e67e22; }
        .risk-跨市 { background: #f39c12; }
        .risk-同城 { background: #28a745; }
        .risk-未知 { background: #95a5a6; }
        .time-info { color: #888; font-size: 12px; margin-left: 15px; }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h2>🌍 可疑IP检测（默认今天）</h2>
        <span class="logout"><a href="?logout=1">退出</a></span>
    </div>

    <form method="get" class="search-form">
        <input type="date" name="date_from" value="<?= htmlspecialchars($date_from) ?>">
        <span style="color:#888;">至</span>
        <input type="date" name="date_to" value="<?= htmlspecialchars($date_to) ?>">
        <input type="text" name="search" placeholder="IP或前缀" value="<?= htmlspecialchars($search) ?>">
        <input type="number" name="uid_search" placeholder="UID关联分析" value="<?= htmlspecialchars($uid_search) ?>">
        <button type="submit">查询</button>
        <?php if ($search !== '' || $uid_search > 0): ?>
            <a href="admin_collect.php" style="line-height:34px;color:#007bff;">清除筛选</a>
        <?php endif; ?>
    </form>

    <div class="stats">
        时间范围：<?= $date_from ?> ~ <?= $date_to ?>，共 <?= $total_groups ?> 个可疑分组，每页 <?= $limit ?> 组
    </div>

    <?php if (empty($page_groups)): ?>
        <p class="no-data">✅ 在 <?= $date_from ?> ~ <?= $date_to ?> 期间没有发现可疑记录（所有出口IP与真实IP C段相同或完全相同）。</p>
    <?php else: ?>
        <?php foreach ($page_groups as $group):
            $segment = $group['c_segment'];
            $cnt = $group['cnt'];
            $ips_list = explode(',', $group['ips']);
            $first = date('Y年m月d日 H:i:s', strtotime($group['first_time']));
            $last = date('Y年m月d日 H:i:s', strtotime($group['last_time']));
        ?>
            <div class="group-card" data-segment="<?= htmlspecialchars($segment) ?>" data-loaded="false" data-date-from="<?= htmlspecialchars($date_from) ?>" data-date-to="<?= htmlspecialchars($date_to) ?>">
                <div class="group-header" onclick="toggleGroup(this)">
                    <div>
                        <span class="segment"><?= $segment ?>.0/24</span>
                        <span class="badge"><?= $cnt ?> 条</span>
                        <span style="margin-left:15px;color:#888;">IP示例：<?= htmlspecialchars(implode(', ', array_slice($ips_list, 0, 3))) ?><?= count($ips_list) > 3 ? ' …' : '' ?></span>
                    </div>
                    <div>
                        <span class="info">首次：<?= $first ?> | 最后：<?= $last ?></span>
                        <span class="toggle-icon">▶</span>
                    </div>
                </div>
                <div class="group-detail">
                    <div class="loading">加载中...</div>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="pagination">
            <?php if ($page > 1): ?>
                <a href="?page=<?= $page-1 ?>&search=<?= urlencode($search) ?>&uid_search=<?= $uid_search ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>">上一页</a>
            <?php endif; ?>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="current"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>&search=<?= urlencode($search) ?>&uid_search=<?= $uid_search ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
            <?php if ($page < $total_pages): ?>
                <a href="?page=<?= $page+1 ?>&search=<?= urlencode($search) ?>&uid_search=<?= $uid_search ?>&date_from=<?= urlencode($date_from) ?>&date_to=<?= urlencode($date_to) ?>">下一页</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<script>
function toggleGroup(header) {
    const card = header.closest('.group-card');
    const detailContainer = card.querySelector('.group-detail');
    const icon = header.querySelector('.toggle-icon');

    if (detailContainer.classList.contains('open')) {
        detailContainer.classList.remove('open');
        icon.textContent = '▶';
        icon.classList.remove('open');
        return;
    }

    detailContainer.classList.add('open');
    icon.textContent = '▼';
    icon.classList.add('open');

    const segment = card.dataset.segment;
    if (card.dataset.loaded === 'true') return;

    const loadMsg = detailContainer.querySelector('.loading');
    if (!loadMsg) {
        const div = document.createElement('div');
        div.className = 'loading';
        div.textContent = '加载中...';
        detailContainer.appendChild(div);
    }
    const loadingDiv = detailContainer.querySelector('.loading');
    if (loadingDiv) loadingDiv.style.display = 'block';

    const search = new URLSearchParams(window.location.search).get('search') || '';
    const date_from = card.dataset.dateFrom || '';
    const date_to = card.dataset.dateTo || '';

    fetch(`?action=detail&segment=${encodeURIComponent(segment)}&search=${encodeURIComponent(search)}&date_from=${encodeURIComponent(date_from)}&date_to=${encodeURIComponent(date_to)}`)
        .then(response => {
            if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            return response.json();
        })
        .then(result => {
            if (loadingDiv) loadingDiv.style.display = 'none';
            
            let riskHtml = '';
            const colors = {'跨国':'risk-跨国','跨省':'risk-跨省','跨市':'risk-跨市','同城':'risk-同城','未知':'risk-未知'};
            for (let key in result.risk_counts) {
                if (result.risk_counts[key] > 0) {
                    riskHtml += `<span class="risk-tag ${colors[key]}">${key} ${result.risk_counts[key]}</span> `;
                }
            }
            let summaryHtml = `<div class="summary-bar">📊 共 ${result.total} 条可疑记录，${riskHtml}</div>`;
            
            let html = summaryHtml;
            html += '<table><thead><tr>' +
                '<th>ID</th>' +
                '<th>出口IP</th>' +
                '<th>出口IP属地</th>' +
                '<th>真实IP</th>' +
                '<th>真实IP属地</th>' +
                '<th>风险</th>' +
                '<th>关联用户（IP历史）</th>' +
                '<th>WebRTC IPv4</th>' +
                '<th>User-Agent</th>' +
                '<th>时间</th>' +
                '</tr></thead><tbody>';
            
            if (result.data.length === 0) {
                html += '<tr><td colspan="10" style="text-align:center;color:#28a745;font-weight:bold;">✅ 该段无可疑记录（已过滤同C段）</td></tr>';
            } else {
                result.data.forEach(row => {
                    const riskClass = 'risk-' + row.risk;
                    html += `<tr>
                        <td>${row.id}</td>
                        <td><strong class="ip-text">${escapeHtml(row.server_remote_addr)}</strong></td>
                        <td class="exit-geo">${escapeHtml(row.exit_geo_display)}</td>
                        <td class="real-ip">${escapeHtml(row.real_ip_display)}</td>
                        <td class="real-geo">${escapeHtml(row.real_geo_display)}</td>
                        <td><span class="risk-tag ${riskClass}">${row.risk}</span></td>
                        <td class="user-link">${row.users}</td>
                        <td style="font-size:11px;">${escapeHtml(row.webrtc_ipv4)}</td>
                        <td style="max-width:150px;word-break:break-all;font-size:11px;">${escapeHtml(row.user_agent)}</td>
                        <td style="white-space:nowrap;font-size:11px;">${escapeHtml(row.created_at_formatted)}</td>
                    </tr>`;
                });
            }
            html += '</tbody></table>';
            
            const oldTable = detailContainer.querySelector('table');
            if (oldTable) oldTable.remove();
            const oldLoading = detailContainer.querySelector('.loading');
            if (oldLoading) oldLoading.remove();
            const oldSummary = detailContainer.querySelector('.summary-bar');
            if (oldSummary) oldSummary.remove();
            
            detailContainer.insertAdjacentHTML('beforeend', html);
            card.dataset.loaded = 'true';
        })
        .catch(error => {
            console.error('加载详情失败:', error);
            const errMsg = '加载失败：' + error.message;
            const loadMsgElem = detailContainer.querySelector('.loading');
            if (loadMsgElem) {
                loadMsgElem.textContent = errMsg;
                loadMsgElem.className = 'error-msg';
            } else {
                const errDiv = document.createElement('div');
                errDiv.className = 'error-msg';
                errDiv.textContent = errMsg;
                detailContainer.appendChild(errDiv);
            }
        });
}

function escapeHtml(text) {
    if (text == null) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return String(text).replace(/[&<>"']/g, function(m) { return map[m]; });
}
</script>
</body>
</html>
<?php
$conn->close();
?>