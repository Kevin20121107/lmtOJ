<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$difficultyColumn = $conn->query("SHOW COLUMNS FROM problem_desc LIKE 'difficulty'");
if ($difficultyColumn && $difficultyColumn->num_rows === 0) {
    $conn->query("ALTER TABLE problem_desc ADD COLUMN difficulty TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER name");
}
if ($difficultyColumn) {
    $difficultyColumn->free();
}

// 检查登录
if (!isset($_SESSION['uid'])) {
    header("Location: login.php");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
$is_admin = 0;
if ($adminRes && $adminRes->num_rows > 0) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}
if ($is_admin !== 1) {
    die("无权访问");
}

// 未读消息数
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}
$msg = '';
if (($_GET['batch'] ?? '') === 'done') {
    $msg = '批量删除成功';
} elseif (($_GET['batch'] ?? '') === 'error') {
    $msg = '批量删除失败';
} elseif (($_GET['batch'] ?? '') === 'none') {
    $msg = '请先选择要删除的题目';
}

// 新增题目
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $pid = (int)trim($_POST['id'] ?? '');
    $pname = trim($_POST['name'] ?? '');
    $difficulty = filter_var($_POST['difficulty'] ?? 0, FILTER_VALIDATE_INT);

    if ($pid <= 0 || empty($pname) || $difficulty === false || $difficulty < 0 || $difficulty > 10) {
        $msg = "请输入合法的ID、名称和0至10级难度";
    } else {
        $check = $conn->query("SELECT id FROM problem_desc WHERE id = {$pid} LIMIT 1");
        if ($check && $check->num_rows > 0) {
            $msg = "该题目ID已存在";
        } elseif (!$check) {
            $msg = '查询题目失败';
        } else {
            $insert = $conn->prepare("INSERT INTO problem_desc (id, name, difficulty) VALUES (?, ?, ?)");
            $insert->bind_param("isi", $pid, $pname, $difficulty);
            $inserted = $insert->execute();
            $insert->close();
            $msg = $inserted ? '题目添加成功' : '题目创建失败';
        }
    }
}

// 编辑题目
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $eid = (int)$_POST['edit_id'];
    $ename = trim($_POST['edit_name'] ?? '');
    $difficulty = filter_var($_POST['edit_difficulty'] ?? null, FILTER_VALIDATE_INT);
    if ($eid > 0 && !empty($ename) && $difficulty !== false && $difficulty !== null && $difficulty >= 0 && $difficulty <= 10) {
        $update = $conn->prepare("UPDATE problem_desc SET name = ?, difficulty = ? WHERE id = ?");
        $update->bind_param("sii", $ename, $difficulty, $eid);
        $updated = $update->execute();
        $update->close();
        exit($updated ? "ok" : "fail");
    }
    exit("fail");
}

// 删除题目
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['del_id'])) {
    $did = (int)$_POST['del_id'];
    $deletedProblem = $conn->query("DELETE FROM problem_desc WHERE id = {$did}");
    $deletedSubmissions = $conn->query("DELETE FROM submissions WHERE problem_id = {$did}");
    exit($deletedProblem && $deletedSubmissions ? "ok" : "fail");
}

// 批量删除
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_del'])) {
    if (empty($_POST['ids'])) {
        header("Location: problem/edit?batch=none");
        exit;
    }
    $batchFailed = false;
    foreach ($_POST['ids'] as $id) {
        $tid = (int)$id;
        $deletedProblem = $conn->query("DELETE FROM problem_desc WHERE id = {$tid}");
        $deletedSubmissions = $conn->query("DELETE FROM submissions WHERE problem_id = {$tid}");
        if (!$deletedProblem || !$deletedSubmissions) {
            $batchFailed = true;
        }
    }
    header("Location: problem/edit?batch=" . ($batchFailed ? 'error' : 'done'));
    exit;
}

$probList = $conn->query("SELECT id, name, difficulty FROM problem_desc ORDER BY id ASC");

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>题目管理 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            background:var(--bg); font-family:var(--font); color:var(--text);
            line-height:1.6; min-height:100vh; -webkit-font-smoothing:antialiased;
        }
        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; letter-spacing:0.4px; color:#f0ece6; }
        .bell-wrap {
            position:relative; font-size:20px; cursor:pointer; margin-right:20px;
            width:36px; height:36px; display:flex; align-items:center; justify-content:center;
            border-radius:50%; transition:var(--transition); user-select:none;
        }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot {
            position:absolute; top:5px; right:5px; width:9px; height:9px;
            background:#f55353; border-radius:50%; border:1.5px solid #3d3a37;
            animation:pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%,100% { box-shadow:0 0 0 0 rgba(245,83,83,0.5); }
            50% { box-shadow:0 0 0 6px rgba(245,83,83,0); }
        }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a {
            color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
            border-radius:20px; transition:var(--transition); white-space:nowrap; font-weight:500;
        }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }

        .main {
            max-width:1100px; margin:28px auto 40px; display:flex; gap:22px;
            padding:0 20px; align-items:flex-start;
        }
        .sidebar {
            background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
            width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0;
        }
        .sidebar a {
            display:block; padding:13px 22px; text-align:center; background:var(--card-bg);
            color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500;
            white-space:nowrap; transition:var(--transition); border-left:3px solid transparent;
            letter-spacing:0.3px;
        }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .sidebar a:first-child { border-radius:var(--radius) var(--radius) 0 0; }
        .sidebar a:last-child { border-radius:0 0 var(--radius) var(--radius); }
        .content { flex:1; min-width:0; }

        a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
        a:hover { color:var(--accent-hover); text-decoration:underline; }
        .back-btn {
            display:inline-flex; align-items:center; gap:6px; margin-bottom:18px;
            padding:8px 18px; background:var(--card-bg); color:var(--text); text-decoration:none;
            border-radius:20px; font-size:13.5px; font-weight:500; border:1px solid var(--border);
            box-shadow:var(--shadow-sm); transition:var(--transition);
        }
        .back-btn:hover {
            background:var(--accent-light); border-color:var(--accent); color:var(--accent); text-decoration:none;
        }

        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:24px;
            box-shadow:var(--shadow); margin-bottom:18px;
        }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; color:var(--text); letter-spacing:0.3px; }
        .msg {
            background:#e8f5e9; color:#2e7d32; text-align:center; padding:10px 14px;
            border-radius:var(--radius-sm); margin-bottom:16px; font-size:14px; border:1px solid #a5d6a7;
        }
        .msg-error { background:#fce4ec; color:#c62828; border:1px solid #ef9a9a; }

        .form-row {
            display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-bottom:16px;
        }
        .form-row input {
            padding:9px 12px; border:1.5px solid var(--border); border-radius:var(--radius-sm);
            outline:none; font-size:14px; background:#fdfdfc; font-family:var(--font); transition:var(--transition);
        }
        .form-row input:focus {
            border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff;
        }
        .form-row input:nth-child(1) { width:100px; }
        .form-row input:nth-child(2) { flex:1; min-width:200px; }
        .form-row select { padding:9px 12px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; background:#fdfdfc; font-family:var(--font); }

        .btn {
            padding:9px 20px; border:none; border-radius:20px; cursor:pointer; font-size:14px;
            font-weight:500; transition:var(--transition); font-family:var(--font); white-space:nowrap;
        }
        .btn-primary { background:var(--accent); color:#fff; }
        .btn-primary:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-danger { background:var(--danger); color:#fff; }
        .btn-danger:hover { background:var(--danger-hover); }

        table { width:100%; border-collapse:collapse; }
        th {
            text-align:left; padding:11px 14px; background:#fafaf8; font-weight:500;
            font-size:13px; color:var(--text-secondary); border-bottom:2px solid var(--border);
        }
        td { padding:10px 14px; border-bottom:1px solid var(--border-light); font-size:14px; }
        tr:hover { background:#fdfcf9; }
        table input {
            width:100%; padding:8px 10px; border:1.5px solid var(--border); border-radius:var(--radius-sm);
            outline:none; font-size:13px; background:#fdfdfc; font-family:var(--font); transition:var(--transition);
        }
        table input:focus { border-color:var(--accent); box-shadow:0 0 0 2px rgba(107,138,116,0.06); background:#fff; }
        table input[readonly] { background:#fafaf8; color:var(--text-muted); }
        table select { width:100%; padding:8px 10px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:13px; background:#fdfdfc; font-family:var(--font); }

        .batch-bar {
            display:flex; gap:10px; align-items:center; margin-bottom:14px; flex-wrap:wrap;
        }
        .batch-bar label {
            font-size:14px; color:var(--text-secondary); cursor:pointer;
            display:flex; align-items:center; gap:6px;
        }
        .batch-bar input[type="checkbox"] { width:16px; height:16px; cursor:pointer; }

        .btn-sm {
            padding:6px 13px; font-size:12.5px; border-radius:20px; border:none;
            cursor:pointer; font-weight:500; transition:var(--transition); font-family:var(--font); margin-right:4px;
        }
        .btn-save { background:var(--accent); color:#fff; }
        .btn-save:hover { background:var(--accent-hover); }
        .btn-del { background:var(--danger); color:#fff; }
        .btn-del:hover { background:var(--danger-hover); }

        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; gap:14px; }
            .sidebar {
                width:100%; position:static; display:flex; flex-wrap:wrap; border-radius:var(--radius);
            }
            .sidebar a {
                flex:1 1 auto; padding:11px 10px; font-size:13px;
                border-left:none; border-bottom:2px solid transparent;
            }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .sidebar a:first-child { border-radius:var(--radius) var(--radius) 0 0; }
            .sidebar a:last-child { border-radius:0 0 var(--radius) var(--radius); }
            .navbar { padding:0 14px; height:48px; }
            .navbar h1 { font-size:15px; }
            .user-info a { font-size:12px; padding:5px 9px; }
            .card { padding:18px 14px; }
            .form-row input:nth-child(1) { width:80px; }
            .form-row input:nth-child(2) { min-width:140px; }
        }
        @media (max-width:480px) {
            .user-info { gap:2px; }
            .user-info a { padding:5px 7px; font-size:11px; }
            .bell-wrap { margin-right:8px; font-size:18px; width:30px; height:30px; }
        }
    </style>
    <link rel="stylesheet" href="/css/problem-theme.css">
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="card">
            <h2>新增&管理题目</h2>

            <?php if (!empty($msg)): ?>
                <div class="msg <?= strpos($msg, '成功') === false ? 'msg-error' : '' ?>">
                    <?= safeContent($msg) ?>
                </div>
            <?php endif; ?>

            <form method="post" class="form-row">
                <input type="number" name="id" placeholder="题目ID" required>
                <input type="text" name="name" placeholder="题目名称" required>
                <select name="difficulty" aria-label="初始难度">
                    <?php for ($level = 0; $level <= 10; $level++): ?>
                        <option value="<?= $level ?>"><?= $level === 0 ? '难度：未定义' : '难度：' . $level . '级' ?></option>
                    <?php endfor; ?>
                </select>
                <button type="submit" name="add" class="btn btn-primary">提交创建</button>
            </form>

            <form method="post" class="batch-bar" id="batchForm">
                <label><input type="checkbox" id="checkAll"> 全选</label>
                <button type="submit" name="batch_del" class="btn btn-danger" onclick="return confirm('确定批量删除选中题目？')">批量删除选中</button>
            </form>

            <table>
                <tr>
                    <th width="10%">选择</th>
                    <th width="12%">ID</th>
                    <th width="42%">题目名称</th>
                    <th width="20%">难度</th>
                    <th width="16%">操作</th>
                </tr>
                <?php if ($probList && $probList->num_rows > 0): ?>
                    <?php while ($row = $probList->fetch_assoc()): ?>
                    <tr data-id="<?= (int)$row['id'] ?>">
                        <td><input type="checkbox" class="item-check" name="ids[]" form="batchForm" value="<?= (int)$row['id'] ?>"></td>
                        <td><input type="number" value="<?= (int)$row['id'] ?>" readonly></td>
                        <td><input type="text" class="inp-name" value="<?= safeContent($row['name']) ?>"></td>
                        <td>
                            <select class="inp-difficulty" aria-label="题目难度">
                                <?php for ($level = 0; $level <= 10; $level++): ?>
                                    <option value="<?= $level ?>" <?= (int)$row['difficulty'] === $level ? 'selected' : '' ?>><?= $level === 0 ? '未定义' : $level . ' 级' ?></option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <td>
                            <button class="btn-sm btn-save save-btn">保存</button>
                            <button class="btn-sm btn-del del-btn">删除</button>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" style="text-align:center;color:var(--text-muted);padding:30px;">暂无数据</td>
                    </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>

<script>
var checkAll = document.getElementById('checkAll');
var checks = document.querySelectorAll('.item-check');
checkAll.addEventListener('change', function () {
    checks.forEach(function (c) { c.checked = checkAll.checked; });
});

document.querySelectorAll('.save-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        var tr = this.closest('tr');
        var id = tr.dataset.id;
        var name = tr.querySelector('.inp-name').value.trim();
        var difficulty = tr.querySelector('.inp-difficulty').value;
        if (!name) {
            alert('名称不能为空');
            return;
        }
        var fd = new FormData();
        fd.append('edit_id', id);
        fd.append('edit_name', name);
        fd.append('edit_difficulty', difficulty);
        fetch('', { method: 'POST', body: fd })
            .then(function (res) { return res.text(); })
            .then(function (txt) {
                alert(txt === 'ok' ? '保存成功' : '保存失败');
            });
    });
});

document.querySelectorAll('.del-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
        if (!confirm('确定删除该题目？')) return;
        var tr = this.closest('tr');
        var id = tr.dataset.id;
        var fd = new FormData();
        fd.append('del_id', id);
        fetch('', { method: 'POST', body: fd })
            .then(function (res) { return res.text(); })
            .then(function (txt) {
                if (txt === 'ok') {
                    tr.remove();
                } else {
                    alert('删除失败');
                }
            });
    });
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>