<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== 数据库连接 ==========
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 获取当前登录用户信息 ==========
$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = (int)($userRow['admin'] ?? 0);

// 非管理员禁止访问
if ($is_admin !== 1) {
    header("Location: https://lmtoj.cn/");
    exit;
}

$login_name = $userRow['name'] ?? 'Admin';

// ========== 确保必要的表存在 ==========
// users 表 star 字段
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'star'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN star INT DEFAULT 0");
}

// user_token 表
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0 COMMENT '持有token数量',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户Token余额表'");

// ========== 处理操作 ==========
$error = '';
$success = '';
$action_result = '';

// 获取用户列表
$userList = $conn->query("
    SELECT u.uid, u.name, u.admin, u.star, 
           COALESCE(t.token_num, 0) AS token_num
    FROM users u
    LEFT JOIN user_token t ON u.uid = t.uid
    ORDER BY u.uid ASC
");

// 处理设置 star
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_star'])) {
    $target_uid = intval($_POST['target_uid']);
    $new_star = intval($_POST['star_value']);
    if ($new_star < 0) $new_star = 0;
    
    $conn->query("UPDATE users SET star = $new_star WHERE uid = $target_uid");
    $success = "已设置用户 ID {$target_uid} 的 star 为 {$new_star}";
}

// 处理设置 token
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_token'])) {
    $target_uid = intval($_POST['target_uid']);
    $new_token = intval($_POST['token_value']);
    if ($new_token < 0) $new_token = 0;
    
    $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($target_uid, $new_token)
                  ON DUPLICATE KEY UPDATE token_num = $new_token");
    $success = "已设置用户 ID {$target_uid} 的 token 为 {$new_token}";
}

// 处理批量添加 star
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_add_star'])) {
    $batch_uids = trim($_POST['batch_uids']);
    $add_amount = intval($_POST['add_amount']);
    if ($batch_uids && $add_amount > 0) {
        $uid_array = array_map('intval', explode(',', $batch_uids));
        $uid_list = implode(',', $uid_array);
        $conn->query("UPDATE users SET star = star + $add_amount WHERE uid IN ($uid_list)");
        $success = "已为 " . count($uid_array) . " 个用户增加 {$add_amount} star";
    } else {
        $error = "请填写正确的 UID 列表和数量";
    }
}

// 处理批量添加 token
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['batch_add_token'])) {
    $batch_uids = trim($_POST['batch_uids']);
    $add_amount = intval($_POST['add_amount']);
    if ($batch_uids && $add_amount > 0) {
        $uid_array = array_map('intval', explode(',', $batch_uids));
        foreach ($uid_array as $uid) {
            $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($uid, $add_amount)
                          ON DUPLICATE KEY UPDATE token_num = token_num + $add_amount");
        }
        $success = "已为 " . count($uid_array) . " 个用户增加 {$add_amount} token";
    } else {
        $error = "请填写正确的 UID 列表和数量";
    }
}

// 处理搜索用户
$search_keyword = '';
$filtered_users = $userList;
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search_keyword = $conn->real_escape_string($_GET['search']);
    $filtered_users = $conn->query("
        SELECT u.uid, u.name, u.admin, u.star, 
               COALESCE(t.token_num, 0) AS token_num
        FROM users u
        LEFT JOIN user_token t ON u.uid = t.uid
        WHERE u.name LIKE '%$search_keyword%' OR u.uid LIKE '%$search_keyword%'
        ORDER BY u.uid ASC
    ");
}

// 获取当前用户自己的信息（用于快速设置）
$self_star = (int)($conn->query("SELECT star FROM users WHERE uid = $login_uid")->fetch_assoc()['star'] ?? 0);
$self_token = (int)($conn->query("SELECT token_num FROM user_token WHERE uid = $login_uid")->fetch_assoc()['token_num'] ?? 0);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>Command Block - 管理后台</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-muted: #a0988e;
            --text-secondary: #7a736b;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --danger: #d9534f;
            --warning: #f0ad4e;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }

        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .navbar .cmd-badge {
            background:var(--warning); color:#fff; padding:2px 12px;
            border-radius:12px; font-size:12px; font-weight:600; margin-left:10px;
        }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a {
            color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
            border-radius:20px; transition:var(--transition);
        }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }

        .main { max-width:1200px; margin:28px auto 40px; padding:0 20px; }
        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:26px 28px;
            margin-bottom:18px; box-shadow:var(--shadow);
        }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .card h3 { font-size:16px; font-weight:600; margin-bottom:12px; margin-top:8px; }

        .form-group { margin-bottom:15px; }
        .form-group label { display:block; font-weight:500; margin-bottom:4px; font-size:14px; }
        .form-control {
            width:100%; padding:10px 14px; border:1.5px solid var(--border);
            border-radius:var(--radius-sm); font-size:14px; outline:none;
            transition:var(--transition); background:#fdfdfc;
        }
        .form-control:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); }
        .form-control-sm { padding:6px 10px; font-size:13px; width:auto; display:inline-block; }

        .btn {
            padding:9px 24px; background:var(--accent); color:#fff; border:none;
            border-radius:20px; cursor:pointer; font-size:14px; font-weight:500;
            transition:var(--transition);
        }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:#c9302c; }
        .btn-warning { background:var(--warning); }
        .btn-warning:hover { background:#e6a020; }
        .btn-sm { padding:4px 14px; font-size:12px; }

        .msg { padding:12px 16px; border-radius:var(--radius-sm); margin-bottom:15px; }
        .msg-error { background:#fce4ec; border:1px solid #ef9a9a; color:#c62828; }
        .msg-success { background:#e8f5e9; border:1px solid #a5d6a7; color:#2e7d32; }

        .table-wrap { overflow-x:auto; }
        table { width:100%; border-collapse:collapse; font-size:14px; }
        table th, table td { padding:10px 12px; text-align:left; border-bottom:1px solid var(--border-light); }
        table th { background:#f8f6f2; font-weight:600; color:var(--text-secondary); font-size:13px; text-transform:uppercase; letter-spacing:0.5px; }
        table tr:hover { background:#faf9f6; }

        .inline-form { display:flex; flex-wrap:wrap; gap:10px; align-items:flex-end; }
        .inline-form .form-group { margin-bottom:0; flex:1 1 150px; }
        .inline-form .form-group label { font-size:13px; }
        .inline-form .btn { flex-shrink:0; }

        .grid-2 { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
        @media(max-width:768px){ .grid-2 { grid-template-columns:1fr; } }

        .search-box { display:flex; gap:10px; margin-bottom:16px; }
        .search-box .form-control { flex:1; }

        .admin-badge { background:#8e44ad; color:#fff; padding:1px 10px; border-radius:10px; font-size:11px; font-weight:600; }
        .self-row { background:#eef4ef !important; }

        .back-link { display:inline-block; margin-top:20px; color:var(--accent); text-decoration:none; font-weight:500; }
        .back-link:hover { text-decoration:underline; }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="main">
    <div class="card">
        <h2>
            ⚡ Command Block
            <span class="cmd-badge">ADMIN</span>
        </h2>
        <p style="color:var(--text-muted);margin-bottom:16px;">
            欢迎回来，<?=htmlspecialchars($login_name)?> ｜
            你的 Star: <strong>⭐ <?=$self_star?></strong> ｜
            你的 Token: <strong>🔹 <?=$self_token?></strong>
        </p>

        <?php if ($error): ?>
            <div class="msg msg-error"><?=htmlspecialchars($error)?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="msg msg-success"><?=htmlspecialchars($success)?></div>
        <?php endif; ?>

        <!-- ===== 快速设置自己的 star/token ===== -->
        <div class="grid-2" style="margin-bottom:20px;padding-bottom:20px;border-bottom:1px solid var(--border-light);">
            <div>
                <h3>设置自己的 Star</h3>
                <form method="post" class="inline-form">
                    <input type="hidden" name="target_uid" value="<?=$login_uid?>">
                    <div class="form-group">
                        <label>Star 数量</label>
                        <input type="number" name="star_value" class="form-control form-control-sm" min="0" value="<?=$self_star?>" required>
                    </div>
                    <button type="submit" name="set_star" class="btn btn-sm">设置</button>
                </form>
            </div>
            <div>
                <h3>设置自己的 Token</h3>
                <form method="post" class="inline-form">
                    <input type="hidden" name="target_uid" value="<?=$login_uid?>">
                    <div class="form-group">
                        <label>Token 数量</label>
                        <input type="number" name="token_value" class="form-control form-control-sm" min="0" value="<?=$self_token?>" required>
                    </div>
                    <button type="submit" name="set_token" class="btn btn-sm">设置</button>
                </form>
            </div>
        </div>

        <!-- ===== 用户管理表格 ===== -->
        <h3>👥 用户列表</h3>
        <div class="search-box">
            <form method="get" style="display:flex;gap:10px;flex:1;">
                <input type="text" name="search" class="form-control" placeholder="搜索用户名或 UID..." value="<?=htmlspecialchars($search_keyword)?>">
                <button type="submit" class="btn btn-sm">搜索</button>
                <?php if ($search_keyword): ?>
                    <a href="?" class="btn btn-sm" style="background:#ccc;">清除</a>
                <?php endif; ?>
            </form>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>UID</th>
                        <th>用户名</th>
                        <th>角色</th>
                        <th>⭐ Star</th>
                        <th>🔹 Token</th>
                        <th style="min-width:200px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $users = $search_keyword ? $filtered_users : $userList;
                    if ($users && $users->num_rows > 0):
                        while ($u = $users->fetch_assoc()):
                            $is_self = ($u['uid'] == $login_uid);
                    ?>
                    <tr class="<?=$is_self ? 'self-row' : ''?>">
                        <td><code><?=$u['uid']?></code></td>
                        <td>
                            <?=htmlspecialchars($u['name'])?>
                            <?php if ($is_self): ?>
                                <span style="font-size:11px;color:var(--text-muted);">(你)</span>
                            <?php endif; ?>
                            <?php if ($u['admin'] == 1): ?>
                                <span class="admin-badge">管理员</span>
                            <?php endif; ?>
                        </td>
                        <td><?=$u['admin'] == 1 ? '👑 Admin' : '👤 User'?></td>
                        <td><strong><?=$u['star']?></strong></td>
                        <td><strong><?=$u['token_num']?></strong></td>
                        <td>
                            <form method="post" style="display:inline-block;">
                                <input type="hidden" name="target_uid" value="<?=$u['uid']?>">
                                <input type="number" name="star_value" class="form-control form-control-sm" style="width:60px;display:inline-block;padding:4px 6px;" value="<?=$u['star']?>" min="0">
                                <button type="submit" name="set_star" class="btn btn-sm" style="padding:4px 10px;">设置Star</button>
                            </form>
                            <form method="post" style="display:inline-block;margin-top:4px;">
                                <input type="hidden" name="target_uid" value="<?=$u['uid']?>">
                                <input type="number" name="token_value" class="form-control form-control-sm" style="width:60px;display:inline-block;padding:4px 6px;" value="<?=$u['token_num']?>" min="0">
                                <button type="submit" name="set_token" class="btn btn-sm" style="padding:4px 10px;">设置Token</button>
                            </form>
                        </td>
                    </tr>
                    <?php 
                        endwhile;
                    else:
                    ?>
                    <tr>
                        <td colspan="6" style="text-align:center;color:var(--text-muted);padding:30px 0;">
                            <?= $search_keyword ? '未找到匹配用户' : '暂无用户' ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- ===== 批量操作 ===== -->
    <div class="card">
        <h2>📦 批量操作</h2>
        <div class="grid-2">
            <div>
                <h3>批量增加 Star</h3>
                <form method="post">
                    <div class="form-group">
                        <label>UID 列表（用英文逗号分隔）</label>
                        <input type="text" name="batch_uids" class="form-control" placeholder="例如: 1,2,3,5,8" required>
                    </div>
                    <div class="form-group">
                        <label>增加数量</label>
                        <input type="number" name="add_amount" class="form-control" min="1" value="10" required>
                    </div>
                    <button type="submit" name="batch_add_star" class="btn btn-warning">批量增加 Star</button>
                </form>
            </div>
            <div>
                <h3>批量增加 Token</h3>
                <form method="post">
                    <div class="form-group">
                        <label>UID 列表（用英文逗号分隔）</label>
                        <input type="text" name="batch_uids" class="form-control" placeholder="例如: 1,2,3,5,8" required>
                    </div>
                    <div class="form-group">
                        <label>增加数量</label>
                        <input type="number" name="add_amount" class="form-control" min="1" value="50" required>
                    </div>
                    <button type="submit" name="batch_add_token" class="btn btn-warning">批量增加 Token</button>
                </form>
            </div>
        </div>
        <div style="margin-top:12px;color:var(--text-muted);font-size:13px;">
            💡 提示：UID 可从上方用户列表获取，批量操作可同时为多个用户增加 star/token
        </div>
    </div>

    <!-- ===== 快速跳转 ===== -->
    <div class="card">
        <h2>🔗 快捷导航</h2>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
            <a href="https://lmtoj.cn/" class="btn" style="background:#5b6e6a;">返回首页</a>
            <a href="https://lmtoj.cn/shop" class="btn" style="background:#4a90d9;">前往商店</a>
            <a href="https://lmtoj.cn/benben" class="btn" style="background:#6b8a74;">前往犇犇</a>
            <a href="?logout" class="btn btn-danger" onclick="return confirm('确定登出吗？')">登出</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>

<?php
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}
?>
</body>
</html>