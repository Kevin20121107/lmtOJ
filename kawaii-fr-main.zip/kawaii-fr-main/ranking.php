<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 登录检查 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$login_uid = (int)$_SESSION['uid'];

// ---------- 辅助函数 ----------
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getUserColor($user, $login_uid, $myShowColorful = 1) {
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    $admin = (int)($user['admin'] ?? 0);
    $color = getColorByTotalScore($total, $admin);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    $isColorful = false;
    if ($user['uid'] == $login_uid) {
        $isColorful = $targetColorful;
    } else {
        $isColorful = $targetColorful && $myShowColorful;
    }
    return ['color' => $color, 'isColorful' => $isColorful];
}

$myShowColorful = 1;
$prefRes = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($prefRes && $prefRes->num_rows > 0) {
    $myShowColorful = (int)$prefRes->fetch_assoc()['show_colorful_names'];
}

$tab = isset($_GET['tab']) ? $_GET['tab'] : 'score';
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 20;
$offset = ($page - 1) * $perPage;

$totalRows = 0;
$rankList = [];
$pinnedUser = null;   // 当前用户自己的数据（用于置顶行）
$myRank = null;       // 当前用户的实际排名

if ($tab === 'score') {
    $sql = "SELECT u.uid, u.name, u.avatar, u.admin, u.tag,
                   u.base_credit, u.practice_score, u.contribute_score, u.contest_score,
                   u.valuation, u.username_color, u.cert_type, u.cert_level,
                   af.frame_img
            FROM users u
            LEFT JOIN user_avatar_frame af ON u.uid = af.uid 
                AND af.expire_time > NOW() 
                AND af.id = COALESCE(
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
                )
            WHERE u.admin = 0";
    $result = $conn->query($sql);
    $allUsers = [];
    while ($row = $result->fetch_assoc()) {
        $base = (int)($row['base_credit'] ?? 10);
        $achieve = min(getAchievementScore($row['cert_type'] ?? '', (int)($row['cert_level'] ?? 0)), 20);
        $practice = min((int)($row['practice_score'] ?? 0), 20);
        $contribute = min((int)($row['contribute_score'] ?? 0), 30);
        $contest = min((int)($row['contest_score'] ?? 0), 20);
        $valuation = (int)($row['valuation'] ?? 0);
        $isBrown = ($valuation === -1);
        $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
        $row['total_score'] = $total;
        $row['display'] = getUserColor($row, $login_uid, $myShowColorful);
        $allUsers[] = $row;
    }
    usort($allUsers, function($a, $b) {
        return $b['total_score'] - $a['total_score'];
    });
    
    // 查找自己的排名（管理员不在列表中，故不会找到）
    foreach ($allUsers as $idx => $user) {
        if ($user['uid'] == $login_uid) {
            $pinnedUser = $user;
            $myRank = $idx + 1;
            break;
        }
    }
    
    $totalRows = count($allUsers);
    $rankList = array_slice($allUsers, $offset, $perPage);
    $totalPage = ceil($totalRows / $perPage);
    
} else if ($tab === 'benben') {
    $countSql = "SELECT COUNT(DISTINCT uid) AS cnt FROM benben";
    $countRes = $conn->query($countSql);
    $totalRows = $countRes->fetch_assoc()['cnt'];
    $sql = "SELECT u.uid, u.name, u.avatar, u.admin, u.tag,
                   u.base_credit, u.practice_score, u.contribute_score, u.contest_score,
                   u.valuation, u.username_color, u.cert_type, u.cert_level,
                   COUNT(b.id) AS benben_count,
                   af.frame_img
            FROM users u
            LEFT JOIN benben b ON u.uid = b.uid
            LEFT JOIN user_avatar_frame af ON u.uid = af.uid 
                AND af.expire_time > NOW() 
                AND af.id = COALESCE(
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
                )
            GROUP BY u.uid
            ORDER BY benben_count DESC
            LIMIT ?, ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $offset, $perPage);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['display'] = getUserColor($row, $login_uid, $myShowColorful);
        $rankList[] = $row;
    }
    $stmt->close();
    $totalPage = ceil($totalRows / $perPage);
    
    // 获取自己的犇犇数据及排名
    $myBenbenSql = "SELECT u.uid, u.name, u.avatar, u.admin, u.tag,
                           u.base_credit, u.practice_score, u.contribute_score, u.contest_score,
                           u.valuation, u.username_color, u.cert_type, u.cert_level,
                           COUNT(b.id) AS benben_count,
                           af.frame_img
                    FROM users u
                    LEFT JOIN benben b ON u.uid = b.uid
                    LEFT JOIN user_avatar_frame af ON u.uid = af.uid 
                        AND af.expire_time > NOW() 
                        AND af.id = COALESCE(
                            (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
                            (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
                        )
                    WHERE u.uid = {$login_uid}
                    GROUP BY u.uid";
    $myRes = $conn->query($myBenbenSql);
    if ($myRes && $myRes->num_rows > 0) {
        $pinnedUser = $myRes->fetch_assoc();
        $pinnedUser['display'] = getUserColor($pinnedUser, $login_uid, $myShowColorful);
        // 计算排名：犇犇数比我多的人数 + 1
        $myCount = (int)$pinnedUser['benben_count'];
        $rankSql = "SELECT COUNT(*) + 1 AS rnk FROM (
                        SELECT u.uid, COUNT(b.id) AS cnt
                        FROM users u LEFT JOIN benben b ON u.uid = b.uid
                        GROUP BY u.uid
                    ) t WHERE t.cnt > {$myCount}";
        $rankRes = $conn->query($rankSql);
        if ($rankRes && $rankRes->num_rows > 0) {
            $myRank = (int)$rankRes->fetch_assoc()['rnk'];
        }
    }
    
} else if ($tab === 'ostracism') {
    $countSql = "SELECT COUNT(DISTINCT l.target_uid) AS cnt FROM ostracism_log l LEFT JOIN users u ON u.uid = l.target_uid WHERE u.admin=0";
    $countRes = $conn->query($countSql);
    $totalRows = $countRes->fetch_assoc()['cnt'];
    $sql = "SELECT u.uid, u.name, u.avatar, u.admin, u.tag,
                   u.base_credit, u.practice_score, u.contribute_score, u.contest_score,
                   u.valuation, u.username_color, u.cert_type, u.cert_level,
                   COUNT(l.id) AS ostracism_count,
                   af.frame_img
            FROM users u
            LEFT JOIN ostracism_log l ON u.uid = l.target_uid
            LEFT JOIN user_avatar_frame af ON u.uid = af.uid 
                AND af.expire_time > NOW() 
                AND af.id = COALESCE(
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
                    (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
                )
            WHERE u.admin = 0
            GROUP BY u.uid
            HAVING ostracism_count > 0
            ORDER BY ostracism_count DESC
            LIMIT ?, ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $offset, $perPage);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $row['display'] = getUserColor($row, $login_uid, $myShowColorful);
        $rankList[] = $row;
    }
    $stmt->close();
    $totalPage = ceil($totalRows / $perPage);
    
    // 获取自己的放逐数据及排名（只有非管理员且被放逐过）
    $myOstracismSql = "SELECT u.uid, u.name, u.avatar, u.admin, u.tag,
                               u.base_credit, u.practice_score, u.contribute_score, u.contest_score,
                               u.valuation, u.username_color, u.cert_type, u.cert_level,
                               COUNT(l.id) AS ostracism_count,
                               af.frame_img
                        FROM users u
                        LEFT JOIN ostracism_log l ON u.uid = l.target_uid
                        LEFT JOIN user_avatar_frame af ON u.uid = af.uid 
                            AND af.expire_time > NOW() 
                            AND af.id = COALESCE(
                                (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
                                (SELECT id FROM user_avatar_frame WHERE uid = u.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
                            )
                        WHERE u.uid = {$login_uid} AND u.admin = 0
                        GROUP BY u.uid
                        HAVING ostracism_count > 0";
    $myRes = $conn->query($myOstracismSql);
    if ($myRes && $myRes->num_rows > 0) {
        $pinnedUser = $myRes->fetch_assoc();
        $pinnedUser['display'] = getUserColor($pinnedUser, $login_uid, $myShowColorful);
        // 计算排名：放逐次数比我多的人数 + 1
        $myCount = (int)$pinnedUser['ostracism_count'];
        $rankSql = "SELECT COUNT(*) + 1 AS rnk FROM (
                        SELECT u.uid, COUNT(l.id) AS cnt
                        FROM users u LEFT JOIN ostracism_log l ON u.uid = l.target_uid
                        WHERE u.admin = 0
                        GROUP BY u.uid
                        HAVING cnt > 0
                    ) t WHERE t.cnt > {$myCount}";
        $rankRes = $conn->query($rankSql);
        if ($rankRes && $rankRes->num_rows > 0) {
            $myRank = (int)$rankRes->fetch_assoc()['rnk'];
        }
    }
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
function getFirstChar($name) {
    $name = trim($name ?? '?');
    if (mb_strlen($name) > 0) return mb_strtoupper(mb_substr($name, 0, 1));
    return '?';
}

$current_page = 'ranking.php';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>排行榜 - lmtOJ</title>
    <link rel="stylesheet" href="/css/katex.min.css" />
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);} 50%{box-shadow:0 0 0 6px rgba(245,83,83,0);} }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); font-weight:500; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:20px; border:1px solid var(--border-light); }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .tab-nav { display:flex; gap:8px; margin-bottom:20px; border-bottom:2px solid var(--border-light); padding-bottom:6px; }
        .tab-nav a { padding:6px 16px; border-radius:20px; text-decoration:none; color:var(--text-secondary); font-weight:500; transition:var(--transition); }
        .tab-nav a:hover { background:var(--accent-light); color:var(--accent); }
        .tab-nav a.active { background:var(--accent); color:#fff; }
        table { width:100%; border-collapse:collapse; }
        th { text-align:left; padding:12px 14px; background:#fafaf8; font-weight:600; color:var(--text-secondary); border-bottom:2px solid var(--border); font-size:14px; }
        td { padding:12px 14px; border-bottom:1px solid var(--border-light); font-size:14px; vertical-align:middle; }
        tr:hover td { background:#fdfcf9; }
        .rank-num { font-weight:700; color:var(--text-muted); min-width:30px; }
        .ben-avatar {
            width: 42px;
            height: 42px;
            position: relative;
            flex-shrink: 0;
            display: inline-block;
            background: transparent !important;
        }
        .ben-avatar .avatar-mask {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            overflow: hidden;
            z-index: 0;
            background: transparent !important;
        }
        .ben-avatar .avatar-mask img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            background: transparent !important;
        }
        .ben-avatar .avatar-mask .avatar-text {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            font-weight: 700;
            color: #fff;
            background: var(--accent);
        }
        .ben-avatar .avatar-frame {
            width: 52px;
            height: 52px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            object-fit: contain;
            pointer-events: none;
            z-index: 2;
        }
        .user-cell {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .ben-name { font-weight:600; text-decoration:none; transition:color 0.2s; }
        .ben-name:hover { opacity:0.8; text-decoration:underline; }
        .ben-name.colorful {
            color: #f1948a;
            animation: colorful 3s linear infinite;
            text-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        @keyframes colorful {
            0% { color: #f1948a; }
            17% { color: #f5b041; }
            33% { color: #f7dc6f; }
            50% { color: #82e0aa; }
            67% { color: #85c1e9; }
            83% { color: #bb8fce; }
            100% { color: #f1948a; }
        }
        .tag {
            border-radius:3px;
            padding:2px 9px;
            color:#fff;
            display:inline-block;
            margin-left:5px;
            font-size:11px;
            font-weight:600;
        }
        .tag.colorful-bg {
            animation: colorfulBg 3s linear infinite;
        }
        @keyframes colorfulBg {
            0% { background-color: #f1948a; }
            17% { background-color: #f5b041; }
            33% { background-color: #f7dc6f; }
            50% { background-color: #82e0aa; }
            67% { background-color: #85c1e9; }
            83% { background-color: #bb8fce; }
            100% { background-color: #f1948a; }
        }
        .score-value { font-weight:600; }
        .page-bar { display:flex; gap:6px; margin-top:16px; flex-wrap:wrap; }
        .page-bar a { padding:6px 12px; border:1.5px solid var(--border); border-radius:20px; text-decoration:none; color:var(--text); font-size:13px; font-weight:500; background:#fff; }
        .page-bar a:hover { border-color:var(--accent); color:var(--accent); background:var(--accent-light); }
        .page-bar a.active-page { background:var(--accent); color:#fff; border-color:var(--accent); }
        .page-ellipsis { padding:6px 4px; color:var(--text-muted); font-size:13px; }

        /* 置顶行样式 */
        .pinned-row {
            background: #fffde7 !important;
            border-left: 4px solid #f39c12;
        }
        .pinned-row:hover td {
            background: #fffde7 !important;
        }
        /* 高亮自己行 */
        .highlight-row {
            background: #f0f7ff !important;
        }
        .highlight-row:hover td {
            background: #e6f0fa !important;
        }

        body.dark-mode .ben-avatar,
        body.dark-mode .ben-avatar .avatar-mask,
        body.dark-mode .ben-avatar .avatar-mask img {
            background: transparent !important;
            border: none !important;
        }
        body.dark-mode .ben-avatar .avatar-mask .avatar-text {
            background: var(--accent) !important;
            color: #fff !important;
        }
        body.dark-mode td {
            background: transparent !important;
        }

        @media(max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .navbar { padding:0 14px; height:48px; }
            .card { padding:18px 14px; }
            .ben-avatar { width: 36px; height: 36px; }
            .ben-avatar .avatar-frame { width: 44px; height: 44px; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <h2>🏆 排行榜</h2>

            <div class="tab-nav">
                <a href="?tab=score" class="<?= $tab === 'score' ? 'active' : '' ?>">总估值</a>
                <a href="?tab=benben" class="<?= $tab === 'benben' ? 'active' : '' ?>">犇犇数量</a>
                <a href="?tab=ostracism" class="<?= $tab === 'ostracism' ? 'active' : '' ?>">放逐榜</a>
            </div>

            <?php if (empty($rankList) && !$pinnedUser): ?>
                <p style="color:var(--text-muted);">
                    <?php if ($tab === 'ostracism'): ?>
                        暂无被放逐记录
                    <?php else: ?>
                        暂无数据
                    <?php endif; ?>
                </p>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>用户</th>
                            <th style="text-align:right;">
                                <?php if ($tab === 'score'): ?>
                                    总估值
                                <?php elseif ($tab === 'benben'): ?>
                                    犇犇数
                                <?php else: ?>
                                    放逐次数
                                <?php endif; ?>
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // ---------- 置顶行：显示自己的实际排名 ----------
                        if ($pinnedUser && $myRank !== null):
                            $display = $pinnedUser['display'];
                            $color = $display['color'];
                            $isColorful = $display['isColorful'];
                            $avatar = $pinnedUser['avatar'] ?? '';
                            $frame = $pinnedUser['frame_img'] ?? '';
                        ?>
                        <tr class="pinned-row">
                            <td class="rank-num" style="color:#f39c12;"><?= $myRank ?></td>
                            <td>
                                <div class="user-cell">
                                    <div class="ben-avatar">
                                        <div class="avatar-mask">
                                            <?php if (!empty($avatar)): ?>
                                                <img src="<?= safeContent($avatar) ?>" alt="avatar">
                                            <?php else: ?>
                                                <div class="avatar-text"><?= getFirstChar($pinnedUser['name']) ?></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($frame)): ?>
                                            <img class="avatar-frame" src="<?= safeContent($frame) ?>" alt="头像框">
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($tab === 'ostracism'): ?>
                                        <a href="https://lmtoj.cn/ostracism?uid=<?= $pinnedUser['uid'] ?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" style="color:<?= $color ?>;">
                                            <?= safeContent($pinnedUser['name']) ?>
                                        </a>
                                    <?php else: ?>
                                        <a href="https://lmtoj.cn/user/<?= $pinnedUser['uid'] ?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" style="color:<?= $color ?>;">
                                            <?= safeContent($pinnedUser['name']) ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($pinnedUser['tag'])): ?>
                                        <span class="tag<?= $isColorful ? ' colorful-bg' : '' ?>" style="background:<?= $color ?>;">
                                            <?= safeContent($pinnedUser['tag']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <span style="font-size:12px; color:#f39c12; font-weight:bold;">(我)</span>
                                </div>
                            </td>
                            <td style="text-align:right; font-weight:600;">
                                <?php if ($tab === 'score'): ?>
                                    <?= $pinnedUser['total_score'] ?>
                                <?php elseif ($tab === 'benben'): ?>
                                    <?= (int)($pinnedUser['benben_count'] ?? 0) ?>
                                <?php else: ?>
                                    <?= (int)($pinnedUser['ostracism_count'] ?? 0) ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>

                        <?php
                        // ---------- 正常排行榜（包含自己，自己行高亮） ----------
                        $rank = $offset + 1;
                        foreach ($rankList as $row):
                            $display = $row['display'];
                            $color = $display['color'];
                            $isColorful = $display['isColorful'];
                            $avatar = $row['avatar'] ?? '';
                            $frame = $row['frame_img'] ?? '';
                            $isMe = ($row['uid'] == $login_uid);
                        ?>
                        <tr class="<?= $isMe ? 'highlight-row' : '' ?>">
                            <td class="rank-num"><?= $rank ?></td>
                            <td>
                                <div class="user-cell">
                                    <div class="ben-avatar">
                                        <div class="avatar-mask">
                                            <?php if (!empty($avatar)): ?>
                                                <img src="<?= safeContent($avatar) ?>" alt="avatar">
                                            <?php else: ?>
                                                <div class="avatar-text"><?= getFirstChar($row['name']) ?></div>
                                            <?php endif; ?>
                                        </div>
                                        <?php if (!empty($frame)): ?>
                                            <img class="avatar-frame" src="<?= safeContent($frame) ?>" alt="头像框">
                                        <?php endif; ?>
                                    </div>
                                    <?php if ($tab === 'ostracism'): ?>
                                        <a href="https://lmtoj.cn/ostracism?uid=<?= $row['uid'] ?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" style="color:<?= $color ?>;">
                                            <?= safeContent($row['name']) ?>
                                        </a>
                                    <?php else: ?>
                                        <a href="https://lmtoj.cn/user/<?= $row['uid'] ?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" style="color:<?= $color ?>;">
                                            <?= safeContent($row['name']) ?>
                                        </a>
                                    <?php endif; ?>
                                    <?php if (!empty($row['tag'])): ?>
                                        <span class="tag<?= $isColorful ? ' colorful-bg' : '' ?>" style="background:<?= $color ?>;">
                                            <?= safeContent($row['tag']) ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="text-align:right; font-weight:600;">
                                <?php if ($tab === 'score'): ?>
                                    <?= $row['total_score'] ?>
                                <?php elseif ($tab === 'benben'): ?>
                                    <?= (int)($row['benben_count'] ?? 0) ?>
                                <?php else: ?>
                                    <?= (int)($row['ostracism_count'] ?? 0) ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php
                        $rank++;
                        endforeach;
                        ?>
                    </tbody>
                </table>

                <?php if ($totalPage > 1): ?>
                <div class="page-bar">
                    <?php if ($page > 1): ?>
                        <a href="?tab=<?= $tab ?>&page=<?= $page-1 ?>">上一页</a>
                    <?php endif; ?>
                    <?php
                    $shown = [1];
                    for ($i = max(2, $page-2); $i <= min($totalPage-1, $page+2); $i++) $shown[] = $i;
                    if ($totalPage > 1) $shown[] = $totalPage;
                    $shown = array_unique($shown);
                    sort($shown);
                    $prev = 0;
                    foreach ($shown as $i):
                        if ($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
                    ?>
                        <a href="?tab=<?= $tab ?>&page=<?= $i ?>" class="<?= $i == $page ? 'active-page' : '' ?>"><?= $i ?></a>
                    <?php $prev = $i; endforeach; ?>
                    <?php if ($page < $totalPage): ?>
                        <a href="?tab=<?= $tab ?>&page=<?= $page+1 ?>">下一页</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>