<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 积分颜色辅助函数（复用） ==========
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getColorLevel($totalScore, $isAdmin) {
    if ($isAdmin) return 'purple';
    if ($totalScore < 0) return 'brown';
    if ($totalScore <= 10) return 'gray';
    if ($totalScore <= 20) return 'blue';
    if ($totalScore <= 45) return 'green';
    if ($totalScore <= 65) return 'orange';
    return 'red';
}

// ========== 登录检查 ==========
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$login_uid = (int)$_SESSION['uid'];

// ========== 自动建表 ==========
// 用户每日任务选择表
$conn->query("CREATE TABLE IF NOT EXISTS user_daily_tasks (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    date DATE NOT NULL,
    task_id INT NOT NULL,
    rewarded TINYINT DEFAULT 0,
    UNIQUE KEY (uid, date, task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 每日奖励领取记录表
$conn->query("CREATE TABLE IF NOT EXISTS daily_rewards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    date DATE NOT NULL,
    claimed TINYINT DEFAULT 0,
    UNIQUE KEY (uid, date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 为 articles 表添加 recommended_at 字段（若缺失）
$colCheck = $conn->query("SHOW COLUMNS FROM articles LIKE 'recommended_at'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE articles ADD COLUMN recommended_at TIMESTAMP NULL DEFAULT NULL");
}

// Token 表（若不存在）
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0 COMMENT '持有token数量',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户Token余额'");

// ========== 获取用户信息 ==========
$userInfo = $conn->query("SELECT uid, name, admin, sqadmin, base_credit, valuation, username_color, cert_type, cert_level, practice_score, contribute_score, contest_score FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
if (!$userInfo) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$is_admin = (int)($userInfo['admin'] ?? 0);
$is_sqadmin = (int)($userInfo['sqadmin'] ?? 0);

// 计算用户总分和颜色等级
$base = (int)($userInfo['base_credit'] ?? 10);
$achieve = min(getAchievementScore($userInfo['cert_type'] ?? '', (int)($userInfo['cert_level'] ?? 0)), 20);
$practice = min((int)($userInfo['practice_score'] ?? 0), 20);
$contribute = min((int)($userInfo['contribute_score'] ?? 0), 30);
$contest = min((int)($userInfo['contest_score'] ?? 0), 20);
$valuation = (int)($userInfo['valuation'] ?? 0);
$isBrown = ($valuation === -1);
$totalScore = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
$isAdmin = (int)($userInfo['admin'] ?? 0);
$colorLevel = getColorLevel($totalScore, $isAdmin);

// ========== 任务定义 ==========
$taskDefs = [
    1 => [
        'name' => '收到通知',
        'desc' => '收到 10 条通知',
        'reward' => ['token' => 5],
        'target' => 10,
        'check' => function($uid, $conn) {
            $today = date('Y-m-d');
            $res = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = $uid AND DATE(create_time) = '$today'");
            return (int)$res->fetch_assoc()['cnt'];
        }
    ],
    2 => [
    'name' => 'AC 题目',
    'desc' => 'AC 一道题目',
    'reward' => ['star' => 1],
    'target' => 1,
    'check' => function($uid, $conn) {
        $today = date('Y-m-d');
        // 先查出用户今日所有提交ID
        $subRes = $conn->query("SELECT id FROM submissions WHERE uid = $uid AND DATE(created_at) = '$today'");
        $acCount = 0;
        $ctx = stream_context_create([
            'http' => [
                'timeout' => 2,
                'ignore_errors' => true,
            ]
        ]);
        while ($row = $subRes->fetch_assoc()) {
            $sid = $row['id'];
            $url = "https://raw.githubusercontent.com/Dream-Ydch/lmtoj-judge/main/results/{$sid}.json";
            $resp = @file_get_contents($url, false, $ctx);
            if ($resp !== false) {
                $data = json_decode($resp, true);
                if (!empty($data['result']) && $data['result'] === 'AC') {
                    $acCount++;
                }
            }
        }
        return $acCount;
    }
],
    3 => [
        'name' => '工单完成',
        'desc' => '一个工单被完成',
        'reward' => ['star' => 1],
        'target' => 1,
        'check' => function($uid, $conn) {
            $today = date('Y-m-d');
            $res = $conn->query("
                SELECT COUNT(*) AS cnt
                FROM discuss_reply r
                JOIN discuss d ON r.tid = d.id
                WHERE r.content LIKE '将工单状态设为已完成%'
                  AND DATE(r.create_time) = '$today'
                  AND d.uid = $uid
                  AND d.category = 3
            ");
            return (int)$res->fetch_assoc()['cnt'];
        }
    ],
      4 => [
    'name' => '文章推荐',
    'desc' => '一篇文章被全站推荐',
    'reward' => ['star' => 2],
    'target' => 1,
    'check' => function($uid, $conn) {
        $today = date('Y-m-d');
        $res = $conn->query("
            SELECT COUNT(*) AS cnt
            FROM articles
            WHERE uid = $uid
              AND is_recommended = 1
              AND (
                DATE(recommended_at) = '$today'
                OR (recommended_at IS NULL AND DATE(created_at) = '$today')
              )
        ");
        return (int)$res->fetch_assoc()['cnt'];
    }
],  
];

// ========== 处理每日奖励领取 ==========
$today = date('Y-m-d');
$rewardMsg = '';
$rewardError = '';

if (isset($_GET['claim_reward'])) {
    // 检查今天是否已领取
    $check = $conn->query("SELECT claimed FROM daily_rewards WHERE uid = $login_uid AND date = '$today'");
    if ($check->num_rows > 0) {
        $row = $check->fetch_assoc();
        if ($row['claimed']) {
            $rewardError = "您今天已领取过每日奖励，请明天再来。";
        } else {
            // 更新为已领取（正常情况下不会发生，因为没领取则记录存在，但claimed=0）
            $conn->query("UPDATE daily_rewards SET claimed = 1 WHERE uid = $login_uid AND date = '$today'");
            // 发放奖励
            $rewardToken = 5;
            $extraToken = 0;
            $extraStar = 0;
            if ($colorLevel === 'green') $extraToken = 3;
            elseif ($colorLevel === 'orange') $extraToken = 5;
            elseif ($colorLevel === 'red') $extraStar = 1;
            $totalToken = $rewardToken + $extraToken;
            // 更新 token
            $conn->query("UPDATE user_token SET token_num = token_num + $totalToken WHERE uid = $login_uid");
            if ($conn->affected_rows == 0) {
                $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($login_uid, $totalToken)");
            }
            if ($extraStar > 0) {
                $conn->query("UPDATE users SET star = star + $extraStar WHERE uid = $login_uid");
            }
            $rewardMsg = "🎉 每日奖励领取成功！获得 {$totalToken} Token" . ($extraStar > 0 ? " 和 {$extraStar} Star" : "") . "。";
        }
    } else {
        // 首次领取，插入记录并发放
        $conn->query("INSERT INTO daily_rewards (uid, date, claimed) VALUES ($login_uid, '$today', 1)");
        $rewardToken = 5;
        $extraToken = 0;
        $extraStar = 0;
        if ($colorLevel === 'green') $extraToken = 3;
        elseif ($colorLevel === 'orange') $extraToken = 5;
        elseif ($colorLevel === 'red') $extraStar = 1;
        $totalToken = $rewardToken + $extraToken;
        $conn->query("UPDATE user_token SET token_num = token_num + $totalToken WHERE uid = $login_uid");
        if ($conn->affected_rows == 0) {
            $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($login_uid, $totalToken)");
        }
        if ($extraStar > 0) {
            $conn->query("UPDATE users SET star = star + $extraStar WHERE uid = $login_uid");
        }
        $rewardMsg = "🎉 每日奖励领取成功！获得 {$totalToken} Token" . ($extraStar > 0 ? " 和 {$extraStar} Star" : "") . "。";
    }
}

// ========== 处理任务选择 ==========
$msg = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_tasks'])) {
    $selected = isset($_POST['tasks']) ? (array)$_POST['tasks'] : [];
    $selected = array_map('intval', $selected);
    $selected = array_unique($selected);
    if (count($selected) !== 3) {
        $error = "请选择正好 3 个任务（已选 " . count($selected) . " 个）。";
    } else {
        // 检查今天是否已选择过
        $check = $conn->query("SELECT id FROM user_daily_tasks WHERE uid = $login_uid AND date = '$today' LIMIT 1");
        if ($check->num_rows > 0) {
            $error = "您今天已选择过任务，不能重复选择。";
        } else {
            $success = true;
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("INSERT INTO user_daily_tasks (uid, date, task_id) VALUES (?, ?, ?)");
                foreach ($selected as $tid) {
                    if (!isset($taskDefs[$tid])) continue;
                    $stmt->bind_param("isi", $login_uid, $today, $tid);
                    $stmt->execute();
                }
                $stmt->close();
                $conn->commit();
                $msg = "任务选择成功！今天加油完成吧！";
            } catch (Exception $e) {
                $conn->rollback();
                $error = "保存失败：" . $e->getMessage();
            }
        }
    }
}

// ========== 获取今日任务（已选择的） ==========
$myTasks = [];
$selectedTaskIds = [];
$res = $conn->query("SELECT task_id, rewarded FROM user_daily_tasks WHERE uid = $login_uid AND date = '$today'");
while ($row = $res->fetch_assoc()) {
    $tid = (int)$row['task_id'];
    if (isset($taskDefs[$tid])) {
        $myTasks[$tid] = $taskDefs[$tid];
        $myTasks[$tid]['rewarded'] = (int)$row['rewarded'];
        $selectedTaskIds[] = $tid;
    }
}

// ========== 检查进度并自动发放奖励 ==========
$needUpdate = false;
foreach ($myTasks as $tid => &$task) {
    $progress = $task['check']($login_uid, $conn);
    $task['progress'] = $progress;
    $task['completed'] = ($progress >= $task['target']);
    if ($task['completed'] && !$task['rewarded']) {
        $reward = $task['reward'];
        if (isset($reward['token'])) {
            $conn->query("UPDATE user_token SET token_num = token_num + {$reward['token']} WHERE uid = $login_uid");
            if ($conn->affected_rows == 0) {
                $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($login_uid, {$reward['token']})");
            }
        }
        if (isset($reward['star'])) {
            $conn->query("UPDATE users SET star = star + {$reward['star']} WHERE uid = $login_uid");
        }
        $conn->query("UPDATE user_daily_tasks SET rewarded = 1 WHERE uid = $login_uid AND date = '$today' AND task_id = $tid");
        $task['rewarded'] = 1;
        $msg = "🎉 任务「{$task['name']}」已完成，奖励已发放！";
    }
}
unset($task);

// ========== 查询今日是否已领每日奖励 ==========
$rewardClaimed = false;
$checkReward = $conn->query("SELECT claimed FROM daily_rewards WHERE uid = $login_uid AND date = '$today'");
if ($checkReward->num_rows > 0) {
    $rewardClaimed = (int)$checkReward->fetch_assoc()['claimed'];
}

// ========== 未读消息数 ==========
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>每日任务 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2{font-size:18px;font-weight:600;margin-bottom:16px;}
        .alert{padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:16px;font-size:14px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;}
        .alert-error{background:#fce4ec;color:#c62828;border:1px solid #ef9a9a;}
        .btn{padding:9px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);text-decoration:none;display:inline-block;}
        .btn:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);}
        .btn-outline{background:transparent;color:var(--accent);border:1.5px solid var(--accent);}
        .btn-outline:hover{background:var(--accent);color:#fff;}
        .task-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-top:16px;}
        .task-card{background:var(--card-bg);border:1.5px solid var(--border-light);border-radius:var(--radius-sm);padding:18px 20px;transition:var(--transition);}
        .task-card:hover{border-color:var(--accent);box-shadow:0 2px 8px rgba(0,0,0,0.04);}
        .task-card label{display:flex;align-items:flex-start;gap:10px;cursor:pointer;font-size:14px;}
        .task-card input[type="checkbox"]{margin-top:3px;width:18px;height:18px;accent-color:var(--accent);}
        .task-card .task-name{font-weight:600;font-size:15px;color:var(--text);}
        .task-card .task-desc{color:var(--text-secondary);font-size:13px;margin-top:4px;}
        .task-card .task-reward{font-size:13px;color:var(--accent);font-weight:500;margin-top:4px;}
        .task-progress{display:flex;align-items:center;gap:12px;margin-top:8px;}
        .task-progress .progress-bar{flex:1;height:6px;background:var(--border-light);border-radius:4px;overflow:hidden;}
        .task-progress .progress-bar .fill{height:100%;background:var(--accent);border-radius:4px;transition:width 0.3s ease;}
        .task-progress .progress-text{font-size:13px;color:var(--text-secondary);white-space:nowrap;}
        .task-status{font-size:13px;font-weight:600;margin-top:6px;}
        .task-status .done{color:#2e7d32;}
        .task-status .undone{color:var(--danger);}
        .task-status .rewarded{color:#e67e22;}
        .task-select-note{color:var(--text-muted);font-size:14px;margin-top:8px;}
        .reward-box{background:var(--accent-light);border:1.5px solid var(--accent);border-radius:var(--radius-sm);padding:16px 20px;margin-bottom:20px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px;}
        .reward-box .reward-info{font-size:14px;color:var(--text);}
        .reward-box .reward-info strong{color:var(--accent);font-size:16px;}
        .reward-box .reward-extra{font-size:13px;color:var(--text-secondary);}
        .reward-box .btn{background:var(--accent);color:#fff;}
        .reward-box .btn:disabled{background:#bfbab0;cursor:not-allowed;}
        @media(max-width:768px){.main{flex-direction:column;padding:0 12px;}.sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}.sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}.sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}.task-grid{grid-template-columns:1fr;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <!-- 每日奖励 -->
        <div class="card">
            <h2>🎁 每日奖励</h2>
            <?php if ($rewardMsg): ?>
                <div class="alert alert-success"><?= safeContent($rewardMsg) ?></div>
            <?php endif; ?>
            <?php if ($rewardError): ?>
                <div class="alert alert-error"><?= safeContent($rewardError) ?></div>
            <?php endif; ?>
            <div class="reward-box">
                <div>
                    <div class="reward-info">
                        <strong>+5 Token</strong> 每日基础奖励
                        <?php if ($colorLevel === 'green'): ?>
                            <span class="reward-extra">+ 绿名额外 <strong>3 Token</strong></span>
                        <?php elseif ($colorLevel === 'orange'): ?>
                            <span class="reward-extra">+ 橙名额外 <strong>5 Token</strong></span>
                        <?php elseif ($colorLevel === 'red'): ?>
                            <span class="reward-extra">+ 红名额外 <strong>1 Star</strong></span>
                        <?php endif; ?>
                    </div>
                    <div class="reward-extra" style="margin-top:4px;">当前等级：<strong><?= ucfirst($colorLevel) ?></strong></div>
                </div>
                <div>
                    <?php if ($rewardClaimed): ?>
                        <button class="btn" disabled>已领取</button>
                    <?php else: ?>
                        <a href="?claim_reward=1" class="btn">领取奖励</a>
                    <?php endif; ?>
                    <a href="https://lmtoj.cn/store" class="btn btn-outline" style="margin-left:8px;">前往兑换</a>
                </div>
            </div>
        </div>

        <!-- 每日任务 -->
        <div class="card">
            <h2>📋 每日任务</h2>
            <?php if ($msg): ?>
                <div class="alert alert-success"><?= safeContent($msg) ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error"><?= safeContent($error) ?></div>
            <?php endif; ?>

            <?php if (empty($myTasks)): ?>
                <!-- 未选择任务 -->
                <p style="color:var(--text-secondary);margin-bottom:16px;">每天从以下任务中选择 3 个完成，获得丰厚奖励！</p>
                <form method="post">
                    <div class="task-grid">
                        <?php foreach ($taskDefs as $tid => $task): ?>
                            <div class="task-card">
                                <label>
                                    <input type="checkbox" name="tasks[]" value="<?= $tid ?>">
                                    <div>
                                        <div class="task-name"><?= safeContent($task['name']) ?></div>
                                        <div class="task-desc"><?= safeContent($task['desc']) ?></div>
                                        <div class="task-reward">
                                            <?php
                                            $rewardParts = [];
                                            if (isset($task['reward']['token'])) $rewardParts[] = $task['reward']['token'] . ' Token';
                                            if (isset($task['reward']['star'])) $rewardParts[] = $task['reward']['star'] . ' Star';
                                            echo '+ ' . implode(' + ', $rewardParts);
                                            ?>
                                        </div>
                                    </div>
                                </label>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <p class="task-select-note">请选择正好 3 个任务（已选 <span id="selectedCount">0</span> 个）</p>
                    <button type="submit" name="select_tasks" class="btn" style="margin-top:16px;">确认选择</button>
                </form>
                <script>
                    document.querySelectorAll('input[name="tasks[]"]').forEach(cb => {
                        cb.addEventListener('change', function() {
                            const checked = document.querySelectorAll('input[name="tasks[]"]:checked').length;
                            document.getElementById('selectedCount').textContent = checked;
                        });
                    });
                </script>
            <?php else: ?>
                <!-- 已选择任务，显示进度 -->
                <p style="color:var(--text-secondary);margin-bottom:16px;">今日任务（已选 <?= count($myTasks) ?> 个）：</p>
                <div class="task-grid">
                    <?php foreach ($myTasks as $tid => $task):
                        $progress = $task['progress'];
                        $target = $task['target'];
                        $pct = min(100, round(($progress / $target) * 100));
                        $completed = $task['completed'];
                        $rewarded = $task['rewarded'];
                        $statusClass = $completed ? ($rewarded ? 'rewarded' : 'done') : 'undone';
                        $statusText = $completed ? ($rewarded ? '✅ 已领奖' : '🎉 已完成') : '⏳ 进行中';
                    ?>
                        <div class="task-card" style="border-color:<?= $completed ? ($rewarded ? '#e67e22' : '#2e7d32') : 'var(--border-light)' ?>;">
                            <div>
                                <div class="task-name"><?= safeContent($task['name']) ?></div>
                                <div class="task-desc"><?= safeContent($task['desc']) ?></div>
                                <div class="task-reward">
                                    <?php
                                    $rewardParts = [];
                                    if (isset($task['reward']['token'])) $rewardParts[] = $task['reward']['token'] . ' Token';
                                    if (isset($task['reward']['star'])) $rewardParts[] = $task['reward']['star'] . ' Star';
                                    echo '+ ' . implode(' + ', $rewardParts);
                                    ?>
                                </div>
                                <div class="task-progress">
                                    <span style="font-size:13px;color:var(--text-secondary);"><?= $progress ?> / <?= $target ?></span>
                                    <div class="progress-bar"><div class="fill" style="width:<?= $pct ?>%;"></div></div>
                                    <span class="progress-text"><?= $pct ?>%</span>
                                </div>
                                <div class="task-status">
                                    <span class="<?= $statusClass ?>"><?= $statusText ?></span>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p style="color:var(--text-muted);font-size:13px;margin-top:16px;">任务进度自动更新，完成后奖励自动发放。</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>