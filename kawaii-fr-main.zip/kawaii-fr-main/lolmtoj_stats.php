<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, avatar, admin, sqadmin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$login_name = $userRow['name'] ?? '英雄';
$is_admin = ((int)($userRow['admin'] ?? 0) == 1 || (int)($userRow['sqadmin'] ?? 0) == 1);

// ===== 保留管理相关表（仅用于存储武将描述） =====
$conn->query("CREATE TABLE IF NOT EXISTS lolmtoj_cards (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ===== 管理员操作（仅保留更新武将描述） =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_action']) && $is_admin) {
    $action = $_POST['admin_action'];
    if ($action === 'update_general_desc') {
        $general_id = (int)$_POST['general_id'];
        $new_desc = trim($_POST['desc_content'] ?? '');
        // 关联数组：ID => 名称
        $general_names = [
            1 => 'Ydch',
            2 => '六面体',
            3 => 'Gary0',
            4 => 'FR',
            5 => 'Rabo',
            7 => 'zhoumurui',
            8 => 'HFF'
        ];
        if (isset($general_names[$general_id])) {
            $name = $general_names[$general_id];
            // 检查是否已存在记录
            $check = $conn->query("SELECT id FROM lolmtoj_cards WHERE name = '$name' LIMIT 1");
            if ($check->num_rows > 0) {
                // 更新
                $stmt = $conn->prepare("UPDATE lolmtoj_cards SET description = ? WHERE name = ?");
                $stmt->bind_param("ss", $new_desc, $name);
                $stmt->execute();
                $stmt->close();
            } else {
                // 插入（image_url 留空，只用描述）
                $stmt = $conn->prepare("INSERT INTO lolmtoj_cards (name, image_url, description) VALUES (?, '', ?)");
                $stmt->bind_param("ss", $name, $new_desc);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    header("Location: /lolmtoj/stats");
    exit;
}

$GENERALS_DEFAULT = [
    1 => ['name' => 'Ydch', 'avatar' => '/upload/lolmtoj/1.png', 'hp' => 4, 'skills' => ['激将', '仁德'], 'description' => '信心领袖，可转移标记并交换体力。'],
    2 => ['name' => '六面体', 'avatar' => '/upload/lolmtoj/2.png', 'hp' => 4, 'skills' => ['暴政'], 'description' => '判定暴政，黑牌则全员扣血。'],
    3 => ['name' => 'Gary0', 'avatar' => '/upload/lolmtoj/3.png', 'hp' => 2, 'skills' => ['瑞平', '制牌'], 'description' => '锐评标记，制牌翻面高爆发。'],
    4 => ['name' => 'FR', 'avatar' => '/upload/lolmtoj/4.png', 'hp' => 2, 'skills' => ['撒娇', '灌水'], 'description' => '卖萌撒娇，限定技可强行撒娇。'],
    5 => ['name' => 'Rabo', 'avatar' => '/upload/lolmtoj/5.png', 'hp' => 3, 'skills' => ['调教', '控制'], 'description' => '调教掌控，可控制 3HO 角色，使其听命于己。'],
    7 => ['name' => 'zhoumurui', 'avatar' => '/upload/lolmtoj/7.png', 'hp' => 3, 'skills' => ['待定'], 'description' => '新武将，等待设定。'],
    8 => ['name' => 'HFF', 'avatar' => '/upload/lolmtoj/6.png', 'hp' => 3, 'skills' => ['鉴权', '猫爪'], 'description' => '滚木。']
];

// ---- 从 lolmtoj_cards 读取自定义描述（覆盖默认） ----
$descOverrides = [];
$res = $conn->query("SELECT name, description FROM lolmtoj_cards WHERE name IN ('Ydch','六面体','Gary0','FR','Rabo','zhoumurui')");
while ($row = $res->fetch_assoc()) {
    $descOverrides[$row['name']] = $row['description'];
}
$GENERALS = [];
foreach ($GENERALS_DEFAULT as $id => $info) {
    $info['description'] = $descOverrides[$info['name']] ?? $info['description'];
    $GENERALS[$id] = $info;
}

// ---- 1. 武将胜率榜 ----
$queryGeneral = "
    SELECT 
        general_id,
        COUNT(*) AS total_games,
        SUM(is_winner) AS wins,
        SUM(kills) AS total_kills
    FROM lolmtoj_game_records
    GROUP BY general_id
";
$resultGen = $conn->query($queryGeneral);
$statsGeneral = [];
while ($row = $resultGen->fetch_assoc()) {
    $gid = (int)$row['general_id'];
    $total = (int)$row['total_games'];
    $wins  = (int)$row['wins'];
    $kills = (int)$row['total_kills'];
    $losses = $total - $wins;
    $rate = $total > 0 ? round($wins / $total * 100, 2) : 0;
    $statsGeneral[$gid] = compact('total', 'wins', 'losses', 'rate', 'kills');
}
$generalData = [];
foreach ($GENERALS as $gid => $info) {
    $s = $statsGeneral[$gid] ?? ['total'=>0,'wins'=>0,'losses'=>0,'rate'=>0,'kills'=>0];
    $generalData[] = [
        'id'     => $gid,
        'name'   => $info['name'],
        'avatar' => $info['avatar'],
        'hp'     => $info['hp'],
        'skills' => $info['skills'],
        'desc'   => $info['description'],
        'total'  => $s['total'],
        'wins'   => $s['wins'],
        'losses' => $s['losses'],
        'rate'   => $s['rate'],
        'kills'  => $s['kills']
    ];
}
usort($generalData, function($a, $b) {
    if ($b['rate'] != $a['rate']) return $b['rate'] <=> $a['rate'];
    return $b['kills'] <=> $a['kills'];
});

// ---- 2. 玩家胜率榜（竞赛排名） ----
$queryPlayer = "
    SELECT 
        u.uid,
        u.name,
        COUNT(r.id) AS total_games,
        SUM(r.is_winner) AS wins,
        SUM(r.kills) AS total_kills
    FROM lolmtoj_game_records r
    LEFT JOIN users u ON r.uid = u.uid
    GROUP BY r.uid
";
$resultPlayer = $conn->query($queryPlayer);
$playerRaw = [];
while ($row = $resultPlayer->fetch_assoc()) {
    $total = (int)$row['total_games'];
    $wins  = (int)$row['wins'];
    $kills = (int)$row['total_kills'];
    $losses = $total - $wins;
    $rate = $total > 0 ? round($wins / $total * 100, 2) : 0;
    $playerRaw[] = [
        'uid'   => $row['uid'],
        'name'  => $row['name'] ?? '未知玩家',
        'total' => $total,
        'wins'  => $wins,
        'losses'=> $losses,
        'rate'  => $rate,
        'kills' => $kills
    ];
}
usort($playerRaw, function($a, $b) {
    if ($b['rate'] != $a['rate']) return $b['rate'] <=> $a['rate'];
    return $b['kills'] <=> $a['kills'];
});
// 竞赛排名
$playerData = [];
$rank = 1;
$i = 0;
while ($i < count($playerRaw)) {
    $j = $i;
    $currentRate = $playerRaw[$i]['rate'];
    while ($j < count($playerRaw) && $playerRaw[$j]['rate'] == $currentRate) $j++;
    for ($k = $i; $k < $j; $k++) {
        $playerRaw[$k]['rank'] = $rank;
    }
    $rank += ($j - $i);
    $i = $j;
}
$playerData = $playerRaw;

// ---- 3. 不再使用自定义卡牌功能 ----

// ===== 调试模式 =====
if (isset($_GET['debug']) && $_GET['debug'] == 1) {
    header('Content-Type: application/json');
    echo json_encode([
        'general' => $generalData,
        'player'  => $playerData,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>lolmtoj 数据榜 · 大厅</title>
    <style>
        /* ===== 全局样式 ===== */
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --radius: 12px;
            --shadow: 0 4px 12px rgba(0,0,0,0.06);
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .user-info { display:flex; align-items:center; gap:8px; font-size:14px; }
        .user-info a { color:#e0dbd3; text-decoration:none; padding:6px 12px; }
        .main { max-width:1320px; margin:20px auto 40px; display:flex; gap:18px; padding:0 14px; }
        .sidebar {
            background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
            width:fit-content; min-width:120px; overflow:hidden; position:sticky; top:80px;
            flex-shrink:0; height:fit-content;
        }
        .sidebar a {
            display:block; padding:13px 22px; text-align:center; color:var(--text);
            text-decoration:none; font-size:14px; font-weight:500;
            border-left:3px solid transparent;
        }
        .sidebar a:hover, .sidebar a.active {
            background:#f5f2ed; border-left-color:var(--accent); color:var(--accent);
        }
        .content { flex:1; min-width:0; }
        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:22px;
            margin-bottom:18px; box-shadow:var(--shadow);
        }
        .card-header {
            display:flex; justify-content:space-between; align-items:center;
            margin-bottom:16px;
        }
        .card-header h2 { font-size:20px; }
        .tabs {
            display:flex; gap:8px; margin-bottom:20px; border-bottom:2px solid var(--border);
            padding-bottom:8px; flex-wrap:wrap;
        }
        .tab-btn {
            padding:8px 20px; background:transparent; border:none; font-size:15px;
            font-weight:500; color:var(--text-muted); cursor:pointer;
            border-radius:20px 20px 0 0; transition:0.2s;
        }
        .tab-btn.active {
            color:var(--accent); background:var(--bg); border-bottom:3px solid var(--accent);
        }
        .tab-btn:hover { color:var(--accent); }
        .tab-content { display:none; }
        .tab-content.active { display:block; }

        table { width:100%; border-collapse:collapse; font-size:14px; margin-top:8px; }
        th { background:#3d3a37; color:#f0ece6; padding:10px 12px; text-align:center; font-weight:500; }
        td { padding:9px 12px; text-align:center; border-bottom:1px solid #e6e1da; }
        tr:hover td { background:#f5f2ed; }
        .rate { font-weight:bold; color:#6b8a74; }
        .kills { color:#d4af37; }
        .rank-badge { display:inline-block; background:#eee; border-radius:12px; padding:0 10px; font-weight:bold; }

        .card-grid {
            display:grid; grid-template-columns:repeat(auto-fill, minmax(190px, 1fr)); gap:16px;
        }
        .card-item {
            background:#fcfcfc; border:1px solid var(--border); border-radius:10px;
            padding:12px; text-align:center; transition:0.2s;
        }
        .card-item:hover { box-shadow:var(--shadow); transform:translateY(-2px); }
        .card-item img { width:100%; max-height:200px; object-fit:contain; border-radius:6px; background:#fff; }
        .card-item .name { font-weight:600; font-size:16px; margin-top:8px; }
        .card-item .info { font-size:13px; color:var(--text-muted); margin-top:4px; }
        .card-item .desc { font-size:13px; color:#555; margin-top:6px; background:#f0ede8; padding:6px; border-radius:4px; }

        .admin-form { background:#f8f6f4; padding:16px; border-radius:8px; margin-bottom:16px; }
        .admin-form textarea { width:100%; padding:8px; margin-bottom:8px; border:1px solid var(--border); border-radius:4px; }
        .admin-form button { background:var(--accent); color:#fff; border:none; padding:8px 16px; border-radius:4px; cursor:pointer; }
        .admin-form button:hover { background:var(--accent-hover); }

        .btn { padding:6px 14px; background:var(--accent); color:#fff; border:none; border-radius:18px; cursor:pointer; font-size:13px; }
        .empty-msg { text-align:center; color:#a0988e; padding:30px 0; }

        @media (max-width: 768px) {
            .main { flex-direction:column; }
            .sidebar { position:static; width:100%; display:flex; flex-wrap:wrap; justify-content:center; }
            .sidebar a { padding:10px 16px; border-left:none; border-bottom:3px solid transparent; }
            .sidebar a.active { border-bottom-color:var(--accent); }
        }
    </style>
</head>
<body>

<?php 
if (file_exists('navbar.php')) {
    include 'navbar.php';
} else {
?>
<div class="navbar">
    <h1><a href="/">lolmtoj 对战</a></h1>
    <div class="user-info">
        <span>👤 <?=htmlspecialchars($login_name)?></span>
        <a href="/">返回首页</a>
    </div>
</div>
<?php } ?>

<div class="main">
    <div class="sidebar">
        <a href="/">主页</a>
        <a href="/lolmtoj">lolmtoj 对战</a>
        <a href="/lolmtoj/stats" class="active">🏆 数据榜</a>
    </div>

    <div class="content">
        <div class="card">
            <div class="card-header">
                <h2>📊 lolmtoj 综合大厅</h2>
                <span style="font-size:13px; color:var(--text-muted);">数据实时更新</span>
            </div>

            <div class="tabs">
                <button class="tab-btn active" data-tab="general">⚔️ 武将胜率</button>
                <button class="tab-btn" data-tab="player">🏅 玩家胜率</button>
                <button class="tab-btn" data-tab="gallery">🖼️ 角色图鉴</button>
                <?php if ($is_admin): ?>
                <button class="tab-btn" data-tab="admin">🔧 管理</button>
                <?php endif; ?>
            </div>

            <!-- 武将胜率 -->
            <div id="tab-general" class="tab-content active">
                <?php
                $hasGeneral = false;
                foreach ($generalData as $d) if ($d['total'] > 0) { $hasGeneral = true; break; }
                if (!$hasGeneral): ?>
                    <div class="empty-msg">暂无对战记录</div>
                <?php else: ?>
                    <table>
                        <thead><tr>
                            <th>排名</th><th>武将</th><th>出场</th><th>胜场</th><th>负场</th><th>胜率</th><th>总击杀</th>
                        </tr></thead>
                        <tbody>
                            <?php $rank=1; foreach ($generalData as $d): if ($d['total'] == 0) continue; ?>
                            <tr>
                                <td><?= $rank++ ?></td>
                                <td>
                                    <img src="<?= $d['avatar'] ?>" style="width:32px;height:32px;border-radius:50%;vertical-align:middle;margin-right:6px;">
                                    <strong><?= htmlspecialchars($d['name']) ?></strong>
                                </td>
                                <td><?= $d['total'] ?></td>
                                <td><?= $d['wins'] ?></td>
                                <td><?= $d['losses'] ?></td>
                                <td class="rate"><?= $d['rate'] ?>%</td>
                                <td class="kills"><?= $d['kills'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- 玩家胜率 -->
            <div id="tab-player" class="tab-content">
                <?php if (empty($playerData)): ?>
                    <div class="empty-msg">暂无对战记录</div>
                <?php else: ?>
                    <table>
                        <thead><tr>
                            <th>排名</th><th>玩家</th><th>胜率</th><th>总场次</th><th>胜场</th><th>负场</th><th>总击杀</th>
                        </tr></thead>
                        <tbody>
                            <?php foreach ($playerData as $p): ?>
                            <tr>
                                <td><span class="rank-badge">#<?= $p['rank'] ?></span></td>
                                <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                                <td class="rate"><?= $p['rate'] ?>%</td>
                                <td><?= $p['total'] ?></td>
                                <td><?= $p['wins'] ?></td>
                                <td><?= $p['losses'] ?></td>
                                <td class="kills"><?= $p['kills'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- 角色图鉴 -->
            <div id="tab-gallery" class="tab-content">
                <h3 style="margin-bottom:10px;">🎴 官方武将</h3>
                <div class="card-grid">
                    <?php foreach ($GENERALS as $gid => $info): ?>
                    <div class="card-item">
                        <img src="<?= $info['avatar'] ?>" alt="<?= $info['name'] ?>">
                        <div class="name"><?= htmlspecialchars($info['name']) ?></div>
                        <div class="info">❤️ <?= $info['hp'] ?> 体力 | 技能: <?= implode('、', $info['skills']) ?></div>
                        <div class="desc">📝 <?= nl2br(htmlspecialchars($info['description'] ?? '暂无介绍')) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- 管理面板（仅修改备注） -->
            <?php if ($is_admin): ?>
            <div id="tab-admin" class="tab-content">
                <div class="admin-form">
                    <h4>✏️ 编辑武将备注（描述）</h4>
                    <?php foreach ($GENERALS as $gid => $info): ?>
                    <form method="POST" style="border-bottom:1px solid #ddd; padding-bottom:10px; margin-bottom:10px;">
                        <input type="hidden" name="admin_action" value="update_general_desc">
                        <input type="hidden" name="general_id" value="<?= $gid ?>">
                        <strong><?= $info['name'] ?>：</strong>
                        <textarea name="desc_content" rows="2" style="width:80%; display:inline-block; margin-left:10px;"><?= htmlspecialchars($info['description']) ?></textarea>
                        <button type="submit" style="display:inline-block; margin-left:10px;">保存</button>
                    </form>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div style="text-align:center; margin-top:24px;">
                <a href="/lolmtoj" class="btn" style="background:var(--accent);">← 返回对战大厅</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Tab 切换
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            const tabId = this.dataset.tab;
            document.getElementById('tab-' + tabId).classList.add('active');
        });
    });
    // URL hash 打开对应选项卡
    if (window.location.hash) {
        const hash = window.location.hash.replace('#', '');
        const btn = document.querySelector(`.tab-btn[data-tab="${hash}"]`);
        if (btn) btn.click();
    }
</script>

<?php 
if (file_exists('footer.php')) {
    include 'footer.php';
}
?>
</body>
</html>