<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;

if ($uid <= 0) {
    echo json_encode(['error' => '无效用户']);
    exit;
}

$pending = $conn->query("SELECT * FROM user_bind WHERE uid = {$uid} AND verified = 0 ORDER BY created_at DESC LIMIT 1")->fetch_assoc();

if (!$pending) {
    echo json_encode(['verified' => false, 'error' => '无待验证绑定']);
    exit;
}

$created = strtotime($pending['created_at']);
$now = time();
if ($now - $created > 600) {
    $conn->query("DELETE FROM user_bind WHERE uid = {$uid} AND verified = 0");
    echo json_encode(['verified' => false, 'error' => '验证超时']);
    exit;
}

$conn->query("UPDATE user_bind SET check_count = check_count + 1, checked_at = NOW() WHERE uid = {$uid} AND verified = 0");

$verified = false;

if ($pending['bind_type'] === 'luogu') {
    $luogu_uid = $pending['bind_value'];
    $verifyCode = $pending['verify_code'];
    
    $url = "https://www.luogu.me/user/{$luogu_uid}";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    
    $html = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode === 200 && $html && strpos($html, $verifyCode) !== false) {
        $verified = true;
    }
}

if ($verified) {
    $conn->query("UPDATE user_bind SET verified = 1 WHERE uid = {$uid} AND verified = 0");
    echo json_encode(['verified' => true, 'message' => '绑定成功']);
} else {
    echo json_encode(['verified' => false, 'message' => '尚未检测到验证码']);
}