<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 自动检查并添加缺失的字段（比赛表） ----------
$missingColumns = [];
$result = $conn->query("DESCRIBE contest");
if ($result) {
    $existingColumns = [];
    while ($row = $result->fetch_assoc()) {
        $existingColumns[] = $row['Field'];
    }
    
    if (!in_array('description', $existingColumns)) {
        $missingColumns[] = "ADD COLUMN description TEXT DEFAULT NULL COMMENT '比赛简介（支持Markdown）'";
    }
    if (!in_array('format', $existingColumns)) {
        $missingColumns[] = "ADD COLUMN format ENUM('IOI','OI','ICPC') DEFAULT 'IOI' COMMENT '赛制'";
    }
    if (!in_array('category', $existingColumns)) {
        $missingColumns[] = "ADD COLUMN category ENUM('公开赛','官方公开赛','整活赛') DEFAULT '公开赛' COMMENT '比赛类别'";
    }
    
    if (!empty($missingColumns)) {
        $sql = "ALTER TABLE contest " . implode(', ', $missingColumns);
        try {
            if (!$conn->query($sql)) {
                throw new Exception("执行 ALTER 失败: " . $conn->error);
            }
            error_log("contest 表已自动添加缺失字段: " . implode(', ', $missingColumns));
        } catch (Exception $e) {
            die("<h3>数据库表结构需要更新</h3>
                 <p>当前数据库用户没有 <code>ALTER</code> 权限，请手动执行以下 SQL：</p>
                 <pre style='background:#f4f4f4;padding:10px;border-radius:4px;'>" 
                 . htmlspecialchars(str_replace('ADD COLUMN ', 'ALTER TABLE contest ADD COLUMN ', implode(";\n", $missingColumns)) . ';') 
                 . "</pre>
                 <p>错误详情：" . htmlspecialchars($e->getMessage()) . "</p>");
        }
    }
}

// ---------- 自动检查并创建 contest_problem 表（若不存在） ----------
$tableCheck = $conn->query("SHOW TABLES LIKE 'contest_problem'");
if ($tableCheck->num_rows == 0) {
    $createSql = "CREATE TABLE contest_problem (
        id INT AUTO_INCREMENT PRIMARY KEY,
        contest_id INT NOT NULL,
        problem_id INT NOT NULL,
        display_order INT DEFAULT 0,
        UNIQUE KEY contest_problem_unique (contest_id, problem_id),
        INDEX idx_contest (contest_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    if (!$conn->query($createSql)) {
        die("创建 contest_problem 表失败：" . $conn->error);
    }
}

// ---------- 检查登录 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$adminStmt = $conn->prepare("SELECT admin, conadmin FROM users WHERE uid = ? LIMIT 1");
$adminStmt->bind_param("i", $login_uid);
$adminStmt->execute();
$adminRes = $adminStmt->get_result();
$conadmin = 0;
if ($adminRes && $adminRes->num_rows > 0) {
    $conadmin = (int)$adminRes->fetch_assoc()['conadmin'];
}
$adminStmt->close();
if ($conadmin !== 1) {
    die("无权访问");
}

// 未读消息数
$msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
$msgStmt->bind_param("i", $login_uid);
$msgStmt->execute();
$msgRes = $msgStmt->get_result();
$unreadCount = 0;
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}
$msgStmt->close();

// ---------- 处理 AJAX 请求：获取题目名称 ----------
if (isset($_GET['get_problem_name']) && is_numeric($_GET['get_problem_name'])) {
    $pid = (int)$_GET['get_problem_name'];
    $stmt = $conn->prepare("SELECT name FROM problem_desc WHERE id = ? LIMIT 1");
    $stmt->bind_param("i", $pid);
    $stmt->execute();
    $res = $stmt->get_result();
    $name = '';
    if ($res && $res->num_rows > 0) {
        $name = $res->fetch_assoc()['name'];
    }
    $stmt->close();
    header('Content-Type: application/json');
    echo json_encode(['name' => $name]);
    exit;
}

// ---------- 处理操作 ----------
$action = $_GET['action'] ?? 'list';
$edit_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// ---------- 处理添加题目 ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_problem'])) {
    $contest_id = (int)$_POST['contest_id'];
    $problem_id = (int)$_POST['problem_id'];
    if ($contest_id > 0 && $problem_id > 0) {
        // 检查题目是否存在
        $checkStmt = $conn->prepare("SELECT id FROM problem_desc WHERE id = ?");
        $checkStmt->bind_param("i", $problem_id);
        $checkStmt->execute();
        $checkRes = $checkStmt->get_result();
        if ($checkRes->num_rows > 0) {
            // 获取当前最大 display_order
            $orderStmt = $conn->prepare("SELECT MAX(display_order) AS max_order FROM contest_problem WHERE contest_id = ?");
            $orderStmt->bind_param("i", $contest_id);
            $orderStmt->execute();
            $orderRes = $orderStmt->get_result();
            $maxOrder = 0;
            if ($orderRes && $orderRes->num_rows > 0) {
                $maxOrder = (int)$orderRes->fetch_assoc()['max_order'];
            }
            $orderStmt->close();
            $newOrder = $maxOrder + 1;
            // 插入关联
            $insStmt = $conn->prepare("INSERT INTO contest_problem (contest_id, problem_id, display_order) VALUES (?, ?, ?)");
            $insStmt->bind_param("iii", $contest_id, $problem_id, $newOrder);
            $insStmt->execute();
            $insStmt->close();
        }
        $checkStmt->close();
    }
}

// ---------- 处理删除题目 ----------
if (isset($_GET['remove_problem']) && is_numeric($_GET['remove_problem']) && isset($_GET['contest_id'])) {
    $cp_id = (int)$_GET['remove_problem'];
    $contest_id = (int)$_GET['contest_id'];
    if ($cp_id > 0 && $contest_id > 0) {
        $delStmt = $conn->prepare("DELETE FROM contest_problem WHERE id = ? AND contest_id = ?");
        $delStmt->bind_param("ii", $cp_id, $contest_id);
        $delStmt->execute();
        $delStmt->close();
    }
}

// ---------- 添加 / 更新比赛信息 ----------
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_contest'])) {
    $name = trim($_POST['name'] ?? '');
    $creator = (int)($_POST['creator'] ?? 0);
    $start_time = $_POST['start_time'] ?? null;
    $end_time = $_POST['end_time'] ?? null;
    $description = trim($_POST['description'] ?? '');
    $format = $_POST['format'] ?? 'IOI';
    $category = $_POST['category'] ?? '公开赛';
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

    // 基本验证
    if (empty($name) || $creator <= 0) {
        $error = "比赛名称和举办者不能为空";
    } elseif (empty($start_time) || empty($end_time)) {
        $error = "开始时间和结束时间都必须填写";
    } elseif (strtotime($start_time) >= strtotime($end_time)) {
        $error = "开始时间必须早于结束时间";
    } elseif (!in_array($format, ['IOI', 'OI', 'ICPC'])) {
        $error = "赛制无效";
    } elseif (!in_array($category, ['公开赛', '官方公开赛', '整活赛'])) {
        $error = "比赛类别无效";
    } else {
        if ($id > 0) {
            $sql = "UPDATE contest SET 
                        name = ?,
                        creator = ?,
                        start_time = ?,
                        end_time = ?,
                        description = ?,
                        format = ?,
                        category = ?
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sisssssi", $name, $creator, $start_time, $end_time, $description, $format, $category, $id);
        } else {
            $sql = "INSERT INTO contest (name, creator, start_time, end_time, description, format, category) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sisssss", $name, $creator, $start_time, $end_time, $description, $format, $category);
        }
        if ($stmt->execute()) {
            $stmt->close();
        } else {
            $error = "数据库操作失败：" . $stmt->error;
            $stmt->close();
        }
    }
}

// 获取所有用户（用于搜索选择器）
$users = [];
$userRes = $conn->query("SELECT uid, name FROM users ORDER BY name");
if ($userRes) {
    while ($row = $userRes->fetch_assoc()) {
        $users[] = $row;
    }
}

// 获取比赛列表（关联用户名）
$contestList = $conn->query("SELECT c.*, u.name AS creator_name FROM contest c LEFT JOIN users u ON c.creator = u.uid ORDER BY c.id DESC");

// 如果是编辑，获取数据（使用预处理）
$editData = null;
if ($action === 'edit' && $edit_id > 0) {
    $editStmt = $conn->prepare("SELECT * FROM contest WHERE id = ?");
    $editStmt->bind_param("i", $edit_id);
    $editStmt->execute();
    $res = $editStmt->get_result();
    if ($res && $res->num_rows > 0) {
        $editData = $res->fetch_assoc();
    }
    $editStmt->close();
}

// 当前选中举办者的姓名
$selectedCreatorName = '';
$selectedCreatorUid = 0;
if ($editData && $editData['creator'] > 0) {
    $selectedCreatorUid = $editData['creator'];
    foreach ($users as $u) {
        if ($u['uid'] == $selectedCreatorUid) {
            $selectedCreatorName = $u['name'];
            break;
        }
    }
}

// ---------- 获取该比赛已编排的题目列表 ----------
$contestProblems = [];
if ($edit_id > 0) {
    $sqlProblems = "SELECT cp.id AS cp_id, cp.problem_id, p.name 
                    FROM contest_problem cp
                    LEFT JOIN problem_desc p ON cp.problem_id = p.id
                    WHERE cp.contest_id = ?
                    ORDER BY cp.display_order ASC";
    $stmt = $conn->prepare($sqlProblems);
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $contestProblems[] = $row;
    }
    $stmt->close();
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>管理比赛 - lmtOJ</title>
    <style>
        /* ---------- 基础样式（同原版） ---------- */
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: var(--bg);
            font-family: var(--font);
            color: var(--text);
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        .navbar {
            background: var(--nav-bg);
            height: 54px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            color: var(--nav-text);
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 {
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 0.4px;
            color: #f0ece6;
        }
        .bell-wrap {
            position: relative;
            font-size: 20px;
            cursor: pointer;
            margin-right: 20px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
            user-select: none;
        }
        .bell-wrap:hover { background: rgba(255,255,255,0.08); }
        .red-dot {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 9px;
            height: 9px;
            background: #f55353;
            border-radius: 50%;
            border: 1.5px solid #3d3a37;
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%, 100% { box-shadow: 0 0 0 0 rgba(245,83,83,0.5); }
            50% { box-shadow: 0 0 0 6px rgba(245,83,83,0); }
        }
        .user-info { display: flex; align-items: center; gap: 6px; }
        .user-info a {
            color: #e0dbd3;
            text-decoration: none;
            font-size: 13.5px;
            padding: 7px 13px;
            border-radius: 20px;
            transition: var(--transition);
            white-space: nowrap;
            font-weight: 500;
        }
        .user-info a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .user-info a.admin-link { color: #f5d76e; font-weight: 600; }

        .main {
            max-width: 1100px;
            margin: 28px auto 40px;
            display: flex;
            gap: 22px;
            padding: 0 20px;
            align-items: flex-start;
        }
        .sidebar {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            width: fit-content;
            min-width: 110px;
            overflow: hidden;
            position: sticky;
            top: 80px;
            flex-shrink: 0;
        }
        .sidebar a {
            display: block;
            padding: 13px 22px;
            text-align: center;
            background: var(--card-bg);
            color: var(--text);
            text-decoration: none;
            font-size: 14.5px;
            font-weight: 500;
            white-space: nowrap;
            transition: var(--transition);
            border-left: 3px solid transparent;
            letter-spacing: 0.3px;
        }
        .sidebar a:hover {
            background: #f5f2ed;
            border-left-color: var(--accent);
            color: var(--accent);
        }
        .sidebar a:first-child { border-radius: var(--radius) var(--radius) 0 0; }
        .sidebar a:last-child { border-radius: 0 0 var(--radius) var(--radius); }
        .sidebar a.active {
            border-left-color: var(--accent);
            background: #f5f2ed;
            color: var(--accent);
        }

        .content { flex: 1; min-width: 0; }

        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 26px 28px;
            box-shadow: var(--shadow);
            margin-bottom: 20px;
        }
        .card h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            letter-spacing: 0.3px;
        }
        .card h3 {
            font-size: 16px;
            font-weight: 600;
            margin-top: 14px;
            margin-bottom: 10px;
        }
        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        a { text-decoration: none; color: var(--accent); transition: var(--transition); }
        a:hover { color: var(--accent-hover); }

        .btn {
            display: inline-block;
            padding: 8px 18px;
            background: var(--accent);
            color: #fff;
            border-radius: 20px;
            font-size: 13.5px;
            font-weight: 500;
            transition: var(--transition);
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background: var(--accent-hover);
            box-shadow: 0 2px 8px rgba(107,138,116,0.25);
            color: #fff;
        }
        .btn-danger {
            background: #c0392b;
        }
        .btn-danger:hover {
            background: #a93226;
        }
        .btn-sm { padding: 4px 12px; font-size: 12px; }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: center;
            padding: 12px 10px;
            background: #f8f6f4;
            font-weight: 600;
            font-size: 13px;
            color: var(--text-secondary);
            border-bottom: 2px solid var(--border);
        }
        td {
            padding: 12px 10px;
            text-align: center;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }
        tr:hover td { background: #fafaf7; }

        .form-group {
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            flex-wrap: wrap;
        }
        .form-group label {
            display: inline-block;
            width: 100px;
            font-weight: 500;
            flex-shrink: 0;
        }
        .form-group input[type="text"],
        .form-group input[type="datetime-local"],
        .form-group textarea,
        .form-group select {
            padding: 6px 12px;
            border: 1px solid var(--border);
            border-radius: 4px;
            font-size: 14px;
            width: 250px;
            flex: 0 0 auto;
        }
        .form-group textarea {
            width: 100%;
            max-width: 500px;
            height: 100px;
            resize: vertical;
        }
        .form-actions {
            margin-top: 10px;
        }
        .form-actions .btn {
            margin-right: 10px;
        }
        .error {
            color: #c0392b;
            margin-bottom: 10px;
        }

        /* ---------- 搜索选择器样式 ---------- */
        .searchable-select {
            position: relative;
            width: 250px;
            flex: 0 0 auto;
        }
        .searchable-select input[type="text"] {
            width: 100%;
            padding: 6px 12px;
            border: 1px solid var(--border);
            border-radius: 4px;
            font-size: 14px;
            background: #fff;
            cursor: pointer;
        }
        .searchable-select input[type="text"]:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(107,138,116,0.2);
        }
        .searchable-select .options {
            position: absolute;
            top: calc(100% + 4px);
            left: 0;
            width: 100%;
            max-height: 200px;
            overflow-y: auto;
            background: #fff;
            border: 1px solid var(--border);
            border-radius: 4px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            list-style: none;
            padding: 4px 0;
            margin: 0;
            z-index: 999;
            display: none;
        }
        .searchable-select .options li {
            padding: 6px 12px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.15s;
        }
        .searchable-select .options li:hover {
            background: #f0f0f0;
        }
        .searchable-select .options li.active {
            background: var(--accent);
            color: #fff;
        }
        .searchable-select .options li.disabled {
            color: var(--text-muted);
            cursor: not-allowed;
        }
        .searchable-select .options li:not(:last-child) {
            border-bottom: 1px solid var(--border);
        }
        .searchable-select .options.show {
            display: block;
        }

        /* 移动端适配 */
        @media (max-width: 768px) {
            .main { flex-direction: column; padding: 0 12px; }
            .sidebar { width: 100%; position: static; display: flex; flex-wrap: wrap; }
            .sidebar a { flex: 1 1 auto; padding: 11px 10px; font-size: 13px; border-left: none; border-bottom: 2px solid transparent; }
            .sidebar a:hover { border-left-color: transparent; border-bottom-color: var(--accent); }
            .card { padding: 18px 14px; }
            .form-group { flex-direction: column; align-items: stretch; }
            .form-group label { width: auto; margin-bottom: 4px; }
            .form-group input[type="text"],
            .form-group input[type="datetime-local"],
            .form-group textarea,
            .form-group select,
            .searchable-select { width: 100%; max-width: 100%; }
        }
    </style>
</head>
<body>

<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <!-- 添加 / 编辑比赛表单 -->
        <div class="card">
            <h2><?= $editData ? '编辑比赛' : '添加比赛' ?></h2>
            <?php if (!empty($error)): ?>
                <div class="error"><?= safeContent($error) ?></div>
            <?php endif; ?>
            <form method="post" id="contestForm">
                <?php if ($editData): ?>
                    <input type="hidden" name="id" value="<?= $editData['id'] ?>">
                <?php endif; ?>
                <input type="hidden" name="save_contest" value="1">
                <div class="form-group">
                    <label>比赛名称</label>
                    <input type="text" name="name" value="<?= safeContent($editData['name'] ?? '') ?>" required>
                </div>
                <div class="form-group">
                    <label>举办者</label>
                    <div style="flex:1;min-width:150px;">
                        <div class="searchable-select" id="creatorSelect">
                            <input type="text" placeholder="搜索用户..." autocomplete="off" id="creatorSearchInput" value="<?= safeContent($selectedCreatorName) ?>">
                            <ul class="options" id="creatorOptions"></ul>
                        </div>
                        <input type="hidden" name="creator" id="creatorUidHidden" value="<?= $selectedCreatorUid ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>开始时间</label>
                    <input type="datetime-local" name="start_time" 
                           value="<?= isset($editData['start_time']) && $editData['start_time'] ? date('Y-m-d\TH:i', strtotime($editData['start_time'])) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label>结束时间</label>
                    <input type="datetime-local" name="end_time"
                           value="<?= isset($editData['end_time']) && $editData['end_time'] ? date('Y-m-d\TH:i', strtotime($editData['end_time'])) : '' ?>" required>
                </div>
                <div class="form-group">
                    <label>比赛简介</label>
                    <textarea name="description" placeholder="支持 Markdown 格式"><?= safeContent($editData['description'] ?? '') ?></textarea>
                </div>
                <div class="form-group">
                    <label>赛制</label>
                    <select name="format">
                        <option value="IOI" <?= (isset($editData['format']) && $editData['format'] == 'IOI') ? 'selected' : '' ?>>IOI</option>
                        <option value="OI" <?= (isset($editData['format']) && $editData['format'] == 'OI') ? 'selected' : '' ?>>OI</option>
                        <option value="ICPC" <?= (isset($editData['format']) && $editData['format'] == 'ICPC') ? 'selected' : '' ?>>ICPC</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>比赛类别</label>
                    <select name="category">
                        <option value="公开赛" <?= (isset($editData['category']) && $editData['category'] == '公开赛') ? 'selected' : '' ?>>公开赛</option>
                        <option value="官方公开赛" <?= (isset($editData['category']) && $editData['category'] == '官方公开赛') ? 'selected' : '' ?>>官方公开赛</option>
                        <option value="整活赛" <?= (isset($editData['category']) && $editData['category'] == '整活赛') ? 'selected' : '' ?>>整活赛</option>
                    </select>
                </div>
                <div class="form-actions">
                    <button type="submit" class="btn"><?= $editData ? '更新' : '添加' ?></button>
                    <a href="https://lmtoj.cn/contest" class="btn" style="background:var(--text-muted);">取消</a>
                </div>
            </form>
        </div>

        <!-- 题目编排（仅编辑时显示） -->
        <?php if ($editData): ?>
        <div class="card">
            <h2>题目编排</h2>
            <form method="post" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                <input type="hidden" name="contest_id" value="<?= $editData['id'] ?>">
                <input type="number" name="problem_id" id="problem_id_input" placeholder="输入题号" required style="padding:6px 12px; border:1px solid var(--border); border-radius:4px; width:150px;">
                <span id="problem_name_display" style="font-weight:500; color:var(--accent); min-width:100px;">自动识别</span>
                <button type="submit" name="add_problem" class="btn btn-sm">添加题目</button>
            </form>

            <?php if (count($contestProblems) > 0): ?>
            <h3 style="margin-top:20px;">已编排题目</h3>
            <table>
                <tr><th>显示顺序</th><th>题号</th><th>题目名称</th><th>操作</th></tr>
                <?php $order = 1; foreach ($contestProblems as $cp): ?>
                <tr>
                    <td><?= $order++ ?></td>
                    <td><?= $cp['problem_id'] ?></td>
                    <td><?= safeContent($cp['name'] ?? '（已删除题目）') ?></td>
                    <td>
                        <a href="https://lmtoj.cn/contest/edit?action=edit&id=<?= $editData['id'] ?>&remove_problem=<?= $cp['cp_id'] ?>&contest_id=<?= $editData['id'] ?>" 
                           class="btn btn-danger btn-sm" onclick="return confirm('确定从比赛中移除此题目吗？')">移除</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
            <?php else: ?>
            <p style="color:var(--text-muted); margin-top:12px;">该比赛尚未添加题目。</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
// ---------- 搜索选择器（举办者） ----------
const users = <?= json_encode($users) ?>;

const searchInput = document.getElementById('creatorSearchInput');
const optionsContainer = document.getElementById('creatorOptions');
const hiddenUid = document.getElementById('creatorUidHidden');

let selectedUid = parseInt(hiddenUid.value) || 0;
let isOpen = false;

function renderOptions(filter = '') {
    optionsContainer.innerHTML = '';
    const filtered = users.filter(u => 
        u.name.toLowerCase().includes(filter.toLowerCase())
    );
    if (filtered.length === 0) {
        const li = document.createElement('li');
        li.textContent = '未找到用户';
        li.className = 'disabled';
        optionsContainer.appendChild(li);
    } else {
        filtered.forEach(u => {
            const li = document.createElement('li');
            li.textContent = u.name;
            li.dataset.uid = u.uid;
            if (u.uid === selectedUid) li.classList.add('active');
            li.addEventListener('click', function() {
                selectUser(u.uid, u.name);
            });
            optionsContainer.appendChild(li);
        });
    }
}

function selectUser(uid, name) {
    selectedUid = uid;
    hiddenUid.value = uid;
    searchInput.value = name;
    closeOptions();
    document.querySelectorAll('#creatorOptions li').forEach(li => {
        li.classList.toggle('active', parseInt(li.dataset.uid) === uid);
    });
}

function openOptions() {
    if (!isOpen) {
        isOpen = true;
        optionsContainer.classList.add('show');
        renderOptions(searchInput.value);
    }
}

function closeOptions() {
    isOpen = false;
    optionsContainer.classList.remove('show');
}

searchInput.addEventListener('input', function() {
    if (!isOpen) openOptions();
    renderOptions(this.value);
});

searchInput.addEventListener('focus', function() {
    openOptions();
});

document.addEventListener('click', function(e) {
    const container = document.getElementById('creatorSelect');
    if (!container.contains(e.target)) closeOptions();
});

searchInput.addEventListener('keydown', function(e) {
    const items = optionsContainer.querySelectorAll('li:not(.disabled)');
    if (items.length === 0) return;
    let activeIndex = -1;
    items.forEach((li, idx) => {
        if (li.classList.contains('active')) activeIndex = idx;
    });
    if (e.key === 'ArrowDown') {
        e.preventDefault();
        const next = (activeIndex + 1) % items.length;
        items.forEach((li, idx) => li.classList.toggle('active', idx === next));
    } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        const prev = (activeIndex - 1 + items.length) % items.length;
        items.forEach((li, idx) => li.classList.toggle('active', idx === prev));
    } else if (e.key === 'Enter') {
        e.preventDefault();
        const activeLi = optionsContainer.querySelector('li.active:not(.disabled)');
        if (activeLi) {
            const uid = parseInt(activeLi.dataset.uid);
            const name = activeLi.textContent;
            selectUser(uid, name);
        }
    }
});

if (selectedUid > 0) {
    const found = users.find(u => u.uid === selectedUid);
    if (found) searchInput.value = found.name;
} else {
    searchInput.value = '';
}
closeOptions();

// ---------- AJAX 自动识别题目名称 ----------
const problemInput = document.getElementById('problem_id_input');
const nameDisplay = document.getElementById('problem_name_display');

if (problemInput && nameDisplay) {
    let timer = null;
    problemInput.addEventListener('input', function() {
        const val = this.value.trim();
        if (!val || isNaN(val) || parseInt(val) <= 0) {
            nameDisplay.textContent = '自动识别';
            return;
        }
        clearTimeout(timer);
        timer = setTimeout(() => {
            fetch('https://lmtoj.cn/contest/edit?get_problem_name=' + encodeURIComponent(val))
                .then(res => res.json())
                .then(data => {
                    if (data.name) {
                        nameDisplay.textContent = data.name;
                    } else {
                        nameDisplay.textContent = '❌ 未找到题目';
                    }
                })
                .catch(() => {
                    nameDisplay.textContent = '⚠️ 请求失败';
                });
        }, 300);
    });
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>