<?php
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/security.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------- 自动建表（主题偏好） ----------
if (!isset($conn) || !($conn instanceof mysqli)) {
    $conn = db();
}
$conn->query("CREATE TABLE IF NOT EXISTS user_preferences (
    uid INT PRIMARY KEY,
    theme VARCHAR(10) DEFAULT 'light',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 读取当前用户主题 ----------
$login_uid = isset($login_uid) ? (int) $login_uid : (int) ($_SESSION['uid'] ?? 0);
$cookieTheme = isset($_COOKIE['site_theme']) && in_array($_COOKIE['site_theme'], ['light', 'dark'])
    ? $_COOKIE['site_theme']
    : null;
$currentTheme = $cookieTheme ?? 'light';
if ($login_uid > 0) {
    $stmt = $conn->prepare("SELECT theme FROM user_preferences WHERE uid = ?");
    if ($stmt) {
        $stmt->bind_param('i', $login_uid);
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        if ($cookieTheme === null && $result && in_array($result['theme'], ['light', 'dark'])) {
            $currentTheme = $result['theme'];
        }
        $stmt->close();
    }
}

// ===== 采集数据所需变量 =====
$collect_uid = $login_uid;  
$collect_page = $_SERVER['REQUEST_URI'] ?? '/';
$collect_ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$collect_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// ---------- CSRF token ----------
$navbarCsrfToken = csrf_token();

// ---------- 通知/私信未读数 ----------
$unreadCount = 0;
$unreadMsgCount = 0;
$is_devadmin = isset($is_devadmin) ? (int) $is_devadmin : 0;
$is_sqadmin = isset($is_sqadmin) ? (int) $is_sqadmin : 0;

if ($login_uid > 0) {
    $noticeStmt = $conn->prepare("SELECT
        SUM(CASE WHEN content IS NULL OR content NOT IN ('message', 'group') THEN 1 ELSE 0 END) AS notice_count,
        SUM(CASE WHEN content IN ('message', 'group') THEN 1 ELSE 0 END) AS message_count
        FROM notice WHERE uid = ? AND is_read = 0");
    if ($noticeStmt) {
        $noticeStmt->bind_param('i', $login_uid);
        $noticeStmt->execute();
        $counts = $noticeStmt->get_result()->fetch_assoc() ?: [];
        $unreadCount = (int) ($counts['notice_count'] ?? 0);
        $unreadMsgCount = (int) ($counts['message_count'] ?? 0);
        $noticeStmt->close();
    }

    $adminStmt = $conn->prepare('SELECT admin,sqadmin,devadmin FROM users WHERE uid = ? LIMIT 1');
    if ($adminStmt) {
        $adminStmt->bind_param('i', $login_uid);
        $adminStmt->execute();
        $adminRow = $adminStmt->get_result()->fetch_assoc();
        $is_devadmin = (int) ($adminRow['devadmin'] ?? 0);
        $is_sqadmin = (int) ($adminRow['sqadmin'] ?? 0);
        $adminStmt->close();
    }
}

function navbarBadge(int $count): string
{
    return $count > 99 ? '99+' : (string) $count;
}

// ========== 构建管理员下拉菜单链接 ==========
$adminLinks = '';
if ($is_sqadmin) {
    $adminLinks .= '<a href="https://lmtoj.cn/admin" class="admin-link"><i class="fas fa-shield-alt"></i> 后台管理</a>';
    $adminLinks .= '<a href="https://lmtoj.cn/infoview" class="admin-link"><i class="fas fa-database"></i> 数据采集</a>';
    $adminLinks .= '<a href="https://lmtoj.cn/userdata" class="admin-link"><i class="fas fa-database"></i> 用户数据</a>';
}
if ($is_devadmin) {
    $adminLinks .= '<a href="https://lmtoj.cn/admin/file" class="admin-link"><i class="fas fa-folder-open"></i> 文件管理</a>';
    $adminLinks .= '<a href="https://lmtoj.cn/admin_collect" class="admin-link"><i class="fas fa-network-wired"></i> 可疑ip</a>';
    $adminLinks .= '<a href="https://lmtoj.cn/msg_history" class="admin-link"><i class="fas fa-comments"></i> 查看私信</a>';
    $adminLinks .= '<a href="https://lmtoj.cn/admin/sync" class="admin-link"><i class="fas fa-folder-open"></i> 三方同步</a>';
}
if ($is_devadmin && $is_sqadmin) {
    $adminLinks .= '<a href="https://lmtoj.cn/admin/sql" class="admin-link"><i class="fas fa-terminal"></i> SQL&DB</a>';
}
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<script src="/js/markdown-it.min.js"></script>
<script src="/js/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
<script src="/js/texmath.min.js"></script>
<!-- Font Awesome（用于工具栏图标） -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<!-- CodeMirror 核心 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/codemirror.min.js"></script>

<!-- CodeMirror Markdown 语法高亮（可选） -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.16/mode/markdown/markdown.min.js"></script>

<!-- 预览代码块语法高亮 -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/styles/github.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.11.1/highlight.min.js"></script>
<script src="/markdown-renderer.js"></script>

<!-- 你自己的 CodeMirror 初始化脚本 -->
<script src="/codemr.js"></script>
<style>
/* ========== 导航栏（统一对齐间距、精制视觉与交互，绝对不改原配色） ========== */
.sidebar a {
    text-decoration: none !important;
    color: #23201d !important;
}

.navbar {
    background: rgba(239, 248, 240, 0.98) !important;
    color: #17392a !important;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 28px;
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: 0 5px 20px rgba(28, 77, 52, 0.08), inset 0 1px 0 rgba(255, 255, 255, 0.72);
    border-bottom: 1px solid rgba(67, 128, 91, 0.14);
}
.navbar-brand {
    color: #204d31 !important;
    text-decoration: none;
    font-size: 17px;
    font-weight: 600;
    letter-spacing: -0.2px;
    transition: opacity 0.2s ease;
}
.navbar-brand:hover {
    opacity: 0.8;
}
.navbar-actions { 
    display: flex; 
    align-items: center; 
    gap: 6px; 
}
.navbar-links { 
    display: flex; 
    align-items: center; 
    gap: 6px;
    margin-left: 4px;
    padding-left: 8px;
    border-left: 1px solid rgba(67, 128, 91, 0.2);
}

.admin-dropdown-content { background: #e8f4e9 !important; }
.admin-dropdown-content a:hover { background: #d6ead9 !important; }

/* 统一交互组件尺寸与内边距，消除间距跳动 */
.bell-wrap, 
.theme-toggle-btn, 
.admin-dropdown-toggle {
    width: 36px !important;
    height: 36px !important;
    padding: 0 !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    border-radius: 8px !important;
    transition: all 0.2s cubic-bezier(0.4, 0, 0.2, 1) !important;
    box-sizing: border-box !important;
}

.theme-toggle-btn {
    margin-right: 10px !important;
}
.bell-wrap {
    margin-right: 10px !important;
    position: relative;
    color: #285b39 !important;
    text-decoration: none;
    font-size: 16px;
}
.bell-wrap:hover {
    background: rgba(67, 160, 106, 0.14);
    color: #176b40 !important;
}
.bell-wrap i, 
.theme-toggle-btn i, 
.admin-dropdown-toggle i { 
    font-size: 16px !important;
    line-height: 1 !important;
}

.badge {
    position: absolute;
    top: 4px; 
    right: 4px;
    display: flex;
    align-items: center;
    justify-content: center;
    min-width: 15px; 
    height: 15px;
    padding: 0 3px;
    border: 1.5px solid #e4f1e5;
    border-radius: 999px;
    background: #e54848;
    color: #fff;
    font: 700 9px/1 'Segoe UI', sans-serif;
    box-shadow: 0 1px 2px rgba(0,0,0,0.1);
}

.admin-dropdown { position: relative; display: inline-block; }
.admin-dropdown-toggle {
    background: none;
    border: none;
    color: #285b39;
    cursor: pointer;
}
.admin-dropdown-toggle:hover { 
    background: rgba(67, 160, 106, 0.14);
    color: #176b40;
}
.admin-dropdown-content {
    max-height: 0;
    opacity: 0;
    overflow: hidden;
    visibility: hidden;
    transition: max-height 0.25s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease, visibility 0s 0.25s;
    position: absolute;
    right: 0;
    top: calc(100% + 6px);
    background: #e8f4e9;
    min-width: 170px;
    box-shadow: 0 12px 28px -8px rgba(28, 77, 52, 0.2), 0 4px 10px rgba(28, 77, 52, 0.08);
    z-index: 1000;
    border-radius: 10px;
    padding: 0;
    border: 1px solid rgba(67, 128, 91, 0.2);
}
.admin-dropdown-content a {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 14px;
    color: #254a31;
    text-decoration: none;
    font-size: 13.5px;
    white-space: nowrap;
    transition: background 0.15s ease;
}
.admin-dropdown-content a i {
    width: 16px;
    text-align: center;
    color: #587365;
}
.admin-dropdown-content a:hover { background: #d6ead9 !important; }
.admin-dropdown.show .admin-dropdown-content {
    max-height: 320px;
    opacity: 1;
    visibility: visible;
    transition: max-height 0.25s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.2s ease, visibility 0s 0s;
    padding: 6px;
}

/* 主题切换按钮 */
.theme-toggle-btn {
    background: none;
    border: none;
    color: #285b39 !important;
    cursor: pointer;
}
.theme-toggle-btn:hover {
    background: rgba(67, 160, 106, 0.14);
    color: #176b40 !important;
}

/* 个人主页与退出链接 */
.user-info a {
    color: #285b39;
    text-decoration: none;
    font-size: 13.5px;
    font-weight: 500;
    padding: 6px 10px;
    border-radius: 6px;
    transition: all 0.15s ease;
}
.user-info a:hover {
    background: rgba(67, 160, 106, 0.14);
    color: #176b40;
}

.navbar h1 { font-size:17px; font-weight:600; color:#204d31; letter-spacing:0.4px; }
.navbar h1 a { color:#204d31; text-decoration:none; }

.user-info a.admin-link { color:#705b18; font-weight:600; }

/* ========== Sidebar 窄屏收缩适配（修复文本残留、支持多种常见结构类名并保证原始配色与UI不变） ========== */
@media screen and (max-width: 768px) {
    .sidebar,
    aside,
    .left-sidebar,
    #sidebar {
        width: 64px !important;
        min-width: 64px !important;
        max-width: 64px !important;
        overflow: hidden !important;
        transition: width 0.3s ease !important;
    }
    .sidebar span, 
    .sidebar .sidebar-title, 
    .sidebar .nav-text,
    .sidebar .menu-text,
    .sidebar p,
    .sidebar div:not(:has(i)):not([class*="icon"]),
    aside span, aside .nav-text, aside .menu-text,
    .left-sidebar span, .left-sidebar .nav-text, .left-sidebar .menu-text,
    #sidebar span, #sidebar .nav-text, #sidebar .menu-text {
        display: none !important;
    }
    .sidebar a,
    aside a,
    .left-sidebar a,
    #sidebar a {
        justify-content: center !important;
        padding: 12px 0 !important;
        gap: 0 !important;
        text-align: center !important;
    }
    .sidebar i,
    aside i,
    .left-sidebar i,
    #sidebar i {
        font-size: 18px !important;
        margin: 0 !important;
    }
}

/* ========== 深色模式（森林绿） ========== */
body.dark-mode {
    color-scheme: dark;
    filter: none !important;
    --bg: linear-gradient(135deg, #08150c 0%, #102317 46%, #09170e 100%);
    --card-bg: rgba(13, 31, 18, 0.94);
    --nav-bg: rgba(6, 22, 11, 0.98);
    --nav-text: #effaf1;
    --text: #e2f1e5;
    --text-secondary: #bad1bf;
    --text-muted: #93ad99;
    --border: rgba(216, 245, 221, 0.15);
    --border-light: rgba(174, 219, 184, 0.11);
    --accent: #68b77f;
    --accent-hover: #8bd19d;
    --accent-light: rgba(67, 160, 106, 0.16);
    --danger: #ef7773;
    --danger-hover: #ff9690;
    --shadow: 0 20px 52px rgba(0, 0, 0, 0.4);
    background:
        repeating-linear-gradient(0deg, transparent 0 35px, rgba(220, 250, 226, 0.018) 36px),
        repeating-linear-gradient(90deg, transparent 0 35px, rgba(220, 250, 226, 0.018) 36px),
        var(--bg) !important;
    color: var(--text) !important;
}

body.dark-mode .navbar {
    background: rgba(5, 20, 10, 0.98) !important;
    color: #effff3 !important;
    border-bottom: 1px solid rgba(203, 237, 211, 0.12) !important;
    box-shadow: 0 10px 32px rgba(0, 0, 0, 0.34), inset 0 1px 0 rgba(230, 255, 235, 0.08) !important;
    backdrop-filter: blur(26px) saturate(155%);
    -webkit-backdrop-filter: blur(26px) saturate(155%);
}

body.dark-mode .navbar-brand,
body.dark-mode .navbar h1,
body.dark-mode .navbar h1 a,
body.dark-mode .user-info a,
body.dark-mode .bell-wrap,
body.dark-mode .theme-toggle-btn,
body.dark-mode .admin-dropdown-toggle {
    color: #e3f3e7 !important;
}

body.dark-mode .navbar-links {
    border-left-color: rgba(203, 237, 211, 0.2) !important;
}

body.dark-mode .navbar .bell-wrap:hover,
body.dark-mode .navbar .theme-toggle-btn:hover,
body.dark-mode .navbar .admin-dropdown-toggle:hover,
body.dark-mode .navbar .user-info a:hover {
    background: rgba(191, 232, 201, 0.12) !important;
    color: #fff !important;
}

body.dark-mode .navbar .user-info a.admin-link {
    color: #f2d982 !important;
}

body.dark-mode .sidebar,
body.dark-mode .card,
body.dark-mode [class*="card"],
body.dark-mode .modal-content,
body.dark-mode .panel,
body.dark-mode .admin-dropdown-content,
body.dark-mode .dropdown-menu {
    background-color: rgba(11, 29, 16, 0.94) !important;
    border-color: rgba(203, 237, 211, 0.13) !important;
    color: #e3efe6 !important;
    box-shadow: 0 20px 52px rgba(0, 0, 0, 0.3), inset 0 1px 0 rgba(230, 255, 235, 0.05) !important;
    backdrop-filter: blur(24px) saturate(135%);
    -webkit-backdrop-filter: blur(24px) saturate(135%);
}

body.dark-mode .sidebar a,
body.dark-mode .admin-dropdown-content a,
body.dark-mode .card h1,
body.dark-mode .card h2,
body.dark-mode .card h3,
body.dark-mode .card h4,
body.dark-mode .card p,
body.dark-mode label,
body.dark-mode th,
body.dark-mode td,
body.dark-mode .text-secondary,
body.dark-mode .text-muted {
    color: #d8e9dc !important;
}

body.dark-mode .sidebar a:hover,
body.dark-mode .admin-dropdown-content a:hover {
    background: rgba(134, 196, 148, 0.16) !important;
    color: #f4fff6 !important;
}

body.dark-mode .admin-dropdown-content a i {
    color: #a8c8ae !important;
}

body.dark-mode input:not([type="checkbox"]):not([type="radio"]),
body.dark-mode textarea,
body.dark-mode select {
    background-color: rgba(5, 18, 9, 0.88) !important;
    border-color: rgba(177, 218, 186, 0.18) !important;
    color: #e3efe6 !important;
}

body.dark-mode input::placeholder,
body.dark-mode textarea::placeholder {
    color: #9ab6a0 !important;
}

body.dark-mode input:focus,
body.dark-mode textarea:focus,
body.dark-mode select:focus {
    border-color: #5ea875 !important;
    box-shadow: 0 0 0 3px rgba(94, 168, 117, 0.2) !important;
}

body.dark-mode .btn,
body.dark-mode button:not(.theme-toggle-btn):not(.bell-wrap):not(.admin-dropdown-toggle) {
    background: #1b5732;
    border-color: rgba(198, 233, 206, 0.2);
    color: #f1fff4;
}

body.dark-mode .btn:hover,
body.dark-mode button:not(.theme-toggle-btn):not(.bell-wrap):not(.admin-dropdown-toggle):hover {
    background: #246b3f;
}

body.dark-mode a:not(.navbar-brand):not(.admin-link),
body.dark-mode .at-link {
    color: #8bd19d;
}

body.dark-mode .badge,
body.dark-mode .red-dot {
    filter: none !important;
}

body.dark-mode .navbar .badge {
    border-color: #12351f !important;
}

body.dark-mode img,
body.dark-mode video,
body.dark-mode canvas {
    filter: none !important;
}

body.dark-mode .sidebar a,
body.dark-mode .card h1,
body.dark-mode .card h2,
body.dark-mode .card h3,
body.dark-mode .card h4,
body.dark-mode .card p,
body.dark-mode .card label,
body.dark-mode .msg-content,
body.dark-mode .ben-content,
body.dark-mode .md-content,
body.dark-mode .prob-title,
body.dark-mode .prob-section h3 {
    color: var(--text);
}

body.dark-mode .sidebar a:hover,
body.dark-mode .admin-dropdown-content a:hover {
    background: rgba(255, 255, 255, 0.1) !important;
    color: var(--accent-hover) !important;
}

body.dark-mode .admin-dropdown-content a,
body.dark-mode .admin-dropdown-content a i {
    color: var(--text-secondary) !important;
}

body.dark-mode a,
body.dark-mode .msg-link,
body.dark-mode .at-link,
body.dark-mode .prob-link {
    color: var(--accent) !important;
}

body.dark-mode a:hover {
    color: var(--accent-hover) !important;
}

body.dark-mode input:not([type="checkbox"]):not([type="radio"]),
body.dark-mode select,
body.dark-mode textarea {
    background-color: rgba(10, 32, 18, 0.72) !important;
    border-color: var(--border) !important;
    color: var(--text) !important;
}

body.dark-mode input::placeholder,
body.dark-mode textarea::placeholder {
    color: var(--text-muted) !important;
}

body.dark-mode input:focus,
body.dark-mode select:focus,
body.dark-mode textarea:focus {
    border-color: var(--accent) !important;
    box-shadow: 0 0 0 3px rgba(123, 201, 145, 0.18) !important;
}

body.dark-mode .btn,
body.dark-mode .btn-primary,
body.dark-mode .btn-save {
    background: linear-gradient(135deg, #329763, #21794b) !important;
    border-color: rgba(216, 245, 221, 0.22) !important;
    color: #fff !important;
}

body.dark-mode .btn-danger,
body.dark-mode .btn-del {
    background: #a53f3c !important;
    color: #fff !important;
}

body.dark-mode .btn-outline {
    background: rgba(255, 255, 255, 0.06) !important;
    border-color: var(--border) !important;
    color: var(--text-secondary) !important;
}

body.dark-mode th,
body.dark-mode .prob-meta span,
body.dark-mode .file-tag,
body.dark-mode .sample-group,
body.dark-mode .api-binding,
body.dark-mode .msg-unread,
body.dark-mode .page-bar a,
body.dark-mode .page-box a {
    background: rgba(255, 255, 255, 0.06) !important;
    border-color: var(--border-light) !important;
    color: var(--text-secondary);
}

body.dark-mode tr:hover,
body.dark-mode tr:hover td,
body.dark-mode .msg-item:hover,
body.dark-mode .page-bar a:hover,
body.dark-mode .page-box a:hover {
    background: rgba(123, 201, 145, 0.12) !important;
}

body.dark-mode .msg-unread {
    border-left-color: var(--accent) !important;
}

body.dark-mode .page-bar a.active,
body.dark-mode .page-box a.active-page {
    background: rgba(37, 132, 83, 0.72) !important;
    color: #fff !important;
}

body.dark-mode .head-bar,
body.dark-mode .prob-meta,
body.dark-mode td,
body.dark-mode .sol-item {
    border-color: var(--border-light) !important;
}

body.dark-mode .prob-meta span,
body.dark-mode .sample-group,
body.dark-mode .file-tag,
body.dark-mode .api-id {
    color: var(--text-secondary) !important;
}

body.dark-mode .token-balance {
    background: var(--accent-light) !important;
    color: var(--accent) !important;
}

body.dark-mode .alert-success,
body.dark-mode .msg {
    background: rgba(41, 93, 54, 0.72) !important;
    border-color: rgba(123, 201, 145, 0.3) !important;
    color: #c9f0d0 !important;
}

body.dark-mode .alert-error,
body.dark-mode .msg-error {
    background: rgba(105, 37, 39, 0.72) !important;
    color: #ffd4d2 !important;
}

body.dark-mode .red-dot,
body.dark-mode .badge {
    border-color: var(--nav-bg) !important;
}

body:not(.dark-mode) .code-wrapper,
body:not(.dark-mode) .code-wrapper pre,
body:not(.dark-mode) .sample-code-block,
body:not(.dark-mode) .article-content pre,
body:not(.dark-mode) .comment-content pre,
body:not(.dark-mode) .ben-content pre,
body:not(.dark-mode) .md-content pre,
body:not(.dark-mode) .cm-preview-box pre,
body:not(.dark-mode) .card pre,
body:not(.dark-mode) .sample-code-block pre {
    background: #fff !important;
    color: #24292f !important;
}

body.dark-mode .code-wrapper,
body.dark-mode .code-wrapper pre,
body.dark-mode .sample-code-block,
body.dark-mode .article-content pre,
body.dark-mode .comment-content pre,
body.dark-mode .ben-content pre,
body.dark-mode .md-content pre,
body.dark-mode .cm-preview-box pre,
body.dark-mode .card pre,
body.dark-mode .sample-code-block pre {
    background: #000 !important;
    color: #e6edf3 !important;
}
</style>

<div class="navbar">
    <h1><a href="https://lmtoj.cn/" class="navbar-brand">lmtOJ</a></h1>
    <?php if ($login_uid > 0): ?>
        <div class="navbar-actions">
            <button id="themeToggle" class="theme-toggle-btn" title="切换深色/浅色模式">
                <i class="fas fa-moon"></i>
            </button>

            <a class="bell-wrap" href="https://lmtoj.cn/notice" title="系统通知">
                <i class="fas fa-bell"></i>
                <?php if ($unreadCount > 0): ?><span class="badge"><?= navbarBadge($unreadCount) ?></span><?php endif; ?>
            </a>
            <a class="bell-wrap" href="https://lmtoj.cn/message" title="私信">
                <i class="fas fa-envelope"></i>
                <?php if ($unreadMsgCount > 0): ?><span class="badge"><?= navbarBadge($unreadMsgCount) ?></span><?php endif; ?>
            </a>
            <div class="user-info navbar-links">
                <?php if ($adminLinks !== ''): ?>
                    <div class="admin-dropdown">
                        <button class="admin-dropdown-toggle" aria-haspopup="true" aria-expanded="false" title="管理菜单">
                            <i class="fas fa-cog"></i>
                        </button>
                        <div class="admin-dropdown-content"><?= $adminLinks ?></div>
                    </div>
                <?php endif; ?>
                <a href="https://lmtoj.cn/user/<?= $login_uid ?>">个人主页</a>
                <a href="https://lmtoj.cn/?logout=1">退出登录</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<meta name="csrf-token" content="<?= htmlspecialchars($navbarCsrfToken, ENT_QUOTES, 'UTF-8') ?>">

<script>
// ========== 深色模式切换 ==========
(function() {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;
    const currentTheme = '<?= $currentTheme ?>';
    const isLoggedIn = <?= $login_uid > 0 ? 'true' : 'false' ?>;
    const uid = <?= $login_uid ?: 0 ?>;

    body.classList.toggle('dark-mode', currentTheme === 'dark');
    if (!themeToggle) return;
    updateIcon(currentTheme);

    themeToggle.addEventListener('click', function() {
        const newTheme = body.classList.contains('dark-mode') ? 'light' : 'dark';
        body.classList.toggle('dark-mode', newTheme === 'dark');
        updateIcon(newTheme);

        document.cookie = 'site_theme=' + newTheme + '; path=/; max-age=' + (30*24*60*60) + '; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');

        if (isLoggedIn) {
            fetch('/theme_ajax.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'action=set_theme&theme=' + newTheme
            }).catch(() => {});
        }
    });

    function updateIcon(theme) {
        const icon = themeToggle.querySelector('i');
        if (theme === 'dark') {
            icon.className = 'fas fa-sun';
            themeToggle.title = '切换浅色模式';
        } else {
            icon.className = 'fas fa-moon';
            themeToggle.title = '切换深色模式';
        }
    }
})();

// ========== CSRF 与管理下拉菜单 ==========
(function () {
    'use strict';
    var token = <?= json_encode($navbarCsrfToken, JSON_UNESCAPED_SLASHES) ?>;

    function sameOrigin(url) {
        try { return new URL(url, window.location.href).origin === window.location.origin; }
        catch (e) { return false; }
    }

    function addTokenToForms() {
        document.querySelectorAll('form').forEach(function (form) {
            if ((form.method || 'get').toLowerCase() !== 'post'
                || !sameOrigin(form.action || window.location.href)
                || form.querySelector('input[name="_csrf"]')) return;
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = '_csrf';
            input.value = token;
            form.appendChild(input);
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', addTokenToForms);
    } else {
        addTokenToForms();
    }

    if (window.fetch) {
        var originalFetch = window.fetch;
        window.fetch = function (input, init) {
            init = init || {};
            var request = (typeof Request !== 'undefined' && input instanceof Request) ? input : null;
            var method = String(init.method || (request && request.method) || 'GET').toUpperCase();
            var url = request ? request.url : String(input);
            if (method !== 'GET' && method !== 'HEAD' && sameOrigin(url)) {
                var headers = new Headers(init.headers || (request && request.headers) || {});
                if (!headers.has('X-CSRF-Token')) headers.set('X-CSRF-Token', token);
                init.headers = headers;
            }
            return originalFetch.call(this, input, init);
        };
    }

    if (window.XMLHttpRequest) {
        var originalOpen = XMLHttpRequest.prototype.open;
        var originalSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function (method, url) {
            this.__csrfProtected = !/^(GET|HEAD)$/i.test(String(method)) && sameOrigin(url);
            return originalOpen.apply(this, arguments);
        };
        XMLHttpRequest.prototype.send = function () {
            if (this.__csrfProtected) this.setRequestHeader('X-CSRF-Token', token);
            return originalSend.apply(this, arguments);
        };
    }

    document.addEventListener('DOMContentLoaded', function() {
        var toggle = document.querySelector('.admin-dropdown-toggle');
        if (!toggle) return;
        var dropdown = toggle.closest('.admin-dropdown');
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            var isExpanded = toggle.getAttribute('aria-expanded') === 'true';
            toggle.setAttribute('aria-expanded', !isExpanded);
            dropdown.classList.toggle('show');
        });
        document.addEventListener('click', function(e) {
            if (!dropdown.contains(e.target)) {
                dropdown.classList.remove('show');
                toggle.setAttribute('aria-expanded', 'false');
            }
        });
    });
})();
</script>
<script>
(function() {
    var uid = <?= json_encode($collect_uid) ?>;
    var page = <?= json_encode($collect_page) ?>;
    var ip = <?= json_encode($collect_ip) ?>;
    var device = navigator.userAgent || '';
    var data = {
        uid: uid,
        ip: ip,
        device: device,
        page: page
    };
    if (navigator.sendBeacon) {
        navigator.sendBeacon('/infocollect.php', JSON.stringify(data));
    } else {
        fetch('/infocollect.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
            keepalive: true
        }).catch(function() { /* 静默失败 */ });
    }
})();
</script>
<script src="/collect.js"></script>