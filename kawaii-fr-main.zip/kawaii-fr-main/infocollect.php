<?php
session_start();
require_once __DIR__ . '/database.php';
header('Content-Type: application/json; charset=utf-8');
$input = file_get_contents('php://input');
$data = json_decode($input, true);
if (!$data) {
    $data = $_POST;
}
$uid = isset($data['uid']) ? (int)$data['uid'] : 0;
$ip = isset($data['ip']) ? trim($data['ip']) : ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
$user_agent = isset($data['device']) ? trim($data['device']) : ($_SERVER['HTTP_USER_AGENT'] ?? '');
$page_url = isset($data['page']) ? trim($data['page']) : ($_SERVER['HTTP_REFERER'] ?? '');
if (empty($page_url)) {
    $page_url = $_SERVER['REQUEST_URI'] ?? '/';
}
$conn = db();
$conn->set_charset('utf8mb4');
$conn->query("CREATE TABLE IF NOT EXISTS info_log2 (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT DEFAULT 0,
    ip VARCHAR(45) NOT NULL,
    user_agent TEXT,
    page_url VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    backup_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(uid),
    INDEX(backup_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conn->begin_transaction();
try {
    $stmt1 = $conn->prepare("INSERT INTO page_visits (uid, ip, user_agent, page_url) VALUES (?, ?, ?, ?)");
    $stmt1->bind_param("isss", $uid, $ip, $user_agent, $page_url);
    $ok1 = $stmt1->execute();
    $stmt1->close();
    $stmt2 = $conn->prepare("INSERT INTO info_log2 (uid, ip, user_agent, page_url) VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("isss", $uid, $ip, $user_agent, $page_url);
    $ok2 = $stmt2->execute();
    $stmt2->close();
    if (!$ok1 || !$ok2) {
        throw new Exception('插入失败');
    }
    $conn->commit();
    echo json_encode(['status' => 'ok']);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => '数据库写入失败：' . $e->getMessage()]);
}
$conn->close();