<?php

error_reporting(0);
ini_set('display_errors', 0);

session_start();
header('Content-Type: application/json');

$debug = isset($_GET['debug']) && $_GET['debug'] == 1;

if (!isset($_SESSION['uid'])) {
    echo json_encode([]);
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
if ($conn->connect_error) {
    if ($debug) {
        echo json_encode(['error' => '数据库连接失败: ' . $conn->connect_error]);
    } else {
        echo json_encode([]);
    }
    exit;
}
$conn->set_charset("utf8mb4");

$uid = (int)$_SESSION['uid'];

$userRow = $conn->query("SELECT interests FROM users WHERE uid = $uid LIMIT 1");
if (!$userRow) {
    if ($debug) {
        echo json_encode(['error' => '查询用户兴趣失败: ' . $conn->error]);
    } else {
        echo json_encode([]);
    }
    exit;
}
$user = $userRow->fetch_assoc();
$myInterests = array_filter(explode(',', $user['interests'] ?? ''));

$recommendedUsers = [];

if (!empty($myInterests)) {
    $escapedInterests = array_map([$conn, 'real_escape_string'], $myInterests);
    $likeConditions = [];
    foreach ($escapedInterests as $tag) {
        $likeConditions[] = "interests LIKE '%{$tag}%'";
    }
    $where = implode(' OR ', $likeConditions);
    $recRes = $conn->query("SELECT uid, name, avatar, interests FROM users WHERE uid != {$uid} AND ({$where}) ORDER BY RAND() LIMIT 5");
    if ($recRes) {
        while ($row = $recRes->fetch_assoc()) {
            $row['common_tags'] = array_intersect($myInterests, array_filter(explode(',', $row['interests'] ?? '')));
            $recommendedUsers[] = $row;
        }
    }
}
if (empty($recommendedUsers)) {
    $recRes = $conn->query("SELECT uid, name, avatar, interests FROM users WHERE uid != {$uid} ORDER BY RAND() LIMIT 5");
    if ($recRes) {
        while ($row = $recRes->fetch_assoc()) {
            $row['common_tags'] = [];
            $recommendedUsers[] = $row;
        }
    }
}
echo json_encode($recommendedUsers, JSON_UNESCAPED_UNICODE);
$conn->close();
?>