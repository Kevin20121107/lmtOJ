<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type:text/html;charset=utf-8");

// 安全过滤（POST 不转义，防止代码被破坏）
function safeInput($data) {
    if (is_array($data)) {
        return array_map('safeInput', $data);
    }
    $data = trim($data);
    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}
if (!empty($_GET)) $_GET = safeInput($_GET);
if (!empty($_COOKIE)) $_COOKIE = safeInput($_COOKIE);

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 自动创建 ide_files 表
$conn->query("CREATE TABLE IF NOT EXISTS ide_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    code TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY (uid, filename)
)");

$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin, jinyan, avatar FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = $userRow['admin'] ?? 0;
$login_name = $userRow['name'] ?? '';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

$current_page = basename($_SERVER['SCRIPT_NAME']);

// ===== 处理 AJAX 请求 =====
// 保存代码
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['action']) && $_GET['action'] === 'save') {
    $uid = (int)$_SESSION['uid'];
    $filename = isset($_POST['filename']) ? trim($_POST['filename']) : 'main.cpp';
    $code = isset($_POST['code']) ? $_POST['code'] : '';
    $filename = preg_replace('/[^a-zA-Z0-9_.-]/', '', $filename);
    if (empty($filename)) $filename = 'main.cpp';
    if (!strpos($filename, '.')) $filename .= '.cpp';
    
    $stmt = $conn->prepare("INSERT INTO ide_files (uid, filename, code) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE code = VALUES(code)");
    $stmt->bind_param("iss", $uid, $filename, $code);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => '保存成功']);
    } else {
        echo json_encode(['success' => false, 'message' => '保存失败：' . $stmt->error]);
    }
    $stmt->close();
    exit;
}

// 获取文件列表
if (isset($_GET['action']) && $_GET['action'] === 'list') {
    $uid = (int)$_SESSION['uid'];
    $result = $conn->query("SELECT id, filename, updated_at FROM ide_files WHERE uid = $uid ORDER BY updated_at DESC");
    $files = [];
    while ($row = $result->fetch_assoc()) {
        $files[] = $row;
    }
    header('Content-Type: application/json');
    echo json_encode($files);
    exit;
}

// 获取单个文件内容
if (isset($_GET['action']) && $_GET['action'] === 'get') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id <= 0) { echo json_encode(['error'=>'Invalid ID']); exit; }
    $uid = (int)$_SESSION['uid'];
    $stmt = $conn->prepare("SELECT code FROM ide_files WHERE id = ? AND uid = ?");
    $stmt->bind_param("ii", $id, $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        echo json_encode(['code' => $row['code']]);
    } else {
        echo json_encode(['error' => 'Not found']);
    }
    $stmt->close();
    exit;
}

// 删除文件
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if ($id <= 0) { echo json_encode(['success' => false, 'message' => '无效ID']); exit; }
    $uid = (int)$_SESSION['uid'];
    $stmt = $conn->prepare("DELETE FROM ide_files WHERE id = ? AND uid = ?");
    $stmt->bind_param("ii", $id, $uid);
    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => '删除成功']);
        } else {
            echo json_encode(['success' => false, 'message' => '文件不存在或无权限']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => '删除失败：' . $stmt->error]);
    }
    $stmt->close();
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>C++ 在线IDE - lmtOJ</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/dracula.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldgutter.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/dialog/dialog.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/matchesonscrollbar.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* ===== 全局样式 ===== */
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --accent: #6b8a74;
            --accent-light: #eef4ef;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
            --font-mono: 'Consolas', 'Fira Code', monospace;
            --transition: 0.18s ease;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body {
            background:var(--bg);
            font-family:var(--font);
            color:var(--text);
            min-height:100vh;
            display:flex;
            flex-direction:column;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background:var(--nav-bg);
            height:54px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:0 28px;
            color:var(--nav-text);
            flex-shrink:0;
            position:sticky;
            top:0;
            z-index:100;
            box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 {
            font-size:17px;
            font-weight:600;
            color:#f0ece6;
            letter-spacing:0.4px;
        }
        .navbar h1 a {
            color:#f0ece6;
            text-decoration:none;
        }
        .bell-wrap {
            position:relative;
            font-size:20px;
            cursor:pointer;
            margin-right:20px;
            width:36px;
            height:36px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-radius:50%;
            transition:var(--transition);
        }
        .bell-wrap:hover {
            background:rgba(255,255,255,0.08);
        }
        .red-dot {
            position:absolute;
            top:5px;
            right:5px;
            width:9px;
            height:9px;
            background:#f55353;
            border-radius:50%;
            border:1.5px solid #3d3a37;
            animation:pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}
            50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}
        }
        .user-info {
            display:flex;
            align-items:center;
            gap:6px;
        }
        .user-info a {
            color:#e0dbd3;
            text-decoration:none;
            font-size:13.5px;
            padding:7px 13px;
            border-radius:20px;
            transition:var(--transition);
            font-weight:500;
        }
        .user-info a:hover {
            background:rgba(255,255,255,0.1);
            color:#fff;
        }
        .user-info a.admin-link {
            color:#f5d76e;
            font-weight:600;
        }

        /* ===== 主布局 ===== */
        .main {
            flex:1;
            display:flex;
            gap:22px;
            max-width:1100px;
            margin:28px auto 40px;
            padding:0 20px;
            align-items:flex-start;
            width:100%;
        }

        /* ===== 侧边栏样式（宽度固定130px，与 admin.php 统一） ===== */
        .sidebar {
            background:var(--card-bg);
            border-radius:var(--radius);
            box-shadow:var(--shadow);
            width: 100px;           /* 固定宽度，替代 fit-content */
            min-width: 100px;       /* 防止收缩 */
            overflow:hidden;
            position:sticky;
            top:80px;
            flex-shrink:0;
        }
        .sidebar a {
            display:block;
            padding:13px 22px;
            text-align:center;
            background:var(--card-bg);
            color:var(--text);
            text-decoration:none;
            font-size:14.5px;
            font-weight:500;
            white-space:nowrap;
            transition:var(--transition);
            border-left:3px solid transparent;
            letter-spacing:0.3px;
        }
        .sidebar a:hover {
            background:#f5f2ed;
            border-left-color:var(--accent);
            color:var(--accent);
        }
        .sidebar a:first-child {
            border-radius:var(--radius) var(--radius) 0 0;
        }
        .sidebar a:last-child {
            border-radius:0 0 var(--radius) var(--radius);
        }

        /* ===== 内容区域（编辑器） ===== */
        .content {
            flex:1;
            min-width:0;
            display:flex;
            flex-direction:column;
            height:100%;
            min-height:0;
        }
        .toolbar {
            display:flex;
            flex-wrap:wrap;
            gap:8px;
            margin-bottom:10px;
            align-items:center;
            background:var(--card-bg);
            padding:8px 14px;
            border-radius:var(--radius);
            box-shadow:var(--shadow);
        }
        .toolbar input, .toolbar select, .toolbar button {
            padding:6px 12px;
            border-radius:6px;
            border:1px solid #ddd;
            background:#fff;
            font-size:13px;
            font-family:var(--font);
        }
        .toolbar button {
            background:var(--accent);
            color:#fff;
            border:none;
            cursor:pointer;
            transition:0.2s;
        }
        .toolbar button:hover { background:#55735e; }
        .toolbar .file-select { min-width:140px; }
        .editor-container {
            flex:1;
            overflow:hidden;
            border-radius:var(--radius);
            box-shadow:var(--shadow);
            min-height:0;
        }
        .CodeMirror {
            height:100% !important;
            font-size:14px;
            font-family:var(--font-mono);
            line-height:1.6;
        }
        .CodeMirror-gutters { background:#17231a; border-right:1px solid #304436; }
        .CodeMirror-linenumber { color:#718978; }
        .cm-s-dracula .cm-keyword { color:#91dfa4 !important; font-weight:600; }
        .cm-s-dracula .cm-atom { color:#c6a0f6 !important; }
        .cm-s-dracula .cm-number { color:#efc27d !important; }
        .cm-s-dracula .cm-def { color:#82d4df !important; }
        .cm-s-dracula .cm-variable { color:#e3eee5 !important; }
        .cm-s-dracula .cm-variable-2 { color:#f2a58a !important; }
        .cm-s-dracula .cm-variable-3,
        .cm-s-dracula .cm-type { color:#9bd8b0 !important; }
        .cm-s-dracula .cm-property { color:#b7c9f2 !important; }
        .cm-s-dracula .cm-operator { color:#a7d9b2 !important; }
        .cm-s-dracula .cm-comment { color:#829988 !important; font-style:italic; }
        .cm-s-dracula .cm-string,
        .cm-s-dracula .cm-string-2 { color:#e7ce91 !important; }
        .cm-s-dracula .cm-meta { color:#c6a0f6 !important; }
        .cm-s-dracula .cm-builtin { color:#83cbd9 !important; }

        body:not(.dark-mode) .CodeMirror,
        body:not(.dark-mode) .CodeMirror-scroll,
        body:not(.dark-mode) .CodeMirror-sizer,
        body:not(.dark-mode) .CodeMirror-lines,
        body:not(.dark-mode) .CodeMirror-lines pre {
            background-color:#f3f8f3 !important;
        }
        body:not(.dark-mode) .CodeMirror { color:#203a28 !important; }
        body:not(.dark-mode) .CodeMirror-gutters { background:#e8f1e9 !important; border-right:1px solid #d1e0d3; }
        body:not(.dark-mode) .CodeMirror-linenumber { color:#829788; }
        body:not(.dark-mode) .cm-s-dracula .cm-keyword { color:#167143 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-atom { color:#7542a8 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-number { color:#a35a12 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-def { color:#08788a !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-variable { color:#203a28 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-variable-2 { color:#a34d37 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-variable-3,
        body:not(.dark-mode) .cm-s-dracula .cm-type { color:#347b57 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-property { color:#465f98 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-operator { color:#356f45 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-comment { color:#78897b !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-string,
        body:not(.dark-mode) .cm-s-dracula .cm-string-2 { color:#8d641d !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-meta { color:#7542a8 !important; }
        body:not(.dark-mode) .cm-s-dracula .cm-builtin { color:#08788a !important; }
        body:not(.dark-mode) .editor-container { background:#f3f8f3 !important; }
        body.dark-mode .CodeMirror,
        body.dark-mode .CodeMirror-scroll,
        body.dark-mode .CodeMirror-sizer,
        body.dark-mode .CodeMirror-lines,
        body.dark-mode .CodeMirror-lines pre {
            background-color:#101b13 !important;
        }
        body.dark-mode .CodeMirror { color:#e3eee5 !important; }
        body.dark-mode .CodeMirror-gutters { background:#17231a !important; }

        .footer-copyright {
            text-align:center;
            font-size:12px;
            color:#888;
            padding:8px 0;
            flex-shrink:0;
        }

        #deleteBtn { background:#d9534f; }
        #deleteBtn:hover { background:#c9302c; }

        /* ===== 响应式 ===== */
        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; gap:14px; }
            .sidebar {
                width:100%;
                position:static;
                display:flex;
                flex-wrap:wrap;
                border-radius:var(--radius);
                min-width: unset; /* 移动端取消固定宽度 */
            }
            .sidebar a {
                flex:1 1 auto;
                padding:11px 10px;
                font-size:13px;
                border-left:none;
                border-bottom:2px solid transparent;
            }
            .sidebar a:hover {
                border-left-color:transparent;
                border-bottom-color:var(--accent);
            }
        }
    </style>
</head>
<body>
    <!-- ===== 导航栏 ===== -->
    <?php include __DIR__ . '/navbar.php'; ?>

    <!-- ===== 主体 ===== -->
    <div class="main">
        <!-- ===== 侧边栏（引用独立文件） ===== -->
        <?php include __DIR__ . '/sidebar.php'; ?>

        <!-- 编辑器主内容 -->
        <div class="content">
            <div class="toolbar">
                <input type="text" id="filenameInput" value="main.cpp" placeholder="文件名" style="width:120px;">
                <select id="templateSelect">
                    <option value="">-- 插入模板 --</option>
                    <option value="cpp">C++ (iostream)</option>
                </select>
                <button id="saveBtn"><i class="fas fa-save"></i> 保存</button>
                <button id="downloadBtn"><i class="fas fa-download"></i> 下载</button>
                <button id="loadBtn" style="background:#6c757d;"><i class="fas fa-folder-open"></i> 加载列表</button>
                <select id="fileListSelect" class="file-select" style="display:none;">
                    <option value="">-- 选择已保存文件 --</option>
                </select>
                <button id="deleteBtn" style="display:none;"><i class="fas fa-trash"></i> 删除</button>
                <span style="margin-left:auto; font-size:12px; color:#888;" id="statusMsg">就绪</span>
            </div>
            <div class="editor-container">
                <textarea id="codeEditor"></textarea>
            </div>
        </div>
    </div>

    <!-- CodeMirror 依赖 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/edit/closebrackets.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/foldgutter.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/brace-fold.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/fold/comment-fold.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/dialog/dialog.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/searchcursor.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/search.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/jump-to-line.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/addon/search/matchesonscrollbar.min.js"></script>

    <script>
        // ---- 初始化编辑器 ----
        const textarea = document.getElementById('codeEditor');
        const editor = CodeMirror.fromTextArea(textarea, {
            lineNumbers: true,
            mode: "text/x-c++src",
            theme: "dracula",
            autoCloseBrackets: true,
            indentUnit: 4,
            tabSize: 4,
            lineWrapping: true,
            foldGutter: true,
            gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
            extraKeys: {
                "Ctrl-S": function() { saveFile(); return false; },
                "Cmd-S": function() { saveFile(); return false; }
            }
        });
        editor.setValue("");

        // ---- DOM 引用 ----
        const filenameInput = document.getElementById('filenameInput');
        const templateSelect = document.getElementById('templateSelect');
        const saveBtn = document.getElementById('saveBtn');
        const downloadBtn = document.getElementById('downloadBtn');
        const loadBtn = document.getElementById('loadBtn');
        const fileListSelect = document.getElementById('fileListSelect');
        const deleteBtn = document.getElementById('deleteBtn');
        const statusMsg = document.getElementById('statusMsg');

        // ---- 模板定义 ----
        const templates = {
            cpp: `#include <iostream>
using namespace std;

int main() {
    // 在此编写代码
    return 0;
}`
        };

        // ---- 插入模板 ----
        templateSelect.addEventListener('change', function() {
            const lang = this.value;
            if (!lang) return;
            const code = templates[lang];
            if (code) {
                const cursor = editor.getCursor();
                editor.replaceRange(code, cursor);
                let ext = '.cpp';
                const base = filenameInput.value.replace(/\.[^.]+$/, '');
                filenameInput.value = base ? base + ext : 'main' + ext;
                editor.setOption('mode', 'text/x-c++src');
            }
            this.value = '';
        });

        // ---- 保存文件 ----
        function saveFile() {
            const code = editor.getValue();
            const filename = filenameInput.value.trim() || 'main.cpp';
            if (!code) {
                statusMsg.textContent = '代码为空，未保存';
                return;
            }
            fetch('?action=save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'filename=' + encodeURIComponent(filename) + '&code=' + encodeURIComponent(code)
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    statusMsg.textContent = '保存成功: ' + filename;
                    refreshFileList(false);
                } else {
                    statusMsg.textContent = '保存失败: ' + data.message;
                }
            })
            .catch(err => {
                statusMsg.textContent = '网络错误';
                console.error(err);
            });
        }
        saveBtn.addEventListener('click', saveFile);

        // ---- 下载文件 ----
        downloadBtn.addEventListener('click', function() {
            const code = editor.getValue();
            if (!code) {
                alert('代码为空，无法下载');
                return;
            }
            let filename = filenameInput.value.trim() || 'main.cpp';
            if (!filename.includes('.')) filename += '.cpp';
            const blob = new Blob([code], { type: 'text/plain' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.download = filename;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(link.href);
            statusMsg.textContent = '下载: ' + filename;
        });

        // ---- 文件列表 ----
        function refreshFileList(autoSelectId = null) {
            fetch('?action=list')
            .then(res => res.json())
            .then(files => {
                const sel = fileListSelect;
                sel.innerHTML = '<option value="">-- 选择已保存文件 --</option>';
                if (files.length === 0) {
                    sel.style.display = 'none';
                    deleteBtn.style.display = 'none';
                    return;
                }
                sel.style.display = 'inline-block';
                deleteBtn.style.display = 'inline-block';
                files.forEach(f => {
                    const opt = document.createElement('option');
                    opt.value = f.id;
                    opt.textContent = f.filename + ' (' + new Date(f.updated_at).toLocaleString() + ')';
                    sel.appendChild(opt);
                });
                if (autoSelectId) {
                    sel.value = autoSelectId;
                }
            })
            .catch(err => console.error(err));
        }

        loadBtn.addEventListener('click', function() {
            refreshFileList();
        });

        // 选择文件加载
        fileListSelect.addEventListener('change', function() {
            const id = this.value;
            if (!id) {
                deleteBtn.style.display = 'none';
                return;
            }
            deleteBtn.style.display = 'inline-block';
            fetch('?action=get&id=' + id)
            .then(res => res.json())
            .then(data => {
                if (data.code !== undefined) {
                    editor.setValue(data.code);
                    statusMsg.textContent = '已加载文件 ID=' + id;
                    const selectedOption = this.options[this.selectedIndex];
                    if (selectedOption) {
                        const fn = selectedOption.textContent.split(' (')[0];
                        filenameInput.value = fn;
                    }
                    editor.setOption('mode', 'text/x-c++src');
                } else {
                    statusMsg.textContent = '加载失败: ' + (data.error || '未知错误');
                }
            })
            .catch(err => {
                statusMsg.textContent = '网络错误';
                console.error(err);
            });
        });

        // ---- 删除文件 ----
        deleteBtn.addEventListener('click', function() {
            const id = fileListSelect.value;
            if (!id) return;
            if (!confirm('确定要删除此文件吗？(不会影响当前编辑内容)')) return;
            fetch('?action=delete&id=' + id)
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    statusMsg.textContent = '删除成功';
                    refreshFileList();
                } else {
                    statusMsg.textContent = '删除失败: ' + data.message;
                }
            })
            .catch(err => {
                statusMsg.textContent = '网络错误';
                console.error(err);
            });
        });

        // ---- 初始加载 ----
        refreshFileList();

        // ---- 自动调整大小 ----
        window.addEventListener('resize', () => editor.refresh());
        setTimeout(() => editor.refresh(), 200);

        // 快捷键 Ctrl+S
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                saveFile();
            }
        });
    </script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>