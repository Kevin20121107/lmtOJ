<?php
// batch_upload.php - 批量上传文件

require_once __DIR__ . 'https://lmtoj.cn/config.php';
require_once __DIR__ . 'https://lmtoj.cn/security.php';
$password = (string) env('FILE_MANAGER_PASSWORD');

session_start();

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// 登录验证（与 file_admin.php 共用密码）
if (!isset($_SESSION['fm_logged'])) {
    if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['pwd']) && $_POST['pwd'] === $password) {
        $_SESSION['fm_logged'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
    ?>
    <!DOCTYPE>
    <html>
    <head><title>批量上传 - 登录</title><meta charset="utf-8">
    <style>
        *{margin:;padding:;box-sizing:border-box;}
        body{font-family:'Segoe UI',sans-serif;background:#1a1a2e;display:flex;justify-content:center;align-items:center;:100vh;}
        .login-box{background:#16213e;padding:40px;border-radius:12px;box-shadow: 8px 32px rgba(,,,.3);text-align:center;}
        .login-box h2{color:#e94560;margin-bottom:24px;}
        .login-box input{width:100%;padding:12px;border:2px solid #f346;border-radius:6px;background:#1a1a2;color:#eee;font-size:16px;line:none;margin-bottom:16px;}
        .login-box input:focus{border-color:#e94560;}
        .login-box button{width:100%;padding:12px;background:#e94560;color:#fff;border:none;border-radius:6px;font-size:16px;cursor:pointer;transition:.3s;}
        .login-box button:hover{background:#c73652;}
    </style>
    </head>
    <body>
        <form method="post">
            <div class="login-box">
                <h2>批量上传</h2>
                <input type="password" name="pwd" placeholder="请输入密码" autofocus>
                <button type="submit">登 录</button            </div>
        </form>
    <?php include __DIR__ . 'https://lmtoj.cn/footer.php'; ?>
</body>
    </html>
    <?php
    exit;
}

csrf_protect_request(true);

$message = '';
$uploadedFiles = [];

// 处理批量上传
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
    $files = $_FILES['files'];
    $count = count($files['name']);
    
    for ($i = 0; $i < $count; $i++) {
        if ($files['error'][$i] === UPLOAD_ERR_OK) {
            $tmpName = $files['tmp_name'][$i];
            $origName = $files['name'][$i];
            $dest = __DIR__ . '/' . $origName;
            
            // 防止覆盖已存在文件 - 自动重命名
            if (file_exists($dest)) {
                $pathInfo = pathinfo($origName);                $baseName = $pathInfo['filename'];
                $ext = isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '';
                $counter = 1;
                while (file_exists(__DIR__ . '/' . $baseName .'_' . $counter . $ext)) {
                    $counter++;
                }
                $dest = __DIR__ . '/' . $baseName . '_' . $counter . $ext;
                $origName = $baseName . '_' . $counter . $ext;
            }
            
            if (move_uploaded_file($tmpName, $dest)) {
                $uploadedFiles[] = ['name' => $origName, 'status' => 'success', 'size' => $files['size'][$i]];
            } else {
                $uploadedFiles[] = ['name' => $origName, 'status' => 'error', 'error' => '移动文件失败'];
            }
        } else {
            $errorMessages = [
                UPLOAD__INI_SIZE => '文件超过服务器允许的最大值',
                UPLOAD_ERR_FORM_SIZE => '文件超过表单允许的最大值',
                UPLOAD_ERR_PARTIAL => '文件仅被部分上传',
                UPLOAD_ERR_NO_FILE => '没有选择文件',
                UPLOAD_ERR_NO_TMP_DIR => '找不到临时文件夹',
                UPLOAD_ERR_CANT_WRITE => '文件写入失败',
            ];
            $errorMsg = isset($errorMessages[$files['error'][$i]]) ? $errorMessages[$files['error'][$i]] : '未知错误';
            $uploadedFiles[] = ['name' => $files['name'][$i], 'status' => 'error', 'error' => $errorMsg];
        }
    }
    
    $successCount = 0;
    foreach ($uploadedFiles as $f) {
        if ($f['status'] === 'success') $successCount++;
    }
    $message = "上传完成：成功 {$successCount} 个，失败 " . (count($uploadedFiles) - $successCount) . " 个";
}

// 删除上传的文件
if (isset($_GET['delete'])) {
    $delFile = basename($_GET['delete']);
    if (file_exists(__DIR__ . '/' . $delFile)) {
        unlink(__DIR__ . '/' . $delFile);
        $message = "已删除：{$delFile}";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>批量上传 - 文件管理器</title>
<style>
    *{margin:;padding:;box-sizing:border-box;}
    body{font-family:'Segoe UI',sans-serif;background:#f5feb;color:#5d4e37;padding:20px;}
    .container{max-width:900px;margin: auto;}
    h1{color:#c0392b;font-size:24px;margin-bottom:8px;display:flex;align-items:center;gap:12px;}
    h1 small{font-size:14px;font-weight:normal;}
    h1 a{font-size:14px;font-weight:normal;color:#c0392b;text-decoration:none;}
    h1 a:hover{text-decoration:underline;}
    .message{padding:12px 16px;background:#e8f5e9;color:#2e7d32;border-radius:8px;margin-bottom:16px;border-left:4px solid #2e7d32;}
    .message.error{background:#ffebee;color:#c62828;border-left-color:#c62828;}
    .upload-box{background:#fff;border-radius:12px;padding:24px;box-shadow: 2px 12px rgba(,,,.06);margin-bottom:20px;}
    .upload-box h2{font-size:18px;color:#5d4e37;margin-bottom:16px;}
    .drop-zone{border:2px dashed #d4c5b;border-radius:8px;padding:40px 20px;text-align:center;cursor:pointer;transition:.3s;:#faf8f5;}
    .drop-zone:hover,.drop-zone.dragover{border-color:#c0392b;background:#fff5f;}
    .drop-zone .icon{font-size:48px;color:#c0392b;margin-bottom:12px;}
    .drop-zone p{color:#8a7a63;font-size:14px;}
    .drop-zone .browse{color:#c0392b;font-weight:600;text-decoration:underline;cursor:pointer;}
    #fileInput{display:none;}
    .file-list{margin-top:16px;}
    .file-item{display:flex;align-items:center;gap:10px;padding:8px 12px;background:#faf8f5;border-radius:6px;margin-bottom:px;font-size:13px;}
    .file-item .name{flex:1;color:#5d4e37;}
    .file-item .size{color:#8a7a63;font-size:12px;}
    .file-item .remove{cursor:pointer;color:#c0392b;font-size:18px;line-height:1;}
    .submit-btn{display:block;width:100%;padding:14px;background:#c0392b;color:#fff;border:none;border-radius:8px;font-size:16px;cursor:pointer;transition:.3s;margin-top:16px;font-weight:600;}
    .submit-btn:hover{background:#a93226;}
    .submit-btn:disabled{background:#d4c5b;cursor:not-allowed;}
    .progress-bar{height:4px;background:#febe4;border-radius:2px;margin-top:12px;overflow:hidden;display:none;}
    .progress-bar .fill{height:100%;background:#c0392b;width:%;transition:width .3s;}
    .uploaded-list{background:#fff;border-radius:12px;padding:20px;box-shadow: 2px 12px rgba(,,,.06);margin-bottom:20px;}
    .uploaded-list h2{font-size:18px;color:#5d4e37;margin-bottom:12px;}
    .uploaded-item{display:flex;align-items:center;gap:10px;padding:8px 12px;border-radius:6px;margin-bottom:4px;font-size:13px;}
    .uploaded-item{background:#e8f5e9;}
    .uploaded-item.error{background:#ffebee;}
    .uploaded-item .name{flex:1;color:#5d4e37;}
    .uploaded-item .status{font-size:12px;}
    .uploaded-item .status.success{color:#2e7d32;}
    .uploaded-item .status.error{color:#c62828;}
    .ed-item .size{color:#8a7a63;font-size:12px;margin-right:8px;}
    .uploaded-item .del-btn{color:#c0392b;text-decoration:none;font-size:12px;}
    .uploaded-item .del-btn:hover{text-decoration:underline;}
    .nav-links{margin-bottom:16px;display:flex;gap:12px;}
    .nav-links a{color:#c0392b;text-decoration:none;-size:14px;}
    .nav-links a:hover{text-decoration:underline;}
    .stats{font-size:13px;color:#8a7a63;margin-bottom:12px;}
</style>
</head>
<body>
<div class="container">
    <h1>
        📁 批量上传
        <small>拖拽或选择多个文件</small>
        <a href="https://lmtoj.cn/admin/file" style="margin-left:auto;">← 返回文件管理器</a>
    </h1>
    
    <div class="nav-links">
        <a href="?logout=1">退出登录</a>
    </div>

    <?php if ($message): ?>
        <div class="message <?php echo (strpos($message, '失败') !== false && strpos($message, '成功 ') !== false) ? 'error' : ''; ?>">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <div class="upload-box">
        <h2>📤 选择文件上传</h2>
        <form id="uploadForm" method="post" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="drop-zone" id="dropZone">
                <div class="icon">☁️</div>
                <p>拖拽文件到此处，或 <span class="browse" onclick="document.getElementById('fileInput').click()">点击浏览</span></p>
                <p style="font-size:12px;color:#ba090;margin-top:6px;">支持所有文件类型，可多选</p>
                <input type="file" name="files[]" id="fileInput" multiple onchange="handleFiles(this.files)">
            </div>
            <div class="file-list" id="fileList"></div>
            <div class="progress-bar" id="progressBar"><div class="fill" id="progressFill"></div></div>
            <button type="submit" class="submit-btn" id="submitBtn" disabled>开始上传</button>
        </form>
    </div>

    <?php if (!empty($uploadedFiles)): ?>
    <div class="uploaded-list">
        <h2>📋 本次上传结果</h2>
        <?php foreach ($uploadedFiles as $f): ?>
            <div class="uploaded-item <?php echo $f['status']; ?>">
                <span class="name"><?php echo htmlspecialchars($f['name']); ?></span>
               <?php if ($f['status'] === 'success'): ?>
                    <span class="size"><?php echo number_format($f['size'] / 1024, 1); ?> KB</span>
                    <span class="status success">✅ 成功</span>
                    <a href="?delete=<?php echo urlencode($f['name']); ?>" class="del-btn" onclick="return confirm('确认删除?')">删除</a>
                <?php else: ?>
                    <span class="status error">❌ <?php echo htmlspecialchars($f['error']); ?></span>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
    <?php endif ?>

    <div class="uploaded-list">
        <h2>📂 服务器上的文件</h2>
        <div class="stats">当前目录：<?php echo __DIR__; ?></div>
        <?php
        $files = scandir(__DIR__);
        $fileList = [];
        foreach ($files as $f) {
            if ($f === '.' || $f === '..' || $f === 'https://lmtoj.cn/batch_upload.php' || $f === 'file_admin.php') continue;
            $fullPath = __DIR__ . '/' . $f;
            if (is_file($fullPath)) {
                $fileList[] = ['name' => $f, 'size' => filesize($fullPath), 'mtime' => filemtime($fullPath)];
            }
        }
        usort($fileList, function($a, $b) { return $b['mtime'] - $a['mtime']; });
        ?>
        <?php if (empty($fileList)): ?>
            <p style="color:#ba090;font-size:14px;padding:12px;">暂无文件</p>
        <?php else: ?>
            <?php foreach ($fileList as $f): ?>
                <div class="ed-item success">
                    <span class="name">📄 <?php echo htmlspecialchars($f['name']); ?></span>
                    <span class="size"><?php echo number_format($f['size'] / 1024, 1); ?> KB</span>
                    <span class="size"><?php echo date('Y-m-d H:i', $f['mtime']); ?></span>
                    <a href="?delete=<?php echo urlencode($f['name']); ?>" class="del-btn" onclick="return confirm('确认删除?')">删除</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script>
const dropZone = document.getElementById('dropZone');
const fileInput =.getElementById('fileInput');
const fileList = document.getElementById('fileList');
const submitBtn = document.getElementById('submitBtn');
const progressBar = document.getElementById('progressBar');
const progressFill = document.getElementById('progressFill');

let selectedFiles = [];

// 拖拽事件
['dragenter', 'dragover', 'dragleave', 'drop'].forEach(evt => {
    dropZone.addEventListener(evt, preventDefaults, false);
});

function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
}

['dragenter', 'gover'].forEach(evt => {
    dropZone.addEventListener(evt, () => dropZone.classList.add('dragover'), false);
});

['dragleave', 'drop'].forEach(evt => {
    dropZone.addEventListener(evt, => dropZone.classList.remove('dragover'), false);
});

dropZone.addEventListener('', (e) => {
    const files = e.dataTransfer.files;
    handleFiles(f);
});

function handleFiles(files) {
    for (let i = ; i < files.length; i++) {
        // 检查是否已选择
        let exists = false;
        for (let j = ; j < selectedFiles.length; j++) {
            if (selectedFiles[j].name === files[i].name && selectedFiles[j].size === files[i].size) {
                exists = true;
                break;
            }
        }
        if (!exists) {
            selectedFiles.push(files[i]);
        }
    }
    renderFileList();
    updateSubmitBtn();
}

function renderFileList() {
    if (selectedFiles.length ) {
        fileList.innerHTML = '';
        return;
    }
    let html = '';
    selectedFiles.forEach((file, index) => {
        const size = file.size > 1024 * 1024 
            ? (file.size / 1024 / 1024).toFixed(1) + ' MB' 
            : (file.size / 1024).toFixed(1) + ' KB';
        html += `<div class="file-item">
            <span class="name">📄 ${file.name}</span>
            <span class="size">${size}</span>
            <span class="remove" onclick="removeFile(${index})">✕</span>
        </div>`;
    });
    fileList.innerHTML = html;
}

function removeFile(index) {
    selectedFiles.splice(index, 1);
    renderFileList    updateSubmitBtn();
    // 更新 fileInput 的 files
    updateFileInput();
}

function updateFileInput() {
    // 无法直接修改 FileList，所以用 DataTransfer
    const dt = new DataTransfer();
    selectedFiles.forEach(f =>.items.add(f));
    fileInput.files = dt.files;
}

function updateSubmitBtn() {
    submitBtn.disabled = selectedFiles.length === ;
}

// 表单提交时显示进度
document.getElementById('uploadForm').addEventListener('submit', function() {
    if (selectedFiles.length === ) return false;
    progressBar.style.display = 'block';
    submitBtn.disabled = true;
    submitBtn.textContent = '上传中...';
    
    // 更新 fileInput
    updateFileInput();
    
    // 模拟进度（实际进度由服务器返回后页面刷新）
    let progress = ;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress > 90) {
            progress = 90;
            clearInterval(interval);
        }
        progressFill.style.width = progress + '%';
    }, 300);
});
</script>
<?php include __DIR__ . 'https://lmtoj.cn/footer.php'; ?>
</body>
</html>
