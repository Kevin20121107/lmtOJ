<?php
// Lightweight .env loader. No Composer dependency is required.
if (!function_exists('loadEnvFile')) {
    function loadEnvFile(string $path): void
    {
        if (!is_file($path) || !is_readable($path)) {
            throw new RuntimeException('Missing environment file: ' . $path);
        }

        foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) {
                continue;
            }

            [$name, $value] = array_map('trim', explode('=', $line, 2));
            if ($name === '') {
                continue;
            }
            if (strlen($value) >= 2) {
                $quote = $value[0];
                if (($quote === '"' || $quote === "'") && substr($value, -1) === $quote) {
                    $value = substr($value, 1, -1);
                }
            }

            // Shared hosting providers may disable or isolate putenv(). Keep the
            // parsed value in PHP memory and only use the process environment as
            // an optional override.
            if (!array_key_exists($name, $_ENV)) {
                $_ENV[$name] = $value;
            }
            if (getenv($name) === false && function_exists('putenv')) {
                @putenv($name . '=' . $value);
            }
        }
    }
}

if (!function_exists('env')) {
    function env(string $name, ?string $default = null): ?string
    {
        if (array_key_exists($name, $_ENV)) {
            return (string) $_ENV[$name];
        }
        $value = getenv($name);
        return $value === false ? $default : $value;
    }
}

loadEnvFile(__DIR__ . '/.env');

// Backward compatibility for view.php, which expects config.php to return its password.
return env('VIEW_PASSWORD', '');
