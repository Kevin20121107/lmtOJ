<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT admin FROM users WHERE uid = $login_uid")->fetch_assoc();
if (!$userRow || (int)$userRow['admin'] !== 1) {
    http_response_code(403);
    exit('无权限访问');
}

// 工作目录
$workDir = __DIR__ . '/ai_browser';
if (!is_dir($workDir)) {
    mkdir($workDir, 0755, true);
}

$pythonScript = $workDir . '/ai_browser.py';
$taskFile = $workDir . '/task.txt';
$stopFile = $workDir . '/stop.flag';
$screenshotFile = $workDir . '/screenshot.png';
$statusFile = $workDir . '/status.txt';
$pidFile = $workDir . '/pid.txt';

// 处理 AJAX 请求
$action = $_GET['action'] ?? ($_POST['action'] ?? '');

switch ($action) {
    case 'start':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $requirement = trim($_POST['requirement'] ?? '');
            if ($requirement === '') {
                echo json_encode(['error' => '请输入需求']);
                exit;
            }

            // 清理旧任务
            @unlink($stopFile);
            @unlink($statusFile);
            @unlink($screenshotFile);
            file_put_contents($taskFile, $requirement);

            // 创建 Python 脚本（如果不存在）
            if (!file_exists($pythonScript)) {
                createPythonScript($pythonScript);
            }

            // 启动进程
            $cmd = "python3 " . escapeshellarg($pythonScript) . " " .
                   escapeshellarg($taskFile) . " " .
                   escapeshellarg($stopFile) . " " .
                   escapeshellarg($screenshotFile) . " " .
                   escapeshellarg($statusFile) . " " .
                   " > /dev/null 2>&1 & echo $!";
            $pid = trim(shell_exec($cmd));
            file_put_contents($pidFile, $pid);
            echo json_encode(['success' => true, 'pid' => $pid]);
        }
        exit;

    case 'stop':
        file_put_contents($stopFile, 'stop');
        echo json_encode(['success' => true]);
        exit;

    case 'screenshot':
        if (file_exists($screenshotFile) && filesize($screenshotFile) > 0) {
            header('Content-Type: image/png');
            header('Cache-Control: no-cache, no-store, must-revalidate');
            readfile($screenshotFile);
        } else {
            // 返回 1x1 透明 PNG
            header('Content-Type: image/png');
            echo base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=');
        }
        exit;

    case 'status':
        $status = 'idle';
        $pid = null;
        if (file_exists($pidFile)) {
            $pid = trim(file_get_contents($pidFile));
        }
        if ($pid && shell_exec("ps -p $pid -o pid= 2>/dev/null")) {
            $status = 'running';
            if (file_exists($stopFile)) {
                $status = 'stopping';
            }
        } elseif ($pid) {
            $status = 'stopped';
        }
        if (file_exists($statusFile)) {
            $fileStatus = trim(file_get_contents($statusFile));
            if ($fileStatus === 'completed') {
                $status = 'completed';
            } elseif ($fileStatus === 'stopped') {
                $status = 'stopped';
            }
        }
        echo json_encode(['status' => $status, 'pid' => $pid]);
        exit;

    default:
        break;
}

/**
 * 创建 Python 自动化脚本
 */
function createPythonScript($file) {
    $python = <<<'PY'
import sys, json, time, os, requests
from playwright.sync_api import sync_playwright

DEEPSEEK_API_KEY = "sk-f01bb88531d647709551e56ec35bcf6a"
MODEL = "deepseek-v4-flash"
BASE_URL = "https://api.deepseek.com/chat/completions"

def call_deepseek(messages):
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": MODEL,
        "messages": messages,
        "temperature": 0.1,
        "max_tokens": 800
    }
    resp = requests.post(BASE_URL, headers=headers, json=payload, timeout=60)
    resp.raise_for_status()
    return resp.json()["choices"][0]["message"]["content"]

def get_page_description(page):
    url = page.url
    title = page.title()
    elements = page.evaluate("""() => {
        const items = [];
        const selector = 'button, a, input, textarea, select, [role="button"], [onclick], [href]';
        document.querySelectorAll(selector).forEach((el, index) => {
            if (index > 120) return;
            const rect = el.getBoundingClientRect();
            if (rect.width === 0 || rect.height === 0) return;
            const text = (el.innerText || el.value || el.getAttribute('aria-label') || el.getAttribute('placeholder') || '').trim().substring(0, 60);
            const tag = el.tagName.toLowerCase();
            const id = el.id ? '#' + el.id : '';
            const classes = el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').join('.') : '';
            const type = el.getAttribute('type') || '';
            const href = el.getAttribute('href') || '';
            const name = el.getAttribute('name') || '';
            const selectorStr = id || (classes ? tag + classes : tag);
            items.push({
                index: index,
                tag: tag,
                text: text,
                id: id,
                classes: classes,
                type: type,
                href: href,
                name: name,
                selector: selectorStr,
                x: Math.round(rect.x + rect.width / 2),
                y: Math.round(rect.y + rect.height / 2)
            });
        });
        return items;
    }""")
    desc = f"当前URL: {url}\n标题: {title}\n可交互元素列表:\n"
    for idx, el in enumerate(elements):
        desc += f"[{idx}] <{el['tag']}> text='{el['text']}' id='{el['id']}' class='{el['classes']}' type='{el['type']}' href='{el['href']}' selector='{el['selector']}' center=({el['x']},{el['y']})\n"
    return desc

def execute_action(page, action):
    action_type = action.get("action")
    try:
        if action_type == "click":
            selector = action.get("selector")
            try:
                page.click(selector, timeout=5000)
            except:
                text = action.get("text") or selector
                page.click(f"text={text}", timeout=5000)
        elif action_type == "type":
            selector = action.get("selector")
            text = action.get("text", "")
            try:
                page.fill(selector, text, timeout=5000)
            except:
                page.type(selector, text, timeout=5000)
        elif action_type == "scroll":
            direction = action.get("direction", "down")
            if direction == "down":
                page.evaluate("window.scrollBy(0, 500)")
            elif direction == "up":
                page.evaluate("window.scrollBy(0, -500)")
        elif action_type == "goto":
            url = action.get("url")
            if url:
                page.goto(url, timeout=10000)
        elif action_type == "press":
            key = action.get("key", "Enter")
            page.keyboard.press(key)
        elif action_type == "stop":
            return False
    except Exception as e:
        print(f"执行操作出错: {e}")
    return True

def main():
    task_file = sys.argv[1]
    stop_flag = sys.argv[2]
    screenshot_path = sys.argv[3]
    status_file = sys.argv[4]

    with open(task_file, 'r', encoding='utf-8') as f:
        requirement = f.read().strip()

    conversation = [
        {"role": "system", "content": "你是一个浏览器自动化助手，根据用户需求和当前页面元素信息，给出下一步操作指令。输出必须是JSON格式：{\"action\": \"click\"|\"type\"|\"scroll\"|\"goto\"|\"stop\", \"selector\": \"CSS选择器或文本\", \"text\": \"输入内容\", \"url\": \"目标URL\", \"direction\": \"滚动方向\", \"key\": \"按键\", \"explanation\": \"简短说明\"}。对于click/type需要selector；type还需要text；scroll需要direction；goto需要url；stop表示任务完成。请确保操作安全可行。"},
        {"role": "user", "content": f"用户需求：{requirement}"}
    ]

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto("https://lmtoj.cn", timeout=15000)
        page.screenshot(path=screenshot_path)

        step = 0
        while True:
            if os.path.exists(stop_flag):
                with open(status_file, 'w') as f:
                    f.write("stopped")
                break

            page_desc = get_page_description(page)
            page.screenshot(path=screenshot_path)

            messages = conversation + [{"role": "user", "content": f"当前页面状态：\n{page_desc}\n请给出下一步操作指令（JSON格式）。如果已经完成任务，请返回action为stop。"}]
            try:
                ai_reply = call_deepseek(messages)
                clean = ai_reply.strip()
                if clean.startswith("```"):
                    clean = clean.split('\n', 1)[-1]
                    if clean.endswith("```"):
                        clean = clean[:-3]
                clean = clean.strip()
                action = json.loads(clean)

                conversation.append({"role": "assistant", "content": ai_reply})
                conversation.append({"role": "user", "content": f"已执行操作：{action.get('action')}，继续下一步。"})

                if not execute_action(page, action):
                    with open(status_file, 'w') as f:
                        f.write("completed")
                    break

                step += 1
                time.sleep(1.5)
            except Exception as e:
                with open(status_file, 'w') as f:
                    f.write("error")
                print(f"AI决策或执行错误: {e}")
                break

        browser.close()

if __name__ == "__main__":
    main()
PY;
    file_put_contents($file, $python);
}

// 获取当前任务状态（用于页面初始显示）
$currentStatus = 'idle';
$currentPid = null;
if (file_exists($pidFile)) {
    $currentPid = trim(file_get_contents($pidFile));
}
if ($currentPid && shell_exec("ps -p $currentPid -o pid= 2>/dev/null")) {
    $currentStatus = 'running';
    if (file_exists($stopFile)) {
        $currentStatus = 'stopping';
    }
} elseif ($currentPid) {
    $currentStatus = 'stopped';
}
if (file_exists($statusFile)) {
    $fileStatus = trim(file_get_contents($statusFile));
    if ($fileStatus === 'completed') {
        $currentStatus = 'completed';
    } elseif ($fileStatus === 'stopped') {
        $currentStatus = 'stopped';
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>AI 社区管理控制台</title>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --text: #2c2a28;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif; color:var(--text); line-height:1.6; padding:20px; }
        .container { max-width: 1200px; margin:0 auto; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:24px 28px; box-shadow:var(--shadow); margin-bottom:20px; }
        h1 { font-size:22px; margin-bottom:20px; }
        .form-group { margin-bottom:15px; }
        .form-group label { display:block; font-weight:500; margin-bottom:5px; }
        .form-control { width:100%; padding:10px 14px; border:1.5px solid var(--border); border-radius:6px; font-size:14px; outline:none; }
        .form-control:focus { border-color:var(--accent); }
        .btn { padding:10px 24px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:14px; font-weight:500; transition:0.2s; }
        .btn:hover { background:var(--accent-hover); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:#c9302c; }
        .btn:disabled { opacity:0.5; cursor:not-allowed; }
        .status-badge { display:inline-block; padding:4px 14px; border-radius:12px; font-size:13px; font-weight:600; }
        .status-idle { background:#e0e0e0; color:#555; }
        .status-running { background:#c8e6c9; color:#2e7d32; }
        .status-stopping { background:#fff3e0; color:#e65100; }
        .status-stopped { background:#ffcdd2; color:#c62828; }
        .status-completed { background:#bbdefb; color:#1565c0; }
        .screenshot-container { margin-top:20px; text-align:center; }
        .screenshot-container img { max-width:100%; border:1px solid var(--border); border-radius:8px; }
        .info { color:var(--text-muted); font-size:14px; margin-top:10px; }
    </style>
</head>
<body>
<div class="container">
    <div class="card">
        <h1>🤖 AI 社区管理控制台</h1>
        <div style="margin-bottom:15px;">
            <span>当前状态：</span>
            <span id="statusBadge" class="status-badge status-<?= $currentStatus ?>"><?= ucfirst($currentStatus) ?></span>
            <?php if ($currentPid): ?><span class="info">PID: <?= htmlspecialchars($currentPid) ?></span><?php endif; ?>
        </div>
        <div class="form-group">
            <label for="requirement">输入需求（告诉 AI 要做什么）</label>
            <textarea id="requirement" class="form-control" rows="3" placeholder="例如：登录社区，查看最新帖子，回复一条欢迎消息"></textarea>
        </div>
        <div style="display:flex; gap:10px;">
            <button id="btnStart" class="btn">启动 AI</button>
            <button id="btnStop" class="btn btn-danger" disabled>停止 AI</button>
        </div>
        <p class="info">启动后，AI 将自动操作浏览器，实时画面显示在下方。你可以随时点击“停止”终止任务。</p>
    </div>

    <div class="card screenshot-container">
        <h3 style="text-align:left; margin-bottom:10px;">🖥 AI 浏览器实时画面</h3>
        <img id="screenshot" src="?action=screenshot&t=<?= time() ?>" alt="AI 浏览器画面">
        <p id="hint" class="info">暂无画面，启动后自动刷新。</p>
    </div>
</div>

<script>
    let statusTimer = null;
    let screenshotTimer = null;

    function updateStatus() {
        fetch('?action=status')
            .then(r => r.json())
            .then(data => {
                const status = data.status;
                const badge = document.getElementById('statusBadge');
                badge.className = 'status-badge status-' + status;
                badge.textContent = status.charAt(0).toUpperCase() + status.slice(1);
                const btnStart = document.getElementById('btnStart');
                const btnStop = document.getElementById('btnStop');
                if (status === 'running') {
                    btnStart.disabled = true;
                    btnStop.disabled = false;
                } else if (status === 'stopping') {
                    btnStart.disabled = true;
                    btnStop.disabled = true;
                } else {
                    btnStart.disabled = false;
                    btnStop.disabled = true;
                }
            });
    }

    function refreshScreenshot() {
        const img = document.getElementById('screenshot');
        img.src = '?action=screenshot&t=' + Date.now();
    }

    document.getElementById('btnStart').addEventListener('click', function() {
        const requirement = document.getElementById('requirement').value.trim();
        if (!requirement) {
            alert('请输入需求');
            return;
        }
        if (!confirm('确定启动 AI 执行此需求吗？')) return;
        fetch('?action=start', {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'requirement=' + encodeURIComponent(requirement)
        })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                alert('AI 已启动，PID: ' + data.pid);
                document.getElementById('btnStart').disabled = true;
                document.getElementById('btnStop').disabled = false;
                startTimers();
            } else {
                alert('启动失败：' + (data.error || '未知错误'));
            }
        });
    });

    document.getElementById('btnStop').addEventListener('click', function() {
        if (!confirm('确定停止 AI 操作吗？')) return;
        fetch('?action=stop')
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    alert('停止指令已发送，AI 将在当前步骤后停止');
                    document.getElementById('btnStop').disabled = true;
                }
            });
    });

    function startTimers() {
        if (statusTimer) clearInterval(statusTimer);
        if (screenshotTimer) clearInterval(screenshotTimer);
        statusTimer = setInterval(updateStatus, 2000);
        screenshotTimer = setInterval(refreshScreenshot, 2000);
    }

    // 页面加载时启动定时器
    startTimers();
    updateStatus();
</script>
</body>
</html>