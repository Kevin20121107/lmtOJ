<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 登录检查
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];

// 权限检查
$isAdmin = false;
$adminRes = $conn->query("SELECT admin, devadmin FROM users WHERE uid = $login_uid LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $adminRow = $adminRes->fetch_assoc();
    $isAdmin = ($adminRow['admin'] == 1 || $adminRow['devadmin'] == 1);
}

// 常量定义
define('MODEL_CACHE_FILE', __DIR__ . '/ai-chat-model.cache');
define('PROGRESS_FILE', __DIR__ . '/ai-chat-progress.txt');
define('LOCK_FILE', __DIR__ . '/ai-chat-build.lock');
define('NGRAM_N', 2);
define('MAX_GEN_LENGTH', 80);

// 处理 AJAX 动作
$action = $_GET['action'] ?? '';

if ($action === 'start_build' && $isAdmin) {
    // 启动构建，并立即返回响应
    if (function_exists('fastcgi_finish_request')) {
        // 先发送 JSON 响应给前端
        header('Content-Type: application/json');
        echo json_encode(['status' => 'started']);
        fastcgi_finish_request();
        // 关闭 session 以允许后续请求
        session_write_close();
        // 后台构建
        ignore_user_abort(true);
        set_time_limit(0);
        buildModel();
        exit;
    } else {
        // 不支持 fastcgi_finish_request 的环境，使用 ob_flush 技巧
        ignore_user_abort(true);
        set_time_limit(0);
        session_write_close();
        header('Content-Type: application/json');
        echo json_encode(['status' => 'started']);
        header('Content-Length: ' . ob_get_length());
        header('Connection: close');
        ob_end_flush();
        flush();
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
        // 继续后台构建
        buildModel();
        exit;
    }
}

if ($action === 'get_progress') {
    $progress = 0;
    if (file_exists(PROGRESS_FILE)) {
        $progress = (int)file_get_contents(PROGRESS_FILE);
        $progress = max(0, min(100, $progress));
    }
    echo json_encode(['progress' => $progress]);
    exit;
}

// ========== 构建模型函数 ==========
function buildModel() {
    // 检查锁，防止并发构建
    $lock = @fopen(LOCK_FILE, 'x');
    if (!$lock) {
        // 已有构建在进行
        return;
    }
    fclose($lock);
    
    // 初始化进度
    file_put_contents(PROGRESS_FILE, '0');
    
    global $conn;
    $model = [];
    $texts = [];
    
    // 读取所有犇犇
    $res = $conn->query("SELECT text FROM benben ORDER BY id ASC");
    if (!$res) {
        @unlink(LOCK_FILE);
        file_put_contents(PROGRESS_FILE, '100');
        return;
    }
    
    while ($row = $res->fetch_assoc()) {
        $text = $row['text'];
        // 清洗文本
        $text = preg_replace('/!\[[^\]]*\]\([^)]*\)/', '', $text);
        $text = preg_replace('/\[[^\]]*\]\([^)]*\)/', '', $text);
        $text = preg_replace('/```[\s\S]*?```/', '', $text);
        $text = preg_replace('/`[^`]*`/', '', $text);
        $text = preg_replace('/@[\w_\x{4e00}-\x{9fa5}]+/u', '', $text);
        $text = preg_replace('/https?:\/\/\S+/', '', $text);
        $text = preg_replace('/\s+/', ' ', $text);
        $text = trim($text);
        if ($text !== '') {
            $texts[] = $text;
        }
    }
    $res->free();
    
    // 拼接所有字符
    $allChars = [];
    foreach ($texts as $text) {
        $chars = preg_split('//u', $text, -1, PREG_SPLIT_NO_EMPTY);
        $allChars = array_merge($allChars, $chars);
    }
    $totalChars = count($allChars);
    
    $n = NGRAM_N;
    if ($totalChars >= $n) {
        $step = max(1, intdiv($totalChars, 100));
        $nextUpdate = $step;
        for ($i = 0; $i <= $totalChars - $n; $i++) {
            $prefix = '';
            for ($j = 0; $j < $n - 1; $j++) {
                $prefix .= $allChars[$i + $j];
            }
            $next = $allChars[$i + $n - 1];
            if (!isset($model[$prefix])) {
                $model[$prefix] = [];
            }
            if (!isset($model[$prefix][$next])) {
                $model[$prefix][$next] = 0;
            }
            $model[$prefix][$next]++;
            
            if ($i >= $nextUpdate) {
                $progress = min(99, intval(($i / $totalChars) * 100));
                file_put_contents(PROGRESS_FILE, (string)$progress);
                $nextUpdate += $step;
            }
        }
    }
    
    // 写入缓存
    file_put_contents(MODEL_CACHE_FILE, serialize($model));
    file_put_contents(PROGRESS_FILE, '100');
    
    // 释放锁
    @unlink(LOCK_FILE);
}

// ========== 聊天生成函数 ==========
function getNextChar($model, $prefix) {
    if (!isset($model[$prefix]) || empty($model[$prefix])) return null;
    $total = array_sum($model[$prefix]);
    $rand = mt_rand(1, $total);
    $cumulative = 0;
    foreach ($model[$prefix] as $char => $count) {
        $cumulative += $count;
        if ($rand <= $cumulative) return $char;
    }
    return null;
}

function generateReply($model, $input, $maxLen = MAX_GEN_LENGTH) {
    $n = NGRAM_N;
    $inputChars = preg_split('//u', $input, -1, PREG_SPLIT_NO_EMPTY);
    if (count($inputChars) < $n - 1) {
        $prefixes = array_keys($model);
        $prefix = $prefixes[array_rand($prefixes)];
    } else {
        $prefix = implode('', array_slice($inputChars, -($n - 1)));
    }
    $result = $prefix;
    for ($i = 0; $i < $maxLen; $i++) {
        $next = getNextChar($model, $prefix);
        if ($next === null) break;
        $result .= $next;
        if (mb_strlen($prefix) >= $n - 1) {
            $prefix = mb_substr($prefix, 1) . $next;
        } else {
            $prefix .= $next;
        }
        if (in_array($next, ['。', '！', '？', '!', '?', '；', ';'])) {
            if (mt_rand(0, 1) === 0) break;
        }
    }
    return $result;
}

// ========== 处理聊天 POST ==========
$reply = '';
$userInput = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $userInput = trim($_POST['message']);
    if ($userInput !== '') {
        if (file_exists(MODEL_CACHE_FILE)) {
            $model = @unserialize(file_get_contents(MODEL_CACHE_FILE));
            if ($model !== false && !empty($model)) {
                $reply = generateReply($model, $userInput);
                $reply = preg_replace('/\s+/', ' ', $reply);
            } else {
                $reply = '模型数据为空，请管理员重新统计。';
            }
        } else {
            $reply = '模型尚未统计，请稍后再试。';
        }
    }
}

// 获取模型状态
$modelExists = file_exists(MODEL_CACHE_FILE);
$modelSize = $modelExists ? filesize(MODEL_CACHE_FILE) : 0;
$benCount = $conn->query("SELECT COUNT(*) AS cnt FROM benben")->fetch_assoc()['cnt'];

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>犇犇 AI 聊天 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .main{max-width:800px;margin:28px auto 40px;padding:0 20px;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:16px;}
        .chat-box{height:400px;overflow-y:auto;border:1px solid var(--border);border-radius:var(--radius-sm);padding:15px;background:#fafaf8;margin-bottom:16px;}
        .msg{display:flex;margin-bottom:12px;}
        .msg .bubble{max-width:80%;padding:10px 14px;border-radius:16px;font-size:14px;line-height:1.6;word-wrap:break-word;}
        .msg.user{justify-content:flex-end;}
        .msg.user .bubble{background:var(--accent);color:#fff;border-bottom-right-radius:4px;}
        .msg.ai{justify-content:flex-start;}
        .msg.ai .bubble{background:#fff;border:1px solid var(--border);color:var(--text);border-bottom-left-radius:4px;}
        .input-area{display:flex;gap:10px;}
        .input-area input{flex:1;padding:10px 14px;border:1.5px solid var(--border);border-radius:20px;font-size:14px;outline:none;background:#fdfdfc;font-family:var(--font);}
        .input-area input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);}
        .input-area button{padding:10px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);}
        .input-area button:hover{background:var(--accent-hover);}
        .model-info{font-size:13px;color:var(--text-muted);margin-bottom:10px;}
        .progress-container{display:none;margin-top:15px;}
        .progress-bar{width:100%;height:20px;background:var(--border-light);border-radius:10px;overflow:hidden;}
        .progress-fill{height:100%;width:0%;background:var(--accent);transition:width 0.3s;}
        .progress-text{text-align:center;font-size:13px;color:var(--text-secondary);margin-top:5px;}
        @media(max-width:768px){.main{padding:0 12px;}.card{padding:18px 14px;}.chat-box{height:300px;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <div class="card">
        <h2>🤖 犇犇 AI 聊天</h2>
        <div class="model-info">
            当前模型状态：<?= $modelExists ? '已缓存（' . round($modelSize/1024, 2) . ' KB）' : '未统计' ?> | 犇犇总数：<?= $benCount ?>
        </div>
        <?php if ($isAdmin): ?>
        <div style="margin-bottom:15px;">
            <button onclick="startBuild()" id="buildBtn" class="btn" style="background:var(--accent);color:#fff;padding:8px 18px;border:none;border-radius:20px;cursor:pointer;">重新统计模型</button>
        </div>
        <div class="progress-container" id="progressContainer">
            <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
            <div class="progress-text" id="progressText">0%</div>
        </div>
        <?php endif; ?>

        <div class="chat-box" id="chatBox">
            <div class="msg ai">
                <div class="bubble">你好！我是基于犇犇内容训练的 n-gram 模型。<?= $modelExists ? '可以开始聊天。' : '请等待管理员完成统计。' ?></div>
            </div>
            <?php if ($userInput !== ''): ?>
                <div class="msg user"><div class="bubble"><?=safeContent($userInput)?></div></div>
                <div class="msg ai"><div class="bubble"><?=safeContent($reply)?></div></div>
            <?php endif; ?>
        </div>
        <form method="post" class="input-area">
            <input type="text" name="message" placeholder="输入消息..." required autocomplete="off" <?= !$modelExists ? 'disabled' : '' ?>>
            <button type="submit" <?= !$modelExists ? 'disabled' : '' ?>>发送</button>
        </form>
    </div>
</div>

<script>
const chatBox = document.getElementById('chatBox');
chatBox.scrollTop = chatBox.scrollHeight;

<?php if ($isAdmin): ?>
function startBuild() {
    const btn = document.getElementById('buildBtn');
    btn.disabled = true;
    btn.textContent = '构建中...';
    const container = document.getElementById('progressContainer');
    container.style.display = 'block';

    fetch('?action=start_build', { method: 'POST' })
        .then(res => res.json())
        .then(data => {
            if (data.status === 'started') {
                pollProgress();
            } else {
                alert('启动失败');
                btn.disabled = false;
                btn.textContent = '重新统计模型';
            }
        })
        .catch(err => {
            alert('请求失败，请检查服务器配置');
            btn.disabled = false;
            btn.textContent = '重新统计模型';
        });
}

function pollProgress() {
    const interval = setInterval(async () => {
        try {
            const res = await fetch('?action=get_progress');
            const data = await res.json();
            const progress = data.progress || 0;
            document.getElementById('progressFill').style.width = progress + '%';
            document.getElementById('progressText').textContent = progress + '%';
            if (progress >= 100) {
                clearInterval(interval);
                setTimeout(() => {
                    document.getElementById('buildBtn').disabled = false;
                    document.getElementById('buildBtn').textContent = '重新统计模型';
                    document.getElementById('progressContainer').style.display = 'none';
                    alert('模型统计完成！');
                    location.reload();
                }, 500);
            }
        } catch (e) {
            clearInterval(interval);
        }
    }, 1000);
}
<?php endif; ?>
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>