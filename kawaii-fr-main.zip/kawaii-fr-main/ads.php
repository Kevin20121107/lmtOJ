<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>可嵌入图片轮播组件</title>
    <style>
        :root {
            --carousel-width: 100%;
            --carousel-height: 420px;
            --carousel-radius: 16px;
            --carousel-arrow-bg: rgba(0, 0, 0, 0.45);
            --carousel-arrow-hover: rgba(0, 0, 0, 0.7);
            --carousel-arrow-size: 44px;
            --carousel-dot-size: 10px;
            --carousel-dot-active: #ffffff;
            --carousel-dot-inactive: rgba(255, 255, 255, 0.5);
            --carousel-transition: 0.55s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            --carousel-caption-bg: linear-gradient(transparent, rgba(0, 0, 0, 0.6));
            --carousel-caption-color: #fff;
        }

        .emb-carousel {
            position: relative;
            width: var(--carousel-width);
            max-width: 100%;
            height: var(--carousel-height);
            border-radius: var(--carousel-radius);
            overflow: hidden;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            user-select: none;
            -webkit-user-select: none;
            touch-action: pan-y pinch-zoom;
            background: #1a1a2e;
        }

        .emb-carousel-track {
            position: relative;
            width: 100%;
            height: 100%;
            display: flex;
            transition: transform var(--carousel-transition);
            will-change: transform;
        }

        .emb-carousel-slide {
            flex: 0 0 100%;
            height: 100%;
            position: relative;
            overflow: hidden;
            display: block;
            text-decoration: none;
            cursor: pointer;
            -webkit-tap-highlight-color: transparent;
        }

        .emb-carousel-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            pointer-events: none;
            -webkit-user-drag: none;
            user-select: none;
            -webkit-user-select: none;
            /* 已移除缩放过渡和悬停放大效果 */
        }

        /* ========== 图片底部遮罩和标题 ========== */
        .emb-carousel-caption {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 40px 20px 16px;
            background: var(--carousel-caption-bg);
            color: var(--carousel-caption-color);
            font-size: 15px;
            font-weight: 500;
            letter-spacing: 0.5px;
            pointer-events: none;
            opacity: 0;
            transform: translateY(8px);
            transition: opacity 0.4s ease, transform 0.4s ease;
        }

        .emb-carousel-slide.active .emb-carousel-caption {
            opacity: 1;
            transform: translateY(0);
        }

        /* ========== 左右箭头 ========== */
        .emb-carousel-arrow {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: var(--carousel-arrow-size);
            height: var(--carousel-arrow-size);
            background: var(--carousel-arrow-bg);
            border: none;
            border-radius: 50%;
            color: #fff;
            font-size: 18px;
            line-height: 1;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.25s ease, transform 0.25s ease, opacity 0.25s ease;
            z-index: 10;
            opacity: 0;
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            outline: none;
            -webkit-tap-highlight-color: transparent;
        }

        .emb-carousel-arrow:hover {
            background: var(--carousel-arrow-hover);
            transform: translateY(-50%) scale(1.1);
        }
        .emb-carousel-arrow:active {
            transform: translateY(-50%) scale(0.95);
        }

        .emb-carousel-arrow--prev {
            left: 16px;
        }
        .emb-carousel-arrow--next {
            right: 16px;
        }

        .emb-carousel:hover .emb-carousel-arrow {
            opacity: 1;
        }

        @media (hover: none) {
            .emb-carousel-arrow {
                opacity: 0.7;
            }
            .emb-carousel-arrow:active {
                opacity: 1;
            }
        }

        /* ========== 指示器小圆点 ========== */
        .emb-carousel-dots {
            position: absolute;
            bottom: 16px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 8px;
            z-index: 10;
            padding: 6px 12px;
            border-radius: 20px;
            background: rgba(0, 0, 0, 0.3);
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur(8px);
        }

        .emb-carousel-dot {
            width: var(--carousel-dot-size);
            height: var(--carousel-dot-size);
            border-radius: 50%;
            border: none;
            background: var(--carousel-dot-inactive);
            cursor: pointer;
            padding: 0;
            transition: background 0.3s ease, transform 0.3s ease;
            outline: none;
            -webkit-tap-highlight-color: transparent;
        }

        .emb-carousel-dot:hover {
            background: rgba(255, 255, 255, 0.75);
            transform: scale(1.2);
        }

        .emb-carousel-dot.active {
            background: var(--carousel-dot-active);
            transform: scale(1.3);
            box-shadow: 0 0 8px rgba(255, 255, 255, 0.6);
        }

        /* ========== 响应式 ========== */
        @media (max-width: 768px) {
            :root {
                --carousel-height: 260px;
                --carousel-arrow-size: 36px;
                --carousel-radius: 12px;
            }
            .emb-carousel-arrow {
                font-size: 14px;
            }
            .emb-carousel-caption {
                font-size: 13px;
                padding: 30px 14px 12px;
            }
            .emb-carousel-dots {
                bottom: 10px;
                gap: 6px;
                padding: 5px 10px;
            }
        }

        @media (max-width: 480px) {
            :root {
                --carousel-height: 200px;
                --carousel-arrow-size: 30px;
                --carousel-radius: 10px;
            }
            .emb-carousel-arrow {
                font-size: 12px;
                opacity: 0.6;
            }
            .emb-carousel-dot {
                width: 8px;
                height: 8px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .emb-carousel-track {
                transition: none;
            }
        }
    </style>
</head>
<body>

    <div class="emb-carousel" id="emb-carousel" role="region" aria-label="图片轮播" aria-roledescription="carousel">
        <div class="emb-carousel-track" id="emb-carousel-track"></div>

        <button class="emb-carousel-arrow emb-carousel-arrow--prev" id="emb-carousel-prev"
        aria-label="上一张" type="button">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 18 9 12 15 6"></polyline>
        </svg>
    </button>

    <button class="emb-carousel-arrow emb-carousel-arrow--next" id="emb-carousel-next"
    aria-label="下一张" type="button">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <polyline points="9 18 15 12 9 6"></polyline>
    </svg>
</button>

<div class="emb-carousel-dots" id="emb-carousel-dots" role="tablist"></div>
</div>

<script>
    (function() {
        'use strict';

        /**
         * ============================================
         *  🎠  轮播配置 - 在这里修改你的图片列表
         * ============================================
         */
        const carouselConfig = {
            slides: [
                { img: 'https://picsum.photos/id/1015/1200/600', link: 'https://example.com/mountain', title: '🏔️ 壮丽山脉', alt: '壮丽的山脉风景' },
                { img: 'https://picsum.photos/id/1016/1200/600', link: 'https://example.com/canyon', title: '🏜️ 峡谷风光', alt: '峡谷风光' },
                { img: 'https://picsum.photos/id/1018/1200/600', link: '', title: '🌄 山谷晨雾', alt: '山谷晨雾' },
                { img: 'https://picsum.photos/id/1035/1200/600', link: 'https://example.com/river', title: '🌊 河流与森林', alt: '河流与森林' },
                { img: 'https://picsum.photos/id/1043/1200/600', link: 'https://example.com/lake', title: '🏞️ 湖畔日落', alt: '湖畔日落' }
            ],
            autoplay: true,
            autoplayInterval: 4000,
            loop: true,
            showDots: true,
            showArrows: true,
            showCaption: true,
            startIndex: 0,
        };

        const container = document.getElementById('emb-carousel');
        const track = document.getElementById('emb-carousel-track');
        const dotsContainer = document.getElementById('emb-carousel-dots');
        const prevBtn = document.getElementById('emb-carousel-prev');
        const nextBtn = document.getElementById('emb-carousel-next');

        if (!container || !track || !dotsContainer || !prevBtn || !nextBtn) return;

        const slidesData = carouselConfig.slides || [];
        if (slidesData.length === 0) return;

        let currentIndex = carouselConfig.startIndex || 0;
        if (currentIndex < 0 || currentIndex >= slidesData.length) currentIndex = 0;
        let autoplayTimer = null;
        let isTransitioning = false;
        let touchStartX = 0;
        let touchDeltaX = 0;

        function buildCarousel() {
            slidesData.forEach((slide, index) => {
                const slideEl = document.createElement(slide.link ? 'a' : 'div');
                slideEl.className = 'emb-carousel-slide';
                if (index === currentIndex) slideEl.classList.add('active');
                if (slide.link) {
                    slideEl.href = slide.link;
                    if (slide.link.startsWith('http')) {
                        slideEl.target = '_blank';
                        slideEl.rel = 'noopener noreferrer';
                    }
                }
                slideEl.setAttribute('data-index', index);
                slideEl.setAttribute('role', 'group');
                slideEl.setAttribute('aria-roledescription', 'slide');
                slideEl.setAttribute('aria-label', `${index + 1} / ${slidesData.length}`);

                const img = document.createElement('img');
                img.src = slide.img;
                img.alt = slide.alt || slide.title || `图片 ${index + 1}`;
                img.loading = index === 0 ? 'eager' : 'lazy';
                img.draggable = false;

                slideEl.appendChild(img);

                if (carouselConfig.showCaption && slide.title) {
                    const caption = document.createElement('div');
                    caption.className = 'emb-carousel-caption';
                    caption.textContent = slide.title;
                    slideEl.appendChild(caption);
                }

                track.appendChild(slideEl);
            });

            if (carouselConfig.showDots) {
                slidesData.forEach((_, index) => {
                    const dot = document.createElement('button');
                    dot.className = 'emb-carousel-dot';
                    if (index === currentIndex) dot.classList.add('active');
                    dot.setAttribute('data-index', index);
                    dot.setAttribute('role', 'tab');
                    dot.setAttribute('aria-label', `跳转到第 ${index + 1} 张图片`);
                    dot.setAttribute('aria-selected', index === currentIndex ? 'true' : 'false');
                    dot.type = 'button';
                    dot.addEventListener('click', () => goToSlide(index));
                    dotsContainer.appendChild(dot);
                });
            } else {
                dotsContainer.style.display = 'none';
            }

            if (!carouselConfig.showArrows) {
                prevBtn.style.display = 'none';
                nextBtn.style.display = 'none';
            }

            updateArrowVisibility();
            updateTrackPosition(false);
        }

        function updateTrackPosition(animate = true) {
            if (!animate) {
                track.style.transition = 'none';
            } else {
                track.style.transition = '';
            }
            track.style.transform = `translateX(-${currentIndex * 100}%)`;

            if (!animate) {
                void track.offsetHeight;
                track.style.transition = '';
            }
        }

        function updateActiveStates() {
            const slides = track.querySelectorAll('.emb-carousel-slide');
            slides.forEach((slide, index) => {
                slide.classList.toggle('active', index === currentIndex);
            });

            const dots = dotsContainer.querySelectorAll('.emb-carousel-dot');
            dots.forEach((dot, index) => {
                dot.classList.toggle('active', index === currentIndex);
                dot.setAttribute('aria-selected', index === currentIndex ? 'true' : 'false');
            });

            updateArrowVisibility();
        }

        function updateArrowVisibility() {
            if (carouselConfig.loop || !carouselConfig.showArrows) return;
            prevBtn.style.opacity = currentIndex === 0 ? '0.3' : '';
            prevBtn.style.pointerEvents = currentIndex === 0 ? 'none' : '';
            nextBtn.style.opacity = currentIndex === slidesData.length - 1 ? '0.3' : '';
            nextBtn.style.pointerEvents = currentIndex === slidesData.length - 1 ? 'none' : '';
        }

        function goToSlide(index, userInitiated = true) {
            if (isTransitioning) return;

            const slidesCount = slidesData.length;
            let targetIndex = index;

            if (carouselConfig.loop) {
                if (targetIndex < 0) targetIndex = slidesCount - 1;
                if (targetIndex >= slidesCount) targetIndex = 0;
            } else {
                if (targetIndex < 0) targetIndex = 0;
                if (targetIndex >= slidesCount) targetIndex = slidesCount - 1;
            }

            if (targetIndex === currentIndex) return;

            isTransitioning = true;
            currentIndex = targetIndex;
            updateTrackPosition(true);
            updateActiveStates();

            setTimeout(() => {
                isTransitioning = false;
            }, 550);

            if (userInitiated) resetAutoplay();
        }

        function nextSlide() { goToSlide(currentIndex + 1); }
        function prevSlide() { goToSlide(currentIndex - 1); }

        function startAutoplay() {
            if (!carouselConfig.autoplay || slidesData.length <= 1) return;
            stopAutoplay();
            autoplayTimer = setInterval(() => {
                if (carouselConfig.loop || currentIndex < slidesData.length - 1) {
                    nextSlide();
                } else {
                    stopAutoplay();
                }
            }, carouselConfig.autoplayInterval);
        }

        function stopAutoplay() {
            if (autoplayTimer) {
                clearInterval(autoplayTimer);
                autoplayTimer = null;
            }
        }

        function resetAutoplay() {
            if (carouselConfig.autoplay) startAutoplay();
        }

        function handleTouchStart(e) {
            touchStartX = e.touches[0].clientX;
            touchDeltaX = 0;
            stopAutoplay();
        }

        function handleTouchMove(e) {
            touchDeltaX = e.touches[0].clientX - touchStartX;
        }

        function handleTouchEnd() {
            const threshold = 50;
            if (touchDeltaX > threshold) prevSlide();
            else if (touchDeltaX < -threshold) nextSlide();
            resetAutoplay();
        }

        let isDragging = false;
        let dragStartX = 0;
        let dragDeltaX = 0;

        function handleMouseDown(e) {
            if (e.button !== 0) return;
            isDragging = true;
            dragStartX = e.clientX;
            dragDeltaX = 0;
            stopAutoplay();
            track.style.cursor = 'grabbing';
            e.preventDefault();
        }

        function handleMouseMove(e) {
            if (!isDragging) return;
            dragDeltaX = e.clientX - dragStartX;
        }

        function handleMouseUp() {
            if (!isDragging) return;
            isDragging = false;
            track.style.cursor = '';
            const threshold = 50;
            if (dragDeltaX > threshold) prevSlide();
            else if (dragDeltaX < -threshold) nextSlide();
            dragDeltaX = 0;
            resetAutoplay();
        }

        function handleMouseLeave() {
            if (isDragging) {
                isDragging = false;
                track.style.cursor = '';
                dragDeltaX = 0;
                resetAutoplay();
            }
        }

        function handleKeyDown(e) {
            if (e.key === 'ArrowLeft') {
                e.preventDefault();
                prevSlide();
            } else if (e.key === 'ArrowRight') {
                e.preventDefault();
                nextSlide();
            }
        }

        function initEvents() {
            prevBtn.addEventListener('click', prevSlide);
            nextBtn.addEventListener('click', nextSlide);

            container.addEventListener('touchstart', handleTouchStart, { passive: true });
            container.addEventListener('touchmove', handleTouchMove, { passive: true });
            container.addEventListener('touchend', handleTouchEnd);

            container.addEventListener('mousedown', handleMouseDown);
            document.addEventListener('mousemove', handleMouseMove);
            document.addEventListener('mouseup', handleMouseUp);
            container.addEventListener('mouseleave', handleMouseLeave);

            container.setAttribute('tabindex', '0');
            container.addEventListener('keydown', handleKeyDown);

            container.addEventListener('mouseenter', () => {
                if (carouselConfig.autoplay) stopAutoplay();
            });
            container.addEventListener('mouseleave', () => {
                if (carouselConfig.autoplay) startAutoplay();
            });

            document.addEventListener('visibilitychange', () => {
                if (document.hidden) stopAutoplay();
                else if (carouselConfig.autoplay) startAutoplay();
            });
        }

        function handleResize() {
            updateTrackPosition(false);
        }

        function init() {
            buildCarousel();
            initEvents();
            if (carouselConfig.autoplay && slidesData.length > 1) startAutoplay();
            window.addEventListener('resize', handleResize);
            updateActiveStates();
        }

        init();

        window.embCarousel = {
            goTo: (index) => goToSlide(index),
            next: nextSlide,
            prev: prevSlide,
            getCurrentIndex: () => currentIndex,
            getSlidesCount: () => slidesData.length,
            startAutoplay,
            stopAutoplay,
            destroy: function() {
                stopAutoplay();
                window.removeEventListener('resize', handleResize);
                container.removeEventListener('touchstart', handleTouchStart);
                container.removeEventListener('touchmove', handleTouchMove);
                container.removeEventListener('touchend', handleTouchEnd);
                container.removeEventListener('mousedown', handleMouseDown);
                document.removeEventListener('mousemove', handleMouseMove);
                document.removeEventListener('mouseup', handleMouseUp);
                container.removeEventListener('mouseleave', handleMouseLeave);
                container.removeEventListener('keydown', handleKeyDown);
                container.removeEventListener('mouseenter', stopAutoplay);
                container.removeEventListener('mouseleave', startAutoplay);
                document.removeEventListener('visibilitychange', handleResize);
                container.innerHTML = '';
                delete window.embCarousel;
            }
        };
    })();
</script>
</body>
</html>