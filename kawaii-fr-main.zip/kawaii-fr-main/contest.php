<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$is_admin = 0;
$conadmin = 0;
$adminRes = $conn->query("SELECT admin,conadmin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $adminRes1=$adminRes->fetch_assoc();
    $is_admin = (int)$adminRes1['admin'];
    $conadmin = (int)$adminRes1['conadmin'];
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}

// ---------- 查询比赛列表（关联用户获取举办者名称） ----------
$contestList = false;
$tableCheck = $conn->query("SHOW TABLES LIKE 'contest'");
if ($tableCheck && $tableCheck->num_rows > 0) {
    $contestList = $conn->query(
        "SELECT c.id, c.name, c.start_time, c.end_time, u.name AS creator_name
         FROM contest c
         LEFT JOIN users u ON c.creator = u.uid
         ORDER BY c.id ASC"
    );
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function formatTime($time) {
    if (empty($time)) return '-';
    return date('Y-m-d H:i', strtotime($time));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>比赛列表 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --pass-color: #2e7d32;
            --none-color: #a0988e;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: var(--bg);
            font-family: var(--font);
            color: var(--text);
            line-height: 1.6;
            -webkit-font-smoothing: antialiased;
        }

        .navbar {
            background: var(--nav-bg);
            height: 54px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            color: var(--nav-text);
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 {
            font-size: 17px;
            font-weight: 600;
            letter-spacing: 0.4px;
            color: #f0ece6;
        }
        .bell-wrap {
            position: relative;
            font-size: 20px;
            cursor: pointer;
            margin-right: 20px;
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            transition: var(--transition);
            user-select: none;
        }
        .bell-wrap:hover { background: rgba(255,255,255,0.08); }
        .red-dot {
            position: absolute;
            top: 5px;
            right: 5px;
            width: 9px;
            height: 9px;
            background: #f55353;
            border-radius: 50%;
            border: 1.5px solid #3d3a37;
            animation: pulse-dot 2s infinite;
        }
        @keyframes pulse-dot {
            0%, 100% { box-shadow: 0 0 0 0 rgba(245,83,83,0.5); }
            50% { box-shadow: 0 0 0 6px rgba(245,83,83,0); }
        }
        .user-info { display: flex; align-items: center; gap: 6px; }
        .user-info a {
            color: #e0dbd3;
            text-decoration: none;
            font-size: 13.5px;
            padding: 7px 13px;
            border-radius: 20px;
            transition: var(--transition);
            white-space: nowrap;
            font-weight: 500;
        }
        .user-info a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .user-info a.admin-link { color: #f5d76e; font-weight: 600; }

        .main {
            max-width: 1100px;
            margin: 28px auto 40px;
            display: flex;
            gap: 22px;
            padding: 0 20px;
            align-items: flex-start;
        }
        .sidebar {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            width: fit-content;
            min-width: 110px;
            overflow: hidden;
            position: sticky;
            top: 80px;
            flex-shrink: 0;
        }
        .sidebar a {
            display: block;
            padding: 13px 22px;
            text-align: center;
            background: var(--card-bg);
            color: var(--text);
            text-decoration: none;
            font-size: 14.5px;
            font-weight: 500;
            white-space: nowrap;
            transition: var(--transition);
            border-left: 3px solid transparent;
            letter-spacing: 0.3px;
        }
        .sidebar a:hover {
            background: #f5f2ed;
            border-left-color: var(--accent);
            color: var(--accent);
        }
        .sidebar a:first-child { border-radius: var(--radius) var(--radius) 0 0; }
        .sidebar a:last-child { border-radius: 0 0 var(--radius) var(--radius); }

        .content { flex: 1; min-width: 0; }

        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 26px 28px;
            box-shadow: var(--shadow);
        }
        .card h2 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 16px;
            letter-spacing: 0.3px;
        }
        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        a { text-decoration: none; color: var(--accent); transition: var(--transition); }
        a:hover { color: var(--accent-hover); }

        .btn {
            display: inline-block;
            padding: 8px 18px;
            background: var(--accent);
            color: #fff;
            border-radius: 20px;
            font-size: 13.5px;
            font-weight: 500;
            transition: var(--transition);
        }
        .btn:hover {
            background: var(--accent-hover);
            box-shadow: 0 2px 8px rgba(107,138,116,0.25);
            color: #fff;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            text-align: center;
            padding: 12px 10px;
            background: #f8f6f4;
            font-weight: 600;
            font-size: 13px;
            color: var(--text-secondary);
            border-bottom: 2px solid var(--border);
        }
        td {
            padding: 12px 10px;
            text-align: center;
            border-bottom: 1px solid var(--border);
            font-size: 14px;
        }
        tr:hover td { background: #fafaf7; }

        .contest-link {
            color: var(--text);
            font-weight: 500;
        }
        .contest-link:hover { color: var(--accent); }

        @media (max-width: 768px) {
            .main {
                flex-direction: column;
                padding: 0 12px;
                margin: 18px auto 30px;
            }
            .sidebar {
                width: 100%;
                position: static;
                display: flex;
            }
            .sidebar a {
                flex: 1 1 auto;
                padding: 11px 10px;
                font-size: 13px;
                border-left: none;
                border-bottom: 2px solid transparent;
            }
            .sidebar a:hover {
                border-left-color: transparent;
                border-bottom-color: var(--accent);
            }
            .card { padding: 18px 14px; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>
<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="card">
            <h3>比赛列表</h3>
            <table>
                <tr>
                    <th>比赛名称</th>
                    <th>开始时间</th>
                    <th>结束时间</th>
                </tr>
                <?php if ($contestList && $contestList->num_rows > 0): ?>
                    <?php $upcoming_contest_name = null;
                    $upcoming_contest_href = null;
                    $upcoming_contest_start_time = null;
                    $rest_second = 1000000;
                    date_default_timezone_set('Asia/Shanghai');
                    while ($row = $contestList->fetch_assoc()): 
                        $start_time = new DateTime($row['start_time']);
                        $time_now = new DateTime(date("Y-m-d H:i:s"));
                        $cur_rest_second = $start_time->getTimestamp() - $time_now->getTimestamp();
                        if ($cur_rest_second < $rest_second) {
				$upcoming_contest_name = $row['name'];
				$upcoming_contest_href = "/contest/{$row['id']}";
				$upcoming_contest_start_time = $row['start_time'];
				$rest_second = $cur_rest_second;
			}
                    ?>
                    <tr>
                        <td>
                            <!-- 修正链接：改为 contest_view.php?id=... -->
                            <a href="https://lmtoj.cn/contest/<?= (int)$row['id'] ?>" class="contest-link">
                                <?= safeContent($row['name']) ?>
                            </a>
                        </td>
                        <td><?= formatTime($row['start_time']) ?></td>
                        <td><?= formatTime($row['end_time']) ?></td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="4" style="padding: 30px; color: var(--text-muted);">暂无比赛</td>
                    </tr>
                <?php endif; ?>
            </table>
<?php
if ($rest_second >= 0 && $rest_second <= 86400) {
	$notification = json_encode($upcoming_contest_name . " 已经开始了。是否要跳转到比赛页面？");
	echo <<<EOD
<div style="text-align: center; margin-top: 10px">
<div style="color: #28a745">$upcoming_contest_name 倒计时</div>
<div id="contest-countdown"></div>
<script>
function toFilledStr(o, f, l) {
	var s = o.toString();
	while (s.length < l) {
		s = f.toString() + s;
	}
	return s;
}

function scoreToRGB(score) {
    let h, s, l;
    
    if (score == 0) {
        // HSV(0, 100, 80) -> 红色
        return { r: 204, g: 0, b: 0 };
    } else if (score == 100) {
        // HSV(120, 100, 80) -> 绿色
        return { r: 0, g: 204, b: 0 };
    } else {
        // HSV(30 + score * 60/100, 100, 90)
        h = 30 + score * 60 / 100;
        s = 100;
        v = 90;
        return hsvToRgb(h, s, v);
    }
}

function hsvToRgb(h, s, v) {
    h = h / 360;
    s = s / 100;
    v = v / 100;
    
    let r, g, b;
    const i = Math.floor(h * 6);
    const f = h * 6 - i;
    const p = v * (1 - s);
    const q = v * (1 - f * s);
    const t = v * (1 - (1 - f) * s);
    
    switch (i % 6) {
        case 0: r = v; g = t; b = p; break;
        case 1: r = q; g = v; b = p; break;
        case 2: r = p; g = v; b = t; break;
        case 3: r = p; g = q; b = v; break;
        case 4: r = t; g = p; b = v; break;
        case 5: r = v; g = p; b = q; break;
    }
    
    return {
        r: Math.round(r * 255),
        g: Math.round(g * 255),
        b: Math.round(b * 255)
    };
}
function getColOfScore(score) {
    const rgb = scoreToRGB(score);
    return 'rgb(' + rgb.r + ', ' + rgb.g + ', ' + rgb.b + ')';
}

const startTime = 
EOD;
echo strtotime($upcoming_contest_start_time) * 1000;
echo <<<EOD
;
const countdownEl = document.getElementById('contest-countdown');
function updateCountdown() {
    const now = Date.now();
    let target = 0, prefix = '';
    if (now < startTime) {
        target = startTime;
        countdownEl.classList.remove('ended');
    }
    const diff = target - now;
    if (diff <= 0) {
        if (confirm($notification)) {
		window.location.href = "$upcoming_contest_href";
	}
        return;
    }
    var x = Math.floor(diff / 1000);
	var ss = toFilledStr(x % 60, '0', 2);
	x = Math.floor(x / 60);
	var mm = toFilledStr(x % 60, '0', 2);
	x = Math.floor(x / 60);
	var hh = x.toString();
	
	var res = '<span style="font-size:30px">';
	res += '<span style="color:' + getColOfScore(Math.min(diff / 1000 / 10800 * 100, 100)) + '">' + hh + '</span>';
	res += ':';
	res += '<span style="color:' + getColOfScore(mm / 60 * 100) + '">' + mm + '</span>';
	res += ':';
	res += '<span style="color:' + getColOfScore(ss / 60 * 100) + '">' + ss + '</span>';
	res += '</span>'
    countdownEl.innerHTML = res;
}
updateCountdown();
setInterval(updateCountdown, 1000);
</script>
</div>
EOD;
	}
?>
                <?php if ($conadmin): ?>
                <div style="text-align: right">
                    <a href="https://lmtoj.cn/contest/edit" class="btn">新建比赛</a>
                </div>
                <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>