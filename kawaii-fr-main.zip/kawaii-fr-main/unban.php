<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

session_start();

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 自动创建解封申请表
$conn->query("CREATE TABLE IF NOT EXISTS unban_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    reason TEXT,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    handled_at TIMESTAMP NULL,
    handler_uid INT NULL,
    handler_reason TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 确保 ostracism_log 表存在
$conn->query("CREATE TABLE IF NOT EXISTS ostracism_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    target_uid INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    reason TEXT,
    operator_uid INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$result = $conn->query("SHOW COLUMNS FROM ostracism_log LIKE 'action'");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (strpos($row['Type'], 'enum') !== false) {
        $conn->query("ALTER TABLE ostracism_log MODIFY action VARCHAR(50) NOT NULL");
    }
}

// 获取当前用户信息
$userInfo = $conn->query("SELECT uid, name, banned FROM users WHERE uid = $login_uid")->fetch_assoc();
if (!$userInfo) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = $login_uid")->fetch_assoc();
if ($adminRes) $is_admin = (int)$adminRes['admin'];

// ===== 自行解封处理（仅允许特定UID）=====
// 修复：将硬编码的异常值改为合理的UID（例如3，或根据实际需要调整）
if (isset($_GET['self_unban']) && $login_uid == 3 && $userInfo['banned'] == 1) {
    $conn->query("UPDATE users SET banned = 0 WHERE uid = $login_uid");
    // 重新获取用户信息
    $userInfo = $conn->query("SELECT uid, name, banned FROM users WHERE uid = $login_uid")->fetch_assoc();
    // 记录自行解封操作
    $conn->query("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES ($login_uid, 'self_unban', '用户自行解封', $login_uid)");
    // 刷新页面以避免重复提交
    header("Location: https://lmtoj.cn/unban?t=" . time());
    exit;
}

// ===== 管理员操作：删除申请 =====
if ($is_admin && isset($_GET['delete']) && isset($_GET['id'])) {
    $del_id = (int)$_GET['id'];
    $conn->query("DELETE FROM unban_requests WHERE id = $del_id");
    header("Location: https://lmtoj.cn/unban?t=" . time());
    exit;
}

// ===== 管理员操作：处理解封申请 =====
if (isset($_GET['handle']) && isset($_GET['id']) && $is_admin) {
    $request_id = (int)$_GET['id'];
    $action = $_GET['handle'];

    $req = $conn->query("SELECT * FROM unban_requests WHERE id = $request_id AND status = 'pending'")->fetch_assoc();
    if ($req) {
        if ($action === 'approve') {
            if (empty($_GET['reason'])) {
                header("Location: https://lmtoj.cn/unban?action=handle&id=$request_id&error=missing_reason");
                exit;
            }
            $reason = $conn->real_escape_string(trim($_GET['reason']));
            $conn->query("UPDATE users SET banned = 0 WHERE uid = {$req['uid']}");
            $conn->query("UPDATE unban_requests SET status = 'approved', handled_at = NOW(), handler_uid = $login_uid, handler_reason = '' WHERE id = $request_id");
            $conn->query("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES ({$req['uid']}, 'unban_user', '$reason', $login_uid)");
            header("Location: https://lmtoj.cn/unban?t=" . time());
            exit;
        } elseif ($action === 'reject') {
            $conn->query("UPDATE unban_requests SET status = 'rejected', handled_at = NOW(), handler_uid = $login_uid, handler_reason = '' WHERE id = $request_id");
            header("Location: https://lmtoj.cn/unban?t=" . time());
            exit;
        } else {
            die("无效操作");
        }
    }
}

// ===== 提交解封申请 =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_unban'])) {
    $reason = trim($_POST['reason']);
    if (empty($reason)) {
        $error = "请填写申请理由";
    } else {
        $today = date('Y-m-d');
        $existing = $conn->query("SELECT id FROM unban_requests WHERE uid = $login_uid AND DATE(created_at) = '$today'")->num_rows;
        if ($existing > 0) {
            $error = "您今天已提交过申请，请明天再试";
        } else {
            $reason_esc = $conn->real_escape_string($reason);
            $conn->query("INSERT INTO unban_requests (uid, reason) VALUES ($login_uid, '$reason_esc')");

            $admins = $conn->query("SELECT uid FROM users WHERE admin = 1");
            while ($admin = $admins->fetch_assoc()) {
                $admin_uid = $admin['uid'];
                $now = date('Y-m-d H:i:s');
                $content_type = 'unban_request';
                $atid = $login_uid;
                $tid = 0;
                $topic_title = '';
                $conn->query("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES ($admin_uid, $atid, $tid, '$topic_title', '$content_type', '$now', 0)");
            }
            $success = "申请已提交，请等待管理员处理";
            header("Location: https://lmtoj.cn/unban?submitted=1&t=" . time());
            exit;
        }
    }
}

if (isset($_GET['submitted'])) {
    $success = "申请已提交，请等待管理员处理";
}

// 获取当前用户的陶片放逐记录（仅当被封禁时显示）
$ostracismRecords = null;
if ($userInfo['banned'] == 1) {
    $ostracismRecords = $conn->query("
        SELECT l.*, op.name as operator_name
        FROM ostracism_log l
        LEFT JOIN users op ON l.operator_uid = op.uid
        WHERE l.target_uid = {$login_uid}
        ORDER BY l.id DESC
        LIMIT 20
    ");
}

$requestStatus = null;
$req = $conn->query("SELECT * FROM unban_requests WHERE uid = $login_uid ORDER BY id DESC LIMIT 1")->fetch_assoc();
if ($req) {
    $requestStatus = $req;
}

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function formatTime($ts) { return date('Y-m-d H:i', strtotime($ts)); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>封禁状态 - lmtOJ</title>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --danger: #d9534f;
            --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .mini-header{
            background:var(--nav-bg);height:48px;display:flex;align-items:center;
            justify-content:space-between;padding:0 24px;color:var(--nav-text);
            position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .mini-header h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .mini-header .logout-link{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:6px 14px;border-radius:20px;transition:0.18s ease;font-weight:500;}
        .mini-header .logout-link:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .container{max-width:860px;margin:32px auto 48px;padding:0 20px;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:28px 32px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:16px;}
        .card h3{font-size:17px;font-weight:600;margin-bottom:14px;}
        .alert{background:#fce4ec;border:1px solid #ef9a9a;color:#c62828;padding:14px 18px;border-radius:var(--radius-sm);margin-bottom:16px;font-weight:500;}
        .alert-success{background:#e8f5e9;border-color:#a5d6a7;color:#2e7d32;}
        .alert-info{background:#e3f2fd;border-color:#90caf9;color:#0d47a1;}
        .btn{padding:9px 22px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);font-family:var(--font);display:inline-block;text-decoration:none;}
        .btn:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);}
        .btn-danger{background:var(--danger);}
        .btn-danger:hover{background:var(--danger-hover);}
        .btn-sm{padding:5px 14px;font-size:13px;}
        .btn-block{width:100%;justify-content:center;}
        .btn-outline{background:transparent;color:var(--text-muted);border:1px solid var(--border);}
        .btn-outline:hover{background:var(--bg);}
        textarea{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;resize:vertical;min-height:100px;font-family:var(--font);background:#fdfdfc;transition:var(--transition);}
        textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        input[type="text"]{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;font-family:var(--font);background:#fdfdfc;transition:var(--transition);}
        input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        .form-group{margin-bottom:16px;}
        .form-group label{display:block;font-weight:500;color:var(--text-secondary);margin-bottom:4px;font-size:13px;}
        .mt-16{margin-top:16px;}
        .text-center{text-align:center;}
        .status-tag{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600;}
        .tag-pending{background:#fff3e0;color:#e65100;}
        .tag-approved{background:#c8e6c9;color:#2e7d32;}
        .tag-rejected{background:#ffcdd2;color:#c62828;}
        .action-tag{padding:2px 8px;border-radius:10px;font-size:11px;color:#fff;font-weight:600;}
        .tag-set{background:#5a9e6f;}
        .tag-unset{background:#d4a24e;}
        .tag-jy{background:#d9534f;}
        .ostracism-table{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;}
        .ostracism-table th{text-align:left;padding:8px 10px;background:#fafaf8;font-weight:500;color:var(--text-secondary);border-bottom:2px solid var(--border);}
        .ostracism-table td{padding:8px 10px;border-bottom:1px solid var(--border-light);}
        .back-link{display:inline-block;margin-top:12px;color:var(--accent);text-decoration:none;font-weight:500;}
        .back-link:hover{text-decoration:underline;}
        .handler-form{background:#f5f7fa;padding:16px;border-radius:var(--radius-sm);margin-top:16px;}
        .handler-form .btn-group{display:flex;gap:10px;margin-top:12px;}
        .flex-gap{display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
        @media(max-width:768px){.container{padding:0 12px;margin:20px auto;}.card{padding:18px 14px;}}
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>
    <?php
    // ===== 管理员处理界面 =====
    if ($is_admin && isset($_GET['action']) && $_GET['action'] === 'handle' && isset($_GET['id'])) {
        $req_id = (int)$_GET['id'];
        $req = $conn->query("
            SELECT r.*, u.name as applicant_name 
            FROM unban_requests r 
            LEFT JOIN users u ON r.uid = u.uid 
            WHERE r.id = $req_id AND r.status = 'pending'
        ")->fetch_assoc();
        if (!$req) {
            echo '<div class="card"><div class="alert">该申请不存在或已被处理</div><a href="https://lmtoj.cn/unban" class="back-link">返回</a></div>';
            exit;
        }
        if (isset($_GET['error']) && $_GET['error'] === 'missing_reason') {
            echo '<div class="alert">请填写解封理由</div>';
        }
        ?>
        <div class="card">
            <h2>处理解封申请</h2>
            <p><strong>申请人：</strong><?=safeContent($req['applicant_name'])?> (UID: <?=$req['uid']?>)</p>
            <p><strong>申请时间：</strong><?=formatTime($req['created_at'])?></p>
            <p><strong>申请理由：</strong></p>
            <div style="background:#fafaf8;padding:12px;border-radius:var(--radius-sm);margin:8px 0 16px;white-space:pre-wrap;"><?=safeContent($req['reason'])?></div>
            <div class="btn-group">
                <a href="javascript:void(0)" onclick="approveUnban(<?=$req['uid']?>, <?=$req_id?>)" class="btn btn-sm" style="background:#5a9e6f;">同意解封</a>
                <a href="https://lmtoj.cn/unban?handle=reject&id=<?=$req_id?>" class="btn btn-sm btn-danger" onclick="return confirm('确定拒绝该申请吗？')">拒绝解封</a>
                <a href="https://lmtoj.cn/unban?delete=<?=$req_id?>" class="btn btn-sm btn-outline" onclick="return confirm('确定删除此申请记录吗？此操作不可恢复。')">删除申请</a>
                <a href="https://lmtoj.cn/unban" class="btn btn-sm" style="background:var(--text-muted);">取消</a>
            </div>
            <p style="font-size:13px;color:var(--text-muted);margin-top:8px;">注：同意解封需填写理由（记录到陶片放逐）。</p>
        </div>
        <script>
        function approveUnban(uid, rid) {
            var reason = prompt("请输入解封理由（将记录到陶片放逐）：", "管理员解封");
            if (reason !== null && reason.trim() !== "") {
                location.href = "https://lmtoj.cn/unban?handle=approve&id=" + rid + "&reason=" + encodeURIComponent(reason.trim());
            } else if (reason !== null) {
                alert("理由不能为空，请重新操作");
            }
        }
        </script>
        <?php
        exit;
    }
    ?>

    <?php if ($userInfo['banned'] == 0): ?>
        <div class="card">
            <div class="alert alert-success">✅ 您当前未被封禁，可以正常使用。</div>
            <div class="text-center"><a href="https://lmtoj.cn/" class="back-link">← 返回首页</a></div>
        </div>
    <?php else: ?>
        <div class="card">
            <div class="alert">🔒 您的账号已被封禁</div>
            <p style="color:var(--text-secondary);">您暂时无法使用大部分功能。如需解封，请提交解封申请。</p>
            <p style="color: #999; font-size: 12px; margin-top: 8px;">DEBUG: 当前登录UID = <?=$login_uid?></p>
            <?php if ($login_uid == 3): ?>
                <div class="mt-16">
                    <a href="https://lmtoj.cn/unban?self_unban=1" class="btn btn-danger btn-sm" onclick="return confirm('确定立即自行解封吗？')">立即自行解封</a>
                </div>
            <?php endif; ?>
        </div>

        <!-- 陶片放逐记录 -->
        <?php if($ostracismRecords && $ostracismRecords->num_rows > 0): ?>
        <div class="card">
            <h3>陶片放逐记录</h3>
            <table class="ostracism-table">
                <tr><th>时间</th><th>操作人</th><th>操作</th><th>原因</th></tr>
                <?php while($o = $ostracismRecords->fetch_assoc()): 
                    $labels = [
                        'set_admin'     => '授予 进入后台 权限',
                        'unset_admin'   => '撤销 进入后台 权限',
                        'set_jinyan'    => '撤销 自由发言 权限',
                        'cancel_jinyan' => '授予 自由发言 权限',
                        'del_user'      => '撤销 进入主站 权限',
                        'set_sixin'     => '授予 发送私信 权限',
                        'cancel_sixin'  => '撤销 发送私信 权限',
                        'ban_user'      => '撤销 进入主站 权限',
                        'unban_user'    => '授予 进入主站 权限',
                        'set_banned'    => '撤销 进入主站 权限',
                        'unset_banned'  => '授予 进入主站 权限',
                        'self_unban'    => '自行解封'
                    ];
                    $colors = [
                        'set_admin'     => 'tag-set',
                        'unset_admin'   => 'tag-unset',
                        'set_jinyan'    => 'tag-jy',
                        'cancel_jinyan' => 'tag-set',
                        'del_user'      => 'tag-unset',
                        'set_sixin'     => 'tag-set',
                        'cancel_sixin'  => 'tag-jy',
                        'ban_user'      => 'tag-unset',
                        'unban_user'    => 'tag-set',
                        'set_banned'    => 'tag-unset',
                        'unset_banned'  => 'tag-set',
                        'self_unban'    => 'tag-set'
                    ];
                    $typeLabel = $o['action'];
                    $displayLabel = $labels[$typeLabel] ?? $typeLabel;
                    $displayColor = $colors[$typeLabel] ?? '';
                ?>
                <tr>
                    <td><?=date("m-d H:i:s",strtotime($o['created_at'])+15*3600)?></td>
                    <td><?=safeContent($o['operator_name'])?></td>
                    <td><span class="action-tag <?=$displayColor?>"><?=$displayLabel?></span></td>
                    <td><?=safeContent($o['reason'])?></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- 解封申请状态 -->
        <?php if ($requestStatus): ?>
        <div class="card">
            <h3>解封申请状态</h3>
            <?php if ($requestStatus['status'] === 'pending'): ?>
                <p><span class="status-tag tag-pending">待处理</span> 您的申请已提交，请耐心等待管理员审核。</p>
                <p style="font-size:13px;color:var(--text-muted);">提交时间：<?=formatTime($requestStatus['created_at'])?></p>
            <?php elseif ($requestStatus['status'] === 'approved'): ?>
                <p><span class="status-tag tag-approved">已同意</span> 您的解封申请已通过，账号已解封。</p>
                <p style="font-size:13px;color:var(--text-secondary);">处理时间：<?=formatTime($requestStatus['handled_at'])?></p>
                <div class="text-center mt-16"><a href="https://lmtoj.cn/" class="back-link">← 返回首页</a></div>
            <?php elseif ($requestStatus['status'] === 'rejected'): ?>
                <p><span class="status-tag tag-rejected">已拒绝</span> 您的解封申请被驳回。</p>
                <p style="font-size:13px;color:var(--text-secondary);">处理时间：<?=formatTime($requestStatus['handled_at'])?></p>
                <div class="text-center mt-16">
                    <a href="https://lmtoj.cn/unban" class="back-link">刷新查看状态</a>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <!-- 申请解封表单 -->
        <?php
        $today = date('Y-m-d');
        $hasToday = $conn->query("SELECT id FROM unban_requests WHERE uid = $login_uid AND DATE(created_at) = '$today'")->num_rows > 0;
        $showForm = true;
        if ($requestStatus && $requestStatus['status'] === 'pending') {
            $showForm = false;
        } elseif ($hasToday) {
            $showForm = false;
        }
        ?>
        <?php if ($showForm): ?>
        <div class="card">
            <h2>申请解除封禁</h2>
            <?php if (isset($error)): ?>
                <div class="alert"><?=safeContent($error)?></div>
            <?php endif; ?>
            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?=safeContent($success)?></div>
            <?php else: ?>
                <form method="post" action="https://lmtoj.cn/unban">
                    <div class="form-group">
                        <label for="reason">申请理由 <span style="color:var(--danger);">*</span></label>
                        <textarea name="reason" id="reason" placeholder="请详细说明您被误封或有其他理由申请解封..." required></textarea>
                    </div>
                    <button type="submit" name="submit_unban" class="btn btn-block">提交申请</button>
                </form>
                <p style="font-size:12px;color:var(--text-muted);margin-top:8px;">注意：每天仅可提交一次申请，请珍惜机会。</p>
            <?php endif; ?>
        </div>
        <?php elseif (!$hasToday && $requestStatus && $requestStatus['status'] === 'rejected'): ?>
        <div class="card">
            <div class="alert alert-info">您今天已提交过申请（已被拒绝），请明天再尝试。</div>
        </div>
        <?php elseif ($hasToday && $requestStatus && $requestStatus['status'] !== 'pending'): ?>
        <div class="card">
            <div class="alert alert-info">您今天已提交过申请，请明天再尝试。</div>
        </div>
        <?php endif; ?>

    <?php endif; ?>

</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>