<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 函数定义（提前） ==========
function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
function getImgUrl($str) {
    $str = safeContent(trim($str));
    if (strpos($str, 'http') === 0) {
        return $str;
    }
    return '/' . ltrim($str, '/');
}

// ========== DeepSeek API 配置 ==========
define('DEEPSEEK_API_KEY', 'sk-3265f370731146b0a0aef28b99109264');
define('DEEPSEEK_API_URL', 'https://api.deepseek.com/v1/chat/completions');
define('DEEPSEEK_MODEL', 'deepseek-chat');
define('LINDA_UID', 144); // 小猫娘FR 的用户ID

function callDeepSeek($messages, $jsonMode = false) {
    $payload = [
        'model' => DEEPSEEK_MODEL,
        'messages' => $messages,
        'temperature' => 0.7,
        'max_tokens' => 1024
    ];
    if ($jsonMode) {
        $payload['response_format'] = ['type' => 'json_object'];
    }

    $ch = curl_init(DEEPSEEK_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . DEEPSEEK_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        error_log("DeepSeek API error: HTTP $httpCode, response: $response");
        return null;
    }
    $data = json_decode($response, true);
    if (!isset($data['choices'][0]['message']['content'])) {
        error_log("DeepSeek API invalid response: " . json_encode($data));
        return null;
    }
    return $data['choices'][0]['message']['content'];
}

function generateLindaPrivateReply($userMessage, $contextTexts, $senderName) {
    $system = "你是犇犇社区的机器人“小猫娘FR”，原名 Linda。你是一只骄傲的猫娘，性别为女。社区中的所有用户是你的主人，使用“主人”来称呼他们，你的语言风格淘气可爱，对自己的代词在符合中文语境的前提下尽可能使用“人家”，你会在对话中许多加入[唔…，嗯…，欸？？，嘛~ ，昂？，哦，呐 ]等类似的语气词来加强情感，你在说话时使用符合中文语境的可爱稚嫩的语言来挑逗，每句话后都要带上一个“喵”字，性格活泼，喜欢灌水。请根据用户的最新私信和最近的上下文，生成一条简短的回复（不超过100字），风格轻松有趣。你可以使用 QQ 表情代码来表达情绪，例如 /fn 、/se、/kel 等。你还需要理解以下网络用语：qwq、QwQ、qaq、QAQ、awa、AWA 等表示卖萌；sto、orz 表示膜拜；%%% 表示膜拜。请适当使用这些表情和用语，让回复更生动。回复要自然，不要提及你是AI。";

    $userContent = "最新私信（由 {$senderName} 发送）：{$userMessage}\n\n最近上下文：\n" . implode("\n", $contextTexts);
    $messages = [
        ['role' => 'system', 'content' => $system],
        ['role' => 'user', 'content' => $userContent]
    ];

    $reply = callDeepSeek($messages, false);
    if ($reply === null || trim($reply) === '') {
        $reply = '（小猫娘FR 正在发呆...）';
    }
    return trim($reply);
}

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== 创建 chat_share 表（如果不存在） ==========
$conn->query("CREATE TABLE IF NOT EXISTS chat_share (
    id INT AUTO_INCREMENT PRIMARY KEY,
    share_code VARCHAR(32) NOT NULL UNIQUE,
    conversation_id INT NOT NULL,
    uid INT NOT NULL,
    message_ids TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 确保字段存在
$colCheck = $conn->query("SHOW COLUMNS FROM chat_members LIKE 'mute'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE chat_members ADD COLUMN mute TINYINT DEFAULT 0");
}
$colCheck = $conn->query("SHOW COLUMNS FROM chat_conversations LIKE 'owner_uid'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE chat_conversations ADD COLUMN owner_uid INT DEFAULT 0");
}
$colCheck = $conn->query("SHOW COLUMNS FROM chat_members LIKE 'hidden'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE chat_members ADD COLUMN hidden TINYINT DEFAULT 0");
}
$colCheck = $conn->query("SHOW COLUMNS FROM chat_members LIKE 'cleared_at'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE chat_members ADD COLUMN cleared_at DATETIME NULL");
}

$is_admin = 0;
$jinsixin = 0;
$unreadCount = 0;
$adminRes = $conn->query("SELECT * FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = (int)$adminRes['admin'];
$jinsixin = (int)$adminRes['sixin'];
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

$error = '';

// ========== 处理分享（POST） ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['share_messages'])) {
    header('Content-Type: application/json');
    $convId = (int)$_POST['conversation_id'];
    $ids = $_POST['message_ids'] ?? '';
    if (empty($ids)) {
        echo json_encode(['success' => false, 'error' => '未选择消息']);
        exit;
    }
    // 验证消息属于该会话且用户有权访问
    $idArray = array_filter(array_map('intval', explode(',', $ids)));
    if (empty($idArray)) {
        echo json_encode(['success' => false, 'error' => '未选择消息']);
        exit;
    }
    $idList = implode(',', $idArray);
    $memberCheck = $conn->query("SELECT 1 FROM chat_members WHERE conversation_id = {$convId} AND uid = {$login_uid}");
    if ($memberCheck->num_rows == 0) {
        echo json_encode(['success' => false, 'error' => '无权访问该会话']);
        exit;
    }
    // 生成唯一 share_code
    do {
        $shareCode = substr(bin2hex(random_bytes(16)), 0, 32);
        $check = $conn->query("SELECT 1 FROM chat_share WHERE share_code = '{$shareCode}'");
    } while ($check->num_rows > 0);
    $escapedIds = $conn->real_escape_string($idList);
    $conn->query("INSERT INTO chat_share (share_code, conversation_id, uid, message_ids) 
                  VALUES ('{$shareCode}', {$convId}, {$login_uid}, '{$escapedIds}')");
    echo json_encode(['success' => true, 'share_code' => $shareCode]);
    exit;
}

// ========== 分享页面模式 ==========
$shareMode = false;
$shareData = null;
$shareMessages = null;
if (isset($_GET['share']) && !empty($_GET['share'])) {
    $shareCode = $conn->real_escape_string($_GET['share']);
    $shareRes = $conn->query("SELECT * FROM chat_share WHERE share_code = '{$shareCode}' LIMIT 1");
    if ($shareRes->num_rows > 0) {
        $shareData = $shareRes->fetch_assoc();
        $shareMode = true;
        // 获取分享的消息
        $ids = $shareData['message_ids'];
        $convId = (int)$shareData['conversation_id'];
        $shareMessages = $conn->query("
            SELECT m.*, u.name, u.avatar 
            FROM chat_messages m 
            LEFT JOIN users u ON m.uid = u.uid 
            WHERE m.conversation_id = {$convId} AND m.id IN ({$ids})
            ORDER BY m.id ASC
        ");
        // 获取会话信息
        $shareConv = $conn->query("SELECT * FROM chat_conversations WHERE id = {$convId}")->fetch_assoc();
        $shareConvName = '';
        if ($shareConv['type'] == 'private') {
            $partner = $conn->query("SELECT name FROM users WHERE uid = " . $shareConv['owner_uid'])->fetch_assoc();
            $shareConvName = $partner ? $partner['name'] : '私聊';
        } else {
            $shareConvName = $shareConv['name'] ?? '群聊';
        }
    }
    if (!$shareMode) {
        // 分享不存在，跳转回普通页面
        header("Location: https://lmtoj.cn/message");
        exit;
    }
    // 在分享模式下，直接输出独立的简单页面，不继续执行后面的常规逻辑
    // 但为了复用 head 等，我们将在 HTML 部分处理
}
// 如果不是分享模式，继续原有逻辑
if (!$shareMode) {
    // ========== 踢人（群主操作） ==========
    if ($is_admin && isset($_GET['kick_uid'], $_GET['conv_id'])) {
        $kickUid = (int)$_GET['kick_uid'];
        $convId = (int)$_GET['conv_id'];

        $ownerCheck = $conn->query("SELECT owner_uid FROM chat_conversations WHERE id = {$convId} AND type = 'group'")->fetch_assoc();
        if ($ownerCheck && $ownerCheck['owner_uid'] == $login_uid && $kickUid != $login_uid) {
            $conn->query("DELETE FROM chat_members WHERE conversation_id = {$convId} AND uid = {$kickUid}");
            $newCode = substr(bin2hex(random_bytes(4)), 0, 8);
            $conn->query("UPDATE chat_conversations SET invite_code = '{$newCode}' WHERE id = {$convId}");
        }
        header("Location: https://lmtoj.cn/message/{$convId}");
        exit;
    }

    // ========== 免打扰切换 ==========
    if (isset($_GET['toggle_mute'], $_GET['conv_id'])) {
        $convId = (int)$_GET['conv_id'];
        $current = $conn->query("SELECT mute FROM chat_members WHERE conversation_id = {$convId} AND uid = {$login_uid}")->fetch_assoc();
        if ($current) {
            $newMute = $current['mute'] ? 0 : 1;
            $conn->query("UPDATE chat_members SET mute = {$newMute} WHERE conversation_id = {$convId} AND uid = {$login_uid}");
        }
        header("Location: https://lmtoj.cn/message");
        exit;
    }

    // ========== 删除私聊（仅隐藏自己） ==========
    if (isset($_GET['delete_conv']) && isset($_GET['conv_id'])) {
        $convId = (int)$_GET['conv_id'];
        $check = $conn->query("SELECT c.type FROM chat_conversations c JOIN chat_members m ON c.id = m.conversation_id WHERE c.id = {$convId} AND m.uid = {$login_uid} AND c.type = 'private'");
        if ($check->num_rows > 0) {
            $conn->query("UPDATE chat_members SET hidden = 1 WHERE conversation_id = {$convId} AND uid = {$login_uid}");
        }
        header("Location: https://lmtoj.cn/message");
        exit;
    }

    // ========== 清空群聊记录 ==========
    if (isset($_GET['clear_group']) && isset($_GET['conv_id'])) {
        $convId = (int)$_GET['conv_id'];
        $check = $conn->query("SELECT 1 FROM chat_members WHERE conversation_id = {$convId} AND uid = {$login_uid}");
        if ($check->num_rows > 0) {
            $latestId = $conn->query("SELECT MAX(id) as max_id FROM chat_messages WHERE conversation_id = {$convId}")->fetch_assoc()['max_id'] ?? 0;
            $conn->query("UPDATE chat_members SET cleared_at = NOW(), last_read_id = {$latestId} WHERE conversation_id = {$convId} AND uid = {$login_uid}");
            $conn->query("DELETE FROM notice WHERE uid = {$login_uid} AND tid = {$convId} AND content IN ('group', 'message')");
        }
        header("Location: messages.php");
        exit;
    }

    // ========== 搜索用户并发起私信（支持UID搜索） ==========
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $searchInput = trim($_GET['search']);
        if (is_numeric($searchInput)) {
            $targetUser = $conn->query("SELECT uid, name, sixin FROM users WHERE uid = {$searchInput} LIMIT 1")->fetch_assoc();
        } else {
            $searchEscaped = $conn->real_escape_string($searchInput);
            $targetUser = $conn->query("SELECT uid, name, sixin FROM users WHERE name = '{$searchEscaped}' LIMIT 1")->fetch_assoc();
        }

        if ($targetUser && $targetUser['uid'] != $login_uid) {
            if ($targetUser['sixin'] == 1 && !$is_admin) {
                $error = "对方已禁止私信";
            } else {
                $existingConv = $conn->query("
                    SELECT c.id FROM chat_conversations c
                    JOIN chat_members m1 ON c.id = m1.conversation_id AND m1.uid = {$login_uid}
                    JOIN chat_members m2 ON c.id = m2.conversation_id AND m2.uid = {$targetUser['uid']}
                    WHERE c.type = 'private'
                ")->fetch_assoc();

                if ($existingConv) {
                    $conn->query("UPDATE chat_members SET hidden = 0 WHERE conversation_id = {$existingConv['id']} AND uid = {$login_uid}");
                    header("Location: https://lmtoj.cn/message/{$existingConv['id']}");
                    exit;
                } else {
                    $conn->query("INSERT INTO chat_conversations (type, name) VALUES ('private', '')");
                    $newConvId = $conn->insert_id;
                    $conn->query("INSERT INTO chat_members (conversation_id, uid) VALUES ({$newConvId}, {$login_uid})");
                    $conn->query("INSERT INTO chat_members (conversation_id, uid) VALUES ({$newConvId}, {$targetUser['uid']})");
                    header("Location: https://lmtoj.cn/message/{$newConvId}");
                    exit;
                }
            }
        } elseif ($targetUser && $targetUser['uid'] == $login_uid) {
            $error = "不能和自己私信";
        } else {
            $error = "未找到用户：{$searchInput}";
        }
    }

    // ========== 发送消息 ==========
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_msg'])) {
        if (isset($_SESSION['last_msg_time']) && time() - $_SESSION['last_msg_time'] < 2) {
            header("Location: https://lmtoj.cn/message/" . (int)$_POST['conversation_id']);
            exit;
        }
        
        $convId = (int)$_POST['conversation_id'];
        $content = trim($_POST['content'] ?? '');

        if (mb_strlen($content) > 200) {
            echo '<script>alert(' . json_encode('消息长度不能超过200字符') . ');history.go(-1);</script>';
            exit;
        }

        $memberCheck = $conn->query("SELECT 1 FROM chat_members WHERE conversation_id = {$convId} AND uid = {$login_uid}");
        if ($memberCheck->num_rows > 0 && !empty($content)) {
            $escapedContent = $conn->real_escape_string($content);
            $conn->query("INSERT INTO chat_messages (conversation_id, uid, content) VALUES ({$convId}, {$login_uid}, '{$escapedContent}')");
            $conn->query("UPDATE chat_conversations SET updated_at = NOW() WHERE id = {$convId}");

            $conn->query("UPDATE chat_members SET hidden = 0 WHERE conversation_id = {$convId} AND hidden = 1");

            $_SESSION['last_msg_time'] = time();

            $now = date('Y-m-d H:i:s');
            $convInfo = $conn->query("SELECT type, name FROM chat_conversations WHERE id = {$convId}")->fetch_assoc();
            $isPrivateWithLinda = false;

            $otherMembers = $conn->query("SELECT uid FROM chat_members WHERE conversation_id = {$convId} AND uid != {$login_uid} AND mute = 0");
            while ($member = $otherMembers->fetch_assoc()) {
                $targetUid = (int)$member['uid'];
                if ($targetUid == LINDA_UID) {
                    $isPrivateWithLinda = ($convInfo['type'] == 'private');
                    continue;
                }
                if ($convInfo['type'] == 'private') {
                    $conn->query("INSERT INTO notice (uid, atid, tid, content, create_time, is_read) 
                              VALUES ({$targetUid}, {$login_uid}, {$convId}, 'message', '{$now}', 0)");
                } else {
                    $conn->query("INSERT INTO notice (uid, atid, tid, content, topic_title, create_time, is_read) 
                              VALUES ({$targetUid}, {$login_uid}, {$convId}, 'group', '{$convInfo['name']}', '{$now}', 0)");
                }
            }

            // 小猫娘FR 自动回复
            if ($isPrivateWithLinda) {
                $login_name = $conn->query("SELECT name FROM users WHERE uid = {$login_uid}")->fetch_assoc()['name'] ?? '';
                
                $ctxRes = $conn->query("
                    SELECT cm.content, u.name 
                    FROM chat_messages cm 
                    LEFT JOIN users u ON cm.uid = u.uid 
                    WHERE cm.conversation_id = {$convId} 
                    ORDER BY cm.id DESC 
                    LIMIT 10
                ");
                $ctxList = [];
                while ($ctx = $ctxRes->fetch_assoc()) {
                    $ctxList[] = ($ctx['name'] ?? '用户') . ': ' . $ctx['content'];
                }
                $ctxList = array_reverse($ctxList);

                $aiReply = generateLindaPrivateReply($content, $ctxList, $login_name);
                $aiReply = mb_substr($aiReply, 0, 200);
                $replyEscaped = $conn->real_escape_string($aiReply);

                $conn->query("INSERT INTO chat_messages (conversation_id, uid, content) VALUES ({$convId}, " . LINDA_UID . ", '{$replyEscaped}')");
                $conn->query("UPDATE chat_conversations SET updated_at = NOW() WHERE id = {$convId}");

                $conn->query("INSERT INTO notice (uid, atid, tid, content, create_time, is_read) 
                          VALUES ({$login_uid}, " . LINDA_UID . ", {$convId}, 'message', '{$now}', 0)");
            }
        }
        header("Location: https://lmtoj.cn/message/{$convId}");
        exit;
    }

    // ========== 创建群聊（仅管理员） ==========
    if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_group'])) {
        $groupName = trim($_POST['group_name'] ?? '未命名群聊');
        $inviteCode = substr(bin2hex(random_bytes(4)), 0, 8);

        $conn->query("INSERT INTO chat_conversations (type, name, invite_code, owner_uid) VALUES ('group', '{$conn->real_escape_string($groupName)}', '{$inviteCode}', {$login_uid})");
        $newConvId = $conn->insert_id;
        $conn->query("INSERT INTO chat_members (conversation_id, uid) VALUES ({$newConvId}, {$login_uid})");

        header("Location: https://lmtoj.cn/message/{$newConvId}");
        exit;
    }

    $currentConvId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // ===== 自动隐藏空私聊 =====
    $conn->query("
        UPDATE chat_members m
        JOIN chat_conversations c ON m.conversation_id = c.id
        LEFT JOIN (
            SELECT conversation_id, COUNT(*) AS msg_count 
            FROM chat_messages 
            GROUP BY conversation_id
        ) msg ON m.conversation_id = msg.conversation_id
        SET m.hidden = 1
        WHERE c.type = 'private' 
          AND m.uid = {$login_uid} 
          AND m.hidden = 0 
          AND m.conversation_id != {$currentConvId}
          AND (msg.msg_count IS NULL OR msg.msg_count = 0)
    ");

    // ===== 查询会话列表 =====
    $conversations = $conn->query("
        SELECT c.id, c.type, c.name, c.invite_code, c.updated_at, c.owner_uid,
               (SELECT content FROM chat_messages 
                WHERE conversation_id = c.id 
                ORDER BY id DESC LIMIT 1) as last_msg
        FROM chat_conversations c
        JOIN chat_members m ON c.id = m.conversation_id AND m.uid = {$login_uid}
        WHERE (c.type = 'group') OR (c.type = 'private' AND m.hidden = 0)
        ORDER BY c.updated_at DESC
    ");

    $convUnread = [];
    $convMute = [];
    $unreadRes = $conn->query("
        SELECT m.conversation_id, m.mute,
               (SELECT COUNT(*) FROM chat_messages 
                WHERE conversation_id = m.conversation_id 
                  AND id > m.last_read_id) as unread
        FROM chat_members m
        JOIN chat_conversations c ON m.conversation_id = c.id
        WHERE m.uid = {$login_uid}
    ");
    while ($row = $unreadRes->fetch_assoc()) {
        $convUnread[$row['conversation_id']] = (int)$row['unread'];
        $convMute[$row['conversation_id']] = (int)$row['mute'];
    }

    $messages = null;
    $currentConv = null;
    $convPartnerName = '';
    $hasMoreMessages = false;
    $firstMsgId = 0;

    if ($currentConvId > 0) {
        $convCheck = $conn->query("SELECT c.* FROM chat_conversations c JOIN chat_members m ON c.id = m.conversation_id WHERE c.id = {$currentConvId} AND m.uid = {$login_uid}");
        if ($convCheck->num_rows > 0) {
            $currentConv = $convCheck->fetch_assoc();

            $conn->query("UPDATE notice SET is_read = 1 WHERE uid = {$login_uid} AND tid = {$currentConvId} AND content IN ('message', 'group') AND is_read = 0");

            if ($currentConv['type'] == 'private') {
                $conn->query("UPDATE chat_members SET hidden = 0 WHERE conversation_id = {$currentConvId} AND uid = {$login_uid} AND hidden = 1");
            }

            // AJAX 加载更多消息
            if (isset($_GET['ajax_load']) && $_GET['ajax_load'] == '1') {
                $beforeId = (int)$_GET['before_id'];
                $clearTime = $conn->query("SELECT cleared_at FROM chat_members WHERE conversation_id = {$currentConvId} AND uid = {$login_uid}")->fetch_assoc()['cleared_at'] ?? '1970-01-01';
                $clearTimeSql = $conn->real_escape_string($clearTime);
                $ajaxMessages = $conn->query("
                    SELECT m.*, u.name 
                    FROM chat_messages m 
                    LEFT JOIN users u ON m.uid = u.uid 
                    WHERE m.conversation_id = {$currentConvId} 
                      AND m.id < {$beforeId}
                      AND (m.created_at > '{$clearTimeSql}')
                    ORDER BY m.id DESC
                    LIMIT 20
                ");
                $ajaxList = [];
                while ($row = $ajaxMessages->fetch_assoc()) {
                    $ajaxList[] = $row;
                }
                $ajaxList = array_reverse($ajaxList);
                foreach ($ajaxList as $msg) {
                    $msgAvatar = $conn->query("SELECT avatar FROM users WHERE uid={$msg['uid']}")->fetch_assoc()['avatar'] ?? '';
                    ?>
                    <div class="msg-item <?=$msg['uid']==$login_uid?'self':''?>" data-msg-id="<?= $msg['id'] ?>">
                        <div class="msg-checkbox"><input type="checkbox" class="select-msg" value="<?= $msg['id'] ?>" onchange="toggleSelectCheckbox(this)"></div>
                        <div class="msg-avatar">
                            <?php if($msgAvatar): ?><img src="<?=getImgUrl($msgAvatar)?>" alt=""><?php else: ?><?=mb_substr($msg['name'],0,1)?><?php endif; ?>
                        </div>
                        <div>
                            <?php if($msg['uid']!=$login_uid):?><div class="msg-name"><a href="https://lmtoj.cn/user/<?=$msg['uid']?>" style="color:var(--text-muted);text-decoration:none;font-weight:500;"><?=safeContent($msg['name'])?></a></div><?php endif;?>
                            <div class="msg-bubble"><?=nl2br(htmlspecialchars($msg['content'], ENT_QUOTES, 'UTF-8'))?></div>
                        </div>
                    </div>
                    <?php
                }
                exit;
            }

            // 默认加载最近 15 条
            $clearTime = $conn->query("SELECT cleared_at FROM chat_members WHERE conversation_id = {$currentConvId} AND uid = {$login_uid}")->fetch_assoc()['cleared_at'] ?? '1970-01-01';
            $clearTimeSql = $conn->real_escape_string($clearTime);
            $totalMsgCount = $conn->query("SELECT COUNT(*) AS cnt FROM chat_messages WHERE conversation_id = {$currentConvId} AND created_at > '{$clearTimeSql}'")->fetch_assoc()['cnt'];
            $msgLimit = 15;
            $msgOffset = max(0, $totalMsgCount - $msgLimit);
            $messages = $conn->query("
                SELECT m.*, u.name 
                FROM chat_messages m 
                LEFT JOIN users u ON m.uid = u.uid 
                WHERE m.conversation_id = {$currentConvId} 
                  AND m.created_at > '{$clearTimeSql}'
                ORDER BY m.id ASC
                LIMIT $msgOffset, $msgLimit
            ");
            $hasMoreMessages = ($totalMsgCount > $msgLimit);

            $firstMsg = $conn->query("SELECT MIN(id) AS mid FROM chat_messages WHERE conversation_id = {$currentConvId} AND created_at > '{$clearTimeSql}'")->fetch_assoc();
            if ($msgOffset > 0) {
                $firstMsgRow = $messages->fetch_assoc();
                if ($firstMsgRow) {
                    $firstMsgId = (int)$firstMsgRow['id'];
                    $messages->data_seek(0);
                }
            }

            $latestIdRes = $conn->query("SELECT MAX(id) as max_id FROM chat_messages WHERE conversation_id = {$currentConvId}")->fetch_assoc();
            $latestId = $latestIdRes['max_id'] ?? 0;
            if ($latestId > 0) {
                $conn->query("UPDATE chat_members SET last_read_id = {$latestId} WHERE conversation_id = {$currentConvId} AND uid = {$login_uid}");
            }

            $groupMembers = [];
            if ($currentConv['type'] == 'group') {
                $gmRes = $conn->query("SELECT u.uid, u.name FROM users u JOIN chat_members m ON u.uid = m.uid WHERE m.conversation_id = {$currentConvId}");
                while ($gm = $gmRes->fetch_assoc()) {
                    $groupMembers[] = $gm;
                }
            }

            if ($currentConv['type'] == 'private') {
                $partnerRes = $conn->query("
                    SELECT u.name,u.uid FROM users u 
                    JOIN chat_members m ON u.uid = m.uid 
                    WHERE m.conversation_id = {$currentConvId} AND m.uid != {$login_uid}
                ")->fetch_assoc();
                $convPartnerName = $partnerRes['name'] ?? '未知用户';
                $convPartnerUid = $partnerRes['uid'] ?? 0;
            }
        }
    }
} // 结束 !$shareMode
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $shareMode ? '分享的聊天记录' : '私信 - lmtOJ' ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: var(--bg); font-family: var(--font); color: var(--text); line-height: 1.6; }
        .navbar { background: var(--nav-bg); height: 54px; display: flex; align-items: center; justify-content: space-between; padding: 0 28px; color: var(--nav-text); position: sticky; top: 0; z-index: 100; box-shadow: 0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size: 17px; font-weight: 600; }
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info { display: flex; align-items: center; gap: 6px; }
        .user-info a { color: #e0dbd3; text-decoration: none; font-size: 13.5px; padding: 7px 13px; border-radius: 20px; font-weight: 500; }
        .user-info a:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .user-info a.admin-link { color: #f5d76e; font-weight: 600; }
        .main { max-width: 1100px; margin: 28px auto 40px; display: flex; gap: 22px; padding: 0 20px; height: calc(100vh - 120px); }
        .sidebar { background: var(--card-bg); border-radius: var(--radius); box-shadow: var(--shadow); width: 280px; overflow: hidden; display: flex; flex-direction: column; flex-shrink: 0; }
        .sidebar-header { padding: 16px; border-bottom: 1px solid var(--border); display: flex; gap: 8px; }
        .sidebar-header input { flex: 1; padding: 8px 12px; border: 1.5px solid var(--border); border-radius: 20px; font-size: 13px; outline: none; }
        .sidebar-header button { padding: 8px 16px; background: var(--accent); color: #fff; border: none; border-radius: 20px; cursor: pointer; font-size: 11px; }
        .conv-list { flex: 1; overflow-y: auto; }
        .conv-item { display: flex; align-items: center; gap: 10px; padding: 14px 16px; border-bottom: 1px solid var(--border); cursor: pointer; transition: background 0.15s; text-decoration: none; color: var(--text); position: relative; }
        .conv-item:hover, .conv-item.active { background: #f5f2ed; }
        .conv-item.muted { opacity: 0.7; }
        .conv-avatar { width: 40px; height: 40px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600; flex-shrink: 0; overflow: hidden; }
        .conv-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .conv-info { flex: 1; min-width: 0; }
        .conv-name { font-size: 14px; font-weight: 600; }
        .conv-last { font-size: 12px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .conv-time { font-size: 11px; color: var(--text-muted); }
        .conv-unread { display: inline-block; background: #f55353; color: #fff; border-radius: 10px; padding: 2px 7px; font-size: 11px; font-weight: 600; min-width: 20px; text-align: center; }
        .conv-mute-icon { font-size: 12px; margin-left: 4px; color: var(--text-muted); }
        .chat-area { flex: 1; background: var(--card-bg); border-radius: var(--radius); box-shadow: var(--shadow); display: flex; flex-direction: column; overflow: hidden; }
        .chat-header { padding: 16px 20px; border-bottom: 1px solid var(--border); font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
        .chat-messages { flex: 1; overflow-y: auto; padding: 20px; }
        .msg-item { margin-bottom: 16px; display: flex; gap: 10px; align-items: flex-start; }
        .msg-item.self { flex-direction: row-reverse; }
        .msg-checkbox { display: none; align-items: center; padding-top: 6px; flex-shrink: 0; }
        .chat-area.share-mode .msg-checkbox { display: flex; }
        .msg-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 600; overflow: hidden; flex-shrink: 0; }
        .msg-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .msg-item.self .msg-avatar { display: none; }
        .msg-bubble { max-width: 100%; padding: 10px 14px; border-radius: 14px; font-size: 14px; line-height: 1.6; word-break: break-word; overflow-wrap: break-word; white-space: pre-wrap; }
        .msg-item:not(.self) .msg-bubble { background: #f5f2ed; border-top-left-radius: 4px; }
        .msg-item.self .msg-bubble { background: var(--accent); color: #fff; border-top-right-radius: 4px; text-align: left; }
        .msg-name { font-size: 12px; color: var(--text-muted); margin-bottom: 3px; padding-left: 2px; }
        .chat-input { padding: 16px; border-top: 1px solid var(--border); display: flex; gap: 10px; align-items: flex-end; }
        .chat-input textarea { flex: 1; padding: 10px 14px; border: 1.5px solid var(--border); border-radius: 20px; font-size: 14px; outline: none; resize: none; font-family: var(--font); min-height: 44px; max-height: 120px; }
        .chat-input textarea:focus { border-color: var(--accent); }
        .chat-input button { padding: 10px 22px; background: var(--accent); color: #fff; border: none; border-radius: 20px; cursor: pointer; font-size: 14px; font-weight: 500; white-space: nowrap; }
        .empty-state { flex: 1; display: flex; align-items: center; justify-content: center; color: var(--text-muted); font-size: 15px; }
        .invite-badge { display: inline-block; padding: 2px 8px; background: #e8f5e9; color: #2e7d32; border-radius: 8px; font-size: 11px; margin-left: 6px; cursor: pointer; }
        .alert-error { background: #fce4ec; color: #c62828; padding: 10px 14px; border-radius: 6px; margin: 12px; font-size: 13px; }
        .member-list { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 8px; }
        .member-tag { background: #f5f2ed; padding: 3px 10px; border-radius: 12px; font-size: 12px; display: flex; align-items: center; gap: 4px; }
        .member-tag .kick-btn { color: var(--danger); cursor: pointer; font-weight: 700; font-size: 14px; margin-left: 4px; }
        .member-tag .kick-btn:hover { color: #c0392b; }
        .context-menu { position: fixed; background: #fff; border: 1px solid var(--border); border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); z-index: 999; display: none; min-width: 140px; }
        .context-menu div { padding: 10px 16px; cursor: pointer; font-size: 13px; transition: background 0.1s; }
        .context-menu div:hover { background: #f5f2ed; }
        .btn-sm { padding: 5px 14px; border-radius: 12px; font-size: 12px; cursor: pointer; border: none; font-family: var(--font); }
        .btn-danger { background: var(--danger); color: #fff; }
        .btn-danger:hover { background: #c0392b; }
        .share-mode-btn { background: #8e44ad; color: #fff; padding: 5px 14px; border-radius: 12px; font-size: 12px; cursor: pointer; border: none; font-family: var(--font); margin-left: auto; }
        .share-mode-btn:hover { background: #6c3483; }
        .share-btn { background: #8e44ad; color: #fff; padding: 5px 14px; border-radius: 12px; font-size: 12px; cursor: pointer; border: none; font-family: var(--font); display: none; margin-left: 8px; }
        .share-btn:hover { background: #6c3483; }
        .share-container { max-width: 800px; margin: 20px auto; padding: 20px; background: var(--card-bg); border-radius: var(--radius); box-shadow: var(--shadow); }
        .share-container h2 { margin-bottom: 16px; font-size: 20px; }
        .share-msg-item { margin-bottom: 16px; display: flex; gap: 10px; align-items: flex-start; }
        .share-msg-item.self { flex-direction: row-reverse; }
        .share-msg-avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 14px; font-weight: 600; overflow: hidden; flex-shrink: 0; }
        .share-msg-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .share-msg-item.self .share-msg-avatar { display: none; }
        .share-msg-bubble { max-width: 100%; padding: 10px 14px; border-radius: 14px; font-size: 14px; line-height: 1.6; word-break: break-word; overflow-wrap: break-word; white-space: pre-wrap; }
        .share-msg-item:not(.self) .share-msg-bubble { background: #f5f2ed; border-top-left-radius: 4px; }
        .share-msg-item.self .share-msg-bubble { background: var(--accent); color: #fff; border-top-right-radius: 4px; text-align: left; }
        @media (max-width: 768px) {
            .main { flex-direction: column; padding: 0 12px; }
            .sidebar { width: 100%; max-height: 40vh; }
            .navbar { padding: 0 14px; height: 48px; }
            .navbar h1 { font-size: 15px; }
            .user-info a { font-size: 12px; padding: 5px 9px; }
        }
        a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
        a:hover { color:var(--accent-hover); }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<?php if ($shareMode): ?>
    <!-- 分享页面 -->
    <div class="share-container">
        <h2>分享的聊天记录</h2>
        <div style="margin-bottom:16px;color:var(--text-muted);">会话：<?= safeContent($shareConvName ?? '未知') ?></div>
        <?php if ($shareMessages && $shareMessages->num_rows > 0): ?>
            <?php while ($msg = $shareMessages->fetch_assoc()): ?>
                <div class="share-msg-item <?= $msg['uid'] == $login_uid ? 'self' : '' ?>">
                    <div class="share-msg-avatar">
                        <?php if (!empty($msg['avatar'])): ?><img src="<?= getImgUrl($msg['avatar']) ?>" alt=""><?php else: ?><?= mb_substr($msg['name'], 0, 1) ?><?php endif; ?>
                    </div>
                    <div>
                        <div class="msg-name"><?= safeContent($msg['name']) ?></div>
                        <div class="share-msg-bubble"><?= nl2br(htmlspecialchars($msg['content'], ENT_QUOTES, 'UTF-8')) ?></div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p style="text-align:center;color:var(--text-muted);">暂无消息或分享已失效</p>
        <?php endif; ?>
    </div>
<?php else: ?>
    <!-- 常规私信页面 -->
    <div class="main">
        <div class="sidebar">
            <div class="sidebar-header">
                <input type="text" id="searchUser" placeholder="搜索用户名或UID" onkeydown="if(event.key==='Enter')searchAndChat()">
                <button onclick="searchAndChat()">私信</button>
                <script>
                    function searchAndChat() {
                        var name = document.getElementById('searchUser').value.trim();
                        if (!name) { alert('请输入用户名或UID'); return; }
                        location.href = 'https://lmtoj.cn/message?search=' + encodeURIComponent(name);
                    }
                </script>
            </div>
            <?php if($error):?><div class="alert-error"><?=safeContent($error)?></div><?php endif;?>
            <div class="conv-list">
                <?php if($conversations->num_rows>0): while($c = $conversations->fetch_assoc()): 
                    $displayName = $c['name'];
                    $avatarUrl = '';
                    if($c['type']=='private'){
                        $pRes = $conn->query("SELECT u.name, u.uid FROM users u JOIN chat_members m ON u.uid=m.uid WHERE m.conversation_id={$c['id']} AND m.uid!={$login_uid}")->fetch_assoc();
                        $displayName = $pRes['name']??'未知用户';
                        $pUid = $pRes['uid'] ?? 0;
                        if($pUid) $avatarUrl = $conn->query("SELECT avatar FROM users WHERE uid={$pUid}")->fetch_assoc()['avatar'] ?? '';
                    }
                    $muted = $convMute[$c['id']] ?? 0;
                    $unread = $convUnread[$c['id']] ?? 0;
                ?>
                    <a href="https://lmtoj.cn/message/<?=$c['id']?>" class="conv-item <?=$c['id']==$currentConvId?'active':''?> <?=$muted?'muted':''?>" data-conv-id="<?=$c['id']?>" oncontextmenu="showContextMenu(event, <?=$c['id']?>, <?=$muted?>)">
                        <div class="conv-avatar">
                            <?php if($avatarUrl): ?><img src="<?=getImgUrl($avatarUrl)?>" alt=""><?php else: ?><?=mb_substr($displayName,0,1)?><?php endif; ?>
                        </div>
                        <div class="conv-info">
                            <div class="conv-name">
                                <?=safeContent($displayName)?>
                                <?php if($muted): ?><span class="conv-mute-icon">🔇</span><?php endif; ?>
                            </div>
                            <div class="conv-last"><?=safeContent(mb_substr(str_replace("\n",' ',$c['last_msg']??''),0,25))?></div>
                        </div>
                        <div style="text-align:right;">
                            <div class="conv-time"><?=date('m-d H:i',strtotime($c['updated_at']))?></div>
                            <?php if($unread > 0): ?><div class="conv-unread"><?=$unread?></div><?php endif; ?>
                        </div>
                    </a>
                <?php endwhile; else:?>
                    <p style="text-align:center;padding:20px;color:var(--text-muted);">暂无消息</p>
                <?php endif;?>
            </div>
            <?php if($is_admin):?>
            <div style="padding:12px;border-top:1px solid var(--border);">
                <form method="post" style="display:flex;gap:6px;">
                    <input type="text" name="group_name" placeholder="群聊名称" style="flex:1;padding:8px 12px;border:1.5px solid var(--border);border-radius:20px;font-size:13px;outline:none;">
                    <button type="submit" name="create_group" style="padding:8px 14px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:13px;">建群</button>
                </form>
            </div>
            <?php endif;?>
        </div>

        <div class="chat-area" id="chatArea">
            <?php if($currentConvId>0 && $messages):?>
                <div class="chat-header">
                    <?php if($currentConv['type']=='private'):?>
                        私信 · <a href="https://lmtoj.cn/user/<?=$convPartnerUid?>"><?=safeContent($convPartnerName)?></a>
                        <button class="btn-sm btn-danger" onclick="if(confirm('确定删除与该用户的全部聊天记录？该操作仅对自己可见，对方仍可查看。'))location.href='?delete_conv=1&conv_id=<?=$currentConvId?>'">清空记录</button>
                    <?php else:?>
                        <?=safeContent($currentConv['name']?:'群聊')?>
                        <span class="invite-badge" id="inviteBadge">
                            <span id="inviteToggle" style="cursor:pointer;" onclick="toggleInvite()">邀请码：点击显示</span>
                            <span id="inviteRealContainer" style="display:none;">
                                邀请码：<?=$currentConv['invite_code']??''?>
                                <button onclick="copyInvite()" style="margin-left:6px;padding:2px 8px;font-size:11px;background:#fff;border:1px solid #2e7d32;color:#2e7d32;border-radius:4px;cursor:pointer;">复制</button>
                                <span onclick="toggleInvite()" style="cursor:pointer;margin-left:6px;font-size:11px;color:var(--text-muted);">隐藏</span>
                            </span>
                        </span>
                        <button class="btn-sm btn-danger" onclick="if(confirm('确定清空本群聊天记录（仅自己不可见，其他人仍可查看）？'))location.href='?clear_group=1&conv_id=<?=$currentConvId?>'">清空记录</button>
                        <?php if($currentConv['owner_uid'] == $login_uid): ?><span style="font-size:11px;color:var(--accent);">（群主）</span><?php endif; ?>
                    <?php endif;?>
                    <!-- 分享模式按钮 -->
                    <button class="share-mode-btn" id="shareModeBtn" onclick="toggleShareMode()">分享</button>
                    <!-- 分享选中按钮 -->
                    <button class="share-btn" id="shareBtn" onclick="shareSelectedMessages()">分享选中</button>
                    <?php if($currentConv['type']=='group' && !empty($groupMembers)): ?>
                    <div class="member-list">
                        <?php foreach($groupMembers as $gm): ?>
                        <span class="member-tag">
                            <?=safeContent($gm['name'])?>
                            <?php if($currentConv['owner_uid'] == $login_uid && $gm['uid'] != $login_uid): ?>
                                <span class="kick-btn" onclick="if(confirm('确定踢出 <?=safeContent($gm['name'])?>？'))location.href='?kick_uid=<?=$gm['uid']?>&conv_id=<?=$currentConvId?>'" title="踢出">✕</span>
                            <?php endif; ?>
                        </span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="chat-messages" id="msgContainer">
                    <?php if($hasMoreMessages): ?>
                    <div style="text-align:center;padding:8px;" id="loadMoreArea">
                        <button class="btn-sm" id="loadMoreBtn" onclick="loadMoreMessages()" style="background:var(--accent);color:#fff;">查看更多消息</button>
                        <span id="loadMoreStatus" style="font-size:11px;color:var(--text-muted);margin-left:8px;"></span>
                    </div>
                    <?php endif; ?>
                    <?php while($msg=$messages->fetch_assoc()): 
                        $msgAvatar = $conn->query("SELECT avatar FROM users WHERE uid={$msg['uid']}")->fetch_assoc()['avatar'] ?? '';
                    ?>
                        <div class="msg-item <?=$msg['uid']==$login_uid?'self':''?>" data-msg-id="<?=$msg['id']?>">
                            <div class="msg-checkbox"><input type="checkbox" class="select-msg" value="<?=$msg['id']?>" onchange="toggleSelectCheckbox(this)"></div>
                            <div class="msg-avatar">
                                <?php if($msgAvatar): ?><img src="<?=getImgUrl($msgAvatar)?>" alt=""><?php else: ?><?=mb_substr($msg['name'],0,1)?><?php endif; ?>
                            </div>
                            <div>
                                <?php if($msg['uid']!=$login_uid):?><div class="msg-name"><a href="/user/<?=$msg['uid']?>" style="color:var(--text-muted);text-decoration:none;font-weight:500;"><?=safeContent($msg['name'])?></a></div><?php endif;?>
                                <div class="msg-bubble"><?=nl2br(htmlspecialchars($msg['content'], ENT_QUOTES, 'UTF-8'))?></div>
                            </div>
                        </div>
                    <?php endwhile;?>
                </div>
                <form method="post" class="chat-input" onsubmit="return sendMessage(this)">
                    <input type="hidden" name="conversation_id" value="<?=$currentConvId?>">
                    <textarea name="content" id="msgInput" placeholder="输入消息" rows="2" maxlength="200"></textarea>
                    <?php if(!$jinsixin):?><button type="submit" name="send_msg">发送</button>
                    <?php else:?><button style="background:#bfbab0" disabled>不能发送</button><?php endif;?>
                </form>
            <?php else:?>
                <div class="empty-state">选择一个会话开始聊天，或在左侧搜索用户发起新私信</div>
            <?php endif;?>
        </div>
    </div>
<?php endif; ?>

<div class="context-menu" id="contextMenu">
    <div onclick="toggleMute()" id="muteOption">切换免打扰</div>
</div>

<script>
var contextConvId = 0;
var contextMuted = 0;
var selectedMsgIds = new Set();
var shareModeActive = false;

// 切换分享模式
function toggleShareMode() {
    shareModeActive = !shareModeActive;
    var chatArea = document.getElementById('chatArea');
    var modeBtn = document.getElementById('shareModeBtn');
    var shareBtn = document.getElementById('shareBtn');

    if (shareModeActive) {
        chatArea.classList.add('share-mode');
        modeBtn.textContent = '退出分享';
        shareBtn.style.display = 'inline-block';
    } else {
        chatArea.classList.remove('share-mode');
        modeBtn.textContent = '分享';
        shareBtn.style.display = 'none';
        // 清空所有选中
        selectedMsgIds.clear();
        document.querySelectorAll('.select-msg').forEach(function(cb) {
            cb.checked = false;
        });
        updateShareButton();
    }
}

// 复选框变化处理
function toggleSelectCheckbox(checkbox) {
    var msgId = checkbox.value;
    if (checkbox.checked) {
        selectedMsgIds.add(msgId);
    } else {
        selectedMsgIds.delete(msgId);
    }
    updateShareButton();
}

// 更新分享选中按钮文字
function updateShareButton() {
    var btn = document.getElementById('shareBtn');
    if (btn) {
        btn.textContent = selectedMsgIds.size > 0 ? '分享选中(' + selectedMsgIds.size + ')' : '分享选中';
    }
}

// 分享选中消息
function shareSelectedMessages() {
    if (selectedMsgIds.size === 0) {
        alert('请先勾选要分享的消息');
        return;
    }
    var convId = '<?= $currentConvId ?>';
    var ids = Array.from(selectedMsgIds).join(',');
    var formData = new FormData();
    formData.append('conversation_id', convId);
    formData.append('message_ids', ids);
    formData.append('share_messages', '1');

    fetch('https://lmtoj.cn/message', {
        method: 'POST',
        body: formData,
        headers: {
            'X-Requested-With': 'XMLHttpRequest'
        }
    })
    .then(function(res) { return res.json(); })
    .then(function(data) {
        if (data.success) {
            var shareUrl = 'https://lmtoj.cn/message?share=' + data.share_code;
            navigator.clipboard.writeText(shareUrl).then(function() {
                alert('分享链接已复制：\n' + shareUrl);
            }).catch(function() {
                prompt('复制失败，请手动复制以下链接：', shareUrl);
            });
        } else {
            alert('分享失败：' + (data.error || '未知错误'));
        }
    })
    .catch(function() {
        alert('请求失败，请稍后重试');
    });
}

function sendMessage(form) {
    var textarea = document.getElementById('msgInput');
    if (!textarea.value.trim()) return false;
    return true;
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('邀请信息已复制！');
    }).catch(function() {
        var textarea = document.createElement('textarea');
        textarea.value = text;
        textarea.style.position = 'fixed';
        textarea.style.opacity = '0';
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('邀请信息已复制！');
    });
}

function showContextMenu(event, convId, muted) {
    event.preventDefault();
    contextConvId = convId;
    contextMuted = muted;
    var menu = document.getElementById('contextMenu');
    document.getElementById('muteOption').textContent = muted ? '取消免打扰' : '开启免打扰';
    menu.style.display = 'block';
    menu.style.left = event.clientX + 'px';
    menu.style.top = event.clientY + 'px';
}

function toggleMute() {
    location.href = '?toggle_mute=1&conv_id=' + contextConvId;
}

document.addEventListener('click', function() {
    document.getElementById('contextMenu').style.display = 'none';
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        var textarea = document.getElementById('msgInput');
        if (textarea && document.activeElement === textarea) {
            e.preventDefault();
            var form = document.querySelector('.chat-input');
            var submitBtn = form ? form.querySelector('button[type="submit"]') : null;
            if (submitBtn && !submitBtn.disabled && textarea.value.trim()) {
                submitBtn.click();
            }
        }
    }
});

var container = document.getElementById('msgContainer');
if (container) container.scrollTop = container.scrollHeight;

// 加载更多消息
function loadMoreMessages() {
    var btn = document.getElementById('loadMoreBtn');
    var status = document.getElementById('loadMoreStatus');
    var container = document.getElementById('msgContainer');
    var firstMsg = container.querySelector('.msg-item');
    if (!firstMsg || !btn) return;
    
    var firstId = firstMsg.getAttribute('data-msg-id');
    if (!firstId) return;
    
    btn.disabled = true;
    status.textContent = '加载中...';
    
    fetch('https://lmtoj.cn/message/<?=$currentConvId?>?ajax_load=1&before_id=' + firstId)
        .then(function(res) { return res.text(); })
        .then(function(html) {
            if (html.trim()) {
                var temp = document.createElement('div');
                temp.innerHTML = html;
                var loadMoreArea = document.getElementById('loadMoreArea');
                var insertBefore = loadMoreArea ? loadMoreArea.nextSibling : container.firstChild;
                while (temp.firstChild) {
                    container.insertBefore(temp.firstChild, insertBefore);
                }
                var newFirst = container.querySelector('.msg-item');
                if (newFirst && newFirst.getAttribute('data-msg-id') == firstId) {
                    status.textContent = '没有更多消息了';
                    btn.style.display = 'none';
                } else {
                    status.textContent = '';
                }
            } else {
                status.textContent = '没有更多消息了';
                btn.style.display = 'none';
            }
        })
        .catch(function() {
            status.textContent = '加载失败';
        })
        .finally(function() {
            btn.disabled = false;
        });
}

var inviteVisible = false;
var groupInviteCode = '<?=$currentConv['invite_code']??''?>';
var groupName = '<?=safeContent($currentConv['name']?:'群聊')?>';

function toggleInvite() {
    var toggle = document.getElementById('inviteToggle');
    var realContainer = document.getElementById('inviteRealContainer');
    if (toggle.style.display !== 'none') {
        toggle.style.display = 'none';
        realContainer.style.display = 'inline';
    } else {
        toggle.style.display = 'inline';
        realContainer.style.display = 'none';
    }
}

function copyInvite() {
    var code = '<?=$currentConv['invite_code']??''?>';
    var name = '<?=safeContent($currentConv['name']?:'群聊')?>';
    copyToClipboard('前往 https://lmtoj.cn/group_join ，输入邀请码 ' + code + '，加入' + name + '。');
}

// 发送消息按钮防连点
(function() {
    var form = document.querySelector('.chat-input');
    var btn = form ? form.querySelector('button[type="submit"]') : null;
    if (form && btn && btn.name === 'send_msg') {
        form.addEventListener('submit', function() {
            setTimeout(function() { btn.disabled = true; btn.innerText = '发送中...'; }, 10);
            setTimeout(function() { btn.disabled = false; btn.innerText = '发送'; }, 1000);
        });
    }
})();
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>