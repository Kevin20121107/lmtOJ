<?php
// The PHP development server sends every request through this router. Serve
// existing public assets directly, and keep legacy root-level *.php URLs
// working, while refusing to expose arbitrary private file types.
$documentRoot = realpath(__DIR__);
$requestPath = rawurldecode((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/'));
$requestedFile = realpath(__DIR__ . $requestPath);
if (
    $requestPath !== '/' &&
    $documentRoot !== false &&
    $requestedFile !== false &&
    is_file($requestedFile) &&
    ($requestedFile === $documentRoot || str_starts_with($requestedFile, $documentRoot . DIRECTORY_SEPARATOR))
) {
    $extension = strtolower(pathinfo($requestedFile, PATHINFO_EXTENSION));
    $publicPhpFiles = ['index.php', 'login.php', 'register.php', 'jiaozhun.php'];
    if (
        $extension === 'php' &&
        dirname($requestedFile) === $documentRoot &&
        in_array(basename($requestedFile), $publicPhpFiles, true)
    ) {
        require $requestedFile;
        exit;
    }
    $publicExtensions = [
        'css', 'js', 'map', 'json', 'txt', 'xml',
        'png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico',
        'woff', 'woff2', 'ttf', 'otf', 'pdf', 'zip'
    ];
    if (!str_starts_with(basename($requestedFile), '.') && in_array($extension, $publicExtensions, true)) {
        return false;
    }
}

/**
 * 在当前请求内嵌入 404 页面，而不是跳转或返回空响应。
 *
 * - 设置 HTTP 404 状态码，浏览器地址栏 URL 不变；
 * - 404.php 以“片段 / 内嵌视图”的方式被 require 进来；
 * - 传入 $context，方便 404.php 显示是哪个地址/目标没找到。
 */
function render404(array $context = []): void
{
    if (!headers_sent()) {
        http_response_code(404);
        header('Content-Type: text/html; charset=utf-8');
    }

    // 让 404.php 拿得到上下文（同时也注入局部变量，方便直接用）
    $GLOBALS['__404_context'] = $context;
    extract($context, EXTR_SKIP);

    $notFoundFile = __DIR__ . '/404.php';
    if (is_file($notFoundFile)) {
        // 不用 require_once：同一请求内多次渲染也要能正常输出
        require $notFoundFile;
        return;
    }

    // 兜底：连 404.php 都没有时，至少给出一个内嵌的极简 404 输出
    echo '<div class="page-404" style="padding:40px;text-align:center">'
        . '<h1>404 Not Found</h1>'
        . '<p>你访问的页面不存在或已被移除。</p>'
        . '</div>';
}

require_once 'config.php';
require_once 'Route.php';

Route::pattern('uid', '[0-9]{1,10}');
Route::pattern('id', '[0-9]{1,10}');
Route::pattern('room_id', '[0-9]{1,10}');
Route::pattern('cid', '[0-9]{1,10}');
Route::pattern('tab', '[0-9a-zA-Z_]{1,20}');
Route::pattern('cate', '[0-9]{1,10}');
Route::pattern('type', '[0-9a-zA-Z\_\/\-]{1,10}');
Route::pattern('view', '[a-z]{1,10}');
Route::pattern('filter', '[a-z]{1,10}');

Route::any('/decrypt5', '/qwq.php');

Route::any('/403', '/403.php');
Route::any('/403', '/403.php');
Route::any('/ai-chat', '/ai-chat.php');
Route::any('/ai-cat.php', '/ai-cat.php');
Route::any('/404', '/404.php');
Route::any('/', '/index.php');
Route::any('/login', '/login.php');
Route::any('/register', '/register.php');

Route::any('/admin/file', '/file_admin.php');
Route::any('/admin/sql', '/sql_admin.php');
Route::any('/admin/sync', '/file_sync.php');
Route::any('/admin', '/admin.php');

Route::any('/benben', '/benben.php');
Route::any('/benben/{filter}', '/benben.php');

Route::any('/Part2', '/Part2.pdf');

Route::any('/bind', '/bind.php');

Route::any('/Error', '/Error.php');

Route::any('/article', '/article.php');
Route::any('/article/{id}', '/article.php');
Route::any('/article/{id}/edit', function() {
    $_GET['action'] = 'edit';
    require_once __DIR__ . '/article.php';
});
Route::any('/article/new', function() {
    $_GET['action'] = 'edit';
    $_GET['id'] = 0;
    require_once __DIR__ . '/article.php';
});

Route::any('/ticket', '/ticket.php');
Route::any('/ticket/{id}', '/ticket.php');

Route::any('/user/{uid}', '/user.php');
Route::any('/user/{uid}/{view}', '/user.php');

Route::any('/list/admin', '/admin_list.php');

Route::any('/unban', '/unban.php');

Route::any('/ostracism', '/ostracism.php');

Route::any('/discuss', '/discuss.php');
Route::any('/discuss/pin', '/zhiding.php');
Route::any('/discuss/cate/{id}{cate}', '/discuss.php');
Route::any('/discuss/{id}', '/discuss.php');

Route::any('/ad_manage', '/ad_manage.php');

Route::any('/group_join', '/group_join.php');

Route::any('/password_risk.php', '/password_risk.php');
Route::any('/contest', '/contest.php');
Route::any('/contest/{id}', '/contest_view.php');
Route::any('/contest/{id}/manage', function() {
    $_GET['action'] = 'edit';
    require_once __DIR__ . '/contest_edit.php';
});
Route::any('/contest/{id}/{tab}', '/contest_view.php');
Route::any('/contest/{cid}/problem/{id}', '/problem_view.php');
Route::any('/contest/edit', '/contest_edit.php');

Route::any('/problem', '/problem.php');
Route::any('/problem/edit', '/problem_edit.php');
Route::any('/problem/sync', '/problem_sync.php');
Route::any('/problem/{id}', '/problem_view.php');
Route::any('/problem/solution/{id}', '/problem_sol.php');

Route::any('/image_host', '/image_host.php');
Route::any('/image', '/image.php');
Route::any('/css/fonts/latex', '/css/fonts/latex.php');

Route::any('/notice', '/notice.php');

Route::any('/record', '/record.php');
Route::any('/record/{id}', '/record.php');

Route::any('/ide', '/ide.php');

Route::any('/hec_lmtoj', '/hec_lmtoj.php');
Route::any('/avatar_map', '/avatarmap.php');

Route::any('/ostracism', '/ostracism.php');

Route::any('/written', '/written.php');
Route::any('/written/{id}', '/written_view.php');

Route::any('/team', '/team.php');
Route::any('/team/{id}', '/team_view.php');
Route::any('/ai-chat.php', '/ai-chat.php');

Route::any('/collect', '/collect.php');

Route::any('/task', '/task.php');

Route::any('/store', '/store.php');
Route::any('/theme_ajax.php', '/theme_ajax.php');
Route::any('/help', '/help.php');
Route::any('/help/{type}', '/help.php');

Route::any('/message', '/messages.php');
Route::any('/message/{id}', '/messages.php');

Route::any('/recorder', '/recorder.php');
Route::any('/infoview', '/infoview.php');
Route::any('/userdata', '/userdata.php');
Route::any('/msg_history', '/msg_history.php');
Route::any('/admin_collect', '/admin_collect.php');
Route::any('/test', '/test.php');
Route::any('/backup', '/backup.php');

Route::any('/grant_sqadmin', '/grant_sqadmin.php');

Route::any('/ranking', '/ranking.php');

Route::any('/werewolf', '/werewolf.php');
Route::any('/werewolf/{id}', '/werewolf.php');

Route::any('/lolmtoj/stats', '/lolmtoj_stats.php');
Route::any('/lolmtoj', '/lolmtoj.php');
Route::any('/lolmtoj/{room_id}', '/lolmtoj.php');

Route::any('/uno', '/uno.php');
Route::any('/uno/{room_id}', '/uno.php');

Route::any('/liesbar', '/liesbar.php');
Route::any('/liesbar/{room_id}', '/liesbar.php');

Route::any('/commandblock', '/commandblock.php');

Route::any('/uno/stats', '/uno_stats.php');
Route::any('/uno', '/uno.php');
Route::any('/uno/{room_id}', '/uno.php');

$route = Route::dispatch();

if ($route) {
    $action = $route['action'];

    // 闭包 / 回调路由
    if (is_callable($action)) {
        call_user_func($action);
        exit;
    }

    if (is_string($action)) {
        $path = __DIR__ . '/' . ltrim($action, '/');
        if (file_exists($path)) {
            require_once $path;
            exit;
        }

        // 路由命中了，但目标文件不存在：把 404 内嵌进当前请求
        render404([
            'reason'        => 'missing_route_target',
            'requestPath'   => $requestPath,
            'routeAction'   => $action,
        ]);
        exit;
    }
}

// 没有任何路由命中：同样内嵌 404，而不是空响应或跳转
render404([
    'reason'      => 'no_matching_route',
    'requestPath' => $requestPath,
]);