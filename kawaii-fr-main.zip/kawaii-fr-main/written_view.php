<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header("Location: https://lmtoj.cn/written");
    exit;
}

$sql = "SELECT w.*, u.name as source_name 
        FROM written_questions w 
        LEFT JOIN users u ON w.source_uid = u.uid 
        WHERE w.id = $id";
$result = $conn->query($sql);
if ($result->num_rows == 0) {
    header("Location: https://lmtoj.cn/written");
    exit;
}
$q = $result->fetch_assoc();
$q['options'] = json_decode($q['options'], true);
$q['source_name'] = $q['source_name'] ?? '系统';

$seriesMap = [
    'gesp' => 'GESP',
    'cspj' => 'CSP-J',
    'csps' => 'CSP-S',
    'user' => '用户精选集'
];
function seriesName($key) { global $seriesMap; return $seriesMap[$key] ?? $key; }
function safe($str) { return htmlspecialchars($str, ENT_QUOTES, 'UTF-8'); }

$current_page = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>题目详情 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js"></script>
    <style>
        /* ===== 全局样式（与 ide.php 对齐） ===== */
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
            --transition: 0.18s ease;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body {
            background:var(--bg);
            font-family:var(--font);
            color:var(--text);
            min-height:100vh;
            display:flex;
            flex-direction:column;
            line-height:1.6;
        }

        /* ===== 导航栏 ===== */
        .navbar {
            background:var(--nav-bg);
            height:54px;
            display:flex;
            align-items:center;
            justify-content:space-between;
            padding:0 28px;
            color:var(--nav-text);
            flex-shrink:0;
            position:sticky;
            top:0;
            z-index:100;
            box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 {
            font-size:17px;
            font-weight:600;
            color:#f0ece6;
            letter-spacing:0.4px;
        }
        .navbar h1 a {
            color:#f0ece6;
            text-decoration:none;
        }
        .user-info {
            display:flex;
            align-items:center;
            gap:6px;
        }
        .user-info a {
            color:#e0dbd3;
            text-decoration:none;
            font-size:13.5px;
            padding:7px 13px;
            border-radius:20px;
            transition:var(--transition);
            font-weight:500;
        }
        .user-info a:hover {
            background:rgba(255,255,255,0.1);
            color:#fff;
        }

        /* ===== 主布局（与 ide.php 完全一致） ===== */
        .main {
            flex:1;
            display:flex;
            gap:22px;
            max-width:1100px;
            margin:28px auto 40px;
            padding:0 20px;
            align-items:flex-start;
            width:100%;
        }

        /* ===== 侧边栏样式（与 admin.php / ide.php 一致） ===== */
        .sidebar {
            background:var(--card-bg);
            border-radius:var(--radius);
            box-shadow:var(--shadow);
            width:fit-content;
            min-width:110px;
            overflow:hidden;
            position:sticky;
            top:80px;
            flex-shrink:0;
        }
        .sidebar a {
            display:block;
            padding:13px 22px;
            text-align:center;
            background:var(--card-bg);
            color:var(--text);
            text-decoration:none;
            font-size:14.5px;
            font-weight:500;
            white-space:nowrap;
            transition:var(--transition);
            border-left:3px solid transparent;
            letter-spacing:0.3px;
        }
        .sidebar a:hover {
            background:#f5f2ed;
            border-left-color:var(--accent);
            color:var(--accent);
        }
        .sidebar a:first-child {
            border-radius:var(--radius) var(--radius) 0 0;
        }
        .sidebar a:last-child {
            border-radius:0 0 var(--radius) var(--radius);
        }

        /* ===== 内容区域 ===== */
        .content {
            flex:1;
            min-width:0;
        }

        .back-link {
            display:inline-block;
            margin-bottom:20px;
            color:var(--accent);
            text-decoration:none;
            font-weight:500;
        }
        .back-link:hover {
            text-decoration:underline;
        }

        .card {
            background:#fff;
            border-radius:var(--radius);
            padding:30px 32px;
            box-shadow:var(--shadow);
            margin-bottom:20px;
        }
        .card h2 {
            font-size:22px;
            font-weight:600;
            margin-bottom:16px;
        }
        .meta {
            font-size:14px;
            color:var(--text-muted);
            margin-bottom:16px;
        }
        .meta span {
            display:inline-block;
            padding:2px 12px;
            border-radius:12px;
            margin-right:8px;
            background:var(--accent-light);
            color:var(--accent);
            font-weight:600;
        }
        .question-text {
            font-size:17px;
            margin:16px 0;
        }
        .options {
            font-size:15px;
            color:var(--text-secondary);
            margin-left:20px;
        }
        .options li {
            list-style:none;
            padding:4px 0;
        }
        .answer-box {
            background:#f0f7f0;
            padding:16px 20px;
            border-radius:var(--radius-sm);
            margin-top:16px;
            border-left:4px solid var(--accent);
        }
        .answer-box .label {
            font-weight:600;
            color:var(--accent);
        }
        .explanation-box {
            background:#f8f6f0;
            padding:16px 20px;
            border-radius:var(--radius-sm);
            margin-top:12px;
            border-left:4px solid #d4a24e;
        }
        .md-content {
            line-height:1.8;
        }
        .md-content p {
            margin:6px 0;
        }
        .md-content blockquote {
            border-left:4px solid var(--accent);
            padding:6px 14px;
            margin:8px 0;
            background:#fafaf8;
        }
        .md-content pre {
            background:#2b2a27;
            color:#e8e4dd;
            padding:10px 14px;
            border-radius:var(--radius-sm);
            overflow-x:auto;
        }
        .md-content code {
            background:#f3f0eb;
            padding:2px 6px;
            border-radius:3px;
        }
        .md-content pre code {
            background:transparent;
            padding:0;
            color:inherit;
        }

        /* ===== 响应式（与 admin.php 一致） ===== */
        @media (max-width:768px) {
            .main {
                flex-direction:column;
                padding:0 12px;
                margin:18px auto 30px;
                gap:14px;
            }
            .sidebar {
                width:100%;
                position:static;
                display:flex;
                flex-wrap:wrap;
                border-radius:var(--radius);
            }
            .sidebar a {
                flex:1 1 auto;
                padding:11px 10px;
                font-size:13px;
                border-left:none;
                border-bottom:2px solid transparent;
            }
            .sidebar a:hover {
                border-left-color:transparent;
                border-bottom-color:var(--accent);
            }
            .card {
                padding:18px 14px;
            }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <a href="https://lmtoj.cn/written" class="back-link">← 返回题库</a>
        <div class="card">
            <h2>题目详情</h2>
            <div class="meta">
                <span><?= seriesName($q['series']) ?></span>
                <span>#<?= safe($q['sort_order']) ?></span>
                <?php if (!empty($q['year'])): ?><span><?= safe($q['year']) ?></span><?php endif; ?>
                <?php if (!empty($q['question_type'])): ?><span><?= safe($q['question_type']) ?></span><?php endif; ?>
                <span><?= safe($q['source_name']) ?></span>
            </div>
            <div class="question-text md-content" data-md="<?= safe($q['question']) ?>"></div>
            <div class="options">
                <?php foreach ($q['options'] as $opt): ?>
                    <li><?= safe($opt) ?></li>
                <?php endforeach; ?>
            </div>
            <div class="answer-box">
                <div class="label">正确答案：<?= $q['answer'] ?></div>
            </div>
            <?php if (!empty($q['explanation'])): ?>
                <div class="explanation-box">
                    <div style="font-weight:600;color:#b8860b;">解析：</div>
                    <div class="md-content" data-md="<?= safe($q['explanation']) ?>"></div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<script>
const md = window.markdownit({html:false,linkify:true,typographer:true,breaks:true});
function renderAllMarkdown() {
    document.querySelectorAll('.md-content[data-md]').forEach(el => {
        const raw = el.dataset.md;
        if (raw) {
            let html = md.render(raw);
            html = html.replace(/\$\$([\s\S]*?)\$\$/g, (m, math) => {
                try { return '<div style="text-align:center;">' + katex.renderToString(math, {displayMode:true,throwOnError:false}) + '</div>'; } catch(e) { return m; }
            });
            html = html.replace(/\$([^$]+?)\$/g, (m, math) => {
                try { return katex.renderToString(math, {throwOnError:false}); } catch(e) { return m; }
            });
            el.innerHTML = html;
        }
    });
}
document.addEventListener('DOMContentLoaded', renderAllMarkdown);
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>