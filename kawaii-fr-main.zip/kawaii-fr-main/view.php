<?php
session_start();
require_once __DIR__ . '/security.php';
csrf_protect_request(isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true);

// 从同目录 config.php 读取密码
$password = require __DIR__ . '/config2.php';

// ---------- 操作处理 ----------
if (isset($_GET['delete']) && isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
    $deleteId = $_GET['delete'];
    $storageFile = __DIR__ . '/data.json';
    if (file_exists($storageFile)) {
        $data = json_decode(file_get_contents($storageFile), true);
        if (is_array($data)) {
            foreach ($data as $key => $record) {
                if (isset($record['id']) && $record['id'] === $deleteId) {
                    unset($data[$key]);
                    break;
                }
            }
            $data = array_values($data);
            file_put_contents($storageFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit;
        }
    }
}

if (isset($_GET['clear']) && $_GET['clear'] === 'all' && isset($_SESSION['logged_in'])) {
    $storageFile = __DIR__ . '/data.json';
    file_put_contents($storageFile, json_encode([], JSON_PRETTY_PRINT));
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

if (isset($_POST['password'])) {
    if ($_POST['password'] === $password) {
        $_SESSION['logged_in'] = true;
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    } else {
        $error = '密码错误，请重试。';
    }
}

// 未登录显示登录表单
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    ?>
    <!DOCTYPE html>
    <html lang="zh">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>需要密码</title>
        <style>
            body { font-family: Arial, sans-serif; background: #f5f5f5; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
            .login-box { background: #fff; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,.1); width: 300px; }
            h2 { margin-top: 0; }
            input[type="password"] { width: 100%; padding: 8px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
            button { background: #5e72e4; color: #fff; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; width: 100%; }
            button:hover { background: #4a5fc1; }
            .error { color: #e74c3c; margin-top: 10px; }
        </style>
    </head>
    <body>
        <div class="login-box">
            <h2>Enter Password</h2>
            <form method="post">
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
                <?php if (isset($error)) echo '<div class="error">' . htmlspecialchars($error) . '</div>'; ?>
            </form>
        </div>
    <?php include __DIR__ . '/footer.php'; ?>
</body>
    </html>
    <?php
    exit;
}

// 已登录，展示数据
$storageFile = __DIR__ . '/data.json';
$data = [];
if (file_exists($storageFile)) {
    $json = file_get_contents($storageFile);
    $data = json_decode($json, true);
    if (!is_array($data)) $data = [];
}

usort($data, function($a, $b) {
    return ($b['updated_at'] ?? 0) - ($a['updated_at'] ?? 0);
});
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>收集的数据</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 1400px; margin: 0 auto; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,.1); }
        table { width: 100%; border-collapse: collapse; font-size: 13px; }
        th, td { padding: 6px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f0f0f0; }
        .empty { color: #999; text-align: center; padding: 20px; }
        .count { margin-bottom: 10px; font-weight: bold; }
        .delete-btn { color: #e74c3c; text-decoration: none; border: 1px solid #e74c3c; padding: 2px 8px; border-radius: 4px; font-size: 12px; }
        .delete-btn:hover { background: #e74c3c; color: #fff; }
        .logout-btn { float: right; margin-top: -30px; }
        .logout-btn a { color: #5e72e4; text-decoration: none; }
        .logout-btn a:hover { text-decoration: underline; }
        .actions { margin-bottom: 15px; }
        .actions .clear-btn { background: #e74c3c; color: #fff; border: none; padding: 5px 15px; border-radius: 4px; cursor: pointer; }
        .actions .clear-btn:hover { background: #c0392b; }
        .location-cell, .browser-cell, .hardware-cell, .ip-cell { max-width: 150px; word-break: break-all; }
    </style>
</head>
<body>
    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center;">
            <h1>Data</h1>
            <div class="logout-btn">
                <a href="?logout=1">Exit</a>
            </div>
        </div>
        <div class="actions">
            <span class="count">Total: <?= count($data) ?> records</span>
            <?php if (!empty($data)): ?>
                <button class="clear-btn" onclick="if(confirm('确定要删除所有记录吗？')) location.href='?clear=all'">Delete All</button>
            <?php endif; ?>
        </div>
        <?php if (empty($data)): ?>
            <div class="empty">暂无数据</div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>_uid</th>
                        <th>__client_id</th>
                        <th>IP</th>
                        <th>City</th>
                        <th>Browser&Device Info</th>
                        <th>Hardware Info</th>
                        <th>Operation</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($data as $index => $row): ?>
                        <tr>
                            <td><?= htmlspecialchars($index + 1) ?></td>
                            <td><?= htmlspecialchars($row['_uid'] ?? '') ?></td>
                            <td><?= htmlspecialchars($row['__client_id'] ?? '') ?></td>
                            <td class="ip-cell"><?= htmlspecialchars($row['ip'] ?? 'N/A') ?></td>
                            <td class="city-cell"><?= htmlspecialchars($row['city'] ?? 'Unknown') ?></td>
                            <td class="browser-cell">
                                <?php 
                                if (isset($row['browser']) && is_array($row['browser'])) {
                                    $b = $row['browser'];
                                    $str = "UA: " . htmlspecialchars($b['userAgent'] ?? '') . "<br>";
                                    $str .= "Lang: " . htmlspecialchars($b['language'] ?? '') . "<br>";
                                    $str .= "Platform: " . htmlspecialchars($b['platform'] ?? '') . "<br>";
                                    $str .= "Screen: " . htmlspecialchars($b['screenWidth'] ?? '') . "x" . htmlspecialchars($b['screenHeight'] ?? '') . "<br>";
                                    $str .= "ColorDepth: " . htmlspecialchars($b['colorDepth'] ?? '') . "<br>";
                                    $str .= "Timezone: " . htmlspecialchars($b['timezone'] ?? '');
                                    echo $str;
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td class="hardware-cell">
                                <?php 
                                if (isset($row['hardware']) && is_array($row['hardware'])) {
                                    $h = $row['hardware'];
                                    $str = "CPU Cores: " . htmlspecialchars($h['hardwareConcurrency'] ?? 'N/A') . "<br>";
                                    $str .= "Device Memory: " . htmlspecialchars($h['deviceMemory'] ?? 'N/A') . " GB";
                                    echo $str;
                                } else {
                                    echo 'N/A';
                                }
                                ?>
                            </td>
                            <td>
                                <a href="?delete=<?= urlencode($row['id'] ?? '') ?>" class="delete-btn" onclick="return confirm('确定删除这条记录吗？')">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
