<?php
session_start(); // 必须放在最前面，确保会话可用

error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

// 检查是否登录
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$page = max(1, (int)($_GET['page'] ?? 1));

// 查询当前用户是否为管理员 - 参数化
$stmt = $conn->prepare("SELECT sqadmin FROM users WHERE uid = ? LIMIT 1");
$stmt->bind_param("i", $login_uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ========== 权限校验：非管理员直接跳转到主页 ==========
 if (!$user || ($user['sqadmin'] != 1 && $user['sqadmin'] != 127) ) {
    header("Location: https://lmtoj.cn/");
    exit;
 }
// ==================================================

// 自动添加 banned 字段
$check = $conn->query("SHOW COLUMNS FROM users LIKE 'banned'");
if ($check->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN banned TINYINT DEFAULT 0");
}

// 自动添加 original_name 字段
$checkOrig = $conn->query("SHOW COLUMNS FROM users LIKE 'original_name'");
if ($checkOrig->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN original_name VARCHAR(255) NULL AFTER name");
}

// 自动添加 achievement_score 字段
$checkScore = $conn->query("SHOW COLUMNS FROM users LIKE 'achievement_score'");
if ($checkScore->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN achievement_score INT DEFAULT 0");
}

// ========== 新增：自动添加 base_credit 字段 ==========
$checkBase = $conn->query("SHOW COLUMNS FROM users LIKE 'base_credit'");
if ($checkBase->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN base_credit INT DEFAULT 10");
}

$conn->query("CREATE TABLE IF NOT EXISTS ostracism_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    target_uid INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    reason TEXT,
    operator_uid INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 检查字段是否存在，不存在则添加
$checkLast = $conn->query("SHOW COLUMNS FROM users LIKE 'last_username_change'");
if ($checkLast->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN last_username_change DATETIME NULL");
}

$conn->query("CREATE TABLE IF NOT EXISTS user_bind (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    bind_type ENUM('luogu') NOT NULL,
    bind_value VARCHAR(255) NOT NULL,
    verify_code VARCHAR(32) NOT NULL DEFAULT '',
    verified TINYINT DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_bind (uid, bind_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== 管理员修改用户名 ==========
if (isset($_POST['rename_user'], $_POST['uid'], $_POST['newname'])) {
    $uid = (int)$_POST['uid'];
    $newname = trim($_POST['newname']);
    if ($newname === '') {
        header("Location: https://lmtoj.cn/admin?type=user&page=$page&error=empty_name");
        exit;
    }
    $reason = trim($_POST['reason'] ?? '管理员修改。');
    // 检查用户名是否已被占用 - 参数化
    $checkStmt = $conn->prepare("SELECT uid FROM users WHERE name = ? AND uid != ?");
    $checkStmt->bind_param("si", $newname, $uid);
    $checkStmt->execute();
    if ($checkStmt->get_result()->num_rows > 0) {
        $checkStmt->close();
        header("Location: https://lmtoj.cn/admin?type=user&page=$page&error=name_taken");
        exit;
    }
    $checkStmt->close();
    
    // 获取旧用户名 - 参数化
    $oldStmt = $conn->prepare("SELECT name FROM users WHERE uid = ?");
    $oldStmt->bind_param("i", $uid);
    $oldStmt->execute();
    $oldNameRes = $oldStmt->get_result();
    $oldName = ($oldNameRes && $oldNameRes->num_rows > 0) ? $oldNameRes->fetch_assoc()['name'] : '未知';
    $oldStmt->close();
    
    // 更新用户名 - 参数化
    $updateStmt = $conn->prepare("UPDATE users SET name = ?, last_username_change = NOW() WHERE uid = ?");
    $updateStmt->bind_param("si", $newname, $uid);
    $updateStmt->execute();
    $updateStmt->close();
    
    // 记录日志 - 参数化
    $logReason = "管理员修改用户名：{$oldName} → {$newname}：" . $reason;
    $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'rename_user', ?, ?)");
    $logStmt->bind_param("isi", $uid, $logReason, $login_uid);
    $logStmt->execute();
    $logStmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 单用户封禁/解封（保留，但前端按钮已移除，不再使用） ==========
if (isset($_POST['ban_user'])) {
    $uid = (int)$_POST['ban_user'];
    $reason = trim($_POST['reason'] ?? '管理员封禁');
    
    $stmt = $conn->prepare("UPDATE users SET banned = 1 WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->close();
    
    $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'ban_user', ?, ?)");
    $logStmt->bind_param("isi", $uid, $reason, $login_uid);
    $logStmt->execute();
    $logStmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unban_user'])) {
    $uid = (int)$_POST['unban_user'];
    $reason = trim($_POST['reason'] ?? '管理员解封');
    
    $stmt = $conn->prepare("UPDATE users SET banned = 0 WHERE uid = ?");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $stmt->close();
    
    $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unban_user', ?, ?)");
    $logStmt->bind_param("isi", $uid, $reason, $login_uid);
    $logStmt->execute();
    $logStmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 批量封禁/解封（保留，前端按钮已移除，不再使用） ==========
if (isset($_POST['ban_users'])) {
    $ids = array_map('intval', explode(',', $_POST['ban_users']));
    $reason = trim($_POST['reason'] ?? '管理员批量封禁');
    
    $conn->begin_transaction();
    try {
        foreach($ids as $uid) {
            // 获取用户信息 - 参数化
            $infoStmt = $conn->prepare("SELECT name, banned FROM users WHERE uid = ?");
            $infoStmt->bind_param("i", $uid);
            $infoStmt->execute();
            $uinfo = $infoStmt->get_result()->fetch_assoc();
            $infoStmt->close();
            
            if($uinfo && $uinfo['banned'] == 0){
                $origName = $uinfo['name'];
                $updateStmt = $conn->prepare("UPDATE users SET original_name = ? WHERE uid = ?");
                $updateStmt->bind_param("si", $origName, $uid);
                $updateStmt->execute();
                $updateStmt->close();
            }
            
            $banStmt = $conn->prepare("UPDATE users SET banned = 1, name = ? WHERE uid = ?");
            $banName = "封禁用户{$uid}";
            $banStmt->bind_param("si", $banName, $uid);
            $banStmt->execute();
            $banStmt->close();
            
            $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'ban_user', ?, ?)");
            $logStmt->bind_param("isi", $uid, $reason, $login_uid);
            $logStmt->execute();
            $logStmt->close();
        }
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unban_users'])) {
    $ids = array_map('intval', explode(',', $_POST['unban_users']));
    $reason = trim($_POST['reason'] ?? '管理员批量解封');
    
    $conn->begin_transaction();
    try {
        foreach($ids as $uid) {
            $origStmt = $conn->prepare("SELECT original_name FROM users WHERE uid = ?");
            $origStmt->bind_param("i", $uid);
            $origStmt->execute();
            $orig = $origStmt->get_result()->fetch_assoc();
            $origStmt->close();
            
            if ($orig && !empty($orig['original_name'])) {
                $origName = $orig['original_name'];
                $updateStmt = $conn->prepare("UPDATE users SET banned = 0, name = ?, original_name = NULL WHERE uid = ?");
                $updateStmt->bind_param("si", $origName, $uid);
                $updateStmt->execute();
                $updateStmt->close();
            } else {
                $updateStmt = $conn->prepare("UPDATE users SET banned = 0, name = ? WHERE uid = ?");
                $name = "用户{$uid}";
                $updateStmt->bind_param("si", $name, $uid);
                $updateStmt->execute();
                $updateStmt->close();
            }
            
            $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unban_user', ?, ?)");
            $logStmt->bind_param("isi", $uid, $reason, $login_uid);
            $logStmt->execute();
            $logStmt->close();
        }
        $conn->commit();
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 删除用户（仅uid=1允许操作）
if (isset($_POST['del_user'])) {
    if ($login_uid !== 1) {
        header("Location: https://lmtoj.cn/admin?type=user&page=$page");
        exit;
    }
    $del_uid = (int)$_POST['del_user'];
    
    $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'del_user', '超级管理员删除用户', ?)");
    $logStmt->bind_param("ii", $del_uid, $login_uid);
    $logStmt->execute();
    $logStmt->close();
    
    $delStmt = $conn->prepare("DELETE FROM users WHERE uid = ?");
    $delStmt->bind_param("i", $del_uid);
    $delStmt->execute();
    $delStmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 添加用户（原始版本，仅支持admin复选框） ==========
if (isset($_POST['add_user'])) {
    $name = trim($_POST['name']);
    $pass_raw = trim($_POST['pass']);
    $pass = password_hash($pass_raw, PASSWORD_DEFAULT);
    $admin = isset($_POST['admin']) ? 1 : 0;
    
    if ($name === '') {
        header("Location: https://lmtoj.cn/admin?type=user&page=$page&error=empty_name");
        exit;
    }
    
    $maxResult = $conn->query("SELECT MAX(uid) AS m FROM users");
    $max = $maxResult->fetch_assoc();
    $newUID = $max['m'] ? $max['m'] + 1 : 1;
    
    $sql = "INSERT INTO users (uid, name, password, admin) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("issi", $newUID, $name, $pass, $admin);
    $stmt->execute();
    $stmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 设置标签
if (isset($_POST['add_tag'])) {
    $uid = (int)$_POST['add_tag_uid'];
    $name = trim($_POST['add_tag_name']);
    
    $stmt = $conn->prepare("UPDATE users SET tag = ? WHERE uid = ?");
    $stmt->bind_param("si", $name, $uid);
    $stmt->execute();
    $stmt->close();
    
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 修改用户总估值 ==========
if (isset($_POST['update_valuation'])) {
    $uid = (int)$_POST['valuation_uid'];
    $val = (int)$_POST['valuation_value'];
    if ($uid > 0) {
        $stmt = $conn->prepare("UPDATE users SET valuation = ? WHERE uid = ?");
        $stmt->bind_param("ii", $val, $uid);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 修改基础信用 ==========
if (isset($_POST['update_base_credit'])) {
    $uid = (int)$_POST['base_credit_uid'];
    $newBase = (int)$_POST['base_credit_value'];
    if ($uid > 0 && $newBase >= 0) {
        $stmt = $conn->prepare("UPDATE users SET base_credit = ? WHERE uid = ?");
        $stmt->bind_param("ii", $newBase, $uid);
        $stmt->execute();
        $stmt->close();
        
        // 检查是否棕名，若未棕名则重新计算总估值
        $rowStmt = $conn->prepare("SELECT valuation, achievement_score, practice_score, contribute_score, contest_score FROM users WHERE uid = ?");
        $rowStmt->bind_param("i", $uid);
        $rowStmt->execute();
        $row = $rowStmt->get_result()->fetch_assoc();
        $rowStmt->close();
        
        if ($row && $row['valuation'] != -1) {
            $sum = (int)$row['achievement_score'] + (int)$row['practice_score'] + (int)$row['contribute_score'] + (int)$row['contest_score'] + $newBase;
            $updateStmt = $conn->prepare("UPDATE users SET valuation = ? WHERE uid = ?");
            $updateStmt->bind_param("ii", $sum, $uid);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 修改三项分数 ==========
if (isset($_POST['update_scores'])) {
    $uid = (int)$_POST['score_uid'];
    $practice = (int)$_POST['practice_score'];
    $contribute = (int)$_POST['contribute_score'];
    $contest = (int)$_POST['contest_score'];
    
    if ($uid > 0) {
        $stmt = $conn->prepare("UPDATE users SET practice_score = ?, contribute_score = ?, contest_score = ? WHERE uid = ?");
        $stmt->bind_param("iiii", $practice, $contribute, $contest, $uid);
        $stmt->execute();
        $stmt->close();
        
        // 检查是否棕名，若未棕名则重新计算总估值
        $rowStmt = $conn->prepare("SELECT valuation, achievement_score, base_credit FROM users WHERE uid = ?");
        $rowStmt->bind_param("i", $uid);
        $rowStmt->execute();
        $row = $rowStmt->get_result()->fetch_assoc();
        $rowStmt->close();
        
        if ($row && $row['valuation'] != -1) {
            $sum = (int)$row['achievement_score'] + $practice + $contribute + $contest + (int)$row['base_credit'];
            $updateStmt = $conn->prepare("UPDATE users SET valuation = ? WHERE uid = ?");
            $updateStmt->bind_param("ii", $sum, $uid);
            $updateStmt->execute();
            $updateStmt->close();
        }
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 设为棕名 ==========
if (isset($_POST['set_brown'], $_POST['uid'])) {
    $uid = (int)$_POST['uid'];
    if ($uid > 0) {
        $reason = isset($_POST['reason']) ? trim($_POST['reason']) : '';
        if ($reason === '') {
            $reason = 'set_brown';
        }
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_brown', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
        
        $updateStmt = $conn->prepare("UPDATE users SET valuation = -1 WHERE uid = ?");
        $updateStmt->bind_param("i", $uid);
        $updateStmt->execute();
        $updateStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 取消棕名 ==========
if (isset($_POST['unset_brown'], $_POST['uid'])) {
    $uid = (int)$_POST['uid'];
    if ($uid > 0) {
        $rowStmt = $conn->prepare("SELECT achievement_score, practice_score, contribute_score, contest_score, base_credit FROM users WHERE uid = ?");
        $rowStmt->bind_param("i", $uid);
        $rowStmt->execute();
        $row = $rowStmt->get_result()->fetch_assoc();
        $rowStmt->close();
        
        $sum = (int)$row['achievement_score'] + (int)$row['practice_score'] + (int)$row['contribute_score'] + (int)$row['contest_score'] + (int)$row['base_credit'];
        
        $updateStmt = $conn->prepare("UPDATE users SET valuation = ? WHERE uid = ?");
        $updateStmt->bind_param("ii", $sum, $uid);
        $updateStmt->execute();
        $updateStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 批量授予多个权限 ==========
if (isset($_POST['batch_grant_perms'])) {
    $ids = array_map('intval', explode(',', $_POST['batch_grant_perms']));
    $perms = explode(',', $_POST['perm_list'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    if ($reason === '') {
        $reason = '管理员批量授予权限';
    }

    $allowedPerms = ['admin', 'sqadmin', 'proadmin', 'conadmin', 'artadmin', 'devadmin', 'jinyan', 'sixin', 'banned'];
    $permFields = [];
    foreach ($perms as $p) {
        $p = trim($p);
        if (in_array($p, $allowedPerms)) {
            $permFields[] = $p;
        }
    }

    if (!empty($ids) && !empty($permFields)) {
        foreach ($ids as $uid) {
            foreach ($permFields as $field) {
                if ($field === 'banned') {
                    // 查询 original_name
                    $origStmt = $conn->prepare("SELECT original_name FROM users WHERE uid = ?");
                    $origStmt->bind_param("i", $uid);
                    $origStmt->execute();
                    $orig = $origStmt->get_result()->fetch_assoc();
                    $origStmt->close();

                    if ($orig && !empty($orig['original_name'])) {
                        $origName = $orig['original_name'];
                        $updateStmt = $conn->prepare("UPDATE users SET banned = 0, name = ?, original_name = NULL WHERE uid = ?");
                        $updateStmt->bind_param("si", $origName, $uid);
                                    $updateStmt->execute();
                        $updateStmt->close();
                    } else {
                        $updateStmt = $conn->prepare("UPDATE users SET banned = 0, name = ? WHERE uid = ?");
                        $name = "用户{$uid}";
                        $updateStmt->bind_param("si", $name, $uid);
                        $updateStmt->execute();
                        $updateStmt->close();
                    }

                    // 记录日志
                    $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unban_user', ?, ?)");
                    $logStmt->bind_param("isi", $uid, $reason, $login_uid);
                    $logStmt->execute();
                    $logStmt->close();
                    continue;
                }
                // jinyan、sixin、banned 是反逻辑：1表示禁止/封禁，授予时应设为0
                if ($field === 'jinyan' || $field === 'sixin' || $field === 'banned') {
                    $value = 0;
                } else {
                    $value = 1;
                }
                $stmt = $conn->prepare("UPDATE users SET {$field} = ? WHERE uid = ?");
                $stmt->bind_param("ii", $value, $uid);
                $stmt->execute();
                $stmt->close();

                $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, ?, ?, ?)");
                $logAction = 'set_' . $field;
                $logStmt->bind_param("issi", $uid, $logAction, $reason, $login_uid);
                $logStmt->execute();
                $logStmt->close();
            }
        }
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 批量撤销多个权限 ==========
if (isset($_POST['batch_revoke_perms'])) {
    $ids = array_map('intval', explode(',', $_POST['batch_revoke_perms']));
    $perms = explode(',', $_POST['perm_list'] ?? '');
    $reason = trim($_POST['reason'] ?? '');
    if ($reason === '') {
        $reason = '管理员批量撤销权限';
    }

    $allowedPerms = ['admin', 'sqadmin', 'proadmin', 'conadmin', 'artadmin', 'devadmin', 'jinyan', 'sixin', 'banned'];
    $permFields = [];
    foreach ($perms as $p) {
        $p = trim($p);
        if (in_array($p, $allowedPerms)) {
            $permFields[] = $p;
        }
    }

    if (!empty($ids) && !empty($permFields)) {
        foreach ($ids as $uid) {
            foreach ($permFields as $field) {
    if ($field === 'banned') {
        // 获取用户当前信息
        $infoStmt = $conn->prepare("SELECT name, banned FROM users WHERE uid = ?");
        $infoStmt->bind_param("i", $uid);
        $infoStmt->execute();
        $uinfo = $infoStmt->get_result()->fetch_assoc();
        $infoStmt->close();

        // 如果还没被封禁，保存 original_name
        if ($uinfo && $uinfo['banned'] == 0) {
            $origName = $uinfo['name'];
            $updateStmt = $conn->prepare("UPDATE users SET original_name = ? WHERE uid = ?");
            $updateStmt->bind_param("si", $origName, $uid);
            $updateStmt->execute();
            $updateStmt->close();
        }

        // 封禁并改名
        $banStmt = $conn->prepare("UPDATE users SET banned = 1, name = ? WHERE uid = ?");
        $banName = "封禁用户{$uid}";
        $banStmt->bind_param("si", $banName, $uid);
        $banStmt->execute();
        $banStmt->close();

        // 记录日志
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'ban_user', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
        continue;
    }
                // 撤销权限：jinyan/sixin/banned 应设为1（禁止/封禁），其他设为0
                if ($field === 'jinyan' || $field === 'sixin' || $field === 'banned') {
                    $value = 1;
                } else {
                    $value = 0;
                }
                $stmt = $conn->prepare("UPDATE users SET {$field} = ? WHERE uid = ?");
                $stmt->bind_param("ii", $value, $uid);
                $stmt->execute();
                $stmt->close();

                $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, ?, ?, ?)");
                $logAction = 'unset_' . $field;
                $logStmt->bind_param("issi", $uid, $logAction, $reason, $login_uid);
                $logStmt->execute();
                $logStmt->close();
            }
        }
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 管理员手动绑定洛谷账号 ==========
if (isset($_POST['manual_bind'])) {
    $target_uid = (int)$_POST['target_uid'];
    $luogu_uid = trim($_POST['luogu_uid']);
    if ($target_uid > 0 && $luogu_uid !== '' && is_numeric($luogu_uid)) {
        $stmt = $conn->prepare("INSERT INTO user_bind (uid, bind_type, bind_value, verified) 
                                VALUES (?, 'luogu', ?, 1) 
                                ON DUPLICATE KEY UPDATE bind_value = ?, verified = 1");
        $stmt->bind_param("iss", $target_uid, $luogu_uid, $luogu_uid);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page&manual_bind=ok");
    exit;
}

if (isset($_POST['batch_del'])) {
    if (!empty($_POST['ids'])) {
        $ids = array_map('intval', $_POST['ids']);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        $stmt = $conn->prepare("DELETE FROM benben WHERE id IN ($placeholders)");
        $stmt->bind_param($types, ...$ids);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=benben&page=$page");
    exit;
}

if (isset($_POST['del_visit']) && $login_uid == 1) {
    $conn->query("DELETE FROM visit");
    header("Location: https://lmtoj.cn/admin?type=visit");
    exit;
}

// 社区管理
if (isset($_POST['set_sqadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['set_sqadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET sqadmin = 1 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_sqadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unset_sqadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['unset_sqadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET sqadmin = 0 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unset_sqadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 题目管理
if (isset($_POST['set_proadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['set_proadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET proadmin = 1 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_proadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unset_proadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['unset_proadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET proadmin = 0 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unset_proadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 比赛管理
if (isset($_POST['set_conadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['set_conadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET conadmin = 1 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_conadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unset_conadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['unset_conadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET conadmin = 0 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unset_conadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 专栏管理
if (isset($_POST['set_artadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['set_artadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET artadmin = 1 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_artadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unset_artadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['unset_artadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET artadmin = 0 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unset_artadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// 开发组
if (isset($_POST['set_devadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['set_devadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET devadmin = 1 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_devadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

if (isset($_POST['unset_devadmin'])) {
    $ids = array_map('intval', explode(',', $_POST['unset_devadmin']));
    $reason = trim($_POST['reason'] ?? '');
    
    foreach($ids as $uid) {
        $stmt = $conn->prepare("UPDATE users SET devadmin = 0 WHERE uid = ?");
        $stmt->bind_param("i", $uid);
        $stmt->execute();
        $stmt->close();
        
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'unset_devadmin', ?, ?)");
        $logStmt->bind_param("isi", $uid, $reason, $login_uid);
        $logStmt->execute();
        $logStmt->close();
    }
    header("Location: https://lmtoj.cn/admin?type=user&page=$page");
    exit;
}

// ========== 查询部分 - 全部都使用参数化 ==========
$type = $_GET['type'] ?? 'user';
$limit = 20;
$offset = ($page - 1) * $limit;

// 用户列表查询 - 使用 LIMIT 占位符（MySQL支持）
$userCount = $conn->query("SELECT COUNT(*) AS c FROM users")->fetch_assoc()['c'];
$userPage = ceil($userCount / $limit);

// 使用参数化查询获取用户列表
$userStmt = $conn->prepare("SELECT * FROM users ORDER BY uid ASC LIMIT ?, ?");
$userStmt->bind_param("ii", $offset, $limit);
$userStmt->execute();
$userList = $userStmt->get_result();
$userStmt->close();

// 犇犇列表
$benCount = $conn->query("SELECT COUNT(*) AS c FROM benben")->fetch_assoc();
$benPage = ceil(1000 / $limit);

$benStmt = $conn->prepare("
    SELECT b.*, u.name
    FROM benben b
    LEFT JOIN users u ON b.uid = u.uid
    ORDER BY b.time DESC, b.id DESC
    LIMIT ?, ?
");
$benStmt->bind_param("ii", $offset, $limit);
$benStmt->execute();
$benList = $benStmt->get_result();
$benStmt->close();

// 访问记录
$visitCount = 0;
$visitPage = 0;
$visitList = null;
if ($login_uid == 1) {
    $visitCount = $conn->query("SELECT COUNT(*) AS c FROM visit")->fetch_assoc()['c'];
    $visitPage = ceil($visitCount / 500);
    $start = ($page - 1) * 500;
    $visitStmt = $conn->prepare("SELECT * FROM visit ORDER BY time DESC LIMIT $start,500");
    $visitStmt->execute();
    $visitList = $visitStmt->get_result();
    $visitStmt->close();
}

// 未读消息
$msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
$msgStmt->bind_param("i", $login_uid);
$msgStmt->execute();
$msgRes = $msgStmt->get_result();
$unreadCount = $msgRes ? (int)$msgRes->fetch_assoc()['cnt'] : 0;
$msgStmt->close();

$errorMsg = '';
if (isset($_GET['error'])) {
    if ($_GET['error'] === 'invalid_name') {
        $errorMsg = '用户名格式错误：仅允许英文、数字、下划线，长度3-20位。';
    } elseif ($_GET['error'] === 'name_taken') {
        $errorMsg = '该用户名已被占用。';
    } elseif ($_GET['error'] === 'empty_name') {
        $errorMsg = '用户名不能为空。';
    }
}

// 获取单个用户分数
$targetUid = isset($_GET['score_uid']) ? (int)$_GET['score_uid'] : 0;
$scoreRow = null;
if ($targetUid > 0) {
    $scoreStmt = $conn->prepare("SELECT achievement_score, practice_score, contribute_score, contest_score, valuation, base_credit FROM users WHERE uid = ?");
    $scoreStmt->bind_param("i", $targetUid);
    $scoreStmt->execute();
    $scoreRow = $scoreStmt->get_result()->fetch_assoc();
    $scoreStmt->close();
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>后台管理中心 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
	a:hover { color:var(--accent-hover); text-decoration:underline; }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;min-height:100vh;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;letter-spacing:0.4px;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);white-space:nowrap;font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1250px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;background:var(--card-bg);color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;white-space:nowrap;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .sidebar a:first-child{border-radius:var(--radius) var(--radius) 0 0;}
        .sidebar a:last-child{border-radius:0 0 var(--radius) var(--radius);}
        .content{flex:1;min-width:0;}
        .tabs{display:flex;gap:4px;margin-bottom:20px;background:var(--card-bg);border-radius:var(--radius);padding:6px;box-shadow:var(--shadow-sm);}
        .tab{padding:10px 20px;text-decoration:none;color:var(--text-secondary);font-size:14px;font-weight:500;border-radius:var(--radius-sm);transition:var(--transition);}
        .tab:hover{background:#f5f2ed;color:var(--text);}
        .tab.active{background:var(--accent);color:#fff;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;margin-bottom:18px;box-shadow:var(--shadow);}
        .card h3{font-size:16px;font-weight:600;margin-bottom:14px;color:var(--text);}
        table{width:100%;border-collapse:collapse;}
        th{text-align:left;padding:11px 14px;background:#fafaf8;font-weight:500;font-size:13px;color:var(--text-secondary);border-bottom:2px solid var(--border);}
        td{padding:11px 14px;border-bottom:1px solid var(--border-light);font-size:14px;}
        tr:hover{background:#fdfcf9;}
        .btn{padding:6px 13px;border-radius:20px;border:none;cursor:pointer;font-size:12.5px;font-weight:500;text-decoration:none;display:inline-block;transition:var(--transition);font-family:var(--font);letter-spacing:0.2px;}
        .btn-blue{background:var(--accent);color:#fff;}
        .btn-blue:hover{background:var(--accent-hover);}
        .btn-red{background:var(--danger);color:#fff;}
        .btn-red:hover{background:var(--danger-hover);}
        .btn-green{background:#5a9e6f;color:#fff;}
        .btn-green:hover{background:#4a855c;}
        .btn-orange{background:#d4a24e;color:#fff;}
        .btn-orange:hover{background:#b8893c;}
        .btn-sm{padding:4px 10px;font-size:11.5px;}
        .page-bar{display:flex;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap;}
        .page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;transition:var(--transition);background:#fff;}
        .page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
        .page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);}
        .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
        .add-form{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:12px;}
        input,select{padding:8px 12px;border:1.5px solid var(--border);border-radius:var(--radius-sm);outline:none;font-size:14px;font-family:var(--font);transition:var(--transition);background:#fdfdfc;}
        input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);}
        label{font-size:14px;color:var(--text-secondary);}
        .reason-input{padding:6px 10px;border:1.5px solid var(--border);border-radius:20px;font-size:13px;outline:none;width:160px;}
        .reason-input:focus{border-color:var(--accent);}
        .error-box{background:#fde8e8;border:1px solid #f5c6c6;color:#a94442;padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:16px;}
        .score-form { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
        .score-form input[type="number"] { width: 80px; }
        .brown-btn { background: #8b6b4d; color: #fff; }
        .brown-btn:hover { background: #7a5d42; }
        @media(max-width:768px){
            .main{flex-direction:column;padding:0 12px;margin:18px auto 30px;gap:14px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;border-radius:var(--radius);}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .card{padding:18px 14px;}
            .score-form input[type="number"] { width: 60px; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <div class="tabs">
            <a href="https://lmtoj.cn/admin?type=user" class="tab <?=($type=='user')?'active':''?>">用户管理</a>
            <a href="https://lmtoj.cn/admin?type=benben" class="tab <?=($type=='benben')?'active':''?>">犇犇管理</a>
            <?php if($login_uid==1): ?>
            <a href="https://lmtoj.cn/admin?type=visit" class="tab <?=($type=='visit')?'active':''?>">访问记录</a>
            <?php endif; ?>
        </div>

        <?php if($errorMsg): ?>
        <div class="error-box"><?=htmlspecialchars($errorMsg)?></div>
        <?php endif; ?>

    <?php if($type == 'user'): ?>
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:8px;">
            <h3 style="margin:0;">用户列表</h3>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                <input type="text" id="batchReason" class="reason-input" placeholder="操作原因（必填）">
                <input type="text" id="manualUids" class="reason-input" placeholder="手动输入UID（逗号分隔）" style="width:200px;">
                
                <div style="display:flex;flex-wrap:wrap;gap:8px;align-items:center;background:#fafaf8;padding:8px;border-radius:20px;">
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="admin"> 管理
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="sqadmin"> 社区
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="proadmin"> 题目
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="conadmin"> 比赛
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="artadmin"> 专栏
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="devadmin"> 开发
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="jinyan"> 发言
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="sixin"> 私信
                    </label>
                    <label style="display:flex;align-items:center;gap:4px;font-size:13px;">
                        <input type="checkbox" class="perm-check" value="banned"> 进站
                    </label>
                </div>

                <button class="btn btn-green btn-sm" onclick="batchPermAction('grant')">批量授予</button>
                <button class="btn btn-orange btn-sm" onclick="batchPermAction('revoke')">批量撤销</button>

                <button class="btn btn-blue btn-sm" onclick="renameUserBatch()">修改用户名</button>
                <?php if ($login_uid === 1): ?>
                <button class="btn btn-red btn-sm" onclick="batchAction('del_users')">删除用户</button>
                <?php endif; ?>
            </div>
        </div>
        <table>
            <tr>
                <th width="2%"><input type="checkbox" id="checkAllUser"></th>
                <th width="5%">UID</th>
                <th width="15%">用户名</th>
                <th width="10%">tag</th>
                <th width="6%">管理</th>
                <th width="6%">社区</th>
                <th width="6%">题目</th>
                <th width="6%">比赛</th>
                <th width="6%">专栏</th>
                <th width="6%">开发</th>
                <th width="6%">禁言</th>
                <th width="6%">私信</th>
                <?php if($login_uid==1): ?><th width="10%">注册IP</th><?php endif; ?>
                <th>封禁</th>
            </tr>
            <?php while($u = $userList->fetch_assoc()): ?>
            <tr>
                <td><input type="checkbox" class="user-check" value="<?=$u['uid']?>"></td>
                <td><?=$u['uid']?></td>
                <td><a href="https://lmtoj.cn/user/<?=$u['uid']?>"><?=htmlspecialchars($u['name'])?></a></td>
                <td><?=htmlspecialchars($u['tag']??'')?></td>
                <td><?=$u['admin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['sqadmin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['proadmin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['conadmin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['artadmin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['devadmin']?'<span style="color: #8e44ad;font-weight:600;">是</span>' : '否'?></td>
                <td><?=$u['jinyan']?'<span style="color:var(--danger);font-weight:600;">禁止</span>' : '正常'?></td>
                <td><?=$u['sixin']?'<span style="color:var(--danger);font-weight:600;">禁止</span>' : '正常'?></td>
                <?php if($login_uid==1): ?><td><?=htmlspecialchars($u['ip']??'')?></td><?php endif; ?>
                <td><?=$u['banned'] ? '<span style="color:var(--danger);font-weight:600;">封禁</span>' : '正常' ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
        <div class="page-bar">
            <?php if($page > 1): ?><a href="?type=user&page=<?=$page-1?>">上一页</a><?php endif; ?>
            <?php
            $shown = []; $shown[] = 1;
            for($i = max(2, $page-2); $i <= min($userPage-1, $page+2); $i++) $shown[] = $i;
            if($userPage > 1) $shown[] = $userPage;
            $shown = array_unique($shown); sort($shown); $prev = 0;
            foreach($shown as $i):
                if($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
            ?><a href="?type=user&page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a><?php $prev = $i; endforeach; ?>
            <?php if($page < $userPage): ?><a href="?type=user&page=<?=$page+1?>">下一页</a><?php endif; ?>
        </div>
    </div>

    <div class="card">
        <h3>添加用户</h3>
        <form method="post" class="add-form">
            <?= csrf_field() ?>
            <input type="text" name="name" placeholder="用户名（任意字符，不能为空）" required>
            <input type="password" name="pass" placeholder="密码" required>
            <label style="display:flex;align-items:center;gap:4px;"><input type="checkbox" name="admin" value="1"> 设为管理员</label>
            <button type="submit" name="add_user" class="btn btn-blue">添加</button>
        </form>
    </div>

    <div class="card">
        <h3>设置用户标签</h3>
        <form method="post" class="add-form">
            <?= csrf_field() ?>
            <input type="number" name="add_tag_uid" placeholder="用户UID" required>
            <input type="text" name="add_tag_name" placeholder="标签内容" required>
            <button type="submit" name="add_tag" class="btn btn-blue">确定</button>
        </form>
    </div>

    <!-- ===== 修改总估值 ===== -->
    <div class="card">
        <h3>修改总估值</h3>
        <form method="post" class="add-form">
            <?= csrf_field() ?>
            <input type="number" name="valuation_uid" placeholder="用户 UID" required>
            <input type="number" name="valuation_value" placeholder="总估值（整数）" required>
            <button type="submit" name="update_valuation" class="btn btn-blue">更新总估值</button>
        </form>
        <p style="font-size:13px;color:var(--text-muted);margin-top:6px;">直接修改 valuation 字段（不涉及四项分数）。</p>
    </div>

    <!-- ===== 修改基础信用 ===== -->
    <div class="card">
        <h3>修改基础信用</h3>
        <form method="post" class="add-form">
            <?= csrf_field() ?>
            <input type="number" name="base_credit_uid" placeholder="用户 UID" required>
            <input type="number" name="base_credit_value" placeholder="新基础信用（非负整数）" required min="0">
            <button type="submit" name="update_base_credit" class="btn btn-blue">更新基础信用</button>
        </form>
        <p style="font-size:13px;color:var(--text-muted);margin-top:6px;">
            若用户未被棕名，修改后将自动重新计算总估值（四项分数 + 基础信用）。<br>
            基础信用默认 10，建议范围 0~10。
        </p>
    </div>

    <!-- ===== 修改三项分数 ===== -->
    <div class="card">
        <h3>修改练习/贡献/比赛分</h3>
        <form method="post" class="score-form">
            <?= csrf_field() ?>
            <input type="number" name="score_uid" placeholder="用户UID" required value="<?=$targetUid?:''?>" style="width:80px;">
            <span style="color:var(--text-secondary);font-size:13px;">成就分：<?=$scoreRow['achievement_score']??0?></span>
            <label>练习分</label><input type="number" name="practice_score" placeholder="0" value="<?=$scoreRow['practice_score']??0?>" style="width:60px;">
            <label>贡献分</label><input type="number" name="contribute_score" placeholder="0" value="<?=$scoreRow['contribute_score']??0?>" style="width:60px;">
            <label>比赛分</label><input type="number" name="contest_score" placeholder="0" value="<?=$scoreRow['contest_score']??0?>" style="width:60px;">
            <button type="submit" name="update_scores" class="btn btn-blue">更新三项</button>
        </form>
        <div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
            <?php if ($targetUid > 0): ?>
                <span style="font-size:13px;color:var(--text-secondary);">当前基础信用：<?=$scoreRow['base_credit']??10?></span>
                <span style="font-size:13px;color:var(--text-secondary);">当前总估值：<?=$scoreRow['valuation']??'未知'?></span>
            <?php endif; ?>
            <form method="post" style="display:inline; display:flex; gap:6px; flex-wrap:wrap; align-items:center;">
                <?= csrf_field() ?>
                <input type="hidden" name="type" value="user">
                <input type="hidden" name="page" value="<?=$page?>">
                <input type="number" name="uid" placeholder="UID" required style="width:80px;padding:4px 8px;">
                <input type="text" name="reason" placeholder="原因（默认学术不端）" style="width:160px;padding:4px 8px;">
                <button type="submit" name="set_brown" class="btn btn-sm brown-btn">设为棕名</button>
                <button type="submit" name="unset_brown" class="btn btn-sm btn-green">取消棕名</button>
            </form>
        </div>
        <p style="font-size:13px;color:var(--text-muted);margin-top:6px;">
            <strong>成就分</strong> 由系统根据认证自动计算，不可手动修改。<br>
            <strong>棕名</strong>：将总估值强制设为 -1，三项分数不变，并在陶片放逐日志中记录（默认原因：学术不端）。<br>
            <strong>取消棕名</strong>：将总估值恢复为四项分数 + 基础信用的和。
        </p>
    </div>

    <!-- 手动绑定洛谷 -->
    <div class="card">
        <h3>手动绑定洛谷账号</h3>
        <form method="post" class="add-form">
            <?= csrf_field() ?>
            <input type="number" name="target_uid" placeholder="用户 UID" required>
            <input type="number" name="luogu_uid" placeholder="洛谷 UID" required>
            <button type="submit" name="manual_bind" class="btn btn-blue">确认绑定</button>
        </form>
        <p style="font-size:13px;color:var(--text-muted);margin-top:6px;">
            管理员直接为用户绑定洛谷账号（跳过验证）。重复绑定会覆盖原有洛谷 UID。
        </p>
    </div>

    <?php elseif($type == 'benben'): ?>
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
            <h3 style="margin:0;">犇犇管理</h3>
            <form method="post" id="benbenBatchForm" style="margin:0;">
                <?= csrf_field() ?>
                <button type="submit" name="batch_del" class="btn btn-red" onclick="return confirm('确认删除选中内容？')">批量删除</button>
            </form>
        </div>
        <table>
            <tr>
                <th width="40"><input type="checkbox" id="checkAll"></th>
                <th width="50">ID</th><th width="90">发布人</th><th width="150">时间</th><th>内容</th>
            </tr>
            <?php while($b = $benList->fetch_assoc()): ?>
            <tr>
                <td><input type="checkbox" name="ids[]" class="item" value="<?=$b['id']?>" form="benbenBatchForm"></td>
                <td><?=$b['id']?></td>
                <td><?=htmlspecialchars($b['name'])?></td>
                <td><?=$b['time']?></td>
                <td style="max-width:420px;"><?=htmlspecialchars(mb_substr($b['text'],0,80))?>...</td>
            </tr>
            <?php endwhile; ?>
        </table>
        <div class="page-bar">
            <?php if($page > 1): ?><a href="?type=benben&page=<?=$page-1?>">上一页</a><?php endif; ?>
            <?php
            $shown = []; $shown[] = 1;
            for($i = max(2, $page-2); $i <= min($benPage-1, $page+2); $i++) $shown[] = $i;
            if($benPage > 1) $shown[] = $benPage;
            $shown = array_unique($shown); sort($shown); $prev = 0;
            foreach($shown as $i):
                if($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
            ?><a href="?type=benben&page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a><?php $prev = $i; endforeach; ?>
            <?php if($page < $benPage): ?><a href="?type=benben&page=<?=$page+1?>">下一页</a><?php endif; ?>
        </div>
    </div>

    <?php elseif($type == 'visit' && $login_uid == 1): ?>
    <div class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
            <h3 style="margin:0;">访问记录</h3>
            <form method="post" style="margin:0;">
                <?= csrf_field() ?>
                <button type="submit" name="del_visit" value="1" class="btn btn-red" onclick="return confirm('确定清空所有访问记录？')">清空记录</button>
            </form>
        </div>
        <table>
            <tr><th width="180">IP</th><th>时间</th></tr>
            <?php while($v = $visitList->fetch_assoc()): ?>
            <tr><td><?=htmlspecialchars($v['ip'])?></td><td><?=date("Y-m-d H:i:s",strtotime($v['time']))?></td></tr>
            <?php endwhile; ?>
        </table>
        <div class="page-bar">
            <?php if($page > 1): ?><a href="?type=visit&page=<?=$page-1?>">上一页</a><?php endif; ?>
            <?php
            $shown = []; $shown[] = 1;
            for($i = max(2, $page-2); $i <= min($visitPage-1, $page+2); $i++) $shown[] = $i;
            if($visitPage > 1) $shown[] = $visitPage;
            $shown = array_unique($shown); sort($shown); $prev = 0;
            foreach($shown as $i):
                if($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
            ?><a href="?type=visit&page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a><?php $prev = $i; endforeach; ?>
            <?php if($page < $visitPage): ?><a href="?type=visit&page=<?=$page+1?>">下一页</a><?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
    </div>
</div>

<script>
document.getElementById('checkAll')?.addEventListener('change', function(){
    document.querySelectorAll('.item').forEach(c => c.checked = this.checked);
});
document.getElementById('checkAllUser')?.addEventListener('change', function(){
    document.querySelectorAll('.user-check').forEach(c => c.checked = this.checked);
});

function batchAction(action){
    var manualUids = document.getElementById('manualUids').value.trim();
    var ids = [];
    
    if (manualUids) {
        var parts = manualUids.split(',');
        for (var i = 0; i < parts.length; i++) {
            var uid = parseInt(parts[i].trim());
            if (uid > 0) ids.push(uid);
        }
        if (ids.length === 0) { alert('请输入有效的UID'); return; }
    } else {
        var checked = document.querySelectorAll('.user-check:checked');
        if (checked.length === 0) { alert('请选择用户或输入UID'); return; }
        for (var i = 0; i < checked.length; i++) ids.push(checked[i].value);
    }
    
    var reason = document.getElementById('batchReason').value.trim();
    if (!reason) { alert('请填写操作原因'); return; }
    if (action === 'del_users' && !confirm('确定删除选中的 ' + ids.length + ' 个用户？')) return;

    postAdminAction({[action]: ids.join(','), reason: reason});
}

function batchPermAction(action) {
    var reason = document.getElementById('batchReason').value.trim();
    if (!reason) { alert('请填写操作原因'); return; }

    var perms = [];
    document.querySelectorAll('.perm-check:checked').forEach(function(c) {
        perms.push(c.value);
    });
    if (perms.length === 0) { alert('请至少选择一个权限'); return; }

    var manualUids = document.getElementById('manualUids').value.trim();
    var ids = [];
    if (manualUids) {
        var parts = manualUids.split(',');
        for (var i = 0; i < parts.length; i++) {
            var uid = parseInt(parts[i].trim());
            if (uid > 0) ids.push(uid);
        }
        if (ids.length === 0) { alert('请输入有效的UID'); return; }
    } else {
        var checked = document.querySelectorAll('.user-check:checked');
        if (checked.length === 0) { alert('请选择用户或输入UID'); return; }
        for (var i = 0; i < checked.length; i++) ids.push(checked[i].value);
    }

    var fieldName = (action === 'grant') ? 'batch_grant_perms' : 'batch_revoke_perms';
    postAdminAction({
        [fieldName]: ids.join(','),
        perm_list: perms.join(','),
        reason: reason
    });
}

function postAdminAction(fields) {
    var form = document.createElement('form');
    form.method = 'post';
    form.action = 'https://lmtoj.cn/admin?type=user&page=<?= $page ?>';
    fields._csrf = <?= json_encode(csrf_token(), JSON_UNESCAPED_SLASHES) ?>;
    Object.keys(fields).forEach(function (name) {
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = name;
        input.value = fields[name];
        form.appendChild(input);
    });
    document.body.appendChild(form);
    form.submit();
}

function renameUserBatch() {
    var manualUids = document.getElementById('manualUids').value.trim();
    if (!manualUids) {
        alert('请先在"手动输入UID"框中输入要修改的用户 UID（可输入多个，但只取第一个）');
        return;
    }
    var parts = manualUids.split(',');
    var uid = null;
    for (var i = 0; i < parts.length; i++) {
        var v = parseInt(parts[i].trim());
        if (!isNaN(v) && v > 0) {
            uid = v;
            break;
        }
    }
    if (uid === null) {
        alert('未找到有效的 UID，请检查输入');
        return;
    }
    if (parts.length > 1) {
        alert('检测到多个 UID，将只对第一个 UID（' + uid + '）进行修改。如需批量修改，请分别操作。');
    }

    var newname = prompt('请输入新用户名（无字符限制，但不能为空）：');
    if (newname && newname.trim()) {
        newname = newname.trim();
        if (newname === '') {
            alert('用户名不能为空');
            return;
        }

        // 直接从页面上的“操作原因”输入框读取原因，并校验必填
        var reason = document.getElementById('batchReason').value.trim();
        if (!reason) {
            alert('请先填写操作原因');
            return;
        }

        postAdminAction({
            rename_user: '1',
            uid: uid,
            newname: newname,
            reason: reason
        });
    }
}
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>