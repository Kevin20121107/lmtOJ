<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
header("Content-Type:text/html;charset=utf-8");

require_once 'visit_log.php';

// 数据库连接
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");
$editMode = false;
$login_uid = -1;
$is_admin =  0;
$msg = '';
$login_name = '';
$whether_login = false;
if (isset($_SESSION['uid'])) {
    $login_uid = (int)$_SESSION['uid'];
    $userRow = $conn->query("SELECT name, admin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
    $is_admin = $userRow['admin'] ?? 0;
    $login_name = $userRow['name'] ?? '';
    $whether_login = true;

    // 未读消息
    $unreadCount = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0")->fetch_assoc()['cnt'];// ========== 保存提交逻辑 ==========
    if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $targetType = $_POST['edit_type'] ?? '';
        $newRaw = $_POST['content'] ?? '';
        
        if (in_array($targetType, ['rules', 'guzhi'], true)) {
            saveHelp($conn, $targetType, $newRaw, $login_uid);
            $msg = '修改已保存成功'; 
        }
    
        // 刷新页面清除 post，防止重复提交
        header("Location: https://lmtoj.cn/help/{$targetType}");
        exit;
    }
    if ($is_admin && isset($_GET['edit'])) $editMode = true;
}
else {
    $login_url = 'https://lmtoj.cn/login';
    $unreadCount = 0;
}

// 页面类型
$type = isset($_GET['type']) ? $_GET['type'] : 'rules';
$pageTitle = $type . ' - 帮助中心';
$updBy = $conn->query("SELECT * FROM users WHERE uid = (SELECT updated_by FROM help_pages WHERE page_key = '{$type}' LIMIT 1) LIMIT 1")->fetch_assoc() ?? false;

function safeContent($content) {
    return htmlspecialchars($content ?? '', ENT_QUOTES, 'UTF-8');
}

function getHelp($conn, $pageKey) {
    $stmt = $conn->prepare("SELECT content FROM help_pages WHERE page_key = ? LIMIT 1");
    $stmt->bind_param('s', $pageKey);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    return $row ? $row['content'] : '';
}

function saveHelp($conn, $pageKey, $content, $uid) {
    $stmt = $conn->prepare(
        "UPDATE help_pages SET content = ?, updated_at = NOW(), updated_by = ? WHERE page_key = ?"
    );
    $stmt->bind_param('sis', $content, $uid, $pageKey);
    $ok = $stmt->execute();
    $stmt->close();
    return $ok;
}



// 读取当前页面内容
$mainRaw = getHelp($conn, $type);

if ($mainRaw === '') {
    $mainRaw = '帮助暂不存在';
}



$current_page = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?=$pageTitle?> - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
            --font-mono: Consolas, monospace;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .login-button{display:inline-flex;align-items:center;background:#000000;color:#ffffff;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .login-button:hover{background:#1f1f1f;color:#ffffff;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card-header{display:flex;align-items:center;gap:16px;margin-bottom:18px;}
        .card h1{font-size:22px;font-weight:600;margin:0;}
        .card h2{font-size:18px;font-weight:600;margin:20px 0 10px;}
        .card h3{font-size:16px;font-weight:600;margin:16px 0 8px;}
        .card p{margin:8px 0;font-size:15px;}
        .card ul{margin:10px 0 10px 22px;}
        .card li{margin:6px 0;}
        .card blockquote{border-left:4px solid var(--accent);padding:8px 14px;margin:8px 0;background:#fafaf8;color:#5a5550;border-radius:0 4px 4px 0;}
        .card pre{background:#2b2a27;color:#e8e4dd;padding:14px 16px;border-radius:var(--radius-sm);overflow-x:auto;margin:8px 0;font-family:var(--font-mono);font-size:13px;}
        .card code{font-family:var(--font-mono);background:#f3f0eb;padding:2px 6px;border-radius:3px;}
        .card pre code{background:transparent;padding:0;color:inherit;}
        .card img{max-width:100%;height:auto;border-radius:4px;margin:6px 0;}
        .edit-btn{padding:6px 12px;background:var(--accent);color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:14px;}
        .edit-btn:hover{background:var(--accent-hover);}
        .cancel-btn{background:#999;}
        #html-editor{width:100%;min-height:520px;padding:12px;font-family:var(--font-mono);font-size:14px;border:1px solid var(--border);border-radius:var(--radius-sm);margin:12px 0;resize:vertical;}
        .tip-success{color:#2d8842;margin:8px 0;font-weight:500;}
        .edit-desc{color:var(--text-secondary);font-size:14px;margin:6px 0;}
        .btn-row{display:flex;gap:10px;margin-top:10px;}
        @media(max-width:768px){
            .main{flex-direction:column;padding:0 12px;margin:18px auto 30px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .login-button{font-size:12px;padding:5px 9px;}
            .card{padding:18px 16px;}
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<?php if (!$whether_login): ?>
<script>
    (function () {
        const navbar = document.querySelector('.navbar');
        if (!navbar || navbar.querySelector('.login-button')) {
            return;
        }

        const loginButton = document.createElement('a');
        loginButton.className = 'login-button';
        loginButton.href = <?= json_encode($login_url) ?>;
        loginButton.textContent = '登录';
        navbar.appendChild(loginButton);
    })();
</script>
<?php endif; ?>
<div class="main">
    <script>
        const helpMarkdownRenderer = MarkdownRenderer.create({
            markdownOptions: {html: false, linkify: false, typographer: false, breaks: false},
            katexOptions: {macros: {"\\RR": "\\mathbb{R}"}}
        });
        function renderMarkdownTo(elId, rawText) {
            const el = document.getElementById(elId);
            if (!el || rawText === null) return;
            helpMarkdownRenderer.renderTo(el, rawText);
        }
    </script>

    <?php include 'sidebar.php'; ?>
    <div class="sidebar">
        <a href="https://lmtoj.cn/help/rules">用户规范</a>
        <a href="https://lmtoj.cn/help/guzhi">估值系统</a>
    </div>

    <div class="content">
        <div class="card">
            <div class="card-header">
                <h1><?=$pageTitle?> <?php if ($updBy): ?><span style="font-size: 12px; font-weight: 400;">updated by <a style="color: #545454; text-decoration: none;" href="https://lmtoj.cn/user/<?=$updBy['uid']?>" target="_blank"><?=$updBy['name']?></a></span><?php endif; ?></h1>
                <?php if ($is_admin): ?>
                    <?php if (!$editMode): ?>
                        <a href="https://lmtoj.cn/help/<?=$type?>?edit">
                            <button class="edit-btn">编辑页面内容</button>
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <?php if ($msg): ?>
                <div class="tip-success"><?=$msg?></div>
            <?php endif; ?>

            <?php if ($is_admin && $editMode): ?>
                <p class="edit-desc">编辑器使用 Markdown 语法，支持 $LaTeX公式$、#标题、列表、代码块、图片、链接，修改后永久保存到数据库</p>
                <form method="POST" action="https://lmtoj.cn/help/<?=$type?>">
                    <input type="hidden" name="edit_type" value="<?=$type?>">
                    <textarea id="html-editor" name="content"><?=safeContent($mainRaw)?></textarea>
                    <div class="btn-row">
                        <button type="submit" class="edit-btn">永久保存修改</button>
                        <a href="https://lmtoj.cn/help/<?=$type?>">
                            <button type="button" class="edit-btn cancel-btn">取消</button>
                        </a>
                    </div>
                </form>
            <?php else: ?>
                <div id="help-content"></div>
                <script>renderMarkdownTo('help-content', <?=json_encode($mainRaw, JSON_UNESCAPED_UNICODE)?>);</script>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
