<?php
// Shared site footer. Keep links and presentation here so every page stays in sync.

// 计算网站运行天数：从 2026-06-06 开始，包含当天
$site_start_date = '2026-06-06';
$timezone = new DateTimeZone('Asia/Shanghai');
$start = new DateTime($site_start_date, $timezone);
$now   = new DateTime('now', $timezone);
$site_running_days = $start->diff($now)->days + 1; // +1 表示包含起始日
?>
<footer class="site-footer">
    <nav class="site-footer-links" aria-label="页脚导航">
        <a href="https://lmtoj.cn/ostracism">陶片放逐</a>
        <span aria-hidden="true">·</span>
        <a href="https://lmtoj.cn/image_host">图片上传</a>
        <span aria-hidden="true">·</span>
        <a href="https://lmtoj.cn/help">帮助中心</a>
        <span aria-hidden="true">·</span>
        <a href="https://luogu.ac.cn" target="_blank">欢迎支持洛谷档案馆</a>
    </nav>
    <div class="site-footer-copy">
        © 2026 lmtOJ by <a href="https://lmtoj.cn/list/admin">lmtOJ 管理组</a>
        <span aria-hidden="true">,All rights reserved. </span>
        本网站已运行 <?php echo $site_running_days; ?> 天。
    </div>
</footer>

<style>
.site-footer {
    width:min(1440px, calc(100% - 32px));
    margin:28px auto 18px;
    padding:18px 28px;
    border-top:1px solid var(--border-light, var(--border, #e6e1da));
    color:var(--text-muted, #8b837a);
    font-size:13px;
    text-align:center;
    box-sizing:border-box;
}
.site-footer-links {
    display:flex;
    justify-content:center;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
}
.site-footer a {
    color:var(--text-secondary, #6f6861);
    text-decoration:none;
    transition:color var(--transition, .18s ease);
}
.site-footer a:hover { color:var(--accent, #6b8a74); }
.site-footer-copy { margin-top:9px; font-size:12px; }
@media (max-width:640px) {
    .site-footer { width:calc(100% - 20px); padding:16px 10px; }
}
</style>