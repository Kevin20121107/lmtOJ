<?php
// 全站 LaTeX 渲染引擎

session_start();
require_once __DIR__ . '/../../security.php';
require_once __DIR__ . '/../../config.php';

if (isset($_GET['logout'])) {
    $_SESSION['fm_auth']=0;
    header('Location: https://lmtoj.cn/');
    exit;
}

require_once __DIR__ . '/../../database.php';
$conn = db();
$conn->set_charset("utf8mb4");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$conn->query("CREATE TABLE IF NOT EXISTS file_edit_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    action VARCHAR(20) NOT NULL DEFAULT 'edit',
    ip_address VARCHAR(45) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
define('FM_PASSWORD', "asoshirena/ll/bx");

$login_uid = (int)$_SESSION['uid'];
$user = $conn->query("SELECT devadmin FROM users WHERE uid=$login_uid LIMIT 1")->fetch_assoc();

// 二级密码验证
if (!isset($_SESSION['fm_auth']) || $_SESSION['fm_auth'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fm_password'])) {
        if ($_POST['fm_password'] === FM_PASSWORD) {
            $_SESSION['fm_auth'] = true;
            header("/");
            exit;
        } else {
            $error = '密码错误';
        }
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>文件管理器 · 二级验证</title>
        <style>
            :root {
                --bg: #f9f7f4; --card-bg: #fff; --nav-bg: #3d3a37;
                --text: #2c2a28; --accent: #6b8a74; --danger: #d9534f;
                --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            }
            *{margin:0;padding:0;box-sizing:border-box;}
            body{background:var(--bg);font-family:var(--font);display:flex;justify-content:center;align-items:center;height:100vh;}
            .card{background:var(--card-bg);padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.05);text-align:center;width:360px;}
            h2{font-size:20px;margin-bottom:20px;color:var(--text);}
            input{padding:10px 14px;border:1.5px solid #e6e1da;border-radius:6px;font-size:14px;width:100%;}
            .btn{padding:9px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;margin-top:16px;}
            .error{color:var(--danger);margin-top:8px;font-size:13px;}
        </style>
    </head>
    <body>
        <div class="card">
            <h2>文件管理器 · 二级密码</h2>
            <form method="post">
                <input type="password" name="fm_password" placeholder="请输入管理密码" required>
                <button type="submit" class="btn">验证</button>
                <?php if (isset($error)): ?><p class="error"><?=$error?></p><?php endif; ?>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// CSRF 保护（所有 POST 操作）
csrf_protect_request(true);

$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$file = isset($_GET['file']) ? $_GET['file'] : '';
$root = __DIR__ . "/../..";
$message = '';

// ========== 新增：下载所有文件（打包整个根目录） ==========
if ($action === 'download_all') {
    if (!class_exists('ZipArchive')) {
        die('错误：服务器未启用 ZipArchive 扩展，无法打包文件夹');
    }
    $zip = new ZipArchive();
    $zipname = 'lmtoj.zip';
    $zippath = sys_get_temp_dir() . '/' . $zipname;
    if (!is_writable(sys_get_temp_dir())) {
        $zippath = __DIR__ . '/' . $zipname;
        if (!is_writable(__DIR__)) {
            die('错误：临时目录不可写，请检查权限');
        }
    }
    if ($zip->open($zippath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        die('错误：无法创建 ZIP 文件，请检查磁盘空间和权限');
    }
    // 获取所有文件（自动排除 .preview_backups 和 .git）
    $files = getAllFiles($root, '');
    foreach ($files as $relPath) {
        $fullPath = $root . '/' . $relPath;
        if (is_file($fullPath)) {
            $zip->addFile($fullPath, $relPath);
        }
    }
    $zip->close();
    if (!file_exists($zippath) || filesize($zippath) == 0) {
        die('错误：ZIP 文件生成失败或为空');
    }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename=' . $zipname);
    header('Content-Length: ' . filesize($zippath));
    readfile($zippath);
    unlink($zippath);
    exit;
}

// ========== 下载单个文件或文件夹（原有逻辑） ==========
if ($action === 'download' && $file) {
    $path = $root . '/' . $file;
    if (is_file($path)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=' . basename($file));
        readfile($path);
        exit;
    } elseif (is_dir($path)) {
        if (!class_exists('ZipArchive')) {
            die('错误：服务器未启用 ZipArchive 扩展，无法打包文件夹');
        }
        $zip = new ZipArchive();
        $zipname = basename($file) . '.zip';
        $zippath = sys_get_temp_dir() . '/' . $zipname;
        if (!is_writable(sys_get_temp_dir())) {
            $zippath = __DIR__ . '/' . $zipname;
            if (!is_writable(__DIR__)) {
                die('错误：临时目录不可写，请检查权限');
            }
        }
        if ($zip->open($zippath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            die('错误：无法创建 ZIP 文件，请检查磁盘空间和权限');
        }
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($path),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $name => $fileinfo) {
            if (!$fileinfo->isDir()) {
                $filePath = $fileinfo->getRealPath();
                $relativePath = substr($filePath, strlen($path) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        if (!file_exists($zippath) || filesize($zippath) == 0) {
            die('错误：ZIP 文件生成失败或为空');
        }
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename=' . $zipname);
        header('Content-Length: ' . filesize($zippath));
        readfile($zippath);
        unlink($zippath);
        exit;
    } else {
        $message = '文件不存在';
        $action = 'list';
        $file = '';
    }
}

// ========== 兴趣标签分析 ==========
if ($action === 'analyze_interests') {
    $interestTags = [
        'Minecraft', 'Terraria', 'Stardew Valley', 'Hollow Knight', 'Celeste', 'Undertale', 'Factorio', 'RimWorld',
        'Genshin Impact', 'Honkai: Star Rail', 'Arknights', 'Fate/Grand Order', '原神', '崩坏：星穹铁道', '明日方舟',
        '王者荣耀', '和平精英', '第五人格', '光遇', '崩坏3', '少女前线', '碧蓝航线', '赛马娘', '蔚蓝档案', '绝区零',
        '黑神话：悟空', '永劫无间', 'Dota 2', 'League of Legends', 'CS:GO', 'Valorant', 'Apex Legends', 'Fortnite',
        'Overwatch', 'PUBG', '我的世界', '泰拉瑞亚', '星露谷物语', '空洞骑士', '蔚蓝', '异星工厂', '环世界',
        'C++', 'Python', 'Java', 'JavaScript', '算法竞赛', '信息学奥赛', '机器学习', 'Web开发', '游戏开发', '网络安全',
        '进击的巨人', '鬼灭之刃', '咒术回战', '间谍过家家', '电锯人', '葬送的芙莉莲', '孤独摇滚!', '命运石之门',
        '钢之炼金术师', 'CLANNAD', '紫罗兰永恒花园', '魔法少女小圆', '凉宫春日的忧郁', '新世纪福音战士',
        '刀剑神域', 'Re:从零开始的异世界生活', '辉夜大小姐想让我告白', '关于我转生变成史莱姆这档事',
        '无职转生', '迷宫饭', '异世界舅舅', '更衣人偶坠入爱河', 'Lycoris Recoil', '夏日重现', '青之驱魔师', '未来日记',
        'florr.io', '音游', 'V家', '绘画', '东方Project', '动物森友会', '宝可梦', '火焰纹章', '塞尔达传说', '最终幻想',
        '怪物猎人', '黑暗之魂', '艾尔登法环', '只狼', '血源诅咒', '巫师3', '赛博朋克2077', '荒野大镖客2'
    ];

    function analyzeAndSetInterestsFile($conn, $uid, $presetTags) {
        $recent = $conn->query("SELECT text FROM benben WHERE uid = $uid ORDER BY time DESC, id DESC LIMIT 20");
        if ($recent->num_rows === 0) return false;
        $texts = [];
        while ($row = $recent->fetch_assoc()) $texts[] = $row['text'];
        $combined = implode("\n", $texts);

        $presetList = implode(',', $presetTags);
        $prompt = "根据以下用户发布的犇犇内容，从预设标签列表中挑选最多8个最符合的兴趣标签。只能从列表中选择，不要编造。\n列表：$presetList\n内容：\n$combined\n请直接输出逗号分隔的标签，不要其他文字。";

        $apiKey = 'sk-9b23c02f936f4ca8805bb4304ea57f92';
        $url = 'https://api.deepseek.com/v1/chat/completions';
        $payload = [
            'model' => 'deepseek-chat',
            'messages' => [['role' => 'user', 'content' => $prompt]],
            'temperature' => 0.3,
            'max_tokens' => 100
        ];
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec($ch);
        curl_close($ch);
        if (!$res) return false;
        $data = json_decode($res, true);
        $tags = trim($data['choices'][0]['message']['content'] ?? '');
        $tagsArr = array_map('trim', explode(',', $tags));
        $valid = array_intersect($tagsArr, $presetTags);
        $finalTags = array_slice($valid, 0, 8);
        $interests = implode(',', $finalTags);
        $conn->query("UPDATE users SET interests='" . $conn->real_escape_string($interests) . "' WHERE uid=$uid");
        return true;
    }

    $users = [];
    $result = $conn->query("SELECT u.uid, u.name, COUNT(b.id) AS cnt FROM users u LEFT JOIN benben b ON u.uid = b.uid GROUP BY u.uid HAVING cnt > 10");
    while ($row = $result->fetch_assoc()) $users[] = $row;

    $total = count($users);
    $success = 0;
    foreach ($users as $user) {
        set_time_limit(30);
        if (analyzeAndSetInterestsFile($conn, $user['uid'], $interestTags)) {
            $success++;
        }
        usleep(500000);
    }
    $message = "兴趣标签分析完成：成功 {$success}/{$total}";
    $action = 'list';
}

// ========== 服务器端同步处理 ==========
if ($action === 'sync_push_all') {
    $previewUrl = 'https://lmtoj-preview.xo.je/preview_sync.php';
    $syncKey = 'lmtOJ_preview_sync_2024';
    $files = getAllFiles($root, '');
    $total = count($files);
    $success = 0;
    foreach ($files as $relPath) {
        $content = file_get_contents($root . '/' . $relPath);
        $content = replaceForPreview($content);
        $ch = curl_init($previewUrl . '?action=push_file&key=' . $syncKey);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, [
            'path' => $relPath,
            'content' => $content
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_exec($ch);
        if (trim($response) === 'OK' || strpos($response, 'OK') === 0) $success++;
        curl_close($ch);
    }
    $message = "推送完成：{$success}/{$total} 个文件成功";
    $action = 'list';
}

if ($action === 'sync_pull_all') {
    $previewUrl = 'https://lmtoj-preview.xo.je/preview_sync.php';
    $syncKey = 'lmtOJ_preview_sync_2024';
    $ch = curl_init($previewUrl . '?action=list_files&key=' . $syncKey);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $list = json_decode(curl_exec($ch), true);
    curl_close($ch);
    $success = 0;
    foreach ($list as $item) {
        if ($item['type'] !== 'file') continue;
        $ch = curl_init($previewUrl . '?action=pull_file&key=' . $syncKey . '&path=' . urlencode($item['name']));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $content = curl_exec($ch);
        curl_close($ch);
        $content = replaceForLocal($content);
        $localPath = $root . '/' . $item['name'];
        $dir = dirname($localPath);
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        file_put_contents($localPath, $content);
        $success++;
    }
    $message = "拉取完成：{$success} 个文件";
    $action = 'list';
}

if ($action === 'sync_db') {
    $sql = '';
    $tables = [];
    $r = $conn->query("SHOW TABLES");
    while ($row = $r->fetch_row()) $tables[] = $row[0];
    $sql = "-- DB export\nSET FOREIGN_KEY_CHECKS=0;\n";
    foreach ($tables as $t) {
        $create = $conn->query("SHOW CREATE TABLE `{$t}`")->fetch_row();
        $sql .= "DROP TABLE IF EXISTS `{$t}`;\n" . $create[1] . ";\n";
        $data = $conn->query("SELECT * FROM `{$t}`");
        while ($row = $data->fetch_assoc()) {
            $vals = [];
            foreach ($row as $v) $vals[] = is_null($v) ? "NULL" : "'" . $conn->real_escape_string($v) . "'";
            $sql .= "INSERT INTO `{$t}` VALUES (" . implode(',', $vals) . ");\n";
        }
        $sql .= "\n";
    }
    $sql .= "SET FOREIGN_KEY_CHECKS=1;\n";

    $previewUrl = 'https://lmtoj-preview.xo.je/preview_sync.php';
    $syncKey = 'lmtOJ_preview_sync_2024';
    $ch = curl_init($previewUrl . '?action=push_file&key=' . $syncKey);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, [
        'path' => 'db_sync.sql',
        'content' => $sql
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    $message = '数据库同步完成：' . $response;
    $action = 'list';
}

// 预览站文件列表查看（后端获取）
if ($action === 'list_preview') {
    $previewUrl = 'https://lmtoj-preview.xo.je/preview_sync.php';
    $syncKey = 'lmtOJ_preview_sync_2024';
    $dir = $_GET['dir'] ?? '';
    $ch = curl_init($previewUrl . '?action=list_files&key=' . $syncKey . '&dir=' . urlencode($dir));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $list = json_decode(curl_exec($ch), true);
    curl_close($ch);
    if (!isset($_GET['ajax'])) {
        header('Content-Type: application/json');
        echo json_encode($list);
        exit;
    }
}

// 递归获取所有文件
function getAllFiles($root, $subdir = '') {
    $path = $root . ($subdir ? '/' . $subdir : '');
    $files = [];
    $items = array_diff(scandir($path), ['.', '..']);
    foreach ($items as $item) {
        $rel = $subdir ? $subdir . '/' . $item : $item;
        $full = $path . '/' . $item;
        if (is_dir($full)) {
            if ($item === '.preview_backups' || $item === '.git') continue;
            $files = array_merge($files, getAllFiles($root, $rel));
        } else {
            $files[] = $rel;
        }
    }
    return $files;
}

function replaceForLocal($content) {
    $replacements = [
        [env('PREVIEW_DB_HOST', ''), env('DB_HOST', '')],
        [env('PREVIEW_DB_USER', ''), env('DB_USER', '')],
        [env('PREVIEW_DB_PASSWORD', ''), env('DB_PASSWORD', '')],
        [env('PREVIEW_DB_NAME', ''), env('DB_NAME', '')],
        [env('PREVIEW_SITE_HOST', ''), env('SITE_HOST', '')],
    ];
    foreach ($replacements as [$from, $to]) {
        $content = str_replace($from, $to, $content);
    }
    return $content;
}

function replaceForPreview($content) {
    $replacements = [
        [env('DB_HOST', ''), env('PREVIEW_DB_HOST', '')],
        [env('DB_USER', ''), env('PREVIEW_DB_USER', '')],
        [env('DB_PASSWORD', ''), env('PREVIEW_DB_PASSWORD', '')],
        [env('DB_NAME', ''), env('PREVIEW_DB_NAME', '')],
        [env('SITE_HOST', ''), env('PREVIEW_SITE_HOST', '')],
    ];
    foreach ($replacements as [$from, $to]) {
        $content = str_replace($from, $to, $content);
    }
    return $content;
}

// ========== 原有文件操作逻辑 ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['sync_action'])) {
    if ($action === 'edit' && isset($_POST['content'])) {
        $filePath = $root . '/' . $file;
        file_put_contents($filePath, $_POST['content']);
        $message = '文件已保存';
        
        // 记录编辑日志（IP + 时间）
        $ip = $_SERVER['REMOTE_ADDR'];

    } elseif ($action === 'create' && isset($_POST['newfile'])) {
        $path = $root . '/' . ltrim($_POST['newfile'], '/');
        $dir = dirname($path);
        if (!is_dir($dir)) mkdir($dir, 0777, true);
        file_put_contents($path, $_POST['content'] ?? '');
        $message = '文件已创建';
        $file = $_POST['newfile'];
        $action = 'edit';
    } elseif ($action === 'delete' && isset($_POST['confirm'])) {
        $path = $root . '/' . $file;
        if (is_dir($path)) {
            deleteDirRecursive($path);
        } else {
            unlink($path);
        }
        $message = '已删除';
        $action = 'list';
        $file = '';
    } elseif ($action === 'rename' && isset($_POST['newname'])) {
        $old = $root . '/' . $file;
        $new = dirname($old) . '/' . basename($_POST['newname']);
        rename($old, $new);
        $message = '已重命名';
        $action = 'list';
        $file = '';
    } elseif ($action === 'upload' && isset($_FILES['upload_file'])) {
        $target = $root . '/' . ($file ? $file . '/' : '') . basename($_FILES['upload_file']['name']);
        move_uploaded_file($_FILES['upload_file']['tmp_name'], $target);
        $message = '上传成功';
        $action = 'list';
    } elseif ($action === 'mkdir' && isset($_POST['dirname'])) {
        // 确定当前目录
        $dir = $file ? $file : '';
        $currentPath = $root . '/' . $file;
        if ($file && !is_dir($currentPath)) {
            // 如果 $file 是文件，取其所在目录
            $dir = dirname($file);
            if ($dir === '.') $dir = '';
        }
        // 获取安全的文件夹名（去掉路径部分）
        $name = basename($_POST['dirname']);
        // 验证名称合法性
        if ($name === '' || $name === '.' || $name === '..' ||
            strpos($name, '/') !== false || strpos($name, '\\') !== false) {
            $message = '文件夹名称无效';
            $action = 'mkdir'; // 停留在创建文件夹页面
        } else {
            $newDir = $root . '/' . ($dir ? $dir . '/' : '') . $name;
            if (file_exists($newDir)) {
                $message = '文件夹已存在';
                $action = 'mkdir';
            } else {
                if (mkdir($newDir, 0777, true)) {
                    $message = '文件夹已创建';
                    $file = $dir ? $dir . '/' . $name : $name; // 进入新创建的文件夹
                    $action = 'list';
                } else {
                    $message = '创建失败，请检查权限';
                    $action = 'mkdir';
                }
            }
        }
    }
}

function deleteDirRecursive($dir) {
    $items = array_diff(scandir($dir), ['.', '..']);
    foreach ($items as $item) {
        $path = $dir . '/' . $item;
        is_dir($path) ? deleteDirRecursive($path) : unlink($path);
    }
    rmdir($dir);
}

function formatSize($bytes) {
    if ($bytes >= 1073741824) return number_format($bytes / 1073741824, 2) . ' GB';
    if ($bytes >= 1048576) return number_format($bytes / 1048576, 2) . ' MB';
    if ($bytes >= 1024) return number_format($bytes / 1024, 2) . ' KB';
    return $bytes . ' B';
}

$current = $root . ($file ? '/' . $file : '');
if (is_dir($current)) {
    $items = scandir($current);
} else {
    $items = [];
}
$files_list = [];
foreach ($items as $item) {
    if ($item === '.' || $item === '..') continue;
    $path = $current . '/' . $item;
    $files_list[] = [
        'name' => $item,
        'is_dir' => is_dir($path),
        'size' => is_file($path) ? filesize($path) : 0,
        'mtime' => filemtime($path),
        'ext' => pathinfo($item, PATHINFO_EXTENSION)
    ];
}
usort($files_list, function($a, $b) {
    if ($a['is_dir'] !== $b['is_dir']) return $b['is_dir'] - $a['is_dir'];
    return strcasecmp($a['name'], $b['name']);
});
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>文件管理器 · lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --danger: #d9534f;
            --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', 'Cascadia Code', 'Consolas', monospace;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        html, body { height:100%; overflow:hidden; }
        body {
            font-family: var(--font);
            background: var(--bg);
            color: var(--text);
            display: flex;
            line-height: 1.6;
        }

        .left-panel {
            width: 100%;
            min-width: auto;
            background: var(--bg);
            display: flex;
            flex-direction: column;
            border-right: none;
            overflow: hidden;
        }
        .left-header {
            background: var(--nav-bg);
            padding: 12px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
            color: var(--nav-text);
        }
        .left-header h1 { font-size: 18px; font-weight: 600; color: var(--nav-text); }
        .nav-links { display: flex; gap: 6px; }
        .nav-links a, .nav-links button {
            color: #e0dbd3;
            text-decoration: none;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            transition: var(--transition);
            background: none;
            border: none;
            cursor: pointer;
            font-family: var(--font);
        }
        .nav-links a:hover, .nav-links button:hover { background: rgba(255,255,255,0.1); color: #fff; }
        .nav-links a.active, .nav-links button.active { background: var(--accent); color: #fff; }
        .nav-links a.logout { color: #f87171; }
        .left-content { flex: 1; padding: 20px; overflow-y: auto; }
        .left-content::-webkit-scrollbar { width: 6px; }
        .left-content::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }

        .address-bar {
            background: var(--card-bg);
            padding: 10px 16px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            font-family: var(--font-mono);
            font-size: 13px;
            border: 1px solid var(--border);
            display: flex;
            align-items: center;
            gap: 6px;
            flex-wrap: wrap;
        }
        .address-bar a { color: var(--accent); text-decoration: none; font-weight: 500; }
        .address-bar .sep { color: var(--text-muted); }

        .message {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 10px 16px;
            border-radius: var(--radius);
            margin-bottom: 16px;
            border-left: 3px solid var(--accent);
            font-weight: 500;
        }

        .toolbar { display: flex; gap: 10px; margin-bottom: 20px; flex-wrap: wrap; }
        .btn {
            padding: 8px 18px;
            border-radius: 20px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 500;
            transition: var(--transition);
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: var(--card-bg);
            color: var(--text);
            border: 1px solid var(--border);
            font-family: var(--font);
        }
        .btn:hover { background: var(--accent-light); border-color: var(--accent); color: var(--accent); }
        .btn-primary { background: var(--accent); color: #fff; border-color: var(--accent); }
        .btn-primary:hover { background: var(--accent-hover); }
        .btn-danger { background: var(--danger); color: #fff; border-color: var(--danger); }
        .btn-danger:hover { background: var(--danger-hover); }

        table {
            width: 100%;
            border-collapse: collapse;
            background: var(--card-bg);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow-sm);
        }
        th { text-align: left; padding: 12px 16px; background: #fafaf8; font-size: 11px; text-transform: uppercase; color: var(--text-secondary); font-weight: 600; }
        td { padding: 10px 16px; border-bottom: 1px solid var(--border-light); font-size: 14px; }
        tr:hover td { background: #fdfcfb; }
        .name-link { color: var(--accent); text-decoration: none; display: flex; align-items: center; gap: 8px; font-weight: 500; }
        .name-link:hover { color: var(--accent-hover); }
        .actions a { color: var(--text-muted); text-decoration: none; font-size: 12px; padding: 4px 10px; border-radius: 4px; transition: var(--transition); }
        .actions a:hover { background: var(--accent-light); color: var(--accent); }
        .actions a.danger { color: var(--danger); }
        .actions a.danger:hover { background: #fce4ec; }

        input[type="text"],textarea { 
            flex:1;
            padding: 10px 14px;
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            font-size: 14px;
            outline: none;
            background: #fdfdfc;
            font-family: var(--font-mono);
            font-size: 13px;
            resize: vertical;
            transition: var(--transition);
            color: var(--text);
        }
        textarea { height: 380px; font-family: var(--font-mono); font-size: 13px; resize: vertical; }
        input:focus, textarea:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(107,138,116,0.08); background: #fff; }
        .card {
            background: var(--card-bg);
            padding: 24px;
            border-radius: var(--radius);
            border: 1px solid var(--border-light);
            margin-bottom: 20px;
            box-shadow: var(--shadow);
        }
        .card h2 { font-size: 16px; margin-bottom: 18px; color: var(--text); font-weight: 600; }
        .form-group { margin-bottom: 14px; }
        .form-group label { display: block; margin-bottom: 6px; font-size: 13px; color: var(--text-secondary); font-weight: 500; }

        /* ===== 同步面板（全屏覆盖，带遮罩） ===== */
        #syncOverlay {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            z-index: 300;
            justify-content: center;
            align-items: center;
        }
        #syncPanel {
            background: var(--bg);
            width: 90%;
            max-width: 800px;
            max-height: 90vh;
            padding: 30px;
            border-radius: var(--radius);
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            overflow-y: auto;
            position: relative;
        }
        #syncPanel .close-btn {
            position: absolute;
            top: 12px;
            right: 16px;
            background: none;
            border: 1px solid var(--border);
            border-radius: 50%;
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 18px;
            line-height: 1;
            color: var(--text-muted);
        }
        #syncPanel .close-btn:hover { background: var(--accent-light); color: var(--text); }

        @media (max-width: 900px) {
            #syncPanel { width: 96%; padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="left-panel">
        <div class="left-header">
            <h1>📁 文件管理器</h1>
            <div class="nav-links">
                <a href="?action=list" class="<?=$action=='list'?'active':''?>">浏览</a>
                <a href="?action=create" class="<?=$action=='create'?'active':''?>">新建</a>
                <a href="?action=upload" class="<?=$action=='upload'?'active':''?>">上传</a>
                <button id="syncBtn" class="<?=$action=='sync'?'active':''?>" onclick="toggleSync()">📡 同步</button>
                <a href="?action=analyze_interests" class="<?=$action=='analyze_interests'?'active':''?>" onclick="return confirm('确定要批量分析兴趣标签？这可能需要一些时间。')">🔬 标签分析</a>
                <a href="?logout" class="logout">退出</a>
            </div>
        </div>
        <div class="left-content" id="leftContent">
            <?php if ($message): ?><div class="message">✅ <?=htmlspecialchars($message)?></div><?php endif; ?>

            <?php if ($action === 'create'): ?>
            <div class="card"><h2>新建文件</h2>
                <form method="post" action="?action=create">
                    <?= csrf_field() ?>
                    <div class="form-group"><label>文件路径</label><input type="text" name="newfile" placeholder="例如: test.php" required></div>
                    <div class="form-group"><label>内容</label><textarea name="content" rows="8"></textarea></div>
                    <div class="toolbar"><button type="submit" class="btn btn-primary">创建</button><a href="?action=list" class="btn">取消</a></div>
                </form>
            </div>
            <?php elseif ($action === 'mkdir'): ?>
            <div class="card"><h2>新建文件夹</h2>
                <form method="post" action="?action=mkdir&file=<?=urlencode($file)?>">
                    <?= csrf_field() ?>
                    <div class="form-group"><label>文件夹名称</label><input type="text" name="dirname" placeholder="例如: images" required></div>
                    <div class="toolbar"><button type="submit" class="btn btn-primary">创建</button><a href="?action=list&file=<?=urlencode($file)?>" class="btn">取消</a></div>
                </form>
            </div>
            <?php elseif ($action === 'upload'): ?>
            <div class="card"><h2>上传文件</h2>
                <form method="post" action="?action=upload&file=<?=urlencode($file)?>" enctype="multipart/form-data">
                    <?= csrf_field() ?>
                    <div onclick="document.getElementById('fileInput').click()" style="border:2px dashed var(--border);border-radius:8px;padding:32px;text-align:center;cursor:pointer;background:var(--card-bg);"><p style="font-size:36px;">📤</p><p>点击选择文件</p></div>
                    <input type="file" name="upload_file" id="fileInput" style="display:none;" onchange="this.form.submit()">
                </form>
            </div>
            <?php elseif ($action === 'edit' && $file): $path = $root . '/' . $file; $content = is_file($path) ? file_get_contents($path) : ''; 
                $lineCount = substr_count($content, "\n") + 1;
                $lineNums = '';
                for ($i = 1; $i <= $lineCount; $i++) $lineNums .= $i . "\n";
            ?>
            <div class="card"><h2>编辑: <?=htmlspecialchars($file)?></h2>
                <form method="post" action="?action=edit&file=<?=urlencode($file)?>">
                    <?= csrf_field() ?>
                    <div style="display:flex;border:1.5px solid var(--border);border-radius:var(--radius-sm);overflow:hidden;">
                        <div id="lineNumbersWrap" style="overflow:hidden;background:#fafaf8;border-right:1px solid var(--border-light);min-width:50px;max-height:380px;">
                            <pre id="lineNumbers" style="font-family:var(--font-mono);font-size:13px;color:var(--text-muted);padding:10px 12px;margin:0;text-align:right;line-height:1.55;user-select:none;"><?=$lineNums?></pre>
                        </div>
                        <textarea name="content" id="editor" style="border:none;border-radius:0;min-height:380px;resize:vertical;line-height:1.55;overflow-y:auto;" onscroll="syncScroll()" oninput="updateLineNumbers()"><?=htmlspecialchars($content)?></textarea>
                    </div>
                    <div class="toolbar" style="margin-top:12px;"><button type="submit" class="btn btn-primary">保存</button><a href="?action=list" class="btn">取消</a></div>
                </form>
            </div>
            <script>
                var lineWrap = document.getElementById('lineNumbersWrap');
                var linePre = document.getElementById('lineNumbers');
                var editor = document.getElementById('editor');
                function updateLineNumbers() {
                    var lines = editor.value.split('\n');
                    var html = '';
                    for (var i = 0; i < lines.length; i++) html += (i + 1) + '\n';
                    linePre.textContent = html;
                    syncScroll();
                }
                function syncScroll() {
                    lineWrap.scrollTop = editor.scrollTop;
                }
                // 初始设置高度同步
                lineWrap.style.maxHeight = getComputedStyle(editor).height;
                new ResizeObserver(() => {
                    lineWrap.style.maxHeight = getComputedStyle(editor).height;
                    syncScroll();
                }).observe(editor);
                updateLineNumbers();
            </script>
            <?php elseif ($action === 'delete' && $file): ?>
            <div class="card" style="text-align:center;"><h2>确认删除 <?=htmlspecialchars($file)?> ?</h2>
                <form method="post" action="?action=delete&file=<?=urlencode($file)?>">
                    <?= csrf_field() ?>
                    <input type="hidden" name="confirm" value="yes">
                    <button type="submit" class="btn btn-danger">确认删除</button><a href="?action=list" class="btn">取消</a>
                </form>
            </div>
            <?php elseif ($action === 'rename' && $file): ?>
            <div class="card"><h2>重命名: <?=htmlspecialchars(basename($file))?></h2>
                <form method="post" action="?action=rename&file=<?=urlencode($file)?>">
                    <?= csrf_field() ?>
                    <input type="text" name="newname" value="<?=htmlspecialchars(basename($file))?>" required>
                    <button type="submit" class="btn btn-primary">确认</button><a href="?action=list" class="btn">取消</a>
                </form>
            </div>
            <?php else: ?>
            <div class="address-bar">📂 <a href="?action=list" style="color:var(--accent);">root</a>
                <?php if ($file) { $parts = explode('/', $file); $cumulative = ''; foreach ($parts as $part): $cumulative .= ($cumulative ? '/' : '') . $part; ?><span class="sep">/</span><a href="?action=list&file=<?=urlencode($cumulative)?>"><?=htmlspecialchars($part)?></a><?php endforeach; } ?>
            </div>
            <div class="toolbar">
                <a href="?action=create" class="btn btn-primary">➕ 新建</a>
                <a href="?action=mkdir&file=<?=urlencode($file)?>" class="btn">📁 新建文件夹</a>
                <a href="?action=upload&file=<?=urlencode($file)?>" class="btn">📤 上传</a>
                <a href="?action=download_all" class="btn">📦 下载所有</a>
                <button onclick="location.reload()" class="btn">🔄 刷新</button>
            </div>
            <table><thead><tr><th>名称</th><th>大小</th><th>修改时间</th><th>操作</th></tr></thead><tbody>
                <?php if ($file): ?><tr><td colspan="4"><a href="?action=list&file=<?=urlencode(dirname($file))?>" class="name-link">📁 ..</a></td></tr><?php endif; ?>
                <?php if (empty($files_list)): ?><tr><td colspan="4" style="text-align:center;color:var(--text-muted);">此目录为空</td></tr>
                <?php else: foreach ($files_list as $item): $item_path = $file ? $file . '/' . $item['name'] : $item['name']; ?>
                <tr>
                    <td><?php if ($item['is_dir']): ?><a href="?action=list&file=<?=urlencode($item_path)?>" class="name-link">📁 <?=htmlspecialchars($item['name'])?></a>
                    <?php else: ?><a href="?action=edit&file=<?=urlencode($item_path)?>" class="name-link">📄 <?=htmlspecialchars($item['name'])?></a><?php endif; ?></td>
                    <td style="color:var(--text-muted);"><?=$item['is_dir'] ? '-' : formatSize($item['size'])?></td>
                    <td style="color:var(--text-muted);"><?=date('Y-m-d H:i', $item['mtime'])?></td>
                    <td class="actions">
                        <?php if (!$item['is_dir']): ?>
                            <a href="?action=edit&file=<?=urlencode($item_path)?>">编辑</a>
                        <?php endif; ?>
                        <a href="?action=download&file=<?=urlencode($item_path)?>">下载</a>
                        <a href="?action=rename&file=<?=urlencode($item_path)?>">重命名</a>
                        <a href="?action=delete&file=<?=urlencode($item_path)?>" class="danger">删除</a>
                    </td>
                </tr>
                <?php endforeach; endif; ?>
            </tbody></table>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===== 同步面板（全屏遮罩） ===== -->
    <div id="syncOverlay">
        <div id="syncPanel">
            <button class="close-btn" onclick="toggleSync()">✕</button>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                <h2 style="font-size:18px; font-weight:600;">📡 预览站同步</h2>
            </div>

            <div class="card">
                <h3>当前文件操作</h3>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <button class="btn btn-primary" onclick="pushCurrentFile()">⬆️ 推送当前文件</button>
                    <button class="btn" onclick="pullCurrentFile()">⬇️ 拉取当前文件</button>
                </div>
                <div id="syncStatus" class="status-msg" style="margin-top:8px;font-size:13px;color:var(--text-muted);"></div>
            </div>

            <div class="card">
                <h3>批量同步（服务器端，自动替换数据库密码）</h3>
                <div style="display:flex; gap:12px; flex-wrap:wrap;">
                    <button class="btn btn-primary" onclick="pushAllFiles()">📤 一键推送所有文件</button>
                    <button class="btn" onclick="pullAllFiles()">📥 一键拉取所有文件</button>
                </div>
                <div id="batchStatus" class="status-msg" style="margin-top:8px;font-size:13px;color:var(--text-muted);"></div>
            </div>

            <div class="card">
                <h3>数据库同步</h3>
                <button class="btn btn-primary" onclick="syncDatabase()">🗄️ 导出数据库 & 推送</button>
                <div id="dbStatus" class="status-msg" style="margin-top:8px;font-size:13px;color:var(--text-muted);"></div>
            </div>

            <div class="card">
                <h3>预览站文件浏览器</h3>
                <button class="btn" onclick="listPreviewFiles()">📂 打开根目录</button>
                <div id="previewFileList" style="margin-top:12px;"></div>
            </div>
        </div>
    </div>

    <script>
        const SYNC_KEY = 'lmtOJ_preview_sync_2024';
        const PREVIEW_URL = 'https://lmtoj-preview.xo.je/preview_sync.php';
        let syncPanelVisible = false;

        function toggleSync() {
            syncPanelVisible = !syncPanelVisible;
            document.getElementById('syncOverlay').style.display = syncPanelVisible ? 'flex' : 'none';
            document.getElementById('syncBtn').classList.toggle('active', syncPanelVisible);
        }

        function setStatus(msg) { document.getElementById('syncStatus').textContent = msg; }

        function getCurrentFile() { return '<?=$file?>'; }

        function pushAllFiles() {
            if (!confirm('确定推送主站所有文件到预览站？\n（将自动替换数据库配置，并备份预览站文件）')) return;
            location.href = '?action=sync_push_all';
        }
        function pullAllFiles() {
            if (!confirm('⚠️ 将从预览站拉取所有文件并覆盖主站，确认继续？')) return;
            location.href = '?action=sync_pull_all';
        }
        function syncDatabase() {
            if (!confirm('确定导出主站数据库并推送到预览站？')) return;
            location.href = '?action=sync_db';
        }

        async function pushCurrentFile() {
            const f = getCurrentFile();
            if (!f) { setStatus('❌ 请先打开一个文件'); return; }
            setStatus('⏳ 推送中...');
            try {
                const resp = await fetch('?action=edit&file=' + encodeURIComponent(f));
                const html = await resp.text();
                const doc = new DOMParser().parseFromString(html, 'text/html');
                const ta = doc.querySelector('textarea[name="content"]');
                if (!ta) throw new Error('无法读取内容');
                const content = ta.value;
                const fd = new FormData();
                fd.append('path', f);
                fd.append('content', content);
                const pushResp = await fetch(`${PREVIEW_URL}?action=push_file&key=${SYNC_KEY}`, { method: 'POST', body: fd });
                setStatus(pushResp.ok ? `✅ 已推送 ${f}` : '❌ 推送失败');
            } catch (e) { setStatus('❌ ' + e.message); }
        }

        async function pullCurrentFile() {
            const f = getCurrentFile();
            if (!f) { setStatus('❌ 请先打开一个文件'); return; }
            setStatus('⏳ 拉取中...');
            try {
                const resp = await fetch(`${PREVIEW_URL}?action=pull_file&key=${SYNC_KEY}&path=${encodeURIComponent(f)}`);
                if (!resp.ok) { setStatus('❌ 预览站无此文件'); return; }
                const content = await resp.text();
                const ta = document.getElementById('editor');
                if (ta) { ta.value = content; setStatus(`✅ 已拉取 ${f} 到编辑器`); }
                else setStatus('❌ 请先打开文件');
            } catch (e) { setStatus('❌ ' + e.message); }
        }

        async function listPreviewFiles(dir = '') {
            setStatus('⏳ 读取预览站...');
            try {
                const resp = await fetch(`?action=list_preview&dir=${encodeURIComponent(dir)}&ajax=1`);
                if (!resp.ok) { setStatus('❌ 连接失败'); return; }
                const list = await resp.json();
                let html = '<table><tr><th>名称</th><th>大小</th><th>操作</th></tr>';
                if (dir) {
                    const parent = dir.substring(0, dir.lastIndexOf('/')) || '';
                    html += `<tr><td colspan="3"><a href="javascript:void(0)" onclick="listPreviewFiles('${parent}')">📁 ..</a></td></tr>`;
                }
                list.forEach(item => {
                    const p = dir ? dir + '/' + item.name : item.name;
                    html += `<tr><td>${item.type === 'dir' ? '📁' : '📄'} ${item.name}</td><td>${item.type === 'file' ? item.size : '-'}</td><td>${item.type === 'dir' ? `<a href="javascript:void(0)" onclick="listPreviewFiles('${p}')">打开</a>` : `<a href="javascript:void(0)" onclick="pullPreviewFile('${p}')">拉取</a>`}</td></tr>`;
                });
                html += '</table>';
                document.getElementById('previewFileList').innerHTML = html;
                setStatus('');
            } catch (e) { setStatus('❌ 无法连接'); }
        }

        async function pullPreviewFile(path) {
            if (!confirm(`拉取 ${path} 到编辑器？`)) return;
            setStatus('⏳ 拉取中...');
            try {
                const resp = await fetch(`${PREVIEW_URL}?action=pull_file&key=${SYNC_KEY}&path=${encodeURIComponent(path)}`);
                if (!resp.ok) { setStatus('❌ 文件不存在'); return; }
                const content = await resp.text();
                const ta = document.getElementById('editor');
                if (ta) { ta.value = content; setStatus(`✅ 已拉取 ${path} 到编辑器`); }
                else setStatus('❌ 请先打开文件');
            } catch (e) { setStatus('❌ ' + e.message); }
        }
    </script>
</body>
</html>