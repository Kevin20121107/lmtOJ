<?php
/**
 * 网站备份工具（极速流式下载）
 * 权限：登录 + users.devadmin=1 + 二级密码
 * 优化：全程流式输出，无临时文件，不占服务器空间
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('max_execution_time', 0);        // 不限制执行时间
ini_set('memory_limit', '256M');         // 足够内存即可
set_time_limit(0);
ignore_user_abort(true);                 // 客户端断开也继续执行

session_start();

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

define('FM_PASSWORD', env('FM_PASSWORD', 'admin123'));

// ---------- 登录验证 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$login_uid = (int)$_SESSION['uid'];

$conn = db();
if (!$conn) exit("数据库连接失败\n");
$conn->set_charset("utf8mb4");

// ---------- devadmin 验证 ----------
$user = $conn->query("SELECT devadmin FROM users WHERE uid=$login_uid LIMIT 1")->fetch_assoc();
if (!$user || $user['devadmin'] != 1) {
    exit("无权限访问：仅开发者管理员可执行备份操作\n");
}

// ---------- 二级密码验证 ----------
if (!isset($_SESSION['fm_auth']) || $_SESSION['fm_auth'] !== true) {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fm_password'])) {
        if ($_POST['fm_password'] === FM_PASSWORD) {
            $_SESSION['fm_auth'] = true;
            header("Location: https://lmtoj.cn/backup");
            exit;
        } else {
            $error = '密码错误';
        }
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <title>备份工具 · 二级验证</title>
        <style>
            body { font-family: 'Segoe UI', 'PingFang SC', sans-serif; background:#f9f7f4; display:flex; justify-content:center; align-items:center; height:100vh; margin:0; }
            .card { background:#fff; padding:30px; border-radius:10px; box-shadow:0 2px 10px rgba(0,0,0,0.05); text-align:center; width:360px; }
            input { padding:10px; border:1px solid #e6e1da; border-radius:6px; width:100%; margin-bottom:10px; }
            button { padding:10px 20px; background:#6b8a74; color:#fff; border:none; border-radius:20px; cursor:pointer; }
            .error { color:#d9534f; font-size:13px; margin-top:8px; }
        </style>
    </head>
    <body>
        <div class="card">
            <h2>备份工具 · 二级密码</h2>
            <form method="post">
                <input type="password" name="fm_password" placeholder="请输入管理密码" required>
                <button type="submit">验证并下载备份</button>
                <?php if (isset($error)): ?><p class="error"><?=$error?></p><?php endif; ?>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------- 验证通过，开始备份下载 ----------
$siteRoot = __DIR__;
$backupName = 'lmtoj_backup_' . date('Ymd_His');
$excludeDirs = ['backup', '.git', '.Recycle_bin', 'cache', 'node_modules', '.cache', 'vendor']; // 可按需调整

// 检测系统命令
$hasExec = function_exists('exec') && !in_array('exec', array_map('trim', explode(',', ini_get('disable_functions'))));
$hasTar = false;
$hasMysqldump = false;

if ($hasExec) {
    $test = exec('command -v tar 2>/dev/null', $out, $ret);
    if ($ret === 0 && !empty($test)) $hasTar = true;
    $test = exec('command -v mysqldump 2>/dev/null', $out, $ret);
    if ($ret === 0 && !empty($test)) $hasMysqldump = true;
}

$dbHost = env('DB_HOST', 'localhost');
$dbUser = env('DB_USER', 'root');
$dbPass = env('DB_PASSWORD', '');
$dbName = env('DB_NAME', '');

// 关闭输出缓冲，实时输出
while (ob_get_level()) ob_end_clean();
header('Content-Type: application/gzip');
header('Content-Disposition: attachment; filename="' . $backupName . '.tar.gz"');
header('Pragma: no-cache');
header('Expires: 0');
// 不设置 Content-Length，使用 chunked 传输

// ========== 方案一：tar + mysqldump 流式输出（最快） ==========
if ($hasExec && $hasTar && $hasMysqldump) {
    // 构建排除参数
    $excludeArgs = '';
    foreach ($excludeDirs as $dir) {
        $excludeArgs .= " --exclude='$dir'";
    }
    // 创建临时 SQL 文件（使用 /tmp，不会留在网站目录）
    $tmpSql = tempnam(sys_get_temp_dir(), 'db_') . '.sql';
    // 导出数据库到临时文件（使用 --opt 加速）
    $dumpCmd = "mysqldump --host={$dbHost} --user={$dbUser} --password='" . escapeshellarg($dbPass) . "' --opt --skip-comments {$dbName} > {$tmpSql}";
    exec($dumpCmd, $out, $ret);
    if ($ret === 0 && file_exists($tmpSql) && filesize($tmpSql) > 0) {
        // 流式打包：先打包网站文件（排除备份目录），再打包 SQL 文件，重命名为 database.sql
        $tarCmd = "tar -czf - -C {$siteRoot} {$excludeArgs} . -C " . dirname($tmpSql) . " --transform='s/^" . basename($tmpSql) . "$/database.sql/' " . basename($tmpSql);
        // 执行并直接输出
        passthru($tarCmd, $ret);
        unlink($tmpSql);
        exit;
    } else {
        // mysqldump 失败，清理并回退
        if (file_exists($tmpSql)) unlink($tmpSql);
    }
}

// ========== 方案二：纯 PHP 打包（低内存版） ==========
$tmpZip = tempnam(sys_get_temp_dir(), 'zip_');
$tmpSql = tempnam(sys_get_temp_dir(), 'db_') . '.sql'; // 数据库临时文件

$zip = new ZipArchive();
if ($zip->open($tmpZip, ZipArchive::OVERWRITE) === true) {
    // 1. 先生成 SQL 到临时文件（流式写入，避免内存暴涨）
    $sqlFileHandle = fopen($tmpSql, 'w');
    fwrite($sqlFileHandle, "-- lmtOJ Database Backup\n-- Generated: " . date('Y-m-d H:i:s') . "\nSET FOREIGN_KEY_CHECKS=0;\n\n");

    $tables = [];
    $result = $conn->query("SHOW TABLES");
    if ($result) {
        while ($row = $result->fetch_row()) $tables[] = $row[0];
    }

    foreach ($tables as $table) {
        $createRes = $conn->query("SHOW CREATE TABLE `$table`");
        if ($createRes && $createRow = $createRes->fetch_row()) {
            fwrite($sqlFileHandle, "DROP TABLE IF EXISTS `$table`;\n" . $createRow[1] . ";\n\n");
        }

        $dataRes = $conn->query("SELECT * FROM `$table`");
        if ($dataRes && $dataRes->num_rows > 0) {
            while ($row = $dataRes->fetch_assoc()) {
                $values = array_map(function($v) use ($conn) {
                    if ($v === null) return 'NULL';
                    return "'" . $conn->real_escape_string($v) . "'";
                }, array_values($row));
                fwrite($sqlFileHandle, "INSERT INTO `$table` VALUES (" . implode(',', $values) . ");\n");
            }
            fwrite($sqlFileHandle, "\n");
        }
        // 释放结果集，减少内存
        $dataRes->free();
    }
    fwrite($sqlFileHandle, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($sqlFileHandle);

    // 2. 将 SQL 文件添加到 ZIP（流式，不占大量内存）
    $zip->addFile($tmpSql, 'database.sql');

    // 3. 添加网站文件（原有递归函数不变）
    function addFilesToZip($dir, $baseDir, $zip, $excludeDirs) {
        if (!is_dir($dir)) return;
        $items = @scandir($dir);
        if ($items === false) return;
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $fullPath = $dir . '/' . $item;
            $relPath = ltrim(str_replace($baseDir, '', $fullPath), '/');
            $skip = false;
            foreach ($excludeDirs as $exDir) {
                if ($relPath === $exDir || strpos($relPath, $exDir . '/') === 0) {
                    $skip = true;
                    break;
                }
            }
            if ($skip) continue;
            if ($relPath === 'backup.php') continue;
            if (is_dir($fullPath)) {
                addFilesToZip($fullPath, $baseDir, $zip, $excludeDirs);
            } elseif (is_file($fullPath)) {
                try {
                    $zip->addFile($fullPath, $relPath);
                } catch (Exception $e) {}
            }
        }
    }
    addFilesToZip($siteRoot, $siteRoot, $zip, $excludeDirs);

    $zip->close();

    // 输出下载
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $backupName . '.zip"');
    header('Content-Length: ' . filesize($tmpZip));
    readfile($tmpZip);

    // 清理临时文件
    unlink($tmpZip);
    unlink($tmpSql);
    exit;
} else {
    if (file_exists($tmpSql)) unlink($tmpSql);
    exit("无法创建临时 ZIP 文件，请检查 /tmp 目录权限");
}