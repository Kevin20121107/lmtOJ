<?php
// 如果接收到 url 参数，处理并跳转
if (isset($_GET['url'])) {
    $url = trim($_GET['url']);
    
    // 如果没有协议头，默认添加 https://
    if (!preg_match('/^https?:\/\//i', $url)) {
        $url = 'https://' . $url;
    }
    
    // 安全跳转
    header('Location: ' . $url);
    exit;
}
?>
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>网址直达</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #f5f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: white;
            padding: 2.5rem 3rem;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            text-align: center;
        }
        h1 {
            font-weight: 400;
            color: #1a1a2e;
            margin-top: 0;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
        }
        .input-group {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }
        input[type="text"] {
            flex: 1;
            min-width: 220px;
            padding: 12px 18px;
            border: 1px solid #d0d7de;
            border-radius: 40px;
            font-size: 1rem;
            outline: none;
            transition: border-color 0.2s;
        }
        input[type="text"]:focus {
            border-color: #0077ff;
            box-shadow: 0 0 0 3px rgba(0,119,255,0.15);
        }
        button {
            padding: 12px 28px;
            background: #0077ff;
            color: white;
            border: none;
            border-radius: 40px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background 0.2s;
        }
        button:hover {
            background: #005fcc;
        }
        .hint {
            margin-top: 1.2rem;
            font-size: 0.9rem;
            color: #6b7280;
        }
        .hint code {
            background: #f0f2f5;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <form method="get">
            <div class="input-group">
                <input type="text" name="url" placeholder="输入网址，如 example.com" required>
                <button type="submit">打开</button>
            </div>
        </form>
        <p class="hint">
            未指定协议时自动添加 <code>https://</code>，已有协议则保留
        </p>
    </div>
</body>
</html>