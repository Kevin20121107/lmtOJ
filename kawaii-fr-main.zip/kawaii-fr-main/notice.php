<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once __DIR__ . '/security.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");
$conn->query("SET SESSION SQL_BIG_SELECTS=1");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

csrf_protect_request(true);

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 将所有未读系统消息标记为已读（排除私信和群聊）
if (csrf_is_same_origin_request()) {
    $updStmt = $conn->prepare("UPDATE notice SET is_read = 1 WHERE uid = ? AND is_read = 0 AND (content IS NULL OR content NOT IN ('message', 'group'))");
    $updStmt->bind_param("i", $login_uid);
    $updStmt->execute();
    $updStmt->close();
}

$is_admin = 0;
$adminStmt = $conn->prepare("SELECT admin FROM users WHERE uid = ? LIMIT 1");
$adminStmt->bind_param("i", $login_uid);
$adminStmt->execute();
$adminRes = $adminStmt->get_result();
if ($adminRes) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}
$adminStmt->close();

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 15;
$offset = ($page - 1) * $limit;

// 只查询系统通知（排除私信和群聊），并关联 @ 用户信息
$where = "WHERE n.uid = ? AND (n.content IS NULL OR n.content NOT IN ('message', 'group'))";

$countStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice n {$where}");
$countStmt->bind_param("i", $login_uid);
$countStmt->execute();
$total = $countStmt->get_result()->fetch_assoc()['cnt'];
$countStmt->close();
$totalPage = ceil($total / $limit);

$listStmt = $conn->prepare("
    SELECT n.id, n.tid, n.atid, n.topic_title, n.create_time, n.is_read, n.content,
           u.name as at_name
    FROM notice n
    LEFT JOIN users u ON n.atid = u.uid
    {$where}
    ORDER BY n.create_time DESC
    LIMIT ?, ?
");
$listStmt->bind_param("iii", $login_uid, $offset, $limit);
$listStmt->execute();
$msgList = $listStmt->get_result();
$listStmt->close();

function safeContent($content) {
    return htmlspecialchars($content ?? '', ENT_QUOTES, 'UTF-8');
}

function formatTime($timeStr) {
    return empty($timeStr) ? '' : date('Y-m-d H:i:s', strtotime($timeStr));
}

// 系统未读（仅用于导航栏红点，navbar.php 会自己查，这里保留备用）
$unreadStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0 AND (content IS NULL OR content NOT IN ('message', 'group'))");
$unreadStmt->bind_param("i", $login_uid);
$unreadStmt->execute();
$unreadSystem = $unreadStmt->get_result()->fetch_assoc()['cnt'];
$unreadStmt->close();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>消息中心 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .navbar h1 a{color:#f0ece6;text-decoration:none;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);}
        .head-bar{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;padding-bottom:16px;border-bottom:1px solid var(--border-light);}
        .head-bar h2{font-size:18px;font-weight:600;color:var(--text);}
        .message-count{color:var(--text-muted);font-size:13.5px;font-weight:500;}
        .msg-item{padding:16px 18px;margin-bottom:8px;border-radius:var(--radius-sm);border-left:3px solid transparent;transition:all 0.2s ease;}
        .msg-item:hover{background:#fafaf7;}
        .msg-unread{background:#fafaf7;border-left-color:var(--accent);}
        .msg-read{border-left-color:transparent;opacity:0.75;}
        .msg-content{font-size:14.5px;line-height:1.8;color:var(--text);}
        .msg-time{font-size:12px;color:var(--text-muted);margin-top:8px;}
        a{color:var(--accent);text-decoration:none;font-weight:500;transition:var(--transition);}
        a:hover{color:var(--accent-hover);text-decoration:underline;}
        .msg-link{color:var(--accent);font-weight:500;margin-left:6px;}
        .msg-link:hover{text-decoration:underline;color:var(--accent-hover);}
        .user-link{color:var(--text);font-weight:600;}
        .user-link:hover{color:var(--accent);text-decoration:underline;}
        .msg-type-badge{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;margin-right:8px;font-weight:600;}
        .badge-benben{background:#fef3e4;color:#b85c00;}
        .badge-discuss{background:#e8f5e9;color:#2e7d32;}
        .badge-assign{background:#dbeafe;color:#2563eb;}
        .badge-unban{background:#fce4ec;color:#c62828;}
        .badge-article{background:#e0f2fe;color:#0369a1;}
        .badge-team{background:#f3e5f5;color:#6a1b9a;}
        .badge-bind{background:#e8eaf6;color:#3949ab;} /* 绑定申请 badge */
        .empty-tip{text-align:center;color:var(--text-muted);padding:50px 0;}
        .empty-tip .empty-icon{font-size:52px;margin-bottom:16px;display:block;}
        .page-bar{display:flex;align-items:center;gap:6px;margin-top:20px;padding-top:16px;border-top:1px solid var(--border-light);flex-wrap:wrap;}
        .page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;background:#fff;transition:var(--transition);}
        .page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
        .page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);}
        .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
        @media(max-width:768px){.main{flex-direction:column;padding:0 12px;margin:18px auto 30px;gap:14px;}.sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}.sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}.sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}.navbar{padding:0 14px;height:48px;}.card{padding:18px 14px;}.msg-item{padding:12px 14px;}}
    </style>
    <link rel="stylesheet" href="/css/problem-theme.css">
    <style>
        .msg-item:hover {
            background: rgba(255, 255, 255, 0.34);
        }
        .msg-unread {
            background: rgba(67, 160, 106, 0.12);
            border-left-color: var(--accent);
        }
        .msg-read {
            border-left-color: transparent;
            opacity: 0.75;
        }
        .page-bar a {
            border-color: rgba(67, 128, 91, 0.2);
            background: rgba(255, 255, 255, 0.32);
        }
        .page-bar a.active {
            background: rgba(37, 132, 83, 0.72);
            border-color: rgba(255, 255, 255, 0.48);
            color: #fff;
            box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.3), 0 4px 14px rgba(37, 132, 83, 0.16);
        }
    </style>
</head>
<body>
<?php include 'navbar.php';//页首 ?>

<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>

    <div class="content">
        <div class="card">
            <div class="head-bar">
                <h2>通知</h2>
                <?php if($total>0):?><span class="message-count">共 <?=$total?> 条</span><?php endif;?>
            </div>

            <?php if($total<=0):?>
            <div class="empty-tip"><span class="empty-icon">📭</span><p>暂无通知</p></div>
            <?php else:?>
                <?php while($msg=$msgList->fetch_assoc()):
                    $tid=(int)$msg['tid']; $atid=(int)$msg['atid'];
                    $at_name=!empty($msg['at_name'])?safeContent($msg['at_name']):"用户#{$atid}";
                    $cls=$msg['is_read']?'msg-read':'msg-unread';
                    $content=$msg['content']??'';
                    
                    // ---------- 根据 content 决定显示内容 ----------
                    if(empty($content)){
                        // 犇犇 @ 提醒
                        $message_text="<a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 在犇犇中提到了你。";
                        $link_url="https://lmtoj.cn/benben/all"; $link_text="去看看";
                        $badge_class="badge-benben"; $badge_text="犇犇";
                    }elseif($content==="assign"){
                        $message_text="您已被设为 <a href='https://lmtoj.cn/ticket/{$tid}' class='user-link'>".safeContent($msg['topic_title'])."</a> 的责任人。";
                        $link_url="https://lmtoj.cn/ticket/{$tid}"; $link_text="查看";
                        $badge_class="badge-assign"; $badge_text="工单";
                    }elseif($content==="done"){
                        $message_text="您的 <a href=https://lmtoj.cn/ticket/{$tid} class='user-link'>".safeContent($msg['topic_title'])."</a> 已标记结单。";
                        $link_url="https://lmtoj.cn/ticket/{$tid}"; $link_text="查看";
                        $badge_class="badge-assign"; $badge_text="工单";
                    }elseif($content==="ticket"){
                        $topic_title=!empty($msg['topic_title'])?safeContent($msg['topic_title']):"工单 #{$tid}";
                        $message_text="<a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 在 <strong>《{$topic_title}》</strong> 中提到了你。";
                        $link_url="https://lmtoj.cn/ticket/{$tid}"; $link_text="查看工单 →";
                        $badge_class="badge-assign"; $badge_text="工单";
                    }elseif($content==="article_comment"){
                        $topic_title=!empty($msg['topic_title'])?safeContent($msg['topic_title']):"文章 #{$tid}";
                        $message_text="<a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 在 <a href='https://lmtoj.cn/article/{$tid}' class='user-link'>".$topic_title."</a> 中提到了你。";
                        $link_url="https://lmtoj.cn/article/{$tid}"; $link_text="查看文章 →";
                        $badge_class="badge-article"; $badge_text="文章";
                    }elseif($content==="unban_request"){
                        $applicant = $conn->query("SELECT name FROM users WHERE uid = {$atid}")->fetch_assoc();
                        $applicant_name = safeContent($applicant['name'] ?? '用户#' . $atid);
                        $message_text = "用户 <strong>{$applicant_name}</strong> 申请解除封禁。";
                        $req = $conn->query("SELECT id FROM unban_requests WHERE uid = {$atid} AND status = 'pending' ORDER BY id DESC LIMIT 1")->fetch_assoc();
                        if ($req) {
                            $link_url = "https://lmtoj.cn/unban?action=handle&id=" . $req['id'];
                            $link_text = "去处理 →";
                        } else {
                            $link_url = "#";
                            $link_text = "（无有效申请）";
                        }
                        $badge_class="badge-unban"; $badge_text="解封申请";
                    }elseif($content==="team_apply"){
                        $team_name = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "团队 #{$tid}";
                        $message_text = "用户 <a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 申请加入 <strong>{$team_name}</strong>。";
                        $link_url = "https://lmtoj.cn/team/{$tid}"; $link_text = "去处理 →";
                        $badge_class="badge-team"; $badge_text="团队";
                    }elseif($content==="team_approved"){
                        $team_name = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "团队 #{$tid}";
                        $message_text = "您加入 <strong>{$team_name}</strong> 的申请已被批准。";
                        $link_url = "https://lmtoj.cn/team/{$tid}"; $link_text = "查看团队 →";
                        $badge_class="badge-team"; $badge_text="团队";
                    }elseif($content==="team_rejected"){
                        $team_name = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "团队 #{$tid}";
                        $message_text = "您加入 <strong>{$team_name}</strong> 的申请已被拒绝。";
                        $link_url = "https://lmtoj.cn/team/{$tid}"; $link_text = "查看团队 →";
                        $badge_class="badge-team"; $badge_text="团队";
                    }elseif($content==="bind_request"){
                        // 洛谷绑定申请 - 管理员收到的通知
                        $topic_title = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "洛谷绑定申请";
                        $message_text = "用户 <a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 提交了洛谷账号绑定申请。";
                        $link_url = "https://lmtoj.cn/bind?action=handle&id={$tid}";  // 跳转到处理页面
                        $link_text = "去处理 →";
                        $badge_class="badge-bind"; 
                        $badge_text="绑定申请";
                    }elseif($content==="bind_approved"){
                        // 绑定申请已批准 - 申请人收到的通知
                        $topic_title = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "绑定申请已批准";
                        $message_text = "您的洛谷账号绑定申请已通过。";
                        $link_url = "https://lmtoj.cn/bind"; 
                        $link_text = "查看状态 →";
                        $badge_class="badge-bind"; 
                        $badge_text="绑定申请";
                    }elseif($content==="bind_rejected"){
                        // 绑定申请已拒绝 - 申请人收到的通知
                        $topic_title = !empty($msg['topic_title']) ? safeContent($msg['topic_title']) : "绑定申请已拒绝";
                        $message_text = "您的洛谷账号绑定申请被拒绝。";
                        $link_url = "https://lmtoj.cn/bind"; 
                        $link_text = "查看状态 →";
                        $badge_class="badge-bind"; 
                        $badge_text="绑定申请";
                    }elseif($content==="register"){
                        // 新用户注册
                        $message_text = "欢迎你加入 lmtoj，在此希望你先阅读下<a href='https://lmtoj.cn/help'>帮助中心</a>以了解一些功能和规则，感谢你的支持和对维护社区环境做出的贡献。";
                        $link_url = ""; 
                        $link_text = "";
                        $badge_class="badge-bind"; 
                        $badge_text="欢迎注册！";
                    }else{
                        // 默认：讨论帖 @ 提醒
                        $topic_title=!empty($msg['topic_title'])?safeContent($msg['topic_title']):"讨论帖 #{$tid}";
                        $message_text="<a href='https://lmtoj.cn/user/{$atid}' class='user-link'>{$at_name}</a> 在 <strong>《{$topic_title}》</strong> 中提到了你。";
                        $link_url="https://lmtoj.cn/discuss/{$tid}"; $link_text="查看帖子 →";
                        $badge_class="badge-discuss"; $badge_text="讨论";
                    }
                ?>
                <div class="msg-item <?=$cls?>">
                    <div class="msg-content">
                        <span class="msg-type-badge <?=$badge_class?>"><?=$badge_text?></span>
                        <?=$message_text?>
                        <a href="<?=$link_url?>" class="msg-link"><?=$link_text?></a>
                    </div>
                    <div class="msg-time"><?=formatTime($msg['create_time'])?></div>
                </div>
                <?php endwhile;?>
            <?php endif;?>

            <?php if($totalPage>1):?>
            <div class="page-bar">
                <?php if($page>1):?><a href="https://lmtoj.cn/notice?page=<?=$page-1?>">上一页</a><?php endif;?>
                <?php
                $shown=[1];
                for($i=max(2,$page-2);$i<=min($totalPage-1,$page+2);$i++)$shown[]=$i;
                if($totalPage>1)$shown[]=$totalPage;
                $shown=array_unique($shown);sort($shown);$prev=0;
                foreach($shown as $i):
                    if($i-$prev>1)echo'<span class="page-ellipsis">...</span>';
                ?>
                    <a href="https://lmtoj.cn/notice?page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a>
                <?php $prev=$i;endforeach;?>
                <?php if($page<$totalPage):?><a href="https://lmtoj.cn/notice?page=<?=$page+1?>">下一页</a><?php endif;?>
            </div>
            <?php endif;?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>