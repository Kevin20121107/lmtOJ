<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$is_admin = 0;
$unreadCount = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) $is_admin = (int)$adminRes->fetch_assoc()['admin'];
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'maximg'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN maximg INT DEFAULT 20");
}

$conn->query("CREATE TABLE IF NOT EXISTS user_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    filename VARCHAR(255) NOT NULL,
    path VARCHAR(500) NOT NULL,
    size INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$userData = $conn->query("SELECT maximg FROM users WHERE uid = {$login_uid}")->fetch_assoc();
$maxImg = $userData['maximg'] ?? 20;
$uploadCount = $conn->query("SELECT COUNT(*) AS cnt FROM user_images WHERE uid = {$login_uid}")->fetch_assoc()['cnt'];

// 获取当前页码
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;

// 上传处理（AJAX）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image_file'])) {
    $result = ['success' => false, 'message' => '', 'url' => ''];
    $maxSize = $is_admin ? 4 * 1024 * 1024 : 2 * 1024 * 1024;
    if ($uploadCount >= $maxImg && !$is_admin) {
        $result['message'] = "上传已达上限（{$maxImg}张）";
    } else {
        $file = $_FILES['image_file'];
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $result['message'] = '上传失败';
        } elseif ($file['size'] > $maxSize) {
            $result['message'] = '图片大小不能超过 2MB 管理员不能超过 4MB';
        } else {
            // ========== 修改开始：健壮 MIME 检测 ==========
            // 1. 优先使用 finfo，不可用时降级为 getimagesize
            $mime = '';
            if (function_exists('finfo_open')) {
                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                $mime = finfo_file($finfo, $file['tmp_name']);
                finfo_close($finfo);
            } else {
                $info = @getimagesize($file['tmp_name']);
                $mime = $info['mime'] ?? '';
            }

            // 2. MIME 映射表（合并重复键，增加 pjpeg 兼容）
            $mimeExtensions = [
                'image/jpeg'  => 'jpg',
                'image/pjpeg' => 'jpg',   // 兼容 IE 等老浏览器
                'image/png'   => 'png',
                'image/gif'   => 'gif',
                'image/webp'  => 'webp',
                'image/bmp'   => 'bmp',
                'image/x-bmp' => 'bmp',
                'image/x-ms-bmp' => 'bmp',
            ];

            $imageInfo = @getimagesize($file['tmp_name']);

            // 3. 验证：上传文件、图片信息有效、MIME 在白名单内
            if (!is_uploaded_file($file['tmp_name']) || !$imageInfo || !isset($mimeExtensions[$mime])) {
                $result['message'] = '文件内容不是受支持的图片格式';
            } else {
                $ext = $mimeExtensions[$mime];
                $imgDir = __DIR__ . '/upload/img/' . date('Y/m');
                if (!is_dir($imgDir)) mkdir($imgDir, 0755, true);
                $filename = date('d_H-i-s_') . bin2hex(random_bytes(4)) . '.' . $ext;
                $savePath = $imgDir . '/' . $filename;
                if (!move_uploaded_file($file['tmp_name'], $savePath)) {
                    $result['message'] = '图片保存失败';
                } else {
                    $urlPath = '/upload/img/' . date('Y/m') . '/' . $filename;
                    $size = (int) $file['size'];
                    $conn->query("INSERT INTO user_images (uid, filename, path, size) VALUES ({$login_uid}, '{$filename}', '{$urlPath}', {$size})");

                    $result = [
                        'success' => true,
                        'url' => 'https://lmtoj.cn' . $urlPath,
                        'message' => '上传成功'
                    ];
                }
            }
            // ========== 修改结束 ==========
        }
    }

    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
}

// 删除图片处理
if (isset($_GET['del_img']) && is_numeric($_GET['del_img'])) {
    $imgId = (int)$_GET['del_img'];
    $img = $conn->query("SELECT * FROM user_images WHERE id = {$imgId} AND uid = {$login_uid}")->fetch_assoc();
    if ($img) {
        $filePath = __DIR__ . $img['path'];
        if (file_exists($filePath)) unlink($filePath);
        $conn->query("DELETE FROM user_images WHERE id = {$imgId}");
        // 重新计算总数和页码
        $totalAfterDel = $conn->query("SELECT COUNT(*) AS cnt FROM user_images WHERE uid = {$login_uid}")->fetch_assoc()['cnt'];
        $totalPagesAfterDel = max(1, ceil($totalAfterDel / 12));
        if ($page > $totalPagesAfterDel) $page = $totalPagesAfterDel;
        header("Location: ?page={$page}");
        exit;
    }
}

// 查询总数
$totalImages = $conn->query("SELECT COUNT(*) AS cnt FROM user_images WHERE uid = {$login_uid}")->fetch_assoc()['cnt'];
$totalPages = max(1, ceil($totalImages / 12));
if ($page > $totalPages) $page = $totalPages;
$offset = ($page - 1) * 12;

// 查询当前页图片
$userImages = $conn->query("SELECT * FROM user_images WHERE uid = {$login_uid} ORDER BY id DESC LIMIT 12 OFFSET {$offset}");

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>图床 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;position:sticky;top:80px;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card h2{font-size:18px;font-weight:600;margin-bottom:16px;}
        .upload-zone{border:2px dashed var(--border);border-radius:var(--radius);padding:40px;text-align:center;cursor:pointer;transition:var(--transition);background:var(--card-bg);}
        .upload-zone:hover{border-color:var(--accent);background:#fafaf8;}
        .alert{padding:12px 14px;border-radius:6px;margin-bottom:14px;font-size:14px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;}
        .alert-error{background:#fce4ec;color:#c62828;}
        .result-box{text-align:center;padding:16px;}
        .result-box input{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:20px;font-size:13px;text-align:center;outline:none;background:#fdfdfc;font-family:monospace;}
        .gallery{display:grid;grid-template-columns:repeat(6,1fr);gap:8px;margin-top:12px;}
        .gallery-item{position:relative;border-radius:6px;overflow:hidden;border:1px solid var(--border);cursor:pointer;aspect-ratio:1;}
        .gallery-item img{width:100%;height:100%;object-fit:cover;display:block;}
        .gallery-item:hover img{opacity:0.9;}
        .gallery-item .del-btn{position:absolute;top:4px;right:4px;background:rgba(0,0,0,0.5);color:#fff;width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;text-decoration:none;line-height:1;transition:var(--transition);}
        .gallery-item .del-btn:hover{background:var(--danger);}
        .quota{font-size:13px;color:var(--text-muted);margin-bottom:14px;}
        .quota strong{color:var(--accent);}
        #uploadStatus{text-align:center;margin-top:12px;font-size:14px;}
        a{color:var(--accent);text-decoration:none;}
        .pagination { display:flex; gap:6px; flex-wrap:wrap; justify-content:center; margin-top:16px; }
        .pagination .page-link { padding:6px 12px; border:1px solid var(--border); border-radius:6px; text-decoration:none; color:var(--text); font-size:13px; transition:var(--transition); }
        .pagination .page-link:hover { background:#f5f2ed; }
        .pagination .page-link.active { background:var(--accent); color:#fff; border-color:var(--accent); }
        @media(max-width:768px){
            .main{flex-direction:column;padding:0 12px;}
            .sidebar{width:100%;position:static;display:flex;}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .gallery{grid-template-columns:repeat(3,1fr);}
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <h2>图床</h2>
            <div class="quota">已用 <strong id="uploadCount"><?=$uploadCount?></strong> / <strong><?=$is_admin?'∞':$maxImg?></strong> 张</div>
            <div id="uploadStatus"></div>
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="upload-zone" onclick="document.getElementById('imageInput').click()">
                    <p style="font-size:48px;">🖼️</p>
                    <p style="font-size:15px;font-weight:500;">点击选择图片</p>
                    <p style="font-size:12px;color:var(--text-muted);">支持 JPG/PNG/GIF/WebP · 最大 2MB</p>
                </div>
                <input type="file" name="image_file" id="imageInput" accept="image/*" style="display:none;" onchange="uploadImage()">
            </form>
        </div>

        <div class="card">
            <h2>历史图片</h2>
            <?php if($userImages->num_rows > 0):?>
                <div class="gallery" id="gallery">
                    <?php while($img = $userImages->fetch_assoc()): $url='https://lmtoj.cn'.$img['path'];?>
                    <div class="gallery-item" id="img-<?=$img['id']?>">
                        <img src="<?=$url?>" alt="" loading="lazy" onclick="copyUrl('<?=$url?>')" title="点击复制链接">
                        <a href="?del_img=<?=$img['id']?>&page=<?=$page?>" class="del-btn" onclick="event.stopPropagation();return confirm('确定删除？')">×</a>
                    </div>
                    <?php endwhile;?>
                </div>
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?= $page - 1 ?>" class="page-link">&laquo; 上一页</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?= $i ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                        <a href="?page=<?= $page + 1 ?>" class="page-link">下一页 &raquo;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php else:?>
                <p style="color:var(--text-muted);">暂无上传记录</p>
            <?php endif;?>
        </div>
    </div>
</div>

<script>
function copyUrl(url) {
    var input = document.createElement('input');
    input.value = url;
    document.body.appendChild(input);
    input.select();
    document.execCommand('copy');
    document.body.removeChild(input);
    alert('已复制链接');
}

function uploadImage() {
    var form = document.getElementById('uploadForm');
    var fileInput = document.getElementById('imageInput');
    var status = document.getElementById('uploadStatus');

    if (!fileInput.files.length) return;

    var fd = new FormData(form);
    status.innerHTML = '<span style="color:var(--text-muted);">上传中...</span>';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '', true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

    xhr.onload = function() {
        var result = JSON.parse(xhr.responseText);
        if (result.success) {
            // 上传成功，跳转到第一页以显示新图片
            window.location.href = '?page=1';
        } else {
            status.innerHTML = '<span style="color:#c62828;">' + result.message + '</span>';
            fileInput.value = '';
        }
    };

    xhr.onerror = function() {
        status.innerHTML = '<span style="color:#c62828;">上传失败，请重试</span>';
        fileInput.value = '';
    };

    xhr.send(fd);
}
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>