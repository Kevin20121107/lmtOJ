<?php
if(session_status()===PHP_SESSION_NONE){
    session_start();
}
require_once __DIR__ . '/security.php';
csrf_protect_request((int) ($_SESSION['uid'] ?? 0) > 0);

date_default_timezone_set('Asia/Shanghai');
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

function getClientIP() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) return $_SERVER['HTTP_CLIENT_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ipArr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ipArr[0]);
    }
    return $_SERVER['REMOTE_ADDR'];
}

$ip = getClientIP();
$now = date('Y-m-d H:i:s');

// 1. 记录访问日志 - 使用预处理语句
$stmt = $conn->prepare("INSERT INTO visit (ip, time) VALUES (?, NOW())");
$stmt->bind_param("s", $ip);
$stmt->execute();
$stmt->close();

// 2. 检查30秒内访问次数 - 使用预处理语句
$stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM visit WHERE ip = ? AND time > DATE_SUB(NOW(), INTERVAL 30 SECOND)");
$stmt->bind_param("s", $ip);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$count = (int)$row['cnt'];
$stmt->close();

if ($count >= 100) {
    $htaccessPath = __DIR__ . '/.htaccess';
    $denyLine = "deny from {$ip}";
    
    $content = file_exists($htaccessPath) ? file_get_contents($htaccessPath) : '';
    if (strpos($content, $denyLine) === false) {
        $content = rtrim($content) . "\n{$denyLine}\n";
        file_put_contents($htaccessPath, $content);
    }
    http_response_code(403);
    header("Content-Type:text/html;charset=utf-8");
    die("<h1>403 Forbidden</h1><p>访问过于频繁，IP 已被封禁。</p>");
}

// ===== 检查当前用户是否被封禁 =====
// 修复：更准确地检测是否在解封页面
$script_name = $_SERVER['SCRIPT_NAME'] ?? '';
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$is_unban_page = (
    strpos($script_name, 'unban.php') !== false || 
    strpos($request_uri, '/unban') !== false ||
    strpos($request_uri, '/unban.php') !== false ||
    (defined('IN_UNBAN_PAGE') && IN_UNBAN_PAGE === true)
);

// 只有在非解封页面才进行封禁检查
if (!$is_unban_page && isset($_SESSION['uid'])) {
    $uid = (int)$_SESSION['uid'];
    $banCheck = $conn->query("SELECT banned FROM users WHERE uid = $uid")->fetch_assoc();
    if ($banCheck && $banCheck['banned']) {
        header("Location: https://lmtoj.cn/unban");
        exit;
    }
}
// ===== 检查结束 =====

// 3. 如果用户已登录，记录 IP 历史
if (isset($_SESSION['uid'])) {
    $uid = (int)$_SESSION['uid'];
    
    $conn->query("CREATE TABLE IF NOT EXISTS user_ip_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        uid INT NOT NULL,
        ip VARCHAR(45) NOT NULL,
        last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        count INT DEFAULT 1,
        UNIQUE KEY uid_ip (uid, ip)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    
    $stmt = $conn->prepare("INSERT INTO user_ip_history (uid, ip) VALUES (?, ?) ON DUPLICATE KEY UPDATE count = count + 1, last_seen = NOW()");
    $stmt->bind_param("is", $uid, $ip);
    $stmt->execute();
    $stmt->close();
}

$conn->close();
?>