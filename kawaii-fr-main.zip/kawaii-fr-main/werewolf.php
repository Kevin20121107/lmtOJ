<?php
declare(strict_types=1);

session_start();
error_reporting(E_ALL);
ini_set('display_errors', '1');
date_default_timezone_set('Asia/Shanghai');

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/security.php';

$conn = db();
$conn->set_charset('utf8mb4');

if (empty($_SESSION['uid'])) {
    header('Location: https://lmtoj.cn/login');
    exit;
}
$uid = (int)$_SESSION['uid'];

// ====== 辅助函数：确保表中存在指定列 ======
function ensure_column(mysqli $db, string $table, string $column, string $definition): void {
    $res = $db->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($res && $res->num_rows === 0) {
        $db->query("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
    }
}

// ====== 创建所有表（若不存在） ======
$conn->query("CREATE TABLE IF NOT EXISTS werewolf_games (
    id INT AUTO_INCREMENT PRIMARY KEY,
    host_uid INT NOT NULL,
    max_players TINYINT NOT NULL,
    status ENUM('waiting','playing','finished') NOT NULL DEFAULT 'waiting',
    phase VARCHAR(30) NOT NULL DEFAULT 'LOBBY',
    round_no INT NOT NULL DEFAULT 0,
    winner VARCHAR(20) DEFAULT NULL,
    discussion_seat_no TINYINT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX(status), INDEX(host_uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS werewolf_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    uid INT NOT NULL,
    seat_no TINYINT NOT NULL,
    role VARCHAR(20) DEFAULT NULL,
    alive TINYINT NOT NULL DEFAULT 1,
    wolf_vote INT DEFAULT NULL,
    day_vote INT DEFAULT NULL,
    day_spoke TINYINT NOT NULL DEFAULT 0,
    witch_save_used TINYINT NOT NULL DEFAULT 0,
    witch_poison_used TINYINT NOT NULL DEFAULT 0,
    UNIQUE KEY game_uid(game_id,uid),
    UNIQUE KEY game_seat(game_id,seat_no),
    INDEX(game_id), INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS werewolf_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    round_no INT NOT NULL DEFAULT 0,
    phase VARCHAR(30) NOT NULL,
    visible_uid INT DEFAULT NULL,
    content TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(game_id), INDEX(visible_uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS werewolf_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    uid INT NOT NULL,
    content VARCHAR(500) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(game_id), INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS werewolf_wolf_chat (
    id INT AUTO_INCREMENT PRIMARY KEY,
    game_id INT NOT NULL,
    uid INT NOT NULL,
    content VARCHAR(500) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX(game_id, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ====== 确保所有表具有最新字段 ======
ensure_column($conn, 'werewolf_games', 'discussion_seat_no', 'TINYINT NULL');
ensure_column($conn, 'werewolf_players', 'wolf_vote', 'INT DEFAULT NULL');
ensure_column($conn, 'werewolf_players', 'day_vote', 'INT DEFAULT NULL');
ensure_column($conn, 'werewolf_players', 'day_spoke', 'TINYINT NOT NULL DEFAULT 0');
ensure_column($conn, 'werewolf_players', 'witch_save_used', 'TINYINT NOT NULL DEFAULT 0');
ensure_column($conn, 'werewolf_players', 'witch_poison_used', 'TINYINT NOT NULL DEFAULT 0');

// ====== CSRF ======
if (function_exists('csrf_token')) {
    $csrf = csrf_token();
} else {
    if (empty($_SESSION['werewolf_csrf'])) $_SESSION['werewolf_csrf'] = bin2hex(random_bytes(32));
    $csrf = $_SESSION['werewolf_csrf'];
}
function ww_csrf_ok(string $token): bool {
    if (function_exists('csrf_token_is_valid')) return csrf_token_is_valid($token);
    return isset($_SESSION['werewolf_csrf']) && hash_equals($_SESSION['werewolf_csrf'], $token);
}
function h(?string $s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// ====== 核心函数 ======
function ww_log(mysqli $db, int $game, int $round, string $phase, string $content, ?int $visibleUid = null): void {
    $st = $db->prepare("INSERT INTO werewolf_logs(game_id,round_no,phase,visible_uid,content) VALUES(?,?,?,?,?)");
    $st->bind_param('iisis', $game, $round, $phase, $visibleUid, $content);
    $st->execute();
    $st->close();
}
function ww_roles(int $n): array {
    $wolves = match ($n) {
        6,7 => 2,
        8,9,10 => 3,
        default => 4
    };
    return array_merge(array_fill(0, $wolves, '狼人'), ['预言家','女巫'], array_fill(0, $n-$wolves-2, '村民'));
}
function ww_game(mysqli $db, int $id): ?array {
    $st=$db->prepare("SELECT * FROM werewolf_games WHERE id=?");
    $st->bind_param('i',$id); $st->execute();
    $r=$st->get_result()->fetch_assoc(); $st->close(); return $r ?: null;
}
function ww_player(mysqli $db, int $game, int $uid): ?array {
    $st=$db->prepare("SELECT p.*,u.name FROM werewolf_players p JOIN users u ON u.uid=p.uid WHERE p.game_id=? AND p.uid=?");
    $st->bind_param('ii',$game,$uid); $st->execute();
    $r=$st->get_result()->fetch_assoc(); $st->close(); return $r ?: null;
}
function ww_players(mysqli $db, int $game): array {
    $st=$db->prepare("SELECT p.*,u.name FROM werewolf_players p JOIN users u ON u.uid=p.uid WHERE p.game_id=? ORDER BY p.seat_no");
    $st->bind_param('i',$game); $st->execute(); $r=$st->get_result()->fetch_all(MYSQLI_ASSOC); $st->close(); return $r;
}
function ww_check_winner(mysqli $db, int $game): ?string {
    $st = $db->prepare("SELECT role,COUNT(*) c FROM werewolf_players WHERE game_id=? AND alive=1 GROUP BY role");
    $st->bind_param('i', $game);
    $st->execute();
    $r = $st->get_result();
    $w=0;$g=0;
    while($x=$r->fetch_assoc()){ if($x['role']==='狼人') $w+=(int)$x['c']; else $g+=(int)$x['c']; }
    $st->close();
    if($w===0) return '好人';
    if($w >= $g) return '狼人';
    return null;
}
function ww_finish(mysqli $db,int $game,string $winner,int $round,string $reason): void {
    $st=$db->prepare("UPDATE werewolf_games SET status='finished',phase='FINISHED',winner=?,discussion_seat_no=NULL WHERE id=?");
    $st->bind_param('si',$winner,$game);$st->execute();$st->close();
    ww_log($db,$game,$round,'FINISHED',"游戏结束：{$winner}阵营胜利。{$reason}");
}
function ww_current_speaker(mysqli $db,int $game): ?array {
    $g=ww_game($db,$game);
    if(!$g || $g['discussion_seat_no']===null) return null;
    $seat=(int)$g['discussion_seat_no'];
    $st=$db->prepare("SELECT p.*,u.name FROM werewolf_players p JOIN users u ON u.uid=p.uid WHERE p.game_id=? AND p.seat_no=? AND p.alive=1");
    $st->bind_param('ii',$game,$seat); $st->execute();
    $r=$st->get_result()->fetch_assoc(); $st->close();
    return $r ?: null;
}
function ww_start_day_discuss(mysqli $db,int $game,int $round): void {
    $ps=ww_players($db,$game);
    $first=null;
    foreach($ps as $p){
        if((int)$p['alive']===1){ $first=(int)$p['seat_no']; break; }
    }
    $db->query("UPDATE werewolf_players SET day_spoke=0 WHERE game_id={$game}");
    if($first===null){ ww_finish($db,$game,'狼人',$round,'没有存活玩家。'); return; }
    $st=$db->prepare("UPDATE werewolf_games SET phase='DAY_DISCUSS',discussion_seat_no=? WHERE id=?");
    $st->bind_param('ii',$first,$game); $st->execute(); $st->close();
    $speaker=ww_current_speaker($db,$game);
    $name=$speaker['name'] ?? '未知玩家';
    ww_log($db,$game,$round,'DAY',"天亮了。进入白天讨论，{$name}（{$first}号）先发言。每名存活玩家依次发言一次。");
}
function ww_advance_discussion(mysqli $db,int $game,int $round): void {
    $ps=ww_players($db,$game);
    $currentSeat=0;
    $g=ww_game($db,$game);
    if($g && $g['discussion_seat_no']!==null) $currentSeat=(int)$g['discussion_seat_no'];
    $next=null;
    foreach($ps as $p){
        if((int)$p['alive']!==1 || (int)$p['day_spoke']!==0) continue;
        if((int)$p['seat_no']>$currentSeat){ $next=$p; break; }
    }
    if($next===null){
        foreach($ps as $p){
            if((int)$p['alive']===1 && (int)$p['day_spoke']===0){ $next=$p; break; }
        }
    }
    if($next===null){
        $db->query("UPDATE werewolf_games SET phase='DAY_VOTE',discussion_seat_no=NULL WHERE id={$game}");
        ww_log($db,$game,$round,'DAY','所有存活玩家均已发言，进入放逐投票。');
        return;
    }
    $seat=(int)$next['seat_no'];
    $st=$db->prepare("UPDATE werewolf_games SET discussion_seat_no=? WHERE id=?");
    $st->bind_param('ii',$seat,$game); $st->execute(); $st->close();
    ww_log($db,$game,$round,'DAY',"请 {$next['name']}（{$seat}号）发言。");
}
function ww_alive_count(mysqli $db,int $game,string $role): int {
    $st=$db->prepare("SELECT COUNT(*) c FROM werewolf_players WHERE game_id=? AND role=? AND alive=1");
    $st->bind_param('is',$game,$role);$st->execute();$c=(int)$st->get_result()->fetch_assoc()['c'];$st->close();return $c;
}
function ww_apply_night(mysqli $db,int $game,int $round): void {
    $g = ww_game($db, $game);
    if (!$g) return;
    // 允许在 NIGHT_WOLF 或 NIGHT_WITCH 阶段执行（NIGHT_WOLF 用于女巫已出局的情况）
    if ($g['phase'] !== 'NIGHT_WOLF' && $g['phase'] !== 'NIGHT_WITCH') return;

    $rows = ww_players($db, $game);
    $wolfVotes = [];
    foreach ($rows as $p) {
        if ($p['role'] === '狼人' && $p['alive'] && $p['wolf_vote']) {
            $wolfVotes[] = (int)$p['wolf_vote'];
        }
    }
    // 计算狼袭目标（取票数最高的，平票则无人死）
    $victim = null;
    if ($wolfVotes) {
        $cnt = array_count_values($wolfVotes);
        arsort($cnt);
        $top = max($cnt);
        $tops = array_keys(array_filter($cnt, fn($v) => $v === $top));
        if (count($tops) === 1) $victim = (int)$tops[0];
    }

    // 女巫处理（仅在 NIGHT_WITCH 阶段且女巫存活时生效）
    $witch = null;
    foreach ($rows as $p) {
        if ($p['role'] === '女巫' && $p['alive']) { $witch = $p; break; }
    }
    $save = false;
    $poison = null;
    if ($witch && isset($witch['day_vote'])) {
        if ((int)$witch['day_vote'] === -1 && !$witch['witch_save_used'] && $victim) {
            $save = true;
        }
        if ((int)$witch['day_vote'] > 0 && !$witch['witch_poison_used']) {
            $poison = (int)$witch['day_vote'];
        }
    }

    // 执行解药
    if ($victim && $save) {
        $db->query("UPDATE werewolf_players SET witch_save_used=1 WHERE id=" . (int)$witch['id']);
        ww_log($db, $game, $round, 'NIGHT', "女巫使用解药，今晚无人因狼袭死亡。");
        $victim = null;
    } elseif ($victim) {
        $st = $db->prepare("UPDATE werewolf_players SET alive=0 WHERE game_id=? AND uid=?");
        $st->bind_param('ii', $game, $victim);
        $st->execute();
        $st->close();
        $name = $db->query("SELECT name FROM users WHERE uid={$victim}")->fetch_assoc()['name'] ?? '玩家';
        ww_log($db, $game, $round, 'NIGHT', "夜晚结束：{$name} 被狼人袭击出局。");
    } else {
        ww_log($db, $game, $round, 'NIGHT', "夜晚结束：没有玩家因狼人袭击出局。");
    }

    // 执行毒药
    if ($poison) {
        $chk = $db->query("SELECT role,alive,name FROM werewolf_players p JOIN users u ON u.uid=p.uid WHERE p.game_id={$game} AND p.uid={$poison}")->fetch_assoc();
        if ($chk && (int)$chk['alive'] === 1) {
            $db->query("UPDATE werewolf_players SET alive=0,witch_poison_used=1 WHERE game_id={$game} AND uid={$poison}");
            ww_log($db, $game, $round, 'NIGHT', "女巫使用毒药，{$chk['name']} 出局。");
        }
    }

    // 检查胜利条件
    $win = ww_check_winner($db, $game);
    if ($win) {
        ww_finish($db, $game, $win, $round, '夜晚结算后达到胜利条件。');
        return;
    }
    // 进入白天讨论
    ww_start_day_discuss($db, $game, $round);
}
function ww_start_game(mysqli $db,int $game): void {
    $g=ww_game($db,$game); if(!$g || $g['status']!=='waiting') throw new RuntimeException('游戏不能开始。');
    $ps=ww_players($db,$game);
    if(count($ps)!==$g['max_players']) throw new RuntimeException("还需要 ".($g['max_players']-count($ps))." 名玩家。");
    $roles=ww_roles((int)$g['max_players']); shuffle($roles);
    foreach($ps as $i=>$p){
        $st=$db->prepare("UPDATE werewolf_players SET role=?, alive=1, wolf_vote=NULL, day_vote=NULL, day_spoke=0, witch_save_used=0, witch_poison_used=0 WHERE id=?");
        $st->bind_param('si',$roles[$i],$p['id']);$st->execute();$st->close();
        ww_log($db,$game,0,'ROLE',"你的身份是：{$roles[$i]}。", (int)$p['uid']);
    }
    $db->query("UPDATE werewolf_games SET status='playing', phase='NIGHT_WOLF', round_no=1, discussion_seat_no=NULL WHERE id={$game}");
    ww_log($db,$game,1,'NIGHT','第一夜开始。狼人请行动。');
}
function ww_resolve_day(mysqli $db,int $game,int $round): void {
    $g = ww_game($db, $game);
    if(!$g || $g['phase'] !== 'DAY_VOTE') return;
    $ps=ww_players($db,$game);
    $votes=[];$valid=0;
    foreach($ps as $p) if($p['alive'] && $p['day_vote']!==null){$votes[]=(int)$p['day_vote'];$valid++;}
    if($valid===0)return;
    $cnt=array_count_values($votes); arsort($cnt); $top=max($cnt); $tops=array_keys(array_filter($cnt,fn($v)=>$v===$top));
    if(count($tops)>1){
        ww_log($db,$game,$round,'DAY',"投票平票，本轮无人出局。");
    } else {
        $target=(int)$tops[0];
        $row=$db->query("SELECT name FROM werewolf_players p JOIN users u ON u.uid=p.uid WHERE p.game_id={$game} AND p.uid={$target}")->fetch_assoc();
        $db->query("UPDATE werewolf_players SET alive=0 WHERE game_id={$game} AND uid={$target}");
        ww_log($db,$game,$round,'DAY',"投票结果：{$row['name']} 被放逐出局。");
    }
    $win=ww_check_winner($db,$game);
    if($win){ww_finish($db,$game,$win,$round,'白天放逐后达到胜利条件。');return;}
    $db->query("UPDATE werewolf_players SET wolf_vote=NULL,day_vote=NULL,day_spoke=0 WHERE game_id={$game}");
    $next=$round+1;
    $db->query("UPDATE werewolf_games SET phase='NIGHT_WOLF', round_no={$next}, discussion_seat_no=NULL WHERE id={$game}");
    ww_log($db,$game,$next,'NIGHT',"第 {$next} 夜开始。狼人请行动。");
}

// ====== POST 处理 ======
$message=''; $error='';
$gameId=(int)($_GET['id']??0);

try {
    if($_SERVER['REQUEST_METHOD']==='POST'){
        if(!ww_csrf_ok($_POST['csrf']??'')) throw new RuntimeException('CSRF 校验失败，请刷新页面。');
        $action=$_POST['action']??'';

        if($action==='create'){
            $n=(int)$_POST['max_players'];
            if(!in_array($n,range(6,12),true)) throw new RuntimeException('人数必须为 6～12 人。');
            $st=$conn->prepare("INSERT INTO werewolf_games(host_uid,max_players) VALUES(?,?)");
            $st->bind_param('ii',$uid,$n);$st->execute();$gameId=$st->insert_id;$st->close();
            $st=$conn->prepare("INSERT INTO werewolf_players(game_id,uid,seat_no) VALUES(?,?,1)");
            $st->bind_param('ii',$gameId,$uid);$st->execute();$st->close();
            header("Location: https://lmtoj.cn/werewolf/{$gameId}");exit;
        }
        if($action==='join'){
            $gameId=(int)$_POST['game_id'];$g=ww_game($conn,$gameId);
            if(!$g || $g['status']!=='waiting') throw new RuntimeException('该房间不存在或已经开始。');
            if(ww_player($conn,$gameId,$uid)) throw new RuntimeException('你已经在这个房间里。');
            $conn->begin_transaction();
            try {
                $lock=$conn->prepare("SELECT id,max_players,status FROM werewolf_games WHERE id=? FOR UPDATE");
                $lock->bind_param('i',$gameId);
                $lock->execute();
                $locked=$lock->get_result()->fetch_assoc();
                $lock->close();
                if(!$locked || $locked['status']!=='waiting') throw new RuntimeException('该房间不存在或已经开始。');

                $countRow=$conn->query("SELECT COUNT(*) c FROM werewolf_players WHERE game_id={$gameId}")->fetch_assoc();
                $count=(int)$countRow['c'];
                if($count >= (int)$locked['max_players']) throw new RuntimeException('房间已满。');

                $seat=0;
                for($candidate=1;$candidate<=(int)$locked['max_players'];$candidate++){
                    $check=$conn->query("SELECT 1 FROM werewolf_players WHERE game_id={$gameId} AND seat_no={$candidate} LIMIT 1");
                    if(!$check->num_rows){$seat=$candidate;break;}
                }
                if($seat===0) throw new RuntimeException('没有可用座位，请重新进入房间。');

                $st=$conn->prepare("INSERT INTO werewolf_players(game_id,uid,seat_no) VALUES(?,?,?)");
                $st->bind_param('iii',$gameId,$uid,$seat);
                if(!$st->execute()){
                    $err=$st->error;
                    $st->close();
                    throw new RuntimeException('加入房间失败：'.$err);
                }
                $st->close();
                $conn->commit();
            } catch(Throwable $joinEx) {
                $conn->rollback();
                throw $joinEx;
            }
            header("Location: https://lmtoj.cn/werewolf/{$gameId}");exit;
        }
        if($action==='start'){
            $gameId=(int)$_POST['game_id'];$g=ww_game($conn,$gameId);
            if(!$g || (int)$g['host_uid']!==$uid) throw new RuntimeException('只有房主可以开始游戏。');
            ww_start_game($conn,$gameId); header("Location: https://lmtoj.cn/werewolf/{$gameId}");exit;
        }
        if($action==='leave'){
            $gameId=(int)$_POST['game_id'];$g=ww_game($conn,$gameId);$p=ww_player($conn,$gameId,$uid);
            if(!$g||!$p||$g['status']!=='waiting') throw new RuntimeException('当前不能退出。');
            $conn->query("DELETE FROM werewolf_players WHERE game_id={$gameId} AND uid={$uid}");
            if((int)$g['host_uid']===$uid){
                $next=$conn->query("SELECT uid FROM werewolf_players WHERE game_id={$gameId} ORDER BY seat_no LIMIT 1")->fetch_assoc();
                if($next){$new=(int)$next['uid'];$conn->query("UPDATE werewolf_games SET host_uid={$new} WHERE id={$gameId}");}
                else {$conn->query("DELETE FROM werewolf_games WHERE id={$gameId}");}
            }
            header("Location: https://lmtoj.cn/werewolf");exit;
        }
        if($action==='wolf_vote'){
            $gameId=(int)$_POST['game_id'];$target=(int)$_POST['target'];$g=ww_game($conn,$gameId);$p=ww_player($conn,$gameId,$uid);
            if(!$g||$g['phase']!=='NIGHT_WOLF'||!$p||!$p['alive']||$p['role']!=='狼人') throw new RuntimeException('现在不是你的狼人行动阶段。');
            $t=ww_player($conn,$gameId,$target);
            if(!$t||!$t['alive']||$t['role']==='狼人') throw new RuntimeException('不能选择该目标。');
            $st=$conn->prepare("UPDATE werewolf_players SET wolf_vote=? WHERE id=?");$st->bind_param('ii',$target,$p['id']);$st->execute();$st->close();
            $need=ww_alive_count($conn,$gameId,'狼人');
            $done=(int)$conn->query("SELECT COUNT(*) c FROM werewolf_players WHERE game_id={$gameId} AND role='狼人' AND alive=1 AND wolf_vote IS NOT NULL")->fetch_assoc()['c'];
            if($done >= $need){
                $seerAlive = ww_alive_count($conn,$gameId,'预言家');
                if($seerAlive>0){
                    $conn->query("UPDATE werewolf_games SET phase='NIGHT_SEER' WHERE id={$gameId}");
                    ww_log($conn,$gameId,(int)$g['round_no'],'NIGHT','狼人行动结束，预言家请行动。');
                } else {
                    $witchAlive = ww_alive_count($conn,$gameId,'女巫');
                    if($witchAlive>0){
                        $conn->query("UPDATE werewolf_games SET phase='NIGHT_WITCH' WHERE id={$gameId}");
                        ww_log($conn,$gameId,(int)$g['round_no'],'NIGHT','预言家已出局，女巫请行动。');
                    } else {
                        ww_apply_night($conn,$gameId,(int)$g['round_no']);
                    }
                }
            }
        }
        if($action==='seer'){
            $gameId=(int)$_POST['game_id'];$target=(int)$_POST['target'];$g=ww_game($conn,$gameId);$p=ww_player($conn,$gameId,$uid);
            if(!$g||$g['phase']!=='NIGHT_SEER'||!$p||!$p['alive']||$p['role']!=='预言家') throw new RuntimeException('现在不是预言家行动阶段。');
            $t=ww_player($conn,$gameId,$target);
            if(!$t||!$t['alive']||$target===$uid) throw new RuntimeException('目标无效。');
            ww_log($conn,$gameId,(int)$g['round_no'],'ROLE',"查验结果：{$t['name']} 的身份是「{$t['role']}」。",$uid);
            $witchAlive = ww_alive_count($conn,$gameId,'女巫');
            if($witchAlive>0){
                $conn->query("UPDATE werewolf_games SET phase='NIGHT_WITCH' WHERE id={$gameId}");
                ww_log($conn,$gameId,(int)$g['round_no'],'NIGHT','预言家行动结束，女巫请行动。');
            } else {
                ww_apply_night($conn,$gameId,(int)$g['round_no']);
            }
        }
        if($action==='witch'){
            $gameId=(int)$_POST['game_id'];$choice=$_POST['choice']??'none';$target=(int)($_POST['target']??0);
            $g=ww_game($conn,$gameId);$p=ww_player($conn,$gameId,$uid);
            if(!$g||$g['phase']!=='NIGHT_WITCH'||!$p||!$p['alive']||$p['role']!=='女巫') throw new RuntimeException('现在不是女巫行动阶段。');
            $victim=null;$ps=ww_players($conn,$gameId);$votes=[];
            foreach($ps as $x) if($x['role']==='狼人'&&$x['alive']&&$x['wolf_vote'])$votes[]=(int)$x['wolf_vote'];
            if($votes){$c=array_count_values($votes);arsort($c);$top=max($c);$tops=array_keys(array_filter($c,fn($v)=>$v===$top));if(count($tops)===1)$victim=(int)$tops[0];}
            if($choice==='save'){
                if((int)$p['witch_save_used']) throw new RuntimeException('解药已经使用过。');
                if(!$victim) throw new RuntimeException('今晚没有明确的狼人袭击目标。');
                $val=-1;
            } elseif($choice==='poison'){
                if((int)$p['witch_poison_used']) throw new RuntimeException('毒药已经使用过。');
                $t=ww_player($conn,$gameId,$target);
                if(!$t||!$t['alive']||$target===$uid) throw new RuntimeException('毒药目标无效。');
                $val=$target;
            } else $val=0;
            $st=$conn->prepare("UPDATE werewolf_players SET day_vote=? WHERE id=?");$st->bind_param('ii',$val,$p['id']);$st->execute();$st->close();
            ww_apply_night($conn,$gameId,(int)$g['round_no']);
        }
        if($action==='wolf_chat'){
            $gameId=(int)$_POST['game_id'];
            $content=trim((string)($_POST['content']??''));
            $g=ww_game($conn,$gameId); $p=ww_player($conn,$gameId,$uid);
            if(!$g||$g['phase']!=='NIGHT_WOLF'||!$p||!$p['alive']||$p['role']!=='狼人') throw new RuntimeException('现在不能发送狼人消息。');
            if($content==='') throw new RuntimeException('消息不能为空。');
            if(mb_strlen($content)>500) throw new RuntimeException('消息最多 500 字。');
            $st=$conn->prepare("INSERT INTO werewolf_wolf_chat(game_id,uid,content) VALUES(?,?,?)");
            $st->bind_param('iis',$gameId,$uid,$content);
            $st->execute();
            $st->close();
        }
        if($action==='speak'){
            $gameId=(int)$_POST['game_id'];
            $g=ww_game($conn,$gameId); $p=ww_player($conn,$gameId,$uid);
            $content=trim((string)($_POST['content']??''));
            if(!$g||$g['phase']!=='DAY_DISCUSS'||!$p||!$p['alive']) throw new RuntimeException('现在不是你的白天发言阶段。');
            $speaker=ww_current_speaker($conn,$gameId);
            if(!$speaker || (int)$speaker['uid']!==$uid) throw new RuntimeException('现在轮到 '.$speaker['name'].' 发言。');
            if((int)$p['day_spoke']===1) throw new RuntimeException('你本轮已经发言过了。');
            if($content==='') throw new RuntimeException('发言不能为空。');
            if(mb_strlen($content)>500) throw new RuntimeException('单次发言最多 500 字。');
            $st=$conn->prepare("INSERT INTO werewolf_chat(game_id,uid,content) VALUES(?,?,?)");
            $st->bind_param('iis',$gameId,$uid,$content);$st->execute();$st->close();
            $conn->query("UPDATE werewolf_players SET day_spoke=1 WHERE game_id={$gameId} AND uid={$uid}");
            ww_log($conn,$gameId,(int)$g['round_no'],'DAY',"{$p['name']}（{$p['seat_no']}号）完成发言。");
            ww_advance_discussion($conn,$gameId,(int)$g['round_no']);
        }
        if($action==='day_vote'){
            $gameId=(int)$_POST['game_id'];$target=(int)$_POST['target'];$g=ww_game($conn,$gameId);$p=ww_player($conn,$gameId,$uid);
            if(!$g||$g['phase']!=='DAY_VOTE'||!$p||!$p['alive']) throw new RuntimeException('你现在不能投票。');
            if($p['day_vote'] !== null) throw new RuntimeException('你已经投过票，不能重复投票。');
            $t=ww_player($conn,$gameId,$target);
            if(!$t||!$t['alive']||$target===$uid) throw new RuntimeException('目标无效。');
            $st=$conn->prepare("UPDATE werewolf_players SET day_vote=? WHERE id=?");$st->bind_param('ii',$target,$p['id']);$st->execute();$st->close();
            $alive=(int)$conn->query("SELECT COUNT(*) c FROM werewolf_players WHERE game_id={$gameId} AND alive=1")->fetch_assoc()['c'];
            $done=(int)$conn->query("SELECT COUNT(*) c FROM werewolf_players WHERE game_id={$gameId} AND alive=1 AND day_vote IS NOT NULL")->fetch_assoc()['c'];
            if($done >= $alive) ww_resolve_day($conn,$gameId,(int)$g['round_no']);
        }
    }
} catch(Throwable $e){$error=$e->getMessage();}

if($gameId>0){
    $game=ww_game($conn,$gameId);
    if(!$game){$error=$error?:'房间不存在。';$gameId=0;}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>狼人杀 - lmtOJ</title>
<style>
body{font-family:"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;background:#f9f7f4;color:#2c2a28;margin:0}
.wrap{max-width:1000px;margin:28px auto;padding:0 18px}.box{background:#fff;border:1px solid #e6e1da;border-radius:10px;padding:22px;margin-bottom:16px}
h1,h2{margin-top:0}.muted{color:#7a736b}.error{background:#fce4ec;color:#b71c1c;padding:10px;border-radius:7px;margin-bottom:12px}
.notice{background:#eef5ef;padding:10px;border-radius:7px;margin-bottom:12px}.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}
button,.btn{background:#6b8a74;color:white;border:0;border-radius:6px;padding:8px 13px;text-decoration:none;cursor:pointer;font:inherit}
button.secondary,.btn.secondary{background:#77706a}.danger{background:#b94a48}.players{line-height:1.9}.dead{text-decoration:line-through;color:#999}.role{font-weight:700}
input,select{padding:8px;border:1px solid #ddd;border-radius:6px;font:inherit}.log{padding:7px 0;border-bottom:1px solid #eee}.small{font-size:13px}.phase{font-size:18px;font-weight:700}
table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:8px;border-bottom:1px solid #eee}
</style>
</head>
<body>
<?php include __DIR__.'/navbar.php'; ?>
<div class="wrap">
<?php if($error): ?><div class="error"><?=h($error)?></div><?php endif; ?>

<?php if(!$gameId): ?>
<div class="box">
<h1>狼人杀</h1>
<p class="muted">纯文字多人狼人杀。6～12 人一局，身份由服务器随机分配。</p>
<form method="post" class="row">
<input type="hidden" name="csrf" value="<?=h($csrf)?>">
<input type="hidden" name="action" value="create">
<label>人数
<select name="max_players"><?php for($i=6;$i<=12;$i++): ?><option value="<?=$i?>"><?=$i?> 人</option><?php endfor;?></select>
</label>
<button>创建房间</button>
</form>
</div>
<div class="box">
<h2>进行中的房间</h2>
<?php
$list=$conn->query("SELECT g.*,u.name host_name,(SELECT COUNT(*) FROM werewolf_players p WHERE p.game_id=g.id) player_count FROM werewolf_games g JOIN users u ON u.uid=g.host_uid WHERE g.status='waiting' ORDER BY g.id DESC LIMIT 30");
if(!$list||$list->num_rows===0): ?><p class="muted">暂无等待中的房间，创建一个吧。</p><?php else: ?>
<table><tr><th>房间</th><th>房主</th><th>人数</th><th>操作</th></tr>
<?php while($r=$list->fetch_assoc()): ?><tr>
<td>#<?=$r['id']?></td><td><?=h($r['host_name'])?></td><td><?=$r['player_count']?> / <?=$r['max_players']?></td>
<td><form method="post"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="join"><input type="hidden" name="game_id" value="<?=$r['id']?>"><button>加入</button></form></td>
</tr><?php endwhile; ?></table>
<?php endif; ?>
</div>
<?php else: ?>
<?php $me=ww_player($conn,$gameId,$uid);$ps=ww_players($conn,$gameId); ?>
<?php if(!$me): ?><div class="box"><h2>你不在这个房间</h2><form method="post"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="join"><input type="hidden" name="game_id" value="<?=$gameId?>"><button>加入房间</button></form></div>
<?php else: ?>
<div class="box">
<h1>狼人杀 · 房间 #<?=$gameId?></h1>
<p>房主：<?=h($ps[0]['name']??'')?>　|　人数：<?=count($ps)?> / <?=$game['max_players']?>　|　状态：<?=h($game['status'])?></p>
<?php if($game['status']==='playing'): ?><p class="phase">当前阶段：<?=h($game['phase'])?>　·　第 <?=h((string)$game['round_no'])?> 轮</p><?php endif; ?>
<?php if($game['status']==='finished'): ?><div class="notice">游戏结束：<b><?=h($game['winner'])?>阵营胜利</b></div><?php endif; ?>
</div>

<div class="box">
<h2>我的身份</h2>
<?php if($game['status']==='waiting'): ?><p class="muted">游戏开始后才会显示身份。</p>
<?php else: ?><p class="role"><?=h($me['role'])?></p><?php if($me['role']==='狼人'): ?><p class="muted">你的狼队友：
<?php foreach($ps as $x): if($x['role']==='狼人'): ?><?=h($x['name'])?><?=((int)$x['alive']?'':'（已出局）')?>　<?php endif; endforeach; ?></p><?php endif; ?>
<?php endif; ?>
</div>

<div class="box">
<h2>玩家</h2><div class="players">
<?php foreach($ps as $p): ?>
<div class="<?=((int)$p['alive']?'':'dead')?>">
    [<?=$p['seat_no']?>号] <?=h($p['name'])?> <?=((int)$p['uid']===$uid?'（你）':'')?> <?=((int)$p['alive']?'':'（出局）')?>
    <?php if($game['status']==='playing' && $game['phase']==='DAY_DISCUSS' && (int)$p['alive']): ?>
        <?=((int)$p['day_spoke']===1 ? ' ✅已发言' : ' ⏳未发言')?>
    <?php endif; ?>
</div>
<?php endforeach; ?></div>
</div>

<?php if($game['status']==='waiting'): ?>
<div class="box">
<h2>等待开始</h2>
<p>需要 <?=$game['max_players']?> 人，目前 <?=count($ps)?> 人。</p>
<div class="row">
<?php if((int)$game['host_uid']===$uid && count($ps)==$game['max_players']): ?><form method="post"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="start"><input type="hidden" name="game_id" value="<?=$gameId?>"><button>开始游戏</button></form><?php endif; ?>
<form method="post"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="leave"><input type="hidden" name="game_id" value="<?=$gameId?>"><button class="secondary">退出房间</button></form>
</div>
</div>
<?php else: ?>
<div class="box">
<h2>行动</h2>
<?php if($game['phase']==='NIGHT_WOLF' && $me['role']==='狼人' && $me['alive']): ?>
<p>选择今晚要袭击的玩家。所有狼人都提交后进入下一阶段。</p>
<form method="post" class="row"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="wolf_vote"><input type="hidden" name="game_id" value="<?=$gameId?>">
<select name="target"><?php foreach($ps as $p): if($p['alive']&&$p['role']!=='狼人'): ?><option value="<?=$p['uid']?>"><?=h($p['name'])?>（<?=$p['seat_no']?>号）</option><?php endif; endforeach; ?></select><button>提交袭击目标</button></form>

<hr style="margin:16px 0">
<h3>🐺 狼人夜间讨论</h3>
<div style="max-height:200px; overflow-y:auto; border:1px solid #eee; padding:8px; border-radius:6px; background:#fcfcfc;">
    <?php
    $st = $conn->prepare("SELECT c.*, u.name FROM werewolf_wolf_chat c JOIN users u ON u.uid=c.uid WHERE c.game_id=? ORDER BY c.id DESC LIMIT 30");
    $st->bind_param('i', $gameId);
    $st->execute();
    $msgs = $st->get_result();
    while ($msg = $msgs->fetch_assoc()): ?>
        <div style="margin-bottom:4px; font-size:14px;">
            <span style="color:#666;"><?=h($msg['name'])?> · <?=h($msg['created_at'])?></span><br>
            <?=h($msg['content'])?>
        </div>
    <?php endwhile; $st->close(); ?>
</div>
<?php if ($me['alive']): ?>
    <form method="post" style="margin-top:8px; display:flex; gap:8px;">
        <input type="hidden" name="csrf" value="<?=h($csrf)?>">
        <input type="hidden" name="action" value="wolf_chat">
        <input type="hidden" name="game_id" value="<?=$gameId?>">
        <input name="content" maxlength="500" style="flex:1; min-width:200px;" placeholder="输入狼人讨论内容……">
        <button>发送</button>
    </form>
<?php else: ?>
    <p class="muted" style="margin:8px 0 0;">（已出局，仅可查看）</p>
<?php endif; ?>

<?php elseif($game['phase']==='NIGHT_SEER' && $me['role']==='预言家' && $me['alive']): ?>
<p>选择一名其他存活玩家查验身份，结果只有你能看到。</p>
<form method="post" class="row"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="seer"><input type="hidden" name="game_id" value="<?=$gameId?>">
<select name="target"><?php foreach($ps as $p): if($p['alive']&&$p['uid']!=$uid): ?><option value="<?=$p['uid']?>"><?=h($p['name'])?>（<?=$p['seat_no']?>号）</option><?php endif; endforeach; ?></select><button>查验</button></form>
<?php elseif($game['phase']==='NIGHT_WITCH' && $me['role']==='女巫' && $me['alive']): ?>
<p>狼人今晚的袭击目标由系统显示在这里。你有一次解药和一次毒药。</p>
<?php
$votes=[];foreach($ps as $x)if($x['role']==='狼人'&&$x['alive']&&$x['wolf_vote'])$votes[]=(int)$x['wolf_vote'];
$victim=null;if($votes){$c=array_count_values($votes);arsort($c);$top=max($c);$tops=array_keys(array_filter($c,fn($v)=>$v===$top));if(count($tops)===1)$victim=(int)$tops[0];}
?>
<p>今晚袭击：<?= $victim ? h((ww_player($conn,$gameId,$victim)['name']??'未知')) : '无明确目标（平票）' ?></p>
<form method="post"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="witch"><input type="hidden" name="game_id" value="<?=$gameId?>">
<?php if(!$me['witch_save_used']&&$victim): ?><button name="choice" value="save">使用解药</button><?php endif; ?>
<?php if(!$me['witch_poison_used']): ?><select name="target"><?php foreach($ps as $p): if($p['alive']&&$p['uid']!=$uid): ?><option value="<?=$p['uid']?>"><?=h($p['name'])?></option><?php endif; endforeach; ?></select><button name="choice" value="poison">使用毒药</button><?php endif; ?>
<button class="secondary" name="choice" value="none">什么都不做</button>
</form>
<?php elseif($game['phase']==='DAY_DISCUSS'): ?>
<?php $speaker=ww_current_speaker($conn,$gameId); ?>
<?php if($speaker): ?>
<p><strong>当前轮到：<?=$speaker['seat_no']?>号 <?=h($speaker['name'])?></strong></p>
<?php if((int)$speaker['uid']===$uid && $me['alive'] && !(int)$me['day_spoke']): ?>
<form method="post" class="row"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="speak"><input type="hidden" name="game_id" value="<?=$gameId?>"><input name="content" maxlength="500" style="flex:1;min-width:240px" placeholder="现在轮到你发言……" autofocus><button>发言</button></form>
<?php else: ?><p class="muted">请等待当前玩家发言。每名存活玩家本轮只能发言一次。</p><?php endif; ?>
<?php else: ?>
<p class="muted">发言阶段准备中，请稍候…</p>
<?php endif; ?>
<?php elseif($game['phase']==='DAY_VOTE' && $me['alive']): ?>
<p>选择一名其他存活玩家进行放逐投票。所有存活玩家投票后自动结算。</p>
<form method="post" class="row"><input type="hidden" name="csrf" value="<?=h($csrf)?>"><input type="hidden" name="action" value="day_vote"><input type="hidden" name="game_id" value="<?=$gameId?>">
<select name="target"><?php foreach($ps as $p): if($p['alive']&&$p['uid']!=$uid): ?><option value="<?=$p['uid']?>"><?=h($p['name'])?>（<?=$p['seat_no']?>号）</option><?php endif; endforeach; ?></select><button>投票</button></form>
<?php elseif(!$me['alive']): ?><p class="muted">你已经出局，只能观战。</p>
<?php else: ?><p class="muted">当前不是你的行动阶段，请等待其他玩家。</p><?php endif; ?>
</div>

<div class="box">
<h2>文字发言记录</h2>
<?php
$st=$conn->prepare("SELECT c.*,u.name FROM werewolf_chat c JOIN users u ON u.uid=c.uid WHERE c.game_id=? ORDER BY c.id DESC LIMIT 50");
$st->bind_param('i',$gameId);$st->execute();$chats=$st->get_result();
while($c=$chats->fetch_assoc()): ?>
<div class="log"><span class="muted small"><?=h($c['name'])?> · <?=h($c['created_at'])?></span>　<?=h($c['content'])?></div>
<?php endwhile; $st->close(); ?>
</div>

<div class="box">
<h2>游戏记录</h2>
<?php
$st=$conn->prepare("SELECT * FROM werewolf_logs WHERE game_id=? AND (visible_uid IS NULL OR visible_uid=?) ORDER BY id DESC LIMIT 50");
$st->bind_param('ii',$gameId,$uid);$st->execute();$logs=$st->get_result();
while($l=$logs->fetch_assoc()): ?><div class="log"><span class="muted small">第 <?=$l['round_no']?> 轮 · <?=h($l['phase'])?></span>　<?=h($l['content'])?></div><?php endwhile; $st->close();
?>
</div>
<?php endif; endif; ?>
</div>
<script>
setTimeout(function(){ if(document.visibilityState==='visible') location.reload(); }, 7000);
</script>
<?php endif; ?>
</body></html>