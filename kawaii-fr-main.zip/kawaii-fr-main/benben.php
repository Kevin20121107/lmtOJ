<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== 数据库连接 ==========
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 确保必要字段存在（表结构检查） ==========
$checkVal = $conn->query("SHOW COLUMNS FROM users LIKE 'valuation'");
if ($checkVal->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN valuation INT DEFAULT 0");
}
$checkFields = ['practice_score', 'contribute_score', 'contest_score'];
foreach ($checkFields as $field) {
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$field'");
    if ($check->num_rows == 0) {
        $conn->query("ALTER TABLE users ADD COLUMN $field INT DEFAULT 0");
    }
}
$checkCertType = $conn->query("SHOW COLUMNS FROM users LIKE 'cert_type'");
if ($checkCertType->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN cert_type VARCHAR(20) DEFAULT ''");
}
$checkCertLevel = $conn->query("SHOW COLUMNS FROM users LIKE 'cert_level'");
if ($checkCertLevel->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN cert_level INT DEFAULT 0");
}
$checkColor = $conn->query("SHOW COLUMNS FROM users LIKE 'username_color'");
if ($checkColor->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN username_color VARCHAR(20) DEFAULT 'auto'");
}
$checkShow = $conn->query("SHOW COLUMNS FROM users LIKE 'show_colorful_names'");
if ($checkShow->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN show_colorful_names TINYINT DEFAULT 1");
}
$checkBase = $conn->query("SHOW COLUMNS FROM users LIKE 'base_credit'");
if ($checkBase->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN base_credit INT DEFAULT 10");
}

// ========== 添加 violation_count 字段（如果不存在） ==========
$checkViolation = $conn->query("SHOW COLUMNS FROM users LIKE 'violation_count'");
if ($checkViolation->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN violation_count INT DEFAULT 0");
}

// 创建违规记录表
$conn->query("CREATE TABLE IF NOT EXISTS violation_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    original_text TEXT,
    reason VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 创建 Linda @ 记录表
$conn->query("CREATE TABLE IF NOT EXISTS linda_at_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    at_time DATETIME NOT NULL,
    INDEX(uid, at_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== 添加 is_active 字段（如果不存在） ==========
$checkIsActive = $conn->query("SHOW COLUMNS FROM user_avatar_frame LIKE 'is_active'");
if ($checkIsActive->num_rows == 0) {
    $conn->query("ALTER TABLE user_avatar_frame ADD COLUMN is_active TINYINT DEFAULT 0");
}
// 删除过期头像框
$conn->query("DELETE FROM user_avatar_frame WHERE expire_time < NOW()");
// 关闭当前连接，重新连接，清除MySQL查询快照缓存
$conn->close();
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 获取当前登录用户信息（增加 banned 字段） ==========
$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin, jinyan, avatar, practice_score, contribute_score, contest_score, banned, violation_count FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = $userRow['admin'] ?? 0;
$is_jinyan = $userRow['jinyan'] ?? 0;
$login_name = $userRow['name'] ?? '';
$user_violation_count = (int)($userRow['violation_count'] ?? 0);

$myShowColorful = 1;
$showPrefRes = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($showPrefRes && $showPrefRes->num_rows > 0) {
    $myShowColorful = (int)($showPrefRes->fetch_assoc()['show_colorful_names']);
}

// ========== DeepSeek API 配置 ==========
define('DEEPSEEK_API_KEY', 'sk-3265f370731146b0a0aef28b99109264');
define('DEEPSEEK_API_URL', 'https://api.deepseek.com/v1/chat/completions');
define('DEEPSEEK_MODEL', 'deepseek-v4-flash');
define('LINDA_UID', 144);

/**
 * 调用 DeepSeek API 通用函数
 */
function callDeepSeek($messages, $jsonMode = false) {

    $payload = [
        'model' => DEEPSEEK_MODEL,
        'messages' => $messages,
        'temperature' => 0.7,
        'max_tokens' => 1024
    ];
    if ($jsonMode) {
        $payload['response_format'] = ['type' => 'json_object'];
    }

    $ch = curl_init(DEEPSEEK_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . DEEPSEEK_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode !== 200) {
        error_log("DeepSeek API error: HTTP $httpCode, response: $response");
        return null;
    }
    $data = json_decode($response, true);
    if (!isset($data['choices'][0]['message']['content'])) {
        error_log("DeepSeek API invalid response: " . json_encode($data));
        return null;
    }
    return $data['choices'][0]['message']['content'];
}

/**
 * 违规检测：返回 ['violation' => bool, 'reason' => string]
 */
function checkViolation($text) {
    $system = "你是内容安全审核员。判断用户输入的文本是否包含违规内容。违规类型包括：涉政、色情、暴力、侮辱、人身攻击、谐音辱骂（例如'草饲'应理解为'操死'）。如果违规，返回JSON格式：{\"violation\":true,\"reason\":\"违规类型\"}；如果不违规，返回{\"violation\":false,\"reason\":\"\"}。只返回JSON，不要其他内容。";
    $messages = [
        ['role' => 'system', 'content' => $system],
        ['role' => 'user', 'content' => $text]
    ];
    $result = callDeepSeek($messages, true);
    if ($result === null) {
        return ['violation' => false, 'reason' => ''];
    }
    $json = json_decode($result, true);
    if (is_array($json) && isset($json['violation'])) {
        return [
            'violation' => (bool)$json['violation'],
            'reason' => $json['reason'] ?? ''
        ];
    }
    if (strpos($result, '"violation":true') !== false) {
        return ['violation' => true, 'reason' => '检测到违规内容'];
    }
    return ['violation' => false, 'reason' => ''];
}

/**
 * 生成 Linda 的灌水回复（带上下文，使用 QQ 表情和网络用语）
 */
function generateLindaReply($originalText, $originalAuthor, $contextTexts) {
    $system = "你是犇犇社区的机器人 Linda。性格活泼，喜欢灌水。请根据用户的最新犇犇和最近的社区上下文，生成一条简短的回复（不超过100字），风格轻松有趣。你可以使用 QQ 表情代码来表达情绪，例如 /fn 、/se、/kel 等。你还需要理解以下网络用语：qwq、QwQ、qaq、QAQ、awa、AWA 等表示卖萌；sto、orz 表示膜拜；%%% 表示膜拜。请适当使用这些表情和用语，让回复更生动。回复要自然，不要提及你是AI。";
    $userContent = "最新犇犇（由 {$originalAuthor} 发布）：{$originalText}\n\n最近上下文（可能为空）：\n" . implode("\n", $contextTexts);
    $messages = [
        ['role' => 'system', 'content' => $system],
        ['role' => 'user', 'content' => $userContent]
    ];
    $reply = callDeepSeek($messages, false);
    if ($reply === null || trim($reply) === '') {
        $reply = '（小猫娘FR 正在发呆...）';
    }
    return trim($reply);
}

/**
 * 处理 Linda 自动回复的完整流程（异步或同步调用）
 */
function processLindaReply($uid, $authorName, $originalText, $conn) {
    global $is_admin;
    // 检查当日 @Linda 次数
    $today_start = date('Y-m-d 00:00:00');
    $today_end = date('Y-m-d 23:59:59');
    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM linda_at_log WHERE uid = ? AND at_time >= ? AND at_time <= ?");
    $stmt->bind_param("iss", $uid, $today_start, $today_end);
    $stmt->execute();
    $cntLinda = $stmt->get_result()->fetch_assoc()['cnt'];
    $stmt->close();

    if (!$is_admin && $cntLinda >= 20) {
        return; // 超过每日限制，不回复
    }

    // 获取最近 5 条犇犇作为上下文
    $contextTexts = [];
    $contextRes = $conn->query("SELECT b.text, u.name FROM benben b LEFT JOIN users u ON b.uid=u.uid ORDER BY b.time DESC, b.id DESC LIMIT 5");
    while ($ctx = $contextRes->fetch_assoc()) {
        $contextTexts[] = "{$ctx['name']}: {$ctx['text']}";
    }

    // 调用 AI 生成回复
    $aiReply = generateLindaReply($originalText, $authorName, $contextTexts);

    // 构造回复文本：生成内容 || @原作者 : 原内容
    $replyText = $aiReply . ' || @' . $authorName . ' : ' . $originalText;

    // 插入 Linda 的回复犇犇
    $maxIdReply = $conn->query("SELECT MAX(id) AS mid FROM benben")->fetch_assoc()['mid'] ?? 0;
    $newReplyId = $maxIdReply + 1;
    $replyTime = date('Y-m-d H:i:s');
    $replyEscape = $conn->real_escape_string($replyText);
    $conn->query("INSERT INTO benben (id, uid, text, time) VALUES ($newReplyId, " . LINDA_UID . ", '$replyEscape', '$replyTime')");

    // 记录 @Linda 日志
    $logStmt = $conn->prepare("INSERT INTO linda_at_log (uid, at_time) VALUES (?, ?)");
    $logStmt->bind_param("is", $uid, $replyTime);
    $logStmt->execute();
    $logStmt->close();

    // 给原作者发送被 @ 通知
    $noticeStmt = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, create_time, is_read) VALUES (?, ?, 0, '', ?, 0)");
    $atid = LINDA_UID;
    $noticeStmt->bind_param("iis", $uid, $atid, $replyTime);
    $noticeStmt->execute();
    $noticeStmt->close();
}

// ========== 处理登出 ==========
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$filter = $_GET['filter'] ?? 'following';
$getfilter = isset($_GET['filter']) ? '/' . $_GET['filter'] : '';

// ========== 处理发布（包含风控 + AI 审核 + @Linda 异步回复） ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_benben'])) {
    if ($is_jinyan === 1) {
        echo '<script>alert("您已被禁言，无法发布内容");history.go(-1);</script>';
        exit;
    }
    if ($userRow['banned'] == 1) {
        echo '<script>alert("您的账号已被封禁，无法发布");history.go(-1);</script>';
        exit;
    }

    // ---- 风控检查：1分钟30条 / 1小时500条 ----
    $now = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM benben WHERE uid = ? AND time >= DATE_SUB(?, INTERVAL 1 MINUTE)");
    $stmt->bind_param("is", $login_uid, $now);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $cntMinute = $row['cnt'];
    $stmt->close();

    if ($cntMinute >= 6) {
        $conn->query("UPDATE users SET jinyan = 1 WHERE uid = $login_uid");
        $reason = '犇犇刷屏，触发风控（十四天）。';
        $operator = 460;
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'set_jinyan', ?, ?)");
        $logStmt->bind_param("isi", $login_uid, $reason, $operator);
        $logStmt->execute();
        $logStmt->close();
        echo '<script>alert("您因刷屏已被禁言。");history.go(-1);</script>';
        exit;
    }

    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM benben WHERE uid = ? AND time >= DATE_SUB(?, INTERVAL 1 HOUR)");
    $stmt->bind_param("is", $login_uid, $now);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $cntHour = $row['cnt'];
    $stmt->close();

    if ($cntHour >= 200) {
        $conn->query("UPDATE users SET banned = 1 WHERE uid = $login_uid");
        $reason = '犇犇刷屏，触发风控';
        $operator = 460;
        $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'ban_user', ?, ?)");
        $logStmt->bind_param("isi", $login_uid, $reason, $operator);
        $logStmt->execute();
        $logStmt->close();
        echo '<script>alert("您因刷屏已被封禁");history.go(-1);</script>';
        exit;
    }

    $text_original = trim($_POST['text']);
    if (empty($text_original)) {
        echo '<script>alert("内容不能为空");history.go(-1);</script>';
        exit;
    }

    if (!$is_admin) {
        $text_original = mb_substr($text_original, 0, 150);
    }

    // ========== AI 违规审核（管理员跳过） ==========
    $is_violation = false;
    $violation_reason = '';
    $text_final = $text_original;

    /*if (!$is_admin) {
        $violationResult = checkViolation($text_original);
        $is_violation = $violationResult['violation'];
        $violation_reason = $violationResult['reason'];

        if ($is_violation) {
            $logStmt = $conn->prepare("INSERT INTO violation_log (uid, original_text, reason) VALUES (?, ?, ?)");
            $logStmt->bind_param("iss", $login_uid, $text_original, $violation_reason);
            $logStmt->execute();
            $logStmt->close();

            $newViolationCount = $user_violation_count + 1;
            $updateStmt = $conn->prepare("UPDATE users SET violation_count = ? WHERE uid = ?");
            $updateStmt->bind_param("ii", $newViolationCount, $login_uid);
            $updateStmt->execute();
            $updateStmt->close();

            if ($newViolationCount <= 3) {
                $text_final = '[违规内容]';
            } else {
                $conn->query("UPDATE users SET jinyan = 1 WHERE uid = $login_uid");
                $reason = '违规次数超过三次，自动禁言';
                $logStmt = $conn->prepare("INSERT INTO ostracism_log (target_uid, action, reason, operator_uid) VALUES (?, 'auto_jinyan', ?, ?)");
                $operator = LINDA_UID;
                $logStmt->bind_param("isi", $login_uid, $reason, $operator);
                $logStmt->execute();
                $logStmt->close();
                $text_final = '[违规内容]';
            }
        }
    }*/
    // 管理员直接使用原始文本，不进行审核

    // 插入犇犇
    preg_match_all('/@([\w_\x{4e00}-\x{9fa5}]+)/u', $text_final, $atMatches);
    $atNames = array_unique($atMatches[1]);
    $maxId = $conn->query("SELECT MAX(id) AS mid FROM benben")->fetch_assoc()['mid'] ?? 0;
    $newBenId = $maxId + 1;
    $textEscape = $conn->real_escape_string($text_final);
    $conn->query("INSERT INTO benben (id, uid, text, time) VALUES ($newBenId, $login_uid, '$textEscape', '$now')");

    // 处理原犇犇的@通知
    foreach ($atNames as $atName) {
        $atNameEscape = $conn->real_escape_string($atName);
        $targetUser = $conn->query("SELECT uid FROM users WHERE name = '$atNameEscape' LIMIT 1")->fetch_assoc();
        if ($targetUser && $targetUser['uid'] != $login_uid) {
            $targetUid = (int)$targetUser['uid'];
            $conn->query("INSERT INTO notice (uid, atid, tid, topic_title, create_time, is_read) 
                          VALUES ($targetUid, $login_uid, 0, '', '$now', 0)");
        }
    }

    // ========== @Linda 自动回复（异步处理） ==========
    $should_reply_linda = (0 && !$is_violation && (preg_match('/@Linda\b/u', $text_original)));

    // 先发送重定向，让浏览器立即跳转
    header("Location: https://lmtoj.cn/benben{$getfilter}");

    if ($should_reply_linda && function_exists('fastcgi_finish_request')) {
        // 支持异步：发送响应后继续执行后台逻辑
        fastcgi_finish_request();
        processLindaReply($login_uid, $login_name, $text_original, $conn);
    } else {
        // 不支持异步或无需回复：直接正常结束
        if ($should_reply_linda) {
            processLindaReply($login_uid, $login_name, $text_original, $conn);
        }
    }
    exit;
}

// ========== 处理删除 ==========
if (isset($_GET['del_id'])) {
    $del_id = (int)$_GET['del_id'];
    $row = $conn->query("SELECT uid FROM benben WHERE id = $del_id LIMIT 1")->fetch_assoc();
    if ($is_admin || $row['uid'] == $login_uid) {
        $conn->query("DELETE FROM benben WHERE id = $del_id");
    }
    header("Location: https://lmtoj.cn/benben{$getfilter}");
    exit;
}

// ========== 未读消息数 ==========
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

// ========== 分页与过滤 ==========
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

if (!in_array($filter, ['all', 'following'])) $filter = 'all';
if ($filter === 'following' && $login_uid <= 0) {
    $filter = 'all';
}

$selectFields = "b.id, b.uid, b.text, b.time, 
                 u.name, u.admin, u.tag, u.avatar, 
                 u.practice_score, u.contribute_score, u.contest_score,
                 u.cert_type, u.cert_level,
                 u.username_color,
                 u.valuation,
                 u.base_credit,
                 af.frame_img";

$joinFollow = "";
$whereFollow = "";
if ($filter === 'following' && $login_uid > 0) {
    $whereFollow = " AND (b.uid = {$login_uid} OR b.uid IN (SELECT following_uid FROM follow WHERE follower_uid = {$login_uid})) ";
}

$totalSql = "SELECT COUNT(*) AS cnt FROM benben b {$joinFollow} WHERE 1=1 {$whereFollow}";
$totalRes = $conn->query($totalSql);
$total = $totalRes->fetch_assoc()['cnt'];
$totalPage = ceil($total / $limit);

$benList = $conn->query("
    SELECT {$selectFields}
    FROM benben b 
    {$joinFollow}
    LEFT JOIN users u ON b.uid = u.uid 
    LEFT JOIN user_avatar_frame af ON b.uid = af.uid 
        AND af.expire_time > NOW() 
        AND af.id = COALESCE(
            (SELECT id FROM user_avatar_frame WHERE uid = b.uid AND expire_time > NOW() AND is_active = 1 LIMIT 1),
            (SELECT id FROM user_avatar_frame WHERE uid = b.uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1)
        )
    WHERE 1=1 {$whereFollow}
    ORDER BY b.time DESC, b.id DESC
    LIMIT $offset, $limit
");

$allUserRes = $conn->query("SELECT uid, name FROM users");
$nameToUid = [];
while ($u = $allUserRes->fetch_assoc()) {
    $nameToUid[$u['name']] = $u['uid'];
}

function safeContent($content) {
    return htmlspecialchars($content ?? '', ENT_QUOTES, 'UTF-8');
}
function containsEnglish($text) {
    $text = preg_replace('/@[\w_\x{4e00}-\x{9fa5}]+/u', '', $text);
    $text = preg_replace('/```[\s\S]*?```/', '', $text);
    $text = preg_replace('/`[^`]+`/', '', $text);
    $text = preg_replace('/\$[^$]+\$/', '', $text);
    $text = preg_replace('/\$\$[\s\S]*?\$\$/', '', $text);
    $text = preg_replace('/!?\[[^\]]*\]\([^)]+\)/', '', $text);
    return preg_match('/[a-zA-Z]{3,}/', $text);
}
function getFirstChar($name) {
    $name = trim($name ?? '?');
    return mb_strlen($name) > 0 ? mb_strtoupper(mb_substr($name, 0, 1)) : '?';
}
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}
function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>犇犇 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card h2{font-size:18px;font-weight:600;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;}
        .filter-btns {display:flex;gap:0;}
        .filter-btn {
            padding:8px 16px;
            border:1.5px solid var(--border);
            background:var(--card-bg);
            color:var(--text);
            font-size:14px;
            font-weight:500;
            cursor:pointer;
            transition:var(--transition);
            text-decoration:none;
        }
        .filter-btn:first-child { border-radius:20px 0 0 20px; }
        .filter-btn:last-child { border-radius:0 20px 20px 0; }
        .filter-btn.active { background:var(--accent); color:#fff; border-color:var(--accent); }
        .filter-btn:hover:not(.active) { background:var(--accent-light); border-color:var(--accent); color:var(--accent); }
        .ben-input{width:100%;height:100px;padding:13px 16px;border:1.5px solid var(--border);border-radius:var(--radius-sm);margin-bottom:12px;font-size:14px;resize:none;outline:none;font-family:var(--font);background:#fdfdfc;transition:var(--transition);}
        .ben-input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        .btn{padding:9px 20px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);}
        .btn:hover{background:var(--accent-hover);}
        .tip{color:var(--danger);margin:10px 0;font-size:14px;}
        .ben-item{display:flex;gap:14px;padding:15px 0;border-bottom:1px solid var(--border-light);align-items:flex-start;}
        .ben-item:last-child{border-bottom:none;}
        .ben-avatar {
            width: 48px;
            height: 48px;
            position: relative;
            flex-shrink: 0;
        }
        .ben-avatar .avatar-frame {
            width: 58px;
            height: 58px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            object-fit: contain;
            pointer-events: none;
            z-index: 2;
        }
        .ben-avatar .avatar-mask {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            overflow: hidden;
            z-index: 0;
        }
        .ben-avatar .avatar-mask img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .ben-avatar .avatar-mask .avatar-text {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            font-weight: 700;
            color: #fff;
            background: var(--accent);
        }
        .ben-body{flex:1;min-width:0;}
        .ben-name { font-weight:600; text-decoration:none; font-size:14px; color: #ffffff; }
        .ben-name.colorful {
            color: #f1948a;
            animation: colorful 3s linear infinite;
            text-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        @keyframes colorful {
            0% { color: #f1948a; }
            17% { color: #f5b041; }
            33% { color: #f7dc6f; }
            50% { color: #82e0aa; }
            67% { color: #85c1e9; }
            83% { color: #bb8fce; }
            100% { color: #f1948a; }
        }
        .tag { border-radius:3px; padding:2px 9px; color:#fff; display:inline-block; margin:2px 5px; font-size:11.5px; font-weight:600; }
        .tag.colorful-bg { animation: colorfulBg 3s linear infinite; }
        @keyframes colorfulBg {
            0% { background-color: #f1948a; }
            17% { background-color: #f5b041; }
            33% { background-color: #f7dc6f; }
            50% { background-color: #82e0aa; }
            67% { background-color: #85c1e9; }
            83% { background-color: #bb8fce; }
            100% { background-color: #f1948a; }
        }
        .ben-time{font-size:12px;color:var(--text-muted);margin-left:8px;}
        .ben-op{font-size:12px;color:var(--accent);margin-left:10px;cursor:pointer;text-decoration:none;font-weight:500;}
        .ben-op:hover{color:var(--accent-hover);}
        .ben-del{color:var(--danger)!important;}
        .ben-content{word-break:break-word;margin-top:7px;line-height:1.7;font-size:14px;color:#3a3733;}
        .page-box{margin-top:20px;padding-top:14px;border-top:1px solid var(--border-light);display:flex;gap:6px;flex-wrap:wrap;}
        .page-box a {
    padding: 6px 13px;
    border: 1.5px solid var(--border);
    border-radius: 6px;          /* 圆角改为6px，方形圆角 */
    text-decoration: none;
    color: var(--text);
    font-size: 13.5px;
    font-weight: 500;
    background: #fff;
    transition: var(--transition);
}
        .page-box a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
        .page-box a.active-page{background:var(--accent);color:#fff;border-color:var(--accent);font-weight:600;}
        .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
        .ben-content blockquote{border-left:4px solid var(--accent);padding:8px 14px;margin:8px 0;background:#fafaf8;color:#5a5550;border-radius:0 4px 4px 0;}
        .ben-content pre{background:#2b2a27;color:#e8e4dd;padding:14px 16px;border-radius:var(--radius-sm);overflow-x:auto;margin:8px 0;font-family:var(--font-mono);font-size:13px;}
        .ben-content code{font-family:var(--font-mono);background:#f3f0eb;padding:2px 6px;border-radius:3px;}
        .ben-content pre code{background:transparent;padding:0;color:inherit;}
        .translate-btn{font-size:12px;color:var(--accent);cursor:pointer;margin-left:10px;}
        .translation-box{margin-top:8px;padding:8px 12px;background:#f3f7f3;border-left:3px solid var(--accent);border-radius:4px;font-size:13px;color:#4a4a4a;display:none;}
        a{color:var(--accent);text-decoration:none;font-weight:500;}
        .at-link{color:var(--accent)!important;}
        .brown-tag { background: #8b6b4d; color: #fff; border-radius: 4px; padding: 1px 8px; font-size: 11px; font-weight: 600; margin-left: 6px; display: inline-block; }
        @media(max-width:768px){.main{flex-direction:column;padding:0 12px;}.sidebar{width:100%;position:static;display:flex;}.sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}.card{padding:18px 14px;}}
        .ben-content img { max-width: 100%; height: auto; border-radius: 4px; margin: 6px 0; }
    </style>
    <link rel="stylesheet" href="/css/benben-theme.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <script>
    const benbenMarkdownRenderer = MarkdownRenderer.create({
        markdownOptions: {html: false, linkify: false, typographer: false, breaks: false},
        katexOptions: {macros: {"\\RR": "\\mathbb{R}"}}
    });
    function inject_md(id,content){
        const element = document.getElementById(id);
        if (element && content !== null) benbenMarkdownRenderer.renderTo(element, content);
    }
    </script>
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <h2>
                犇犇
                <div class="filter-btns">
                    <a href="https://lmtoj.cn/benben" class="filter-btn <?= $filter === 'following' ? 'active' : '' ?>">仅关注</a>
                    <a href="https://lmtoj.cn/benben/all" class="filter-btn <?= $filter === 'all' ? 'active' : '' ?>">全网犇</a>
                </div>
            </h2>
            <?php if($is_jinyan==1):?>
                <p class="tip">您当前已被禁言，无法发布内容</p>
            <?php else:?>
                <form method="post" id="postForm">
                    <textarea name="text" class="ben-input" id="benText" placeholder="支持 Markdown、公式 $...$、代码块 ```、图片 ![](url)、链接 [文字](url)、@用户" required></textarea>
                    <button type="submit" name="post_benben" class="btn" id="submitBtn">发布</button>
                </form>
            <?php endif;?>
            <div style="margin-top:20px;">
                <?php $count=0; while($b=$benList->fetch_assoc()): 
                    $benAvatar = $b['avatar'] ?? '';
                    $userFrame = $b['frame_img'] ?? '';

                    $achievement = min(getAchievementScore($b['cert_type'] ?? '', (int)($b['cert_level'] ?? 0)), 20);
                    $practice = min((int)($b['practice_score'] ?? 0), 20);
                    $contribute = min((int)($b['contribute_score'] ?? 0), 30);
                    $contest = min((int)($b['contest_score'] ?? 0), 20);
                    $base = (int)($b['base_credit'] ?? 10);
                    
                    $valuation = (int)($b['valuation'] ?? 0);
                    $isBrown = ($valuation === -1);
                    $totalScore = $isBrown ? -1 : $base + $achievement + $practice + $contribute + $contest;
                    
                    $targetColorful = ($b['username_color'] ?? 'auto') === 'beautiful' && ($achievement >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
                    $isColorful = ($b['uid'] == $login_uid) ? $targetColorful : ($targetColorful && $myShowColorful);
                    $color = getColorByTotalScore($totalScore, $b['admin'] ?? 0);
                ?>
                <div class="ben-item">
                    <div class="ben-avatar">
                        <div class="avatar-mask">
                            <?php if($benAvatar):?>
                                <img src="<?=safeContent($benAvatar)?>" alt="avatar">
                            <?php else:?>
                                <div class="avatar-text"><?=getFirstChar($b['name'])?></div>
                            <?php endif;?>
                        </div>
                        <?php if (!empty($userFrame)): ?>
                            <img class="avatar-frame" src="<?=safeContent($userFrame)?>" alt="头像框">
                        <?php endif; ?>
                    </div>
                    <div class="ben-body">
                        <div>
                            <a href="https://lmtoj.cn/user/<?=$b['uid']?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" <?= $isColorful ? '' : 'style="color: ' . $color . ';"' ?>>
                                <?=safeContent($b['name'])?>
                            </a>
                            <?php if($b['tag']):?>
                                <span class="tag<?= $isColorful ? ' colorful-bg' : '' ?>" <?= $isColorful ? '' : 'style="background: ' . $color . ';"' ?>>
                                    <?=safeContent($b['tag'])?>
                                </span>
                            <?php endif;?>
                            <?php 
                            $certType = strtoupper(trim($b['cert_type'] ?? ''));
                            $certLevel = (int)($b['cert_level'] ?? 0);
                            $certColor = '#66d313';
                            if ($certLevel >= 6) $certColor = '#41bcf5';
                            if ($certLevel >= 8) $certColor = '#f5e341';
                            if ($certLevel < 3) $certColor = 'rgba(139, 107, 55, 1)';
                            $certHTML = '<svg class="svg-inline--fa fa-badge-check" data-prefix="fad" data-icon="badge-check" role="img" viewBox="0 0 512 512" style="--fa-secondary-opacity: 1; height: 16px; width: 16px; transform: translate(0px, 4px);">
                                        	<g class="fa-duotone-group">
                                        		<path style="color: ' . $certColor . '" fill="currentColor" d="M0 256C0 292.8 20.7 324.8 51.1 340.9 41 373.8 49 411 75 437s63.3 34 96.1 23.9C187.2 491.3 219.2 512 256 512s68.8-20.7 84.9-51.1C373.8 471 411 463 437 437s34-63.3 23.9-96.1C491.3 324.8 512 292.8 512 256s-20.7-68.8-51.1-84.9C471 138.2 463 101 437 75s-63.3-34-96.1-23.9C324.8 20.7 292.8 0 256 0s-68.8 20.7-84.9 51.1C138.2 41 101 49 75 75s-34 63.3-23.9 96.1C20.7 187.2 0 219.2 0 256zm152.3 41.6c-9.2-9.5-9-24.7 .6-33.9 9.5-9.2 24.7-8.9 33.9 .6l35.8 37 106.1-145.8c7.8-10.7 22.8-13.1 33.5-5.3 10.7 7.8 13.1 22.8 5.3 33.5L244.7 352.7c-4.2 5.7-10.7 9.4-17.8 9.8-7.1 .5-14-2.2-18.9-7.3l-55.7-57.6z"></path>
                                        		<path style="color: #fff;" fill="currentColor" d="M328.7 155.5c7.8-10.7 22.8-13.1 33.5-5.3 10.7 7.8 13.1 22.8 5.3 33.5L244.7 352.7c-4.2 5.7-10.7 9.4-17.8 9.8-7.1 .5-14-2.2-18.9-7.3l-55.7-57.6c-9.2-9.5-9-24.7 .6-33.9 9.5-9.2 24.7-8.9 33.9 .6l35.8 37 106.1-145.8z"></path>
                                        	</g>
                                        </svg>';
                            if (!empty($certType) && $certLevel > 0): 
                            ?>
                            <?= $certHTML ?>
                            <?php endif; ?>
                            <span class="ben-time"><?=safeContent($b['time'])?></span>
                            <span class="ben-op" onclick="reply(<?=htmlspecialchars(json_encode($b['name'], JSON_UNESCAPED_UNICODE), ENT_QUOTES)?>,<?=htmlspecialchars(json_encode($b['text'], JSON_UNESCAPED_UNICODE), ENT_QUOTES)?>)">回复</span>
                            <?php if($is_admin||$b['uid']==$login_uid):?><a href="?del_id=<?=$b['id']?>" class="ben-op ben-del" onclick="return confirm('确定删除？')">删除</a><?php endif;?>
                        </div>
                        <div class="ben-content" id="ben-content-<?=$count?>" data-raw="<?=htmlspecialchars($b['text'],ENT_QUOTES)?>"></div>
                        <script>inject_md('ben-content-<?=$count?>',<?=json_encode($b['text'],JSON_UNESCAPED_UNICODE)?>);</script>
                    </div>
                </div>
                <?php $count++; endwhile;?>
            </div>
            <div class="page-box">
    <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>">上一页</a>
    <?php endif; ?>

    <?php
    // 总页数大于1才显示分页
    if ($totalPage > 1):
        // 显示第一页
        echo '<a href="?page=1" class="' . ($page == 1 ? 'active-page' : '') . '">1</a>';

        // 如果当前页距离第一页较远，显示省略号
        if ($page - 5 > 2) {
            echo '<span class="page-ellipsis">…</span>';
        }

        // 显示当前页前后各5页（但不重复第一页和最后一页）
        $start = max(2, $page - 5);
        $end   = min($totalPage - 1, $page + 5);
        for ($i = $start; $i <= $end; $i++) {
            if ($i == 1 || $i == $totalPage) continue; // 跳过已显示的第一页和最后一页
            echo '<a href="?page=' . $i . '" class="' . ($i == $page ? 'active-page' : '') . '">' . $i . '</a>';
        }

        // 如果当前页距离最后一页较远，显示省略号
        if ($page + 5 < $totalPage - 1) {
            echo '<span class="page-ellipsis">…</span>';
        }

        // 显示最后一页（当总页数大于1时）
        if ($totalPage > 1) {
            echo '<a href="?page=' . $totalPage . '" class="' . ($page == $totalPage ? 'active-page' : '') . '">' . $totalPage . '</a>';
        }
    endif;
    ?>
    <!-- 无“下一页”链接 -->
</div>
        </div>
    </div>
</div>
<script>
var nameToUid=<?=json_encode($nameToUid,JSON_UNESCAPED_UNICODE|JSON_HEX_TAG)?>;
function renderContent(){document.querySelectorAll('.ben-content').forEach(function(el){var raw=el.innerHTML||'';if(!raw)return;raw=raw.replace(/@([\w_\u4e00-\u9fa5]+)/g,function(m,user){if(nameToUid[user])return'<a class="at-link" href="https://lmtoj.cn/user/'+nameToUid[user]+'">'+m+'</a>';return m;});el.innerHTML=raw;});}
function init(){renderContent();setTimeout(renderContent,200);}
window.addEventListener('DOMContentLoaded',init);
window.addEventListener('load',renderContent);

// ===== 修改后的 reply 函数：光标定位到输入框开头 =====
function reply(name,content){
    var ta=document.querySelector('.ben-input');
    if(!ta) return;
    ta.value = ' || @'+name+' : '+content.replace(/[\r\n]/g,' ')+'\n';
    ta.focus();
    // 将光标移动到文本起始位置（第0个字符）
    ta.setSelectionRange(0, 0);
}

async function toggleTranslation(index){
    var btn=document.getElementById('translate-btn-'+index);
    var box=document.getElementById('translation-box-'+index);
    var raw=document.getElementById('ben-content-'+index)?.getAttribute('data-raw');
    if(!raw||!btn||!box)return;
    if(box.style.display==='block'){box.style.display='none';btn.textContent='翻译';return;}
    btn.textContent='翻译中...';
    try{var fd=new FormData();fd.append('text',raw);var resp=await fetch('https://lmtoj.cn/translate.php',{method:'POST',body:fd});var data=await resp.json();if(data.translation){benbenMarkdownRenderer.renderTo(box,data.translation);box.style.display='block';btn.textContent='收起翻译';}else{box.innerHTML='<p>翻译失败</p>';box.style.display='block';btn.textContent='重试';}}catch(e){box.innerHTML='<p>请求失败</p>';box.style.display='block';btn.textContent='重试';}
}
(function(){
    var f=document.getElementById('postForm'),b=document.getElementById('submitBtn');
    if(f&&b){
        f.addEventListener('submit',function(){
            setTimeout(function(){b.disabled=true;b.innerText='发布中...';},10);
            setTimeout(function(){b.disabled=false;b.innerText='发布';},1000);
        });
    }
})();
</script>
<?php require_once __DIR__ . '/event_effect.php'; ?>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>