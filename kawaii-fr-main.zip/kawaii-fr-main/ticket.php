<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    if (strtoupper($certType) !== 'OI') return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getFirstChar($name) {
    $name = trim($name ?? '?');
    return mb_strlen($name) > 0 ? mb_strtoupper(mb_substr($name, 0, 1)) : '?';
}
define('BOT_UID', 464);
$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'star'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN star INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'sixin'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN sixin TINYINT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'cert_type'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN cert_type VARCHAR(20) DEFAULT ''");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'cert_level'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN cert_level INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'contribute_score'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN contribute_score INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'practice_score'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN practice_score INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'contest_score'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN contest_score INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'base_credit'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN base_credit INT DEFAULT 10");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'valuation'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN valuation INT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'username_color'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN username_color VARCHAR(20) DEFAULT 'auto'");
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'show_colorful_names'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE users ADD COLUMN show_colorful_names TINYINT DEFAULT 1");
$conn->query("CREATE TABLE IF NOT EXISTS ostracism_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    target_uid INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    reason TEXT,
    operator_uid INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'assignee_uid'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE discuss ADD COLUMN assignee_uid INT DEFAULT 0 AFTER work_type");
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'parent_tid'");
if ($colCheck && $colCheck->num_rows == 0) $conn->query("ALTER TABLE discuss ADD COLUMN parent_tid INT DEFAULT 0 AFTER assignee_uid");
$usersList = [];
$nameToUid = [];
$uidToUser = [];
$stmt = $conn->prepare("SELECT uid, name, admin, tag, jinyan, sixin,
                               practice_score, contribute_score, contest_score,
                               base_credit, valuation, username_color,
                               cert_type, cert_level, avatar
                        FROM users ORDER BY name ASC");
$stmt->execute();
$uRes = $stmt->get_result();
while ($u = $uRes->fetch_assoc()) {
    $usersList[] = $u;
    $nameToUid[$u['name']] = $u['uid'];
    $uidToUser[$u['uid']] = $u;
}
$stmt->close();
function getUserDisplay($user, $login_uid, $myShowColorful) {
    $uid = (int)($user['uid'] ?? 0);
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    $admin = (int)($user['admin'] ?? 0);
    $color = getColorByTotalScore($total, $admin);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    $isColorful = ($uid == $login_uid) ? $targetColorful : ($targetColorful && $myShowColorful);
    return [
        'color'      => $color,
        'isColorful' => $isColorful,
        'tag'        => $user['tag'] ?? '',
        'admin'      => $admin
    ];
}
$tid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$filter_status = isset($_GET['ws']) ? (int)$_GET['ws'] : 0;
$filter_type = isset($_GET['wt']) ? (int)$_GET['wt'] : 0;
$search = $_GET['search'] ?? '';
$search_assignee = isset($_GET['search_assignee']) ? (int)$_GET['search_assignee'] : 0;
$search_creator = isset($_GET['search_creator']) ? (int)$_GET['search_creator'] : 0;
$is_admin = 0;
$userJinyan = 0;
$myShowColorful = 1;
$unreadCount = 0;
$errorMsg = '';
$where = " WHERE d.category=3 ";
$types = '';
$params = [];
$statusConfig = [
    1 => ['name' => '待处理', 'color' => '#1e40af', 'bg' => '#dbeafe'],
    2 => ['name' => '挂起',   'color' => '#b8860b', 'bg' => '#fef9e7'],
    3 => ['name' => '已完成', 'color' => '#5a8a6a', 'bg' => '#e8f5e9'],
    4 => ['name' => '已关闭', 'color' => '#909399', 'bg' => '#f4f4f5'],
    5 => ['name' => '处理中', 'color' => '#2c7a7a', 'bg' => '#e6fffa']
];
$workTypeArr = [
    1 => ['name' => '权限变更/举报/申诉', 'template' => "【权限变更申请】\n\n\n原因说明（自禁留空）：\n\n期望变更方式与权限："],
    2 => ['name' => '建议/Bug反馈', 'template' => "【建议/Bug反馈】\n问题/建议描述：\n\n复现步骤(如为建议请忽略)："],
    3 => ['name' => '一般咨询', 'template' => "【一般咨询】\n咨询问题："],
    4 => ['name' => '题目相关', 'template' => "【题目相关】\n题目ID：\n\n问题描述："],
    5 => ['name' => '申请全站推荐', 'template' => ""],
    7 => ['name' => '撤销全站推荐', 'template' => "撤销对象：\n\n原因："],
    6 => ['name' => '奖项认证', 'template' => "认证类型：\n认证等级：\n\n"],
    8 => ['name' => '更新工单', 'template' => "【更新内容】\n\n"]
];
$permActions = ['grant' => '授予', 'revoke' => '撤销'];
$permTypes = ['jinyan' => '自由发言', 'sixin' => '发送私信', 'sqadmin' => '社区管理', 'artadmin' => '文章管理', 'proadmin' => '题目管理', 'conadmin' => '比赛管理', 'devadmin' => '后台管理'];

if ($login_uid > 0) {
    $stmt = $conn->prepare("SELECT admin, jinyan, show_colorful_names FROM users WHERE uid = ? LIMIT 1");
    $stmt->bind_param("i", $login_uid);
    $stmt->execute();
    $adminRes = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($adminRes) {
        $is_admin = (int)$adminRes['admin'];
        $userJinyan = (int)$adminRes['jinyan'];
        $myShowColorful = (int)($adminRes['show_colorful_names'] ?? 1);
    }
    $msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
    $msgStmt->bind_param("i", $login_uid);
    $msgStmt->execute();
    $msgRes = $msgStmt->get_result();
    if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
    $msgStmt->close();
}
if (!$is_admin) {
    $where .= " AND (d.work_type != 1 OR d.uid = ?)";
    $params[] = $login_uid;
    $types .= "i";
}

$csrf_token = generateCsrfToken();
if (isset($_POST['set_ws']) && isset($_POST['wtid'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $wtid = (int)$_POST['wtid'];
    $ws = (int)$_POST['set_ws'];
    if ($ws >= 1 && $ws <= 5) {
        $stmt = $conn->prepare("SELECT uid, title, work_type, content FROM discuss WHERE id = ?");
        $stmt->bind_param("i", $wtid);
        $stmt->execute();
        $topicInfo = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$topicInfo) { header("Location: https://lmtoj.cn/ticket/{$wtid}"); exit; }
        $isCreator = ($topicInfo['uid'] == $login_uid);
        if (!$is_admin && !$isCreator) { header("Location: https://lmtoj.cn/ticket/{$wtid}"); exit; }
        if (!$is_admin && $ws !== 4) { header("Location: https://lmtoj.cn/ticket/{$wtid}"); exit; }
        $upd = $conn->prepare("UPDATE discuss SET work_status = ? WHERE id = ?");
        $upd->bind_param("ii", $ws, $wtid);
        $upd->execute();
        $upd->close();
        $nowTime = date('Y-m-d H:i:s');
        $autoContent = "将工单状态设为{$statusConfig[$ws]['name']}。";
        $replyUid=($is_admin? $login_uid: 2);
        $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, 1)");
        $ins->bind_param("iiss", $wtid, $replyUid, $autoContent, $nowTime);
        $ins->execute();
        $ins->close();
        if ($ws == 3 || $ws == 4) {
            $title = $topicInfo['title'];
            $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'done', ?, 0)");
            $nIns->bind_param("iiiss", $topicInfo['uid'], $login_uid, $wtid, $title, $nowTime);
            $nIns->execute();
            $nIns->close();
        }
        if ($ws == 3 && in_array($topicInfo['work_type'], [2, 5])) {
            $updStar = $conn->prepare("UPDATE users SET star = LEAST(star + 1, 2147483647) WHERE uid = ?");
            $updStar->bind_param("i", $topicInfo['uid']);
            $updStar->execute();
            $updStar->close();
        }
        if ($ws == 3) {
            $uid = $topicInfo['uid'];
            $addScore = 0;
            if ($topicInfo['work_type'] == 5) $addScore = 2;
            elseif ($topicInfo['work_type'] == 2) $addScore = 1;
            if ($addScore > 0) {
                $updSc = $conn->prepare("UPDATE users SET contribute_score = LEAST(30, contribute_score + ?) WHERE uid = ?");
                $updSc->bind_param("ii", $addScore, $uid);
                $updSc->execute();
                $updSc->close();
                $sel = $conn->prepare("SELECT contribute_score FROM users WHERE uid = ?");
                $sel->bind_param("i", $uid);
                $sel->execute();
                $cur = $sel->get_result()->fetch_assoc();
                $sel->close();
                $newScore = $cur['contribute_score'] ?? 0;
                $confirmMsg = "已增加 {$addScore} 贡献分（当前共 {$newScore} 分）。";
                $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
                $ins->bind_param("iissi", $wtid, $login_uid, $confirmMsg, $nowTime, $is_admin);
                $ins->execute();
                $ins->close();
            }
            if ($topicInfo['work_type'] == 4) {
                $addScore = 2;
                $updSc = $conn->prepare("UPDATE users SET contribute_score = LEAST(30, contribute_score + ?) WHERE uid = ?");
                $updSc->bind_param("ii", $addScore, $uid);
                $updSc->execute();
                $updSc->close();
                $sel = $conn->prepare("SELECT contribute_score FROM users WHERE uid = ?");
                $sel->bind_param("i", $uid);
                $sel->execute();
                $cur = $sel->get_result()->fetch_assoc();
                $sel->close();
                $newScore = $cur['contribute_score'] ?? 0;
                $confirmMsg = "已增加 2 贡献分（当前共 {$newScore} 分）。";
                $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
                $ins->bind_param("iissi", $wtid, $login_uid, $confirmMsg, $nowTime, $is_admin);
                $ins->execute();
                $ins->close();
            }
        }
        if ($ws == 3 && $topicInfo['work_type'] == 6) {
            $content = $topicInfo['content'];
            $certType = ''; $certLevel = 0;
            if (preg_match('/认证类型：([^\n]+)/', $content, $m1)) $certType = trim($m1[1]);
            if (preg_match('/认证等级：(\d+)/', $content, $m2)) $certLevel = (int)$m2[1];
            if ($certType && $certLevel > 0 && strtoupper($certType) === 'OI' && $certLevel >= 3 && $certLevel <= 10) {
                $updCert = $conn->prepare("UPDATE users SET cert_type = ?, cert_level = ? WHERE uid = ?");
                $updCert->bind_param("sii", $certType, $certLevel, $topicInfo['uid']);
                $updCert->execute();
                $updCert->close();
                $confirmMsg = "已自动更新用户认证：{$certType} 等级 {$certLevel}。";
                $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
                $ins->bind_param("iissi", $wtid, $login_uid, $confirmMsg, $nowTime, $is_admin);
                $ins->execute();
                $ins->close();
            }
        }
        if ($ws == 3 && $topicInfo['work_type'] == 7) {
            $content = $topicInfo['content'];
            if (preg_match('/撤销对象：@([\w_\x{4e00}-\x{9fa5}]+)/u', $content, $m)) {
                $targetName = $m[1];
                $targetUid = $nameToUid[$targetName] ?? 0;
                if ($targetUid > 0) {
                    $updSc = $conn->prepare("UPDATE users SET contribute_score = GREATEST(0, contribute_score - 2) WHERE uid = ?");
                    $updSc->bind_param("i", $targetUid);
                    $updSc->execute();
                    $updSc->close();
                    $sel = $conn->prepare("SELECT contribute_score FROM users WHERE uid = ?");
                    $sel->bind_param("i", $targetUid);
                    $sel->execute();
                    $cur = $sel->get_result()->fetch_assoc();
                    $sel->close();
                    $newScore = $cur['contribute_score'] ?? 0;
                    $confirmMsg = "已减少 2 贡献分（当前共 {$newScore} 分）。";
                    $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
                    $ins->bind_param("iissi", $wtid, $login_uid, $confirmMsg, $nowTime, $is_admin);
                    $ins->execute();
                    $ins->close();
                }
            }
        }
    }
    header("Location: https://lmtoj.cn/ticket/{$wtid}"); exit;
}

if ($is_admin && isset($_POST['assign_uid']) && $tid > 0) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $assignUid = (int)$_POST['assign_uid'];
    $upd = $conn->prepare("UPDATE discuss SET assignee_uid = ? WHERE id = ?");
    $upd->bind_param("ii", $assignUid, $tid);
    $upd->execute();
    $upd->close();
    $nowTime = date('Y-m-d H:i:s');
    if ($assignUid > 0) {
        $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
        $s->bind_param("i", $assignUid);
        $s->execute();
        $assignName = $s->get_result()->fetch_assoc()['name'] ?? '未知用户';
        $s->close();
        $autoContent = "将工单指派给 {$assignName}。";
    } else {
        $autoContent = "取消了工单指派。";
    }
    $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
    $ins->bind_param("iissi", $tid, $login_uid, $autoContent, $nowTime, $is_admin);
    $ins->execute();
    $ins->close();
    if ($assignUid > 0) {
        $s2 = $conn->prepare("SELECT title FROM discuss WHERE id = ?");
        $s2->bind_param("i", $tid);
        $s2->execute();
        $title = $s2->get_result()->fetch_assoc()['title'] ?? '';
        $s2->close();
        $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'assign', ?, 0)");
        $nIns->bind_param("iiiss", $assignUid, $login_uid, $tid, $title, $nowTime);
        $nIns->execute();
        $nIns->close();
    }
    header("Location: https://lmtoj.cn/ticket/{$tid}"); exit;
}
if ($is_admin && isset($_POST['del_tid'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $dtid = (int)$_POST['del_tid'];
    $d1 = $conn->prepare("DELETE FROM discuss WHERE id = ?");
    $d1->bind_param("i", $dtid);
    $d1->execute();
    $d1->close();
    $d2 = $conn->prepare("DELETE FROM discuss_reply WHERE tid = ?");
    $d2->bind_param("i", $dtid);
    $d2->execute();
    $d2->close();
    header("Location: https://lmtoj.cn/ticket"); exit;
}
if (isset($_POST['del_rid'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $drid = (int)$_POST['del_rid'];
    $s = $conn->prepare("SELECT uid FROM discuss_reply WHERE id = ? LIMIT 1");
    $s->bind_param("i", $drid);
    $s->execute();
    $row = $s->get_result()->fetch_assoc();
    $s->close();
    if ($is_admin || ($row && $row['uid'] == $login_uid)) {
        $d = $conn->prepare("DELETE FROM discuss_reply WHERE id = ?");
        $d->bind_param("i", $drid);
        $d->execute();
        $d->close();
    }
    header("Location: https://lmtoj.cn/ticket/{$tid}"); exit;
}
if (isset($_POST['edit_tid'], $_POST['edit_title'], $_POST['edit_content'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $etid = (int)$_POST['edit_tid'];
    $etitle = trim($_POST['edit_title']);
    $econtent = trim($_POST['edit_content']);
    $s = $conn->prepare("SELECT uid FROM discuss WHERE id = ? LIMIT 1");
    $s->bind_param("i", $etid);
    $s->execute();
    $row = $s->get_result()->fetch_assoc();
    $s->close();
    if (($is_admin || ($row && $row['uid'] == $login_uid)) && !empty($etitle) && !empty($econtent)) {
        $upd = $conn->prepare("UPDATE discuss SET title = ?, content = ? WHERE id = ?");
        $upd->bind_param("ssi", $etitle, $econtent, $etid);
        $upd->execute();
        $upd->close();
    }
    header("Location: https://lmtoj.cn/ticket/{$etid}"); exit;
}
if ($tid > 0 && $is_admin && isset($_POST['quick_reply']) && isset($_POST['quick_type'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $quickType = (int)$_POST['quick_type'];
    $quickContents = [
        1 => '该工单无意义，请不要再次提交类似工单，否则创建者可能被禁言。请保管好自己的账号，如发生机房惨案号主全责。',
        2 => '标题不清晰的工单可能被关单。',
        3 => '已有类似工单被创建，该工单无意义，请不要提交类似工单，否则创建者可能会被禁言。',
        4 => '管理员认为该建议有价值，可能在新版本采纳，感谢。',
        5 => '该问题不属于此板块。',
        6 => '相关问题不认为是 bug，是设计如此。请不要再次提交类似工单，否则创建者可能会被禁言。',
        7 => '请提供清晰的复现步骤或完整地描述问题。',
        8 => '管理员认为工单所说的是完全没有道理，或不需要考虑的问题。请不要再次提交类似工单，否则创建者可能会被禁言。',
        9 => '在上一次申请推荐时已经增加了估值，故关闭本工单，文章正常全站推荐。'
    ];
    if (isset($quickContents[$quickType])) {
        $content = $quickContents[$quickType];
        $nowTime = date('Y-m-d H:i:s');
        $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
        $ins->bind_param("iissi", $tid, $login_uid, $content, $nowTime, $is_admin);
        $ins->execute();
        $ins->close();
        header("Location: https://lmtoj.cn/ticket/{$tid}"); exit;
    }
}
if ($tid === 0 && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_title'], $_POST['new_content'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $freqCheck = checkTicketFrequency($login_uid, $conn);
    if ($freqCheck === 'banned') {
        header("Location: https://lmtoj.cn/ticket?error=frequent_ban");
        exit;
    }
    $wtype = isset($_POST['work_type']) ? (int)$_POST['work_type'] : 1;
    if ($wtype == 8 && !$is_admin) {
        header("Location: https://lmtoj.cn/ticket?error=permission_denied");
        exit;
    }
    $title = trim($_POST['new_title']);
    $content = trim($_POST['new_content']);
    if ($wtype == 5) {
        $section = trim($_POST['recommend_section'] ?? '');
        $link = trim($_POST['recommend_link'] ?? '');
        if (empty($section) || empty($link)) { header("Location: https://lmtoj.cn/ticket?error=recommend_missing"); exit; }
        $title = "申请全站推荐";
        $content = "板块：{$section}\n链接：{$link}\n\n" . $content;
    }
    if ($wtype == 1 && isset($_POST['target_uid']) && (int)$_POST['target_uid'] > 0) {
        $targetUid = (int)$_POST['target_uid'];
        $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
        $s->bind_param("i", $targetUid);
        $s->execute();
        $targetName = $s->get_result()->fetch_assoc()['name'] ?? '';
        $s->close();
        if ($targetName) {
            $permAction = $_POST['perm_action'] ?? 'grant';
            $actionLabel = $permActions[$permAction] ?? '授予';
            $permTypesSelected = isset($_POST['perm_types']) ? $_POST['perm_types'] : [];
            if (empty($permTypesSelected)) { header("Location: https://lmtoj.cn/ticket?error=no_perm_selected"); exit; }
            $typeLabels = [];
            foreach ($permTypesSelected as $pt) {
                $typeLabels[] = $permTypes[$pt] ?? $pt;
            }
            $typeLabelStr = implode('、', $typeLabels);
            $content = "申请对象：@{$targetName}\n变更方式：{$actionLabel}\n变更权限：{$typeLabelStr}\n\n" . $content;
        }
    }
    if ($wtype == 6) {
        $certType = isset($_POST['cert_type']) ? trim($_POST['cert_type']) : '';
        $certLevel = isset($_POST['cert_level']) ? (int)$_POST['cert_level'] : 0;
        if (empty($certType) || $certLevel <= 0) { header("Location: https://lmtoj.cn/ticket?error=cert_missing"); exit; }
        if (strtoupper($certType) !== 'OI' || $certLevel < 3 || $certLevel > 10) { header("Location: https://lmtoj.cn/ticket?error=cert_invalid"); exit; }
        $content = "认证类型：{$certType}\n认证等级：{$certLevel}\n\n" . $content;
        $title = "奖项认证申请";
    }
    if ($wtype == 7) {
        $revokeAuthorUid = isset($_POST['revoke_author_uid']) ? (int)$_POST['revoke_author_uid'] : 0;
        $revokeLink = trim($_POST['revoke_link'] ?? '');
        if ($revokeAuthorUid <= 0 || empty($revokeLink)) { header("Location: https://lmtoj.cn/ticket?error=revoke_missing"); exit; }
        if (!filter_var($revokeLink, FILTER_VALIDATE_URL)) { header("Location: https://lmtoj.cn/ticket?error=revoke_invalid_link"); exit; }
        $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
        $s->bind_param("i", $revokeAuthorUid);
        $s->execute();
        $authorCheck = $s->get_result()->fetch_assoc();
        $s->close();
        if (!$authorCheck) { header("Location: https://lmtoj.cn/ticket?error=revoke_invalid"); exit; }
        $authorName = $authorCheck['name'];
        $title = "撤销全站推荐";
        $content = "撤销对象：@{$authorName}\n原文章链接：{$revokeLink}\n\n" . $content;
    }
    if (!empty($title) && !empty($content)) {
        $now = date('Y-m-d H:i:s');
        $ins = $conn->prepare("INSERT INTO discuss(uid, title, content, category, work_type, create_time) VALUES (?, ?, ?, 3, ?, ?)");
        $ins->bind_param("issis", $login_uid, $title, $content, $wtype, $now);
        $ins->execute();
        $ins->close();
    }
    header("Location: https://lmtoj.cn/ticket"); exit;
}
if ($tid > 0 && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_content']) && !isset($_POST['assign_uid']) && !isset($_POST['link_parent'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    if ($userJinyan == 1) {
        header("Location: https://lmtoj.cn/ticket/{$tid}?error=jinyan");
        exit;
    }
    $reply_content = trim($_POST['reply_content']);
    if (!empty($reply_content)) {
        $nowTime = date('Y-m-d H:i:s');
        $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
        $ins->bind_param("iissi", $tid, $login_uid, $reply_content, $nowTime, $is_admin);
        $ins->execute();
        $ins->close();
        preg_match_all('/@([\w_\x{4e00}-\x{9fa5}]+)/u', $reply_content, $atMatches);
        $atNames = array_unique($atMatches[1]);
        $s = $conn->prepare("SELECT title FROM discuss WHERE id = ? LIMIT 1");
        $s->bind_param("i", $tid);
        $s->execute();
        $topicTitle = $s->get_result()->fetch_assoc()['title'] ?? "工单#" . $tid;
        $s->close();
        foreach ($atNames as $atName) {
            $u = $conn->prepare("SELECT uid FROM users WHERE name = ?");
            $u->bind_param("s", $atName);
            $u->execute();
            $targetUser = $u->get_result()->fetch_assoc();
            $u->close();
            if ($targetUser && $targetUser['uid'] != $login_uid) {
                $nIns = $conn->prepare("INSERT INTO notice(uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'ticket', ?, 0)");
                $nIns->bind_param("iiiss", $targetUser['uid'], $login_uid, $tid, $topicTitle, $nowTime);
                $nIns->execute();
                $nIns->close();
            }
        }
    }
    header("Location: https://lmtoj.cn/ticket/{$tid}"); exit;
}
if ($tid > 0 && isset($_POST['link_parent']) && ($is_admin || (isset($topicInfo['assignee_uid']) && $topicInfo['assignee_uid'] == $login_uid))) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $tRes = $conn->query("SELECT * FROM discuss WHERE id={$tid} LIMIT 1");
    if ($tRes && $tRes->num_rows > 0) {
        $topicInfo = $tRes->fetch_assoc();
        $parent_tid = (int)$_POST['parent_tid'];
        if ($parent_tid > 0 && $parent_tid != $tid) {
            $check = $conn->prepare("SELECT id, parent_tid FROM discuss WHERE id = ? AND category=3");
            $check->bind_param("i", $parent_tid);
            $check->execute();
            $p = $check->get_result()->fetch_assoc();
            $check->close();
            if ($p && $p['parent_tid'] != $tid) {
                $upd = $conn->prepare("UPDATE discuss SET parent_tid = ? WHERE id = ?");
                $upd->bind_param("ii", $parent_tid, $tid);
                $upd->execute();
                $upd->close();
                $nowTime = date('Y-m-d H:i:s');
                $autoContent = "已将工单关联到主工单 #{$parent_tid}。";
                $stmt = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?,?,?,?,?)");
                $stmt->bind_param("iissi", $tid, $login_uid, $autoContent, $nowTime, $is_admin);
                $stmt->execute();
                $stmt->close();
                $parentUid = $conn->query("SELECT uid FROM discuss WHERE id={$parent_tid}")->fetch_assoc()['uid'];
                if ($parentUid && $parentUid != $login_uid) {
                    $title = $topicInfo['title'] ?? "工单#" . $tid;
                    $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, 0, ?, ?, '关联子工单', ?, 0)");
                    $nIns->bind_param("iiss", $parentUid, $parent_tid, $title, $nowTime);
                    $nIns->execute();
                    $nIns->close();
                }
            }
        }
    }
    header("Location: https://lmtoj.cn/ticket/{$tid}");
    exit;
}
function checkTicketFrequency($uid, $conn) {
    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM discuss WHERE uid = ? AND create_time >= DATE_SUB(NOW(), INTERVAL 10 MINUTE) AND category=3");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $cnt10 = $stmt->get_result()->fetch_assoc()['cnt'];
    $stmt->close();
    if ($cnt10 >= 20) {
        $conn->query("UPDATE users SET banned = 1, jinyan = 1 WHERE uid = $uid");
        $conn->query("DELETE FROM discuss WHERE uid = $uid AND category=3");
        $reason = '频繁提交工单（10分钟超过20个）';
        $operator = BOT_UID;
        $stmt = $conn->prepare("INSERT INTO ostracism_log(target_uid, action, reason, operator_uid) VALUES (?, 'ban_user', ?, ?)");
        $stmt->bind_param("isi", $uid, $reason, $operator);
        $stmt->execute();
        $stmt->close();
        return 'banned';
    }
    $stmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM discuss WHERE uid = ? AND create_time >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) AND category=3");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $cnt5 = $stmt->get_result()->fetch_assoc()['cnt'];
    $stmt->close();

    if ($cnt5 >= 3) {
        $userName = $conn->query("SELECT name FROM users WHERE uid = $uid")->fetch_assoc()['name'];
        $text = "@{$userName} 请勿频繁提交工单，稍后再试。";
        $now = date('Y-m-d H:i:s');
        $maxId = $conn->query("SELECT MAX(id) AS mid FROM benben")->fetch_assoc()['mid'] ?? 0;
        $newId = $maxId + 1;
        $textEscape = $conn->real_escape_string($text);
        $botUid = BOT_UID;
        $conn->query("INSERT INTO benben (id, uid, text, time) VALUES ($newId, $botUid, '$textEscape', '$now')");
    }
    return 'ok';
}
if (isset($_GET['error']) && $_GET['error'] === 'frequent_ban') {
    $errorMsg = '由于您频繁提交工单，账号已被封禁并禁言。';
} elseif (isset($_GET['error']) && $_GET['error'] === 'permission_denied') {
    $errorMsg = '您没有权限发布"更新工单"类型，该类型仅管理员可用。';
} elseif (isset($_GET['error']) && $_GET['error'] === 'jinyan') {
    $errorMsg = '您已被禁言，无法进行此操作。';
}
$searchAssigneeName = '';
if ($search_assignee > 0) {
    $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
    $s->bind_param("i", $search_assignee);
    $s->execute();
    $r = $s->get_result()->fetch_assoc();
    $searchAssigneeName = $r['name'] ?? '';
    $s->close();
}
$searchCreatorName = '';
if ($search_creator > 0) {
    $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
    $s->bind_param("i", $search_creator);
    $s->execute();
    $r = $s->get_result()->fetch_assoc();
    $searchCreatorName = $r['name'] ?? '';
    $s->close();
}

// ---------- 获取数据 ----------
$topicInfo = []; $replyList = []; $topicList = []; $totalPage = 1;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 15; $offset = ($page - 1) * $limit;
if ($filter_status > 0) { $where .= " AND d.work_status = ?"; $params[] = $filter_status; $types .= "i"; }
if ($filter_type > 0) { $where .= " AND d.work_type = ?"; $params[] = $filter_type; $types .= "i"; }
if (!empty($search)) { $where .= " AND (d.title LIKE ? OR d.content LIKE ?)"; $searchLike = "%{$search}%"; $params[] = $searchLike; $params[] = $searchLike; $types .= "ss"; }
if ($search_assignee > 0) { $where .= " AND d.assignee_uid = ?"; $params[] = $search_assignee; $types .= "i"; }
if ($search_creator > 0) { $where .= " AND d.uid = ?"; $params[] = $search_creator; $types .= "i"; }

if ($tid > 0) {
    $s = $conn->prepare("SELECT * FROM discuss WHERE id = ?");
    $s->bind_param("i", $tid);
    $s->execute();
    $tRes = $s->get_result();
    if ($tRes->num_rows === 0) { header("Location: https://lmtoj.cn/ticket"); exit; }
    $topicInfo = $tRes->fetch_assoc();
    $s->close();

    if ($topicInfo && !$is_admin && $topicInfo['work_type'] == 1 && $topicInfo['uid'] != $login_uid) {
        header("Location: https://lmtoj.cn/");
        exit;
    }

    $c = $conn->prepare("SELECT COUNT(*) AS c FROM discuss_reply WHERE tid = ?");
    $c->bind_param("i", $tid);
    $c->execute();
    $replyCount = $c->get_result()->fetch_assoc()['c'];
    $c->close();
    $totalPage = ceil($replyCount / $limit);

    $rStmt = $conn->prepare("SELECT r.*, u.name, u.tag, u.admin AS uadmin,
                            u.avatar,
                            u.practice_score, u.contribute_score, u.contest_score,
                            u.base_credit, u.valuation, u.username_color,
                            u.cert_type, u.cert_level
                            FROM discuss_reply r
                            LEFT JOIN users u ON r.uid = u.uid
                            WHERE r.tid = ?
                            ORDER BY r.create_time ASC
                            LIMIT ?, ?");
    $rStmt->bind_param("iii", $tid, $offset, $limit);
    $rStmt->execute();
    $rRes = $rStmt->get_result();
    while ($row = $rRes->fetch_assoc()) {
        if (!$row['name']) {
            $row['name'] = '已注销';
            $row['tag'] = '';
            $row['uadmin'] = 0;
            $row['avatar'] = '';
            $row['practice_score'] = 0;
            $row['contribute_score'] = 0;
            $row['contest_score'] = 0;
            $row['base_credit'] = 10;
            $row['valuation'] = 0;
            $row['username_color'] = 'auto';
            $row['cert_type'] = '';
            $row['cert_level'] = 0;
        }
        $row['display'] = getUserDisplay($row, $login_uid, $myShowColorful);
        $replyList[] = $row;
    }
    $rStmt->close();

    $subTickets = [];
    $subStmt = $conn->prepare("SELECT * FROM discuss WHERE parent_tid = ? AND category=3 ORDER BY id DESC");
    $subStmt->bind_param("i", $tid);
    $subStmt->execute();
    $subRes = $subStmt->get_result();
    while ($row = $subRes->fetch_assoc()) {
        $subTickets[] = $row;
    }
    $subStmt->close();
} else {
    $countSql = "SELECT COUNT(*) AS c FROM discuss d " . $where;
    $countStmt = $conn->prepare($countSql);
    if (!empty($params)) {
        $countStmt->bind_param($types, ...$params);
    }
    $countStmt->execute();
    $topicCount = $countStmt->get_result()->fetch_assoc()['c'];
    $countStmt->close();
    $totalPage = ceil($topicCount / $limit);

    $listSql = "SELECT d.*, u.name, u.tag, u.admin,
                       u.avatar,
                       u.practice_score, u.contribute_score, u.contest_score,
                       u.base_credit, u.valuation, u.username_color,
                       u.cert_type, u.cert_level,
                       a.name AS assignee_name
                FROM discuss d
                LEFT JOIN users u ON d.uid = u.uid
                LEFT JOIN users a ON d.assignee_uid = a.uid
                " . $where . "
                ORDER BY d.create_time DESC
                LIMIT ?, ?";
    $listStmt = $conn->prepare($listSql);
    $allParams = array_merge($params, [$offset, $limit]);
    $allTypes = $types . "ii";
    if (!empty($allParams)) {
        $bindParams = array_merge([$allTypes], $allParams);
        $refs = [];
        foreach ($bindParams as $key => $value) {
            $refs[$key] = &$bindParams[$key];
        }
        call_user_func_array([$listStmt, 'bind_param'], $refs);
    }
    $conn->query("SET SESSION SQL_BIG_SELECTS=1");
    $listStmt->execute();
    $listRes = $listStmt->get_result();
    while ($row = $listRes->fetch_assoc()) {
        if (!$row['name']) {
            $row['name'] = '已注销';
            $row['tag'] = '';
            $row['admin'] = 0;
            $row['avatar'] = '';
            $row['practice_score'] = 0;
            $row['contribute_score'] = 0;
            $row['contest_score'] = 0;
            $row['base_credit'] = 10;
            $row['valuation'] = 0;
            $row['username_color'] = 'auto';
            $row['cert_type'] = '';
            $row['cert_level'] = 0;
        }
        $row['display'] = getUserDisplay($row, $login_uid, $myShowColorful);
        $topicList[] = $row;
    }
    $listStmt->close();
}

$assigneeName = '';
if ($tid > 0 && $topicInfo['assignee_uid'] > 0) {
    $s = $conn->prepare("SELECT name FROM users WHERE uid = ?");
    $s->bind_param("i", $topicInfo['assignee_uid']);
    $s->execute();
    $assigneeName = $s->get_result()->fetch_assoc()['name'] ?? '';
    $s->close();
}

$recommendSection = ''; $recommendLink = '';
if ($tid > 0 && $topicInfo['work_type'] == 5) {
    if (preg_match('/板块：(.+)/', $topicInfo['content'], $m1)) $recommendSection = trim($m1[1]);
    if (preg_match('/链接：(.+)/', $topicInfo['content'], $m2)) $recommendLink = trim($m2[1]);
}

$targetUserInfo = null;
if ($tid > 0 && $topicInfo['work_type'] == 1) {
    if (preg_match('/申请对象：@([\w_\x{4e00}-\x{9fa5}]+)/u', $topicInfo['content'], $m)) {
        $targetName = $m[1];
        $targetUid = $nameToUid[$targetName] ?? 0;
        if ($targetUid > 0) {
            $s = $conn->prepare("SELECT uid, name, admin, jinyan, sixin FROM users WHERE uid = ?");
            $s->bind_param("i", $targetUid);
            $s->execute();
            $targetUserInfo = $s->get_result()->fetch_assoc();
            $s->close();
        }
    }
}
$ostracismRecords = null;
if ($targetUserInfo) {
    $s = $conn->prepare("SELECT l.*, op.name as operator_name
                         FROM ostracism_log l
                         LEFT JOIN users op ON l.operator_uid = op.uid
                         WHERE l.target_uid = ?
                         ORDER BY l.id DESC
                         LIMIT 20");
    $s->bind_param("i", $targetUserInfo['uid']);
    $s->execute();
    $ostracismRecords = $s->get_result();
    $s->close();
}

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function getImgUrl($str) {
    $str = safeContent(trim($str));
    if (strpos($str, 'http') === 0) return $str;
    return '/' . ltrim($str, '/');
}
function beijingTime($utcStr) { return empty($utcStr) ? '' : date('Y-m-d H:i:s', strtotime($utcStr)); }

$filterParams = "ws=$filter_status&wt=$filter_type";
$searchParams = "search=" . urlencode($search) . "&search_assignee=$search_assignee&search_creator=$search_creator";
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>工单系统 - lmtOJ</title>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" />
<style>
:root { --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6; --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e; --border: #e6e1da; --border-light: #f0ece6; --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef; --danger: #d9534f; --danger-hover: #c0392b; --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease; --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif; --font-mono: 'JetBrains Mono', 'Consolas', monospace; }
*{margin:0;padding:0;box-sizing:border-box;} body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;} .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);} .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;} .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);} .bell-wrap:hover{background:rgba(255,255,255,0.08);} .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;} @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}} .user-info{display:flex;align-items:center;gap:6px;} .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;} .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;} .user-info a.admin-link{color:#f5d76e;font-weight:600;} .main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;} .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;} .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;} .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);} .content{flex:1;min-width:0;} a{color:var(--accent);text-decoration:none;font-weight:500;} a:hover{color:var(--accent-hover);text-decoration:underline;} .back-btn{display:inline-flex;align-items:center;gap:6px;margin-bottom:18px;padding:8px 18px;background:var(--card-bg);color:var(--text);border-radius:20px;font-size:13.5px;font-weight:500;border:1px solid var(--border);box-shadow:var(--shadow-sm);} .back-btn:hover{background:var(--accent-light);border-color:var(--accent);color:var(--accent);text-decoration:none;} .card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;} .card h2,.card h3{font-size:18px;font-weight:600;margin-bottom:20px;} input[type="text"],select,textarea{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;margin-bottom:16px;background:#fdfdfc;font-family:var(--font);transition:var(--transition);} input[type="text"]:focus,textarea:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;} .edit-wrap{display:flex;gap:16px;width:100%;} .edit-box{width:50%;} .preview-box{width:50%;word-wrap:break-word;word-break:break-all;white-space:normal;} textarea{min-height:220px;resize:vertical;font-family:var(--font);} .preview-box{border:1.5px solid var(--border-light);border-radius:var(--radius-sm);padding:14px;min-height:220px;overflow-y:auto;background:#fafaf8;font-size:14px;} button{padding:9px 22px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);} button:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);} .btn-sm{padding:4px 10px;font-size:12px;margin:0 4px;border-radius:4px;border:none;cursor:pointer;text-decoration:none;display:inline-block;font-weight:500;} .btn-danger{background:var(--danger);color:#fff;} .btn-danger:hover{background:var(--danger-hover);} .btn-green{background:#5a9e6f;color:#fff;} .btn-green:hover{background:#4a855c;} .topic-item{padding:16px 0;border-bottom:1px solid var(--border-light);} .topic-title{font-size:16px;font-weight:600;margin-bottom:8px;} .topic-title a{color:var(--text);} .topic-title a:hover{color:var(--accent);} .topic-meta{font-size:13px;color:var(--text-muted);} .md-content{line-height:1.8;color:var(--text);} .md-content p{margin:8px 0;} .md-content blockquote{border-left:4px solid var(--accent);padding:8px 14px;margin:12px 0;background:#fafaf8;color:#5a5550;border-radius:0 4px 4px 0;} .md-content pre{background:#2b2a27;color:#e8e4dd;padding:14px 16px;border-radius:var(--radius-sm);overflow-x:auto;margin:12px 0;font-family:var(--font-mono);font-size:13px;} .md-content code{font-family:var(--font-mono);background:#f3f0eb;padding:2px 6px;border-radius:3px;color:#5a4a3a;} .md-content pre code{background:transparent;padding:0;color:inherit;} .md-content img { max-width: 100%; height: auto; border-radius: 4px; margin: 6px 0; } .reply-item{padding:16px 0;border-bottom:1px solid var(--border-light);} .reply-meta{font-size:13px;color:var(--text-muted);margin-bottom:10px;} .filter-line{margin-bottom:20px;display:flex;flex-wrap:wrap;gap:8px;} .filter-line a{display:inline-block;padding:5px 14px;background:#f5f2ed;border-radius:20px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:500;transition:var(--transition);} .filter-line a.active{background:var(--accent);color:#fff;} .status-tag{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;margin:0 6px;font-weight:600;} .admin-select{margin-left:8px;padding:4px 8px;border:1px solid var(--border);border-radius:4px;font-size:12px;background:#fff;} .at-user{color:var(--accent);text-decoration:none;font-weight:500;} .at-user:hover{text-decoration:underline;} .page-bar{display:flex;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap;} .page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;background:#fff;} .page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);} .page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);} .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;} .ben-name { font-weight:600; text-decoration:none; font-size:14px; transition:color 0.2s; } .ben-name:hover { opacity:0.8; text-decoration:underline; } .ben-name.colorful { color: #f1948a; animation: colorful 3s linear infinite; text-shadow: 0 0 10px rgba(0,0,0,0.2); } @keyframes colorful { 0% { color: #f1948a; } 17% { color: #f5b041; } 33% { color: #f7dc6f; } 50% { color: #82e0aa; } 67% { color: #85c1e9; } 83% { color: #bb8fce; } 100% { color: #f1948a; } } .tag { border-radius:3px; padding:2px 9px; color:#fff; display:inline-block; margin:2px 5px; font-size:11.5px; font-weight:600; } .tag.colorful-bg { animation: colorfulBg 3s linear infinite; } @keyframes colorfulBg { 0% { background-color: #f1948a; } 17% { background-color: #f5b041; } 33% { background-color: #f7dc6f; } 50% { background-color: #82e0aa; } 67% { background-color: #85c1e9; } 83% { background-color: #bb8fce; } 100% { background-color: #f1948a; } } .error-box{background:#fde8e8;border:1px solid #f5c6c6;color:#a94442;padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:16px;} .assignee-area{display:inline-flex;align-items:center;gap:6px;margin-left:10px;font-size:13px;color:var(--text-secondary);} .searchable-select{position:relative;display:inline-block;min-width:160px;} .searchable-select input{width:100%;padding:8px 12px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;background:#fdfdfc;font-family:var(--font);transition:var(--transition);margin-bottom:0;} .searchable-select input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;} .searchable-select .options{position:absolute;top:100%;left:0;right:0;max-height:200px;overflow-y:auto;background:#fff;border:1px solid var(--border);border-radius:0 0 4px 4px;z-index:99;display:none;list-style:none;} .searchable-select .options li{padding:6px 10px;cursor:pointer;font-size:13px;} .searchable-select .options li:hover{background:var(--accent-light);} .searchable-select .options li.selected{background:var(--accent);color:#fff;} .ostracism-table{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px;} .ostracism-table th{text-align:left;padding:8px 10px;background:#fafaf8;font-weight:500;color:var(--text-secondary);border-bottom:2px solid var(--border);} .ostracism-table td{padding:8px 10px;border-bottom:1px solid var(--border-light);} .action-tag{padding:2px 8px;border-radius:10px;font-size:11px;color:#fff;font-weight:600;} .tag-set{background:#5a9e6f;} .tag-unset{background:#d4a24e;} .tag-jy{background:#d9534f;} .reply-auto{background:#fafaf7;border-radius:4px;padding:10px 14px;} .reply-auto .reply-meta{color:var(--accent);} .reply-avatar{width:32px;height:32px;border-radius:50%;background:var(--accent);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;overflow:hidden;flex-shrink:0;} .reply-avatar img{width:100%;height:100%;object-fit:cover;} .type-filter{margin-bottom:16px;display:flex;flex-wrap:wrap;gap:8px;} .type-filter a{display:inline-block;padding:5px 14px;background:#f5f2ed;border-radius:20px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:500;transition:var(--transition);} .type-filter a.active{background:var(--accent);color:#fff;} /* 新增：编辑展开区样式 */
.edit-toggle-btn { margin-bottom:16px; }
.edit-area { display:none; }
.edit-area.show { display:block; }
@media(max-width:768px){ .main{flex-direction:column;padding:0 12px;} .sidebar{width:100%;position:static;display:flex;} .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;} .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);} .edit-wrap{flex-direction:column;} .edit-box,.preview-box{width:100%;} .card{padding:18px 14px;} }
</style>
</head>
<body>
<script src="/js/markdown-it.min.js"></script>
<script src="/js/katex.min.js"></script>
<script src="/js/texmath.min.js"></script>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if ($errorMsg): ?>
            <div class="error-box"><?=safeContent($errorMsg)?></div>
        <?php endif; ?>
        <?php if ($tid === 0): ?>
            <!-- 搜索表单 -->
            <div class="card" style="margin-bottom:16px;">
                <form method="get" action="https://lmtoj.cn/ticket" style="display:flex;flex-wrap:wrap;gap:10px;align-items:center;">
                    <input type="hidden" name="ws" value="<?=$filter_status?>">
                    <input type="hidden" name="wt" value="<?=$filter_type?>">
                    <input type="text" name="search" placeholder="搜索工单标题/内容" value="<?=safeContent($search)?>" style="width:200px; margin-bottom:0;">
                    <div class="searchable-select" id="searchAssigneeSelect" style="width:200px;">
                        <input type="text" placeholder="搜索责任人" autocomplete="off" id="searchAssigneeInput" value="<?= safeContent($searchAssigneeName) ?>" style="margin-bottom:0;">
                        <input type="hidden" name="search_assignee" value="<?=$search_assignee?>">
                        <ul class="options" id="searchAssigneeOptions"></ul>
                    </div>
                    <div class="searchable-select" id="searchCreatorSelect" style="width:200px;">
                        <input type="text" placeholder="搜索创建人" autocomplete="off" id="searchCreatorInput" value="<?= safeContent($searchCreatorName) ?>" style="margin-bottom:0;">
                        <input type="hidden" name="search_creator" value="<?=$search_creator?>">
                        <ul class="options" id="searchCreatorOptions"></ul>
                    </div>
                    <button type="submit" class="btn-sm" style="background:var(--accent);color:#fff;padding:6px 16px; margin-bottom:0;">搜索</button>
                    <?php if(!empty($search) || $search_assignee > 0 || $search_creator > 0): ?>
                        <a href="https://lmtoj.cn/ticket?<?=$filterParams?>" class="btn-sm" style="background:var(--danger);color:#fff; margin-bottom:0;">清除搜索</a>
                    <?php endif; ?>
                </form>
            </div>

            <!-- 状态筛选 -->
            <div class="filter-line">
                <a href="https://lmtoj.cn/ticket?ws=0&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==0?'active':''?>">全部状态</a>
                <a href="https://lmtoj.cn/ticket?ws=1&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==1?'active':''?>">待处理</a>
                <a href="https://lmtoj.cn/ticket?ws=2&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==2?'active':''?>">挂起</a>
                <a href="https://lmtoj.cn/ticket?ws=5&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==5?'active':''?>">处理中</a>
                <a href="https://lmtoj.cn/ticket?ws=3&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==3?'active':''?>">已完成</a>
                <a href="https://lmtoj.cn/ticket?ws=4&wt=<?=$filter_type?>&<?=$searchParams?>" class="<?=$filter_status==4?'active':''?>">已关闭</a>
            </div>

            <!-- 工单类型筛选 -->
            <div class="type-filter">
                <a href="https://lmtoj.cn/ticket?wt=0&ws=<?=$filter_status?>&<?=$searchParams?>" class="<?=$filter_type==0?'active':''?>">全部类型</a>
                <?php foreach($workTypeArr as $k=>$v): ?>
                    <a href="https://lmtoj.cn/ticket?wt=<?=$k?>&ws=<?=$filter_status?>&<?=$searchParams?>" class="<?=$filter_type==$k?'active':''?>"><?=safeContent($v['name'])?></a>
                <?php endforeach; ?>
            </div>


            <!-- 提交新工单 -->
            <div class="card">
                <h2>提交新工单</h2>
                <form method="post" id="newTicketForm">
                    <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                    <input type="text" name="new_title" id="newTitleInput" placeholder="工单标题" required>
                    <select name="work_type" id="workTypeSelect">
                        <?php if($userJinyan==1 && !$is_admin): ?>
                            <option value="1">权限变更/举报/申诉</option>
                        <?php else: ?>
                            <?php foreach($workTypeArr as $k=>$v):
                                if ($k == 8 && !$is_admin) continue;
                            ?>
                                <option value="<?=$k?>"><?=$v['name']?></option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                    <div id="targetUserArea" style="display:none;margin-bottom:16px;">
                        <div style="display:flex;gap:10px;flex-wrap:wrap;">
                            <div style="flex:1;min-width:150px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:4px;display:block;">申请对象</label>
                                <div class="searchable-select" id="targetUserSelect">
                                    <input type="text" placeholder="搜索用户..." autocomplete="off" id="targetSearchInput">
                                    <ul class="options" id="targetOptions"></ul>
                                </div>
                                <input type="hidden" name="target_uid" id="targetUidHidden" value="0">
                            </div>
                            <div style="flex:1;min-width:150px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:4px;display:block;">变更方式</label>
                                <select name="perm_action">
                                    <?php foreach($permActions as $k=>$v): ?><option value="<?=$k?>"><?=$v?></option><?php endforeach; ?>
                                </select>
                            </div>
                            <div style="flex:1;min-width:180px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);margin-bottom:4px;display:block;">变更权限</label>
                                <div style="display:flex;flex-wrap:wrap;gap:8px;">
                                    <?php foreach($permTypes as $k=>$v): ?>
                                        <label style="font-weight:400;font-size:13px;"><input type="checkbox" name="perm_types[]" value="<?=$k?>"> <?=$v?></label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="recommendArea" style="display:none;margin-bottom:16px;">
                        <div style="display:flex;gap:10px;flex-wrap:wrap;">
                            <div style="flex:1;min-width:200px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">投稿板块（必选）</label>
                                <select name="recommend_section" id="recommendSection">
                                    <option value="">--请选择--</option>
                                    <option value="题解">题解</option>
                                    <option value="科技·工程">科技·工程</option>
                                    <option value="算法·理论">算法·理论</option>
                                    <option value="学习·文化课">学习·文化课</option>
                                    <option value="休闲·娱乐">休闲·娱乐</option>
                                    <option value="生活·游记">生活·游记</option>
                                </select>
                            </div>
                            <div style="flex:1;min-width:200px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">关联链接（必填）</label>
                                <input type="url" name="recommend_link" id="recommendLink" placeholder="https://..." style="width:100%;padding:8px 12px;border:1.5px solid var(--border);border-radius:var(--radius-sm);">
                            </div>
                        </div>
                    </div>
                    <div id="certArea" style="display:none;margin-bottom:16px;">
                        <div style="display:flex;gap:10px;flex-wrap:wrap;">
                            <div style="flex:1;min-width:150px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">认证类型</label>
                                <select name="cert_type" id="certTypeSelect">
                                    <option value="">--请选择--</option>
                                    <option value="OI">OI</option>
                                </select>
                            </div>
                            <div style="flex:1;min-width:150px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">认证等级</label>
                                <select name="cert_level" id="certLevelSelect">
                                    <option value="">--请选择--</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="revokeAuthorArea" style="display:none;margin-bottom:16px;">
                        <div style="display:flex;gap:10px;flex-wrap:wrap;">
                            <div style="flex:1;min-width:200px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">原文章作者（必选）</label>
                                <div class="searchable-select" id="revokeAuthorSelect">
                                    <input type="text" placeholder="搜索用户..." autocomplete="off" id="revokeAuthorInput">
                                    <ul class="options" id="revokeAuthorOptions"></ul>
                                </div>
                                <input type="hidden" name="revoke_author_uid" id="revokeAuthorUidHidden" value="0">
                            </div>
                            <div style="flex:1;min-width:200px;">
                                <label style="font-size:13px;font-weight:500;color:var(--text-secondary);display:block;">原文章链接（必填）</label>
                                <input type="url" name="revoke_link" id="revokeLink" placeholder="https://..." style="width:100%;padding:8px 12px;border:1.5px solid var(--border);border-radius:var(--radius-sm);">
                            </div>
                        </div>
                    </div>
                    <div class="edit-wrap">
                        <div class="edit-box"><textarea id="postEditor" name="new_content" placeholder="工单内容，支持 Markdown、@用户"></textarea></div>
                        <div class="preview-box" id="postPreview">预览区域</div>
                    </div>
                    <button type="submit" id="submitBtn">提交工单</button>
                </form>
            </div>

            <!-- 工单列表 -->
            <div class="card">
                <h2>工单列表</h2>
                <?php if (empty($topicList)): ?><p style="color:var(--text-muted);">暂无工单</p>
                <?php else: ?>
                    <?php foreach ($topicList as $item):
                        $disp = $item['display'];
                        $uid = $item['uid'] ?? 0;
                    ?>
                        <div class="topic-item">
                            <div class="topic-title">
                                <a href="https://lmtoj.cn/ticket/<?=$item['id']?>"><?=safeContent($item['title'])?></a>
                                <?php $s = $statusConfig[$item['work_status']]; ?>
                                <span class="status-tag" style="color:<?=$s['color']?>;background:<?=$s['bg']?>;"><?=$s['name']?></span>
                                <span class="status-tag" style="color:var(--text-secondary);background:#f4f4f5;"><?=$workTypeArr[$item['work_type']]['name']?></span>
                                <?php if($item['assignee_uid'] > 0 && !empty($item['assignee_name'])): ?>
                                    <span style="font-size:12px;color:var(--accent);margin-left:6px;">处理人：<?=safeContent($item['assignee_name'])?></span>
                                <?php endif; ?>
                            </div>
                            <div class="topic-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                                <span class="reply-avatar" style="width:24px;height:24px;font-size:12px;">
                                    <?php if (!empty($item['avatar'])): ?>
                                        <img src="<?=getImgUrl($item['avatar'])?>" alt="avatar">
                                    <?php else: ?>
                                        <?=getFirstChar($item['name'])?>
                                    <?php endif; ?>
                                </span>
                                <a href="https://lmtoj.cn/user/<?=$uid?>" class="ben-name<?= $disp['isColorful'] ? ' colorful' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="color: ' . $disp['color'] . ';"' ?>>
                                    <?=safeContent($item['name'])?>
                                </a>
                                <?php if($disp['tag']): ?>
                                    <span class="tag<?= $disp['isColorful'] ? ' colorful-bg' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="background: ' . $disp['color'] . ';"' ?>>
                                        <?=safeContent($disp['tag'])?>
                                    </span>
                                <?php endif; ?>
                                 · <?=beijingTime($item['create_time'])?>
                                <?php if ($is_admin): ?>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                                        <input type="hidden" name="del_tid" value="<?=$item['id']?>">
                                        <button type="submit" class="btn-sm btn-danger">删除</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if($totalPage > 1):
                    $queryParams = "$filterParams&$searchParams";
                ?>
                <div class="page-bar">
                    <?php if($page > 1): ?><a href="https://lmtoj.cn/ticket?<?=$queryParams?>&page=<?=$page-1?>">上一页</a><?php endif; ?>
                    <?php $shown = [1]; for($i=max(2,$page-2); $i<=min($totalPage-1,$page+2); $i++) $shown[]=$i; if($totalPage>1) $shown[]=$totalPage; $shown=array_unique($shown); sort($shown); $prev=0;
                    foreach($shown as $i): if($i-$prev>1) echo '<span class="page-ellipsis">...</span>'; ?>
                        <a href="https://lmtoj.cn/ticket?<?=$queryParams?>&page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a>
                    <?php $prev=$i; endforeach; ?>
                    <?php if($page<$totalPage): ?><a href="https://lmtoj.cn/ticket?<?=$queryParams?>&page=<?=$page+1?>">下一页</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- 工单详情页 -->
            <a href="https://lmtoj.cn/ticket?<?=$filterParams?>&<?=$searchParams?>" class="back-btn">← 返回工单列表</a>
            <div class="card">
                <?php $canEdit = $is_admin || $topicInfo['uid'] == $login_uid; ?>
                <?php if ($canEdit): ?>
                    <button type="button" id="editToggleBtn" class="edit-toggle-btn btn-sm" style="background:var(--accent);color:#fff;">开始编辑</button>
                    <div id="editArea" class="edit-area">
                        <form method="post" id="editForm">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="edit_tid" value="<?=$topicInfo['id']?>">
                            <input type="text" name="edit_title" value="<?=safeContent($topicInfo['title'])?>" required>
                            <div class="edit-wrap">
                                <div class="edit-box"><textarea id="editEditor" name="edit_content" required><?=safeContent($topicInfo['content'])?></textarea></div>
                                <div class="preview-box" id="editPreview"></div>
                            </div>
                            <button type="submit" id="editSubmitBtn">保存修改</button>
                        </form>
                        <hr style="margin:20px 0;border:0;border-top:1px solid var(--border-light);">
                    </div>
                <?php endif; ?>
                <h2><?=safeContent($topicInfo['title'])?></h2>
                <div class="topic-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <?php
                    $creatorUid = $topicInfo['uid'];
                    $creatorInfo = $uidToUser[$creatorUid] ?? null;
                    if (!$creatorInfo) {
                        $creatorInfo = ['name'=>'未知用户', 'admin'=>0, 'tag'=>'', 'avatar'=>'', 'practice_score'=>0, 'contribute_score'=>0, 'contest_score'=>0, 'base_credit'=>10, 'valuation'=>0, 'username_color'=>'auto', 'cert_type'=>'', 'cert_level'=>0];
                    }
                    $creatorDisplay = getUserDisplay($creatorInfo, $login_uid, $myShowColorful);
                    ?>
                    <span class="reply-avatar">
                        <?php if (!empty($creatorInfo['avatar'])): ?>
                            <img src="<?=getImgUrl($creatorInfo['avatar'])?>" alt="avatar">
                        <?php else: ?>
                            <?=getFirstChar($creatorInfo['name'])?>
                        <?php endif; ?>
                    </span>
                    <a href="https://lmtoj.cn/user/<?=$topicInfo['uid']?>" class="ben-name<?= $creatorDisplay['isColorful'] ? ' colorful' : '' ?>" <?= $creatorDisplay['isColorful'] ? '' : 'style="color: ' . $creatorDisplay['color'] . ';"' ?>>
                        <?=safeContent($creatorInfo['name'])?>
                    </a>
                    <?php if($creatorDisplay['tag']): ?>
                        <span class="tag<?= $creatorDisplay['isColorful'] ? ' colorful-bg' : '' ?>" <?= $creatorDisplay['isColorful'] ? '' : 'style="background: ' . $creatorDisplay['color'] . ';"' ?>>
                            <?=safeContent($creatorDisplay['tag'])?>
                        </span>
                    <?php endif; ?>
                    · <?=beijingTime($topicInfo['create_time'])?>
                    <?php $s = $statusConfig[$topicInfo['work_status']]; ?>
                    <span class="status-tag" style="color:<?=$s['color']?>;background:<?=$s['bg']?>;"><?=$s['name']?></span>
                    <span class="status-tag" style="color:var(--text-secondary);background:#f4f4f5;"><?=$workTypeArr[$topicInfo['work_type']]['name']?></span>

                    <?php if ($is_admin): ?>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="del_tid" value="<?=$topicInfo['id']?>">
                            <button type="submit" class="btn-sm btn-danger">删除工单</button>
                        </form>
                    <?php endif; ?>
                    <?php if (!$is_admin && $topicInfo['uid'] == $login_uid && !in_array($topicInfo['work_status'], [3,4])): ?>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定关闭此工单吗？');">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="wtid" value="<?=$topicInfo['id']?>">
                            <input type="hidden" name="set_ws" value="4">
                            <button type="submit" class="btn-sm" style="background:#d9534f;color:#fff;">关闭工单</button>
                        </form>
                    <?php endif; ?>
                    <?php if ($is_admin): ?>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                        <input type="hidden" name="wtid" value="<?=$topicInfo['id']?>">
                        <select name="set_ws" class="admin-select" onchange="this.form.submit()">
                            <option value="">修改状态</option>
                            <?php foreach($statusConfig as $k=>$v): ?><option value="<?=$k?>" <?=$topicInfo['work_status']==$k?'selected':''?>><?=$v['name']?></option><?php endforeach; ?>
                        </select>
                    </form>
                    <?php endif; ?>
                    <?php if($is_admin || $topicInfo['assignee_uid'] == $login_uid): ?>
                    <div class="assignee-area">
                        处理人：
                        <form method="post" class="assignee-form" id="assignForm">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <div class="searchable-select" id="assigneeSelect">
                                <input type="text" placeholder="搜索用户" autocomplete="off" id="assignSearchInput" value="<?= safeContent($assigneeName) ?>">
                                <input type="hidden" name="assign_uid" value="<?=$topicInfo['assignee_uid']?>">
                                <ul class="options" id="assignOptions"></ul>
                            </div>
                            <button type="button" class="btn-sm" id="assignConfirmBtn" style="margin-left:8px;">确定</button>
                        </form>
                    </div>
                    <?php elseif($topicInfo['assignee_uid'] > 0): ?>
                    <div class="assignee-area">处理人：<strong><?= safeContent($assigneeName) ?></strong></div>
                    <?php endif; ?>
                </div>

                <?php if ($topicInfo['parent_tid'] > 0):
                    $parent = $conn->query("SELECT id, title FROM discuss WHERE id = {$topicInfo['parent_tid']}")->fetch_assoc();
                ?>
                    <div style="margin-top:10px;font-size:14px;color:var(--text-secondary);">
                        关联主工单：<a href="https://lmtoj.cn/ticket/<?=$topicInfo['parent_tid']?>">#<?=$topicInfo['parent_tid']?> <?=safeContent($parent['title']??'')?></a>
                    </div>
                <?php endif; ?>

                <?php if ($is_admin || $topicInfo['assignee_uid'] == $login_uid): ?>
                <div style="margin:15px 0;padding:15px;background:var(--accent-light);border-radius:var(--radius-sm);">
                    <form method="post" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                        <input type="hidden" name="link_parent" value="1">
                        <label style="font-weight:500;">关联主工单 ID：</label>
                        <input type="number" name="parent_tid" placeholder="输入工单编号" style="width:150px;padding:6px 10px;border:1.5px solid var(--border);border-radius:var(--radius-sm);">
                        <button type="submit" class="btn-sm" style="background:var(--accent);color:#fff;">关联</button>
                        <?php if ($topicInfo['parent_tid'] > 0): ?>
                            <span style="font-size:13px;color:var(--text-secondary);">已关联到 #<?=$topicInfo['parent_tid']?></span>
                        <?php endif; ?>
                    </form>
                </div>
                <?php endif; ?>

                <?php if($topicInfo['work_type'] == 1 && $targetUserInfo): ?>
                    <div style="margin-top:10px;font-size:14px;color:var(--text-secondary);">
                        申请对象：<a href="https://lmtoj.cn/user/<?=$targetUserInfo['uid']?>" style="font-weight:600;">@<?=safeContent($targetUserInfo['name'])?></a>
                    </div>
                <?php endif; ?>
                <?php if($topicInfo['work_type'] == 5): ?>
                    <div style="margin-top:10px;font-size:14px;color:var(--text-secondary);">
                        <div>投稿板块：<strong><?=safeContent($recommendSection)?></strong></div>
                        <div>关联链接：<a href="<?=safeContent($recommendLink)?>" target="_blank" style="word-break:break-all;"><?=safeContent($recommendLink)?></a></div>
                    </div>
                <?php endif; ?>
                <?php if($topicInfo['work_type'] == 7):
                    $revokeAuthor = '';
                    $revokeLink = '';
                    $revokeUid = 0;
                    if (preg_match('/撤销对象：@([\w_\x{4e00}-\x{9fa5}]+)/u', $topicInfo['content'], $m)) {
                        $revokeAuthor = $m[1];
                        $revokeUid = $nameToUid[$revokeAuthor] ?? 0;
                    }
                    if (preg_match('/原文章链接：([^\n]+)/', $topicInfo['content'], $m2)) {
                        $revokeLink = trim($m2[1]);
                    }
                ?>
                    <div style="margin-top:10px;font-size:14px;color:var(--text-secondary);">
                        <div>撤销对象：<a href="https://lmtoj.cn/user/<?=$revokeUid?>" style="font-weight:600;">@<?=safeContent($revokeAuthor)?></a></div>
                        <div>原文章链接：<a href="<?=safeContent($revokeLink)?>" target="_blank" style="word-break:break-all;"><?=safeContent($revokeLink)?></a></div>
                    </div>
                <?php endif; ?>
                <?php
                $rawContent = $topicInfo['content'];
                if($topicInfo['work_type'] == 5) {
                    $rawContent = preg_replace('/^(板块：.+\n链接：.+\n\n)/', '', $rawContent);
                } elseif($topicInfo['work_type'] == 6) {
                    $rawContent = preg_replace('/^认证类型：.+\n认证等级：\d+\n\n/', '', $rawContent);
                } elseif($topicInfo['work_type'] == 7) {
                    $rawContent = preg_replace('/^撤销对象：@[^\n]+\n原文章链接：[^\n]+\n\n/', '', $rawContent);
                }
                ?>
                <div class="md-content" data-raw="<?=safeContent($rawContent)?>"></div>
            </div>

            <?php if($ostracismRecords && $ostracismRecords->num_rows > 0): ?>
            <div class="card">
                <h3>陶片放逐记录（<?=safeContent($targetUserInfo['name'])?>）</h3>
                <table class="ostracism-table">
                    <tr>
                        <th>时间</th>
                        <?php if ($is_admin): ?><th>操作人</th><?php endif; ?>
                        <th>操作</th>
                        <th>原因</th>
                    </tr>
                    <?php while($o = $ostracismRecords->fetch_assoc()):
                        $labels = [
                        'set_admin'     => '授予 进入后台 权限',
                        'unset_admin'   => '撤销 进入后台 权限',
                        'set_jinyan'    => '授予 自由发言 权限',
                        'unset_jinyan' => '撤销 自由发言 权限',
                        'del_user'      => '撤销 进入主站 权限',
                        'set_sixin'     => '授予 发送私信 权限',
                        'unset_sixin'  => '撤销 发送私信 权限',
                        'ban_user'      => '撤销 进入主站 权限',
                        'unban_user'    => '授予 进入主站 权限',
                        'set_banned'    => '授予 进入主站 权限',
                        'unset_banned'  => '撤销 进入主站 权限',
                        'rename_user'   => '修改用户名',
                        'set_brown'     => '授予 棕名惩罚',
                        'self_unban'    => '自行解封',
                        'set_sqadmin'   => '授予 社区管理 权限',
                        'unset_sqadmin' => '撤销 社区管理 权限',
                        'set_proadmin'  => '授予 题目管理 权限',
                        'unset_proadmin' => '撤销 题目管理 权限',
                        'set_conadmin'  => '授予 比赛管理 权限',
                        'unset_conadmin' => '撤销 比赛管理 权限',
                        'set_artadmin'  => '授予 文章管理 权限',
                        'unset_artadmin' => '撤销 文章管理 权限',
                        'set_devadmin'  => '授予 文件管理 权限',
                        'unset_devadmin' => '撤销 文件管理 权限'
                        ];
                        $colors = [
                        'set_admin'     => 'tag-set',
                        'unset_admin'   => 'tag-unset',
                        'set_jinyan'    => 'tag-set',
                        'unset_jinyan'  => 'tag-jy',
                        'del_user'      => 'tag-unset',
                        'set_sixin'     => 'tag-set',
                        'unset_sixin'   => 'tag-jy',
                        'ban_user'      => 'tag-unset',
                        'unban_user'    => 'tag-set',
                        'set_banned'    => 'tag-set',
                        'unset_banned'  => 'tag-unset',
                        'rename_user'   => 'tag-rename',
                        'set_brown'     => 'tag-brown',
                        'self_unban'    => 'tag-self',
                        'set_sqadmin'   => 'tag-set',
                        'unset_sqadmin' => 'tag-unset',
                        'set_proadmin'  => 'tag-set',
                        'unset_proadmin' => 'tag-unset',
                        'set_conadmin'  => 'tag-set',
                        'unset_conadmin' => 'tag-unset',
                        'set_artadmin'  => 'tag-set',
                        'unset_artadmin' => 'tag-unset',
                        'set_devadmin'  => 'tag-set',
                        'unset_devadmin' => 'tag-unset'
                        ];
                        $typeLabel = $o['action'];
                        $displayLabel = $labels[$typeLabel] ?? $typeLabel;
                        $displayColor = $colors[$typeLabel] ?? '';
                    ?>
                    <tr>
                        <td><?=date("m-d H:i:s",strtotime($o['created_at']))?></td>
                        <?php if ($is_admin): ?><td><?=safeContent($o['operator_name'])?></td><?php endif; ?>
                        <td><span class="action-tag <?=$displayColor?>"><?=$displayLabel?></span></td>
                        <td><?=safeContent($o['reason'])?></td>
                    </tr>
                    <?php endwhile; ?>
                </table>
            </div>
            <?php endif; ?>

            <?php if (!empty($subTickets)): ?>
            <div class="card">
                <h3>子工单列表（<?=count($subTickets)?>）</h3>
                <?php foreach ($subTickets as $sub):
                    $subUserInfo = $uidToUser[$sub['uid']] ?? null;
                    if (!$subUserInfo) {
                        $subUserInfo = ['name'=>'未知用户', 'admin'=>0, 'tag'=>'', 'avatar'=>'', 'practice_score'=>0, 'contribute_score'=>0, 'contest_score'=>0, 'base_credit'=>10, 'valuation'=>0, 'username_color'=>'auto', 'cert_type'=>'', 'cert_level'=>0];
                    }
                    $subDisplay = getUserDisplay($subUserInfo, $login_uid, $myShowColorful);
                ?>
                    <div class="topic-item">
                        <div class="topic-title">
                            <a href="https://lmtoj.cn/ticket/<?=$sub['id']?>">#<?=$sub['id']?> - <?=safeContent($sub['title'])?></a>
                            <span class="status-tag" style="color:<?=$statusConfig[$sub['work_status']]['color']?>;background:<?=$statusConfig[$sub['work_status']]['bg']?>;"><?=$statusConfig[$sub['work_status']]['name']?></span>
                        </div>
                        <div class="topic-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                            <span class="reply-avatar" style="width:24px;height:24px;font-size:12px;">
                                <?php if (!empty($subUserInfo['avatar'])): ?>
                                    <img src="<?=getImgUrl($subUserInfo['avatar'])?>" alt="avatar">
                                <?php else: ?>
                                    <?=getFirstChar($subUserInfo['name'])?>
                                <?php endif; ?>
                            </span>
                            <a href="https://lmtoj.cn/user/<?=$sub['uid']?>" class="ben-name<?= $subDisplay['isColorful'] ? ' colorful' : '' ?>" <?= $subDisplay['isColorful'] ? '' : 'style="color: ' . $subDisplay['color'] . ';"' ?>>
                                <?=safeContent($subUserInfo['name'])?>
                            </a>
                            <?php if($subDisplay['tag']): ?>
                                <span class="tag<?= $subDisplay['isColorful'] ? ' colorful-bg' : '' ?>" <?= $subDisplay['isColorful'] ? '' : 'style="background: ' . $subDisplay['color'] . ';"' ?>>
                                    <?=safeContent($subDisplay['tag'])?>
                                </span>
                            <?php endif; ?>
                            · <?=beijingTime($sub['create_time'])?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="card">
                <h3>全部回复</h3>
                <?php if (empty($replyList)): ?><p style="color:var(--text-muted);">暂无回复</p>
                <?php else: ?>
                    <?php foreach ($replyList as $rep):
                        $disp = $rep['display'];
                        $uid = $rep['uid'] ?? 0;
                        $contentRaw = $rep['content'];
                        $isAutoReply = ((int)($rep['admin'] ?? 0) === 1) && (
                            strpos($contentRaw, '将工单状态设为') === 0 ||
                            strpos($contentRaw, '将工单指派给') === 0 ||
                            strpos($contentRaw, '取消了工单指派') === 0 ||
                            strpos($contentRaw, '已将用户') === 0 ||
                            strpos($contentRaw, '已将工单关联到主工单') === 0 ||
                            strpos($contentRaw, '已自动更新用户认证：') === 0 ||
                            strpos($contentRaw, '已增加 ') === 0 ||
                            strpos($contentRaw, '已减少 ') === 0 ||
                            strpos($contentRaw, '该工单被系统判定为无意义') === 0 ||
                            strpos($contentRaw, '工单已自动指派给') === 0 ||
                            strpos($contentRaw, '工单已由 AI 重新指派给') === 0
                        );
                        $itemClass = $isAutoReply ? 'reply-item reply-auto' : 'reply-item';
                    ?>
                        <div class="<?=$itemClass?>">
                            <div class="reply-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                                <span class="reply-avatar">
                                    <?php if (!empty($rep['avatar'])): ?>
                                        <img src="<?=getImgUrl($rep['avatar'])?>" alt="avatar">
                                    <?php else: ?>
                                        <?=getFirstChar($rep['name'])?>
                                    <?php endif; ?>
                                </span>
                                <a href="https://lmtoj.cn/user/<?=$uid?>" class="ben-name<?= $disp['isColorful'] ? ' colorful' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="color: ' . $disp['color'] . ';"' ?>>
                                    <?=safeContent($rep['name'])?>
                                </a>
                                <?php if($disp['tag']): ?>
                                    <span class="tag<?= $disp['isColorful'] ? ' colorful-bg' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="background: ' . $disp['color'] . ';"' ?>>
                                        <?=safeContent($disp['tag'])?>
                                    </span>
                                <?php endif; ?>
                                · <?=beijingTime($rep['create_time'])?>
                                <?php if ($is_admin || $uid == $login_uid): ?>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                                        <input type="hidden" name="del_rid" value="<?=$rep['id']?>">
                                        <button type="submit" class="btn-sm btn-danger">删除</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <?php if ($isAutoReply): ?>
                                <?php if (strpos($contentRaw, '将工单状态设为') === 0): $prefix = '将工单状态设为'; $stateName = mb_substr($contentRaw, mb_strlen($prefix)); $pureState = rtrim($stateName, '。'); $tagStyle = ''; foreach ($statusConfig as $cfg) { if ($cfg['name'] . '。' === $stateName) { $tagStyle = 'color:' . $cfg['color'] . ';background:' . $cfg['bg'] . ';'; break; } } ?>
                                    <div class="md-content"><?= safeContent($prefix) ?> <span class="status-tag" style="<?=$tagStyle?>"><?= safeContent($pureState) ?></span>。</div>
                                <?php else: ?>
                                    <div class="md-content"><em><?= safeContent($contentRaw) ?></em></div>
                                <?php endif; ?>
                            <?php else: ?>
                                <div class="md-content" data-raw="<?=safeContent($contentRaw)?>"></div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if($totalPage > 1): ?>
                <div class="page-bar">
                    <?php if($page > 1): ?><a href="https://lmtoj.cn/ticket/<?=$tid?>?page=<?=$page-1?>">上一页</a><?php endif; ?>
                    <?php $shown = [1]; for($i=max(2,$page-2); $i<=min($totalPage-1,$page+2); $i++) $shown[]=$i; if($totalPage>1) $shown[]=$totalPage; $shown=array_unique($shown); sort($shown); $prev=0;
                    foreach($shown as $i): if($i-$prev>1) echo '<span class="page-ellipsis">...</span>'; ?>
                        <a href="https://lmtoj.cn/ticket/<?=$tid?>?page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a>
                    <?php $prev=$i; endforeach; ?>
                    <?php if($page<$totalPage): ?><a href="https://lmtoj.cn/ticket/<?=$tid?>?page=<?=$page+1?>">下一页</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="card">
                <h3>发表回复</h3>
                <?php if ($userJinyan == 1): ?>
                    <p style="color:var(--danger);">您已被禁言，无法发表回复。</p>
                <?php else: ?>
                <?php if ($is_admin && $tid > 0 && $login_uid != 8): ?>
                <div style="margin-bottom:12px;">
                    <span style="font-weight:500;margin-right:10px;">快捷回复：</span>
                    <?php foreach ([1=>'无意义',2=>'啥标题',3=>'交过了',4=>'好建议',5=>'板块错',6=>'是特性',7=>'说明白',8=>'没道理',9=>'加过估'] as $k=>$label): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="quick_reply" value="1">
                            <input type="hidden" name="quick_type" value="<?=$k?>">
                            <button type="submit" class="btn-sm" style="background:#5a9e6f;color:#fff;"><?=$label?></button>
                        </form>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <?php if ($is_admin && $tid > 0 && $login_uid == 8): ?>
                <div style="margin-bottom:12px;">
                    <span style="font-weight:500;margin-right:10px;">快捷回复：</span>
                    <?php foreach ([1=>'何意味',2=>'写好点',3=>'眼睛瞎',4=>'彳亍',5=>'没脑子',6=>'就这样',7=>'打几个字不能死'] as $k=>$label): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="quick_reply" value="1">
                            <input type="hidden" name="quick_type" value="<?=$k?>">
                            <button type="submit" class="btn-sm" style="background:#5a9e6f;color:#fff;"><?=$label?></button>
                        </form>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <form method="post" id="replyForm">
                    <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                    <div class="edit-wrap">
                        <div class="edit-box"><textarea id="replyEditor" name="reply_content" placeholder="支持 Markdown / LaTeX 公式、@用户名" required></textarea></div>
                        <div class="preview-box" id="replyPreview">预览区域</div>
                    </div>
                    <button type="submit" id="replySubmitBtn">提交回复</button>
                </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>
<script>
const md = window.markdownit({html: false, linkify: true, typographer: true, breaks: true});
const workTemplate = {1:"原因说明：",
                      2:"问题/建议描述：\n\n复现步骤（如为建议请忽略）：",
                      3:"",
                      4:"题目 ID：\n\n问题描述：",
                      5:"",
                      6:"",
                      7:"撤销对象：\n\n原因：",
                      8:"【更新内容】\n\n"};
const nameToUid = <?= json_encode($nameToUid, JSON_UNESCAPED_UNICODE) ?>;
const allUsers = <?= json_encode($usersList, JSON_UNESCAPED_UNICODE) ?>;

function replaceAtUser(text) {
    return text.replace(/(^|[ \t\n\r\f,.;:!?()\[\]{}<>，。、；：！？])@([\w_\u4e00-\u9fa5]+)/g, function(m, prefix, userName) {
        if (nameToUid[userName]) return prefix + '[@' + userName + '](https://lmtoj.cn/user/' + nameToUid[userName] + ')';
        return m;
    });
}
function renderMdLatex(raw) { return md.render(replaceAtUser(raw)); }

function renderAllContent() {
    document.querySelectorAll('.md-content').forEach(function(el) {
        var raw = el.dataset.raw;
        if (!raw) return;
        var textarea = document.createElement('textarea');
        textarea.innerHTML = raw;
        el.innerHTML = renderMdLatex(textarea.value);
    });
    if (typeof renderMathInElement !== 'undefined') {
        renderMathInElement(document.body, {delimiters: [{left:"$$",right:"$$",display:true},{left:"$",right:"$",display:false},{left:"\\[",right:"\\]",display:true},{left:"\\(",right:"\\)",display:false}],throwOnError:false});
    }
}

function initUserSelect(containerId, inputId, hiddenName, optionsId) {
    const container = document.getElementById(containerId);
    if (!container) return;
    const input = document.getElementById(inputId);
    const hidden = container.querySelector('input[name="' + hiddenName + '"]');
    const list = document.getElementById(optionsId);
    function renderOptions(filter = '') {
        filter = filter || '';
        let html = '<li data-uid="0" data-name="">全部</li>';
        allUsers.filter(u => u.name.includes(filter) || String(u.uid).includes(filter)).forEach(u => {
            html += '<li data-uid="' + u.uid + '" data-name="' + u.name.replace(/'/g,"\\'") + '">' + u.name + ' (UID: ' + u.uid + ')</li>';
        });
        list.innerHTML = html;
    }
    input.addEventListener('focus', () => { renderOptions(input.value); list.style.display = 'block'; });
    input.addEventListener('input', () => { renderOptions(input.value); list.style.display = 'block'; });
    document.addEventListener('click', (e) => { if (!container.contains(e.target)) list.style.display = 'none'; });
    list.addEventListener('click', (e) => {
        const li = e.target.closest('li');
        if(!li) return;
        hidden.value = li.dataset.uid;
        input.value = li.dataset.name;
        list.style.display = 'none';
    });
    renderOptions();
}

function bindSyncScroll(editor, preview) {
    const updatePreview = () => {
        preview.innerHTML = renderMdLatex(editor.value) || "预览区域";
        if (window.renderMathInElement) renderMathInElement(preview, {delimiters:[{left:"$$",right:"$$",display:true},{left:"$",right:"$",display:false}],throwOnError:false});
    };
    updatePreview();
    editor.addEventListener('input', updatePreview);
    editor.addEventListener('scroll', () => { preview.scrollTop = (editor.scrollTop/(editor.scrollHeight-editor.clientHeight))*(preview.scrollHeight-preview.clientHeight); });
    preview.addEventListener('scroll', () => { editor.scrollTop = (preview.scrollTop/(preview.scrollHeight-preview.clientHeight))*(editor.scrollHeight-editor.clientHeight); });
}

function updateCertLevels() {
    const typeSelect = document.getElementById('certTypeSelect');
    const levelSelect = document.getElementById('certLevelSelect');
    if (!typeSelect || !levelSelect) return;
    const type = typeSelect.value;
    levelSelect.innerHTML = '<option value="">--请选择--</option>';
    if (type === 'OI') {
        for (let i = 3; i <= 10; i++) {
            levelSelect.innerHTML += `<option value="${i}">${i}</option>`;
        }
    }
}

window.addEventListener('DOMContentLoaded', () => {
    const editToggle = document.getElementById('editToggleBtn');
    const editArea = document.getElementById('editArea');
    if (editToggle && editArea) {
        editToggle.addEventListener('click', function() {
            editArea.classList.toggle('show');
            this.textContent = editArea.classList.contains('show') ? '收起编辑' : '开始编辑';
        });
        editArea.classList.remove('show');
    }

    renderAllContent();
    (function() {
        const container = document.getElementById('assigneeSelect');
        if (!container) return;
        const input = container.querySelector('input[type="text"]');
        const hidden = container.querySelector('input[type="hidden"]');
        const list = container.querySelector('.options');
        function renderOptions(filter = '') {
            let html = '<li data-uid="0" data-name="未指派" class="' + (hidden.value == 0 ? 'selected' : '') + '">未指派</li>';
            allUsers.filter(u => u.name.includes(filter) || String(u.uid).includes(filter)).forEach(u => {
                html += '<li data-uid="' + u.uid + '" data-name="' + u.name.replace(/'/g,"\\'") + '" class="' + (hidden.value == u.uid ? 'selected' : '') + '">' + u.name + ' (UID: ' + u.uid + ')</li>';
            });
            list.innerHTML = html;
        }
        input.addEventListener('focus', () => { renderOptions(input.value); list.style.display = 'block'; });
        input.addEventListener('input', () => { renderOptions(input.value); list.style.display = 'block'; });
        document.addEventListener('click', (e) => { if (!container.contains(e.target)) list.style.display = 'none'; });
        list.addEventListener('click', (e) => {
            const li = e.target.closest('li');
            if(!li) return;
            hidden.value = li.dataset.uid;
            input.value = li.dataset.name;
            list.style.display = 'none';
        });
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                document.getElementById('assignConfirmBtn')?.click();
            }
        });
        document.getElementById('assignConfirmBtn').addEventListener('click', function() {
            document.getElementById('assignForm').submit();
        });
        renderOptions();
    })();

    initUserSelect('searchAssigneeSelect', 'searchAssigneeInput', 'search_assignee', 'searchAssigneeOptions');
    initUserSelect('searchCreatorSelect', 'searchCreatorInput', 'search_creator', 'searchCreatorOptions');

    const workSelect = document.getElementById('workTypeSelect'), postEditor = document.getElementById('postEditor');
    const titleInput = document.getElementById('newTitleInput');
    const certArea = document.getElementById('certArea');
    const targetUserArea = document.getElementById('targetUserArea');
    const recommendArea = document.getElementById('recommendArea');
    const revokeAuthorArea = document.getElementById('revokeAuthorArea');

    if (workSelect && postEditor) {
        workSelect.addEventListener('change', function() {
            const val = parseInt(this.value);
            postEditor.value = workTemplate[val] || "";
            postEditor.dispatchEvent(new Event('input'));
            targetUserArea.style.display = (val == 1) ? 'block' : 'none';
            recommendArea.style.display = (val == 5) ? 'block' : 'none';
            certArea.style.display = (val == 6) ? 'block' : 'none';
            revokeAuthorArea.style.display = (val == 7) ? 'block' : 'none';
            if (val == 5) {
                titleInput.value = "申请全站推荐";
            } else if (val == 6) {
                titleInput.value = "奖项认证申请";
                updateCertLevels();
            } else if (val == 7) {
                titleInput.value = "撤销全站推荐";
            } else {
                if (["申请全站推荐","奖项认证申请","撤销全站推荐"].includes(titleInput.value)) {
                    titleInput.value = "";
                }
            }
        });
        const initVal = parseInt(workSelect.value);
        targetUserArea.style.display = (initVal == 1) ? 'block' : 'none';
        recommendArea.style.display = (initVal == 5) ? 'block' : 'none';
        certArea.style.display = (initVal == 6) ? 'block' : 'none';
        revokeAuthorArea.style.display = (initVal == 7) ? 'block' : 'none';
        if (initVal == 5) titleInput.value = "申请全站推荐";
        else if (initVal == 6) { titleInput.value = "奖项认证申请"; updateCertLevels(); }
        else if (initVal == 7) titleInput.value = "撤销全站推荐";
        postEditor.value = workTemplate[initVal] || "";
        postEditor.dispatchEvent(new Event('input'));
    }
    const postPreview = document.getElementById('postPreview'); if (postEditor && postPreview) bindSyncScroll(postEditor, postPreview);
    const editEditor = document.getElementById('editEditor'), editPreview = document.getElementById('editPreview'); if (editEditor && editPreview) bindSyncScroll(editEditor, editPreview);
    const replyEditor = document.getElementById('replyEditor'), replyPreview = document.getElementById('replyPreview'); if (replyEditor && replyPreview) bindSyncScroll(replyEditor, replyPreview);

    (function() {
        const container = document.getElementById('targetUserSelect');
        if (!container) return;
        const input = document.getElementById('targetSearchInput');
        const hidden = document.getElementById('targetUidHidden');
        const list = document.getElementById('targetOptions');
        function renderTargetOptions(filter) {
            filter = filter || '';
            let html = '<li data-uid="0" data-name="未选择">未选择</li>';
            allUsers.filter(function(u) { return u.name.includes(filter) || String(u.uid).includes(filter); }).forEach(function(u) {
                html += '<li data-uid="' + u.uid + '" data-name="' + u.name.replace(/'/g,"\\'") + '">' + u.name + ' (UID: ' + u.uid + ')</li>';
            });
            list.innerHTML = html;
        }
        input.addEventListener('focus', function() { renderTargetOptions(input.value); list.style.display = 'block'; });
        input.addEventListener('input', function() { renderTargetOptions(input.value); list.style.display = 'block'; });
        document.addEventListener('click', function(e) { if (!container.contains(e.target)) list.style.display = 'none'; });
        list.addEventListener('click', function(e) {
            var li = e.target.closest('li');
            if (!li) return;
            hidden.value = li.dataset.uid;
            input.value = li.dataset.name;
            list.style.display = 'none';
        });
        renderTargetOptions();
    })();

    const certTypeSelect = document.getElementById('certTypeSelect');
    if (certTypeSelect) {
        certTypeSelect.addEventListener('change', updateCertLevels);
    }

    (function() {
        const container = document.getElementById('revokeAuthorSelect');
        if (!container) return;
        const input = document.getElementById('revokeAuthorInput');
        const hidden = document.getElementById('revokeAuthorUidHidden');
        const list = document.getElementById('revokeAuthorOptions');
        function renderRevokeOptions(filter) {
            filter = filter || '';
            let html = '<li data-uid="0" data-name="未选择">未选择</li>';
            allUsers.filter(u => u.name.includes(filter) || String(u.uid).includes(filter)).forEach(u => {
                html += '<li data-uid="' + u.uid + '" data-name="' + u.name.replace(/'/g,"\\'") + '">' + u.name + ' (UID: ' + u.uid + ')</li>';
            });
            list.innerHTML = html;
        }
        input.addEventListener('focus', function() { renderRevokeOptions(input.value); list.style.display = 'block'; });
        input.addEventListener('input', function() { renderRevokeOptions(input.value); list.style.display = 'block'; });
        document.addEventListener('click', function(e) { if (!container.contains(e.target)) list.style.display = 'none'; });
        list.addEventListener('click', function(e) {
            var li = e.target.closest('li');
            if (!li) return;
            hidden.value = li.dataset.uid;
            input.value = li.dataset.name;
            list.style.display = 'none';
        });
        renderRevokeOptions();
    })();
});

(function(){var f=document.getElementById('newTicketForm'),b=document.getElementById('submitBtn');if(f&&b){f.addEventListener('submit',function(){setTimeout(function(){b.disabled=true;b.innerText='提交中...';},10);setTimeout(function(){b.disabled=false;b.innerText='提交工单';},2000);});}})();
(function(){var f=document.getElementById('editForm'),b=document.getElementById('editSubmitBtn');if(f&&b){f.addEventListener('submit',function(){setTimeout(function(){b.disabled=true;b.innerText='保存中...';},10);setTimeout(function(){b.disabled=false;b.innerText='保存修改';},2000);});}})();
(function(){var f=document.getElementById('replyForm'),b=document.getElementById('replySubmitBtn');if(f&&b){f.addEventListener('submit',function(){setTimeout(function(){b.disabled=true;b.innerText='提交中...';},10);setTimeout(function(){b.disabled=false;b.innerText='提交回复';},2000);});}})();
</script>
<?php require_once __DIR__ . '/event_effect.php'; ?>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>