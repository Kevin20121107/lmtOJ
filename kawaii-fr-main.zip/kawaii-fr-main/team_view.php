<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 积分颜色辅助函数（与 benben.php 一致） ----------
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getColorName($totalScore, $isAdmin) {
    if ($isAdmin) return 'purple';
    if ($totalScore < 0) return 'brown';
    if ($totalScore <= 10) return 'gray';
    if ($totalScore <= 20) return 'blue';
    if ($totalScore <= 45) return 'green';
    if ($totalScore <= 65) return 'orange';
    return 'red';
}

function getUserDisplay($user, $login_uid, $myShowColorful) {
    $uid = (int)($user['uid'] ?? 0);
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    $admin = (int)($user['admin'] ?? 0);
    $color = getColorByTotalScore($total, $admin);
    $colorName = getColorName($total, $admin);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    $isColorful = false;
    if ($uid == $login_uid) {
        $isColorful = $targetColorful;
    } else {
        $isColorful = $targetColorful && $myShowColorful;
    }
    return [
        'color'      => $color,
        'colorName'  => $colorName,
        'isColorful' => $isColorful,
        'tag'        => $user['tag'] ?? '',
        'admin'      => $admin
    ];
}

// ---------- 自动建表/补字段 ----------
$conn->query("CREATE TABLE IF NOT EXISTS teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    owner_uid INT NOT NULL,
    announcement TEXT DEFAULT NULL,
    banned TINYINT DEFAULT 0,
    allow_join TINYINT DEFAULT 1,
    join_approval TINYINT DEFAULT 1 COMMENT '0=无需审核直接加入, 1=需要审核',
    min_level VARCHAR(20) DEFAULT '' COMMENT '等级要求: brown, blue, green, orange, red, purple',
    blacklist TEXT DEFAULT NULL COMMENT '黑名单UID列表, 逗号分隔',
    notify_on_apply TINYINT DEFAULT 1 COMMENT '1=申请时通知管理员, 0=免打扰',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX(owner_uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 检查并添加缺失字段
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'announcement'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN announcement TEXT DEFAULT NULL");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'banned'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN banned TINYINT DEFAULT 0");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'allow_join'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN allow_join TINYINT DEFAULT 1");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'join_approval'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN join_approval TINYINT DEFAULT 1");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'min_level'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN min_level VARCHAR(20) DEFAULT ''");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'blacklist'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN blacklist TEXT DEFAULT NULL");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'notify_on_apply'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN notify_on_apply TINYINT DEFAULT 1");
$colCheck = $conn->query("SHOW COLUMNS FROM teams LIKE 'discuss_cate'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE teams ADD COLUMN discuss_cate INT UNIQUE");

// 团队讨论相关表
$conn->query("CREATE TABLE IF NOT EXISTS team_topics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status TINYINT DEFAULT 0 COMMENT '0=正常,1=置顶,2=关闭',
    INDEX(team_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS team_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    topic_id INT NOT NULL,
    uid INT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(topic_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS team_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    name VARCHAR(50) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(team_id),
    UNIQUE KEY (team_id, name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS team_member_groups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    group_id INT NOT NULL,
    UNIQUE KEY (team_id, uid, group_id),
    INDEX(group_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 团队成员表（含 note） ----------
$conn->query("CREATE TABLE IF NOT EXISTS team_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    role ENUM('member', 'admin') DEFAULT 'member',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    note TEXT DEFAULT NULL,
    UNIQUE KEY unique_member (team_id, uid),
    INDEX(team_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$colCheck = $conn->query("SHOW COLUMNS FROM team_members LIKE 'note'");
if ($colCheck->num_rows == 0) $conn->query("ALTER TABLE team_members ADD COLUMN note TEXT DEFAULT NULL");

$conn->query("CREATE TABLE IF NOT EXISTS team_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_id INT NOT NULL,
    uid INT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP NULL,
    INDEX(team_id),
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 登录检查 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

$login_uid = (int)$_SESSION['uid'];
$userInfo = $conn->query("SELECT admin, sqadmin, name FROM users WHERE uid = $login_uid")->fetch_assoc();
$is_admin = (int)($userInfo['admin'] ?? 0);
$is_sqadmin = (int)($userInfo['sqadmin'] ?? 0);
$login_name = $userInfo['name'] ?? '';

$team_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($team_id <= 0) {
    header("Location: https://lmtoj.cn/team");
    exit;
}

$myShowColorful = 1;
$showPrefRes = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($showPrefRes && $showPrefRes->num_rows > 0) {
    $myShowColorful = (int)($showPrefRes->fetch_assoc()['show_colorful_names']);
}

// 未读消息数
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

// ---------- 辅助函数 ----------
function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function getTeamRole($conn, $team_id, $uid) {
    $stmt = $conn->prepare("SELECT role FROM team_members WHERE team_id = ? AND uid = ?");
    $stmt->bind_param("ii", $team_id, $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($row = $res->fetch_assoc()) {
        return $row['role'];
    }
    return null;
}

function isTeamOwner($conn, $team_id, $uid) {
    $stmt = $conn->prepare("SELECT 1 FROM teams WHERE id = ? AND owner_uid = ?");
    $stmt->bind_param("ii", $team_id, $uid);
    $stmt->execute();
    return $stmt->get_result()->num_rows > 0;
}

function canManageTeam($conn, $team_id, $uid, $is_sqadmin = false) {
    return isTeamOwner($conn, $team_id, $uid) || $is_sqadmin || getTeamRole($conn, $team_id, $uid) === 'admin';
}

// ---------- 获取团队信息 ----------
$teamInfo = null;
$members = [];
$isOwner = false;
$userRole = null;
$canManage = false;
$pendingRequests = [];
$msg = '';
$error = '';

$stmt = $conn->prepare("SELECT t.*, u.name AS owner_name FROM teams t LEFT JOIN users u ON t.owner_uid = u.uid WHERE t.id = ?");
$stmt->bind_param("i", $team_id);
$stmt->execute();
$res = $stmt->get_result();
if ($res->num_rows == 0) {
    header("Location: https://lmtoj.cn/team");
    exit;
}
$teamInfo = $res->fetch_assoc();
$stmt->close();

// 封禁检查
if ($teamInfo['banned'] == 1 && !$is_admin) {
    header("Location: https://lmtoj.cn/404");
    exit;
}

// 成员列表（含积分字段用于颜色）
$memberStmt = $conn->prepare("
    SELECT m.*, u.name, u.admin, u.tag,
           u.practice_score, u.contribute_score, u.contest_score,
           u.base_credit, u.valuation, u.username_color,
           u.cert_type, u.cert_level
    FROM team_members m
    LEFT JOIN users u ON m.uid = u.uid
    WHERE m.team_id = ?
    ORDER BY m.role DESC, u.name ASC
");
$memberStmt->bind_param("i", $team_id);
$memberStmt->execute();
$memberRes = $memberStmt->get_result();
while ($row = $memberRes->fetch_assoc()) {
    $row['display'] = getUserDisplay($row, $login_uid, 1);
    $members[] = $row;
}
$memberStmt->close();

$userRole = getTeamRole($conn, $team_id, $login_uid);
$isOwner = isTeamOwner($conn, $team_id, $login_uid);
$canManage = $isOwner || ($userRole === 'admin') || $is_sqadmin;

if ($canManage) {
    $reqStmt = $conn->prepare("
        SELECT r.*, u.name
        FROM team_requests r
        LEFT JOIN users u ON r.uid = u.uid
        WHERE r.team_id = ? AND r.status = 'pending'
        ORDER BY r.created_at ASC
    ");
    $reqStmt->bind_param("i", $team_id);
    $reqStmt->execute();
    $reqRes = $reqStmt->get_result();
    while ($row = $reqRes->fetch_assoc()) {
        $pendingRequests[] = $row;
    }
    $reqStmt->close();
}

$canEditTeam = $isOwner || $is_sqadmin;

// ---------- 处理操作 ----------
// 申请加入
if (isset($_GET['request_join'])) {
    if ($teamInfo['allow_join'] == 0) {
        $error = "该团队暂不允许加入。";
    } elseif ($teamInfo['banned'] == 1) {
        $error = "该团队已被封禁，无法加入。";
    } else {
        // 获取申请人的积分信息
        $userData = $conn->query("SELECT uid, admin, practice_score, contribute_score, contest_score, base_credit, valuation, username_color, cert_type, cert_level FROM users WHERE uid = $login_uid")->fetch_assoc();
        if (!$userData) {
            $error = "用户不存在";
        } else {
            // 计算颜色等级
            $base = (int)($userData['base_credit'] ?? 10);
            $achieve = min(getAchievementScore($userData['cert_type'] ?? '', (int)($userData['cert_level'] ?? 0)), 20);
            $practice = min((int)($userData['practice_score'] ?? 0), 20);
            $contribute = min((int)($userData['contribute_score'] ?? 0), 30);
            $contest = min((int)($userData['contest_score'] ?? 0), 20);
            $valuation = (int)($userData['valuation'] ?? 0);
            $isBrown = ($valuation === -1);
            $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
            $isAdmin = (int)($userData['admin'] ?? 0);
            $colorName = getColorName($total, $isAdmin);

            // 检查黑名单
            $blacklist = array_filter(array_map('trim', explode(',', $teamInfo['blacklist'] ?? '')));
            if (in_array($login_uid, $blacklist)) {
                $error = "你已被拉黑";   // ★ 修复提示语
            } else {
                // 检查等级
                $minLevel = $teamInfo['min_level'] ?? '';
                $passLevel = true;
                if (!empty($minLevel)) {
                    $levelOrder = ['brown'=>0, 'gray'=>1, 'blue'=>2, 'green'=>3, 'orange'=>4, 'red'=>5, 'purple'=>6];
                    $currentLevel = $levelOrder[$colorName] ?? -1;
                    $requiredLevel = $levelOrder[$minLevel] ?? -1;
                    if ($requiredLevel > 0 && $currentLevel < $requiredLevel) {
                        $passLevel = false;
                    }
                    if ($minLevel === 'purple' && !$isAdmin) {
                        $passLevel = false;
                    }
                }
                if (!$passLevel) {
                    $error = "你不满足该团队加入条件";   // ★ 修复提示语
                } else {
                    $checkMember = $conn->prepare("SELECT id FROM team_members WHERE team_id = ? AND uid = ?");
                    $checkMember->bind_param("ii", $team_id, $login_uid);
                    $checkMember->execute();
                    if ($checkMember->get_result()->num_rows > 0) {
                        $msg = "您已是团队成员。";
                    } else {
                        if ($teamInfo['join_approval'] == 0) {
                            // 无需审核：直接加入
                            $ins = $conn->prepare("INSERT INTO team_members (team_id, uid, role) VALUES (?, ?, 'member')");
                            $ins->bind_param("ii", $team_id, $login_uid);
                            $ins->execute();
                            $ins->close();
                            $msg = "您已成功加入团队！";
                            header("Location: https://lmtoj.cn/team/$team_id");
                            exit;
                        } else {
                            // 需要审核：检查是否已有待处理申请
                            $checkReq = $conn->prepare("SELECT id FROM team_requests WHERE team_id = ? AND uid = ? AND status = 'pending'");
                            $checkReq->bind_param("ii", $team_id, $login_uid);
                            $checkReq->execute();
                            if ($checkReq->get_result()->num_rows > 0) {
                                $msg = "您已提交过申请，请等待审批。";
                            } else {
                                $insReq = $conn->prepare("INSERT INTO team_requests (team_id, uid) VALUES (?, ?)");
                                $insReq->bind_param("ii", $team_id, $login_uid);
                                $insReq->execute();
                                $insReq->close();

                                // 根据 notify_on_apply 决定是否发送通知
                                if ($teamInfo['notify_on_apply'] == 1) {
                                    // 发送通知给所有者和管理员
                                    $notifyUsers = [];
                                    $ownerRes = $conn->query("SELECT owner_uid FROM teams WHERE id = $team_id")->fetch_assoc();
                                    if ($ownerRes) $notifyUsers[] = (int)$ownerRes['owner_uid'];
                                    $adminRes = $conn->query("SELECT uid FROM team_members WHERE team_id = $team_id AND role = 'admin'");
                                    while ($row = $adminRes->fetch_assoc()) {
                                        $notifyUsers[] = (int)$row['uid'];
                                    }
                                    $notifyUsers = array_unique($notifyUsers);
                                    $teamName = $teamInfo['name'] ?? "团队#$team_id";
                                    $now = date('Y-m-d H:i:s');
                                    foreach ($notifyUsers as $uid) {
                                        if ($uid == $login_uid) continue;
                                        $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'team_apply', ?, 0)");
                                        $nIns->bind_param("iiiss", $uid, $login_uid, $team_id, $teamName, $now);
                                        $nIns->execute();
                                        $nIns->close();
                                    }
                                }
                                $msg = "申请已提交，请等待审批。";
                            }
                            $checkReq->close();
                        }
                    }
                    $checkMember->close();
                }
            }
        }
    }
    header("Location: https://lmtoj.cn/team/$team_id");
    exit;
}

// 处理申请（批准/拒绝）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['handle_request'])) {
    if (!canManageTeam($conn, $team_id, $login_uid, $is_sqadmin)) {
        $error = "您没有权限处理申请";
    } else {
        $request_id = (int)$_POST['request_id'];
        $actionReq = $_POST['action_req'];
        $stmt = $conn->prepare("SELECT uid FROM team_requests WHERE id = ? AND team_id = ? AND status = 'pending'");
        $stmt->bind_param("ii", $request_id, $team_id);
        $stmt->execute();
        $req = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$req) {
            $error = "申请不存在或已处理";
        } else {
            $target_uid = $req['uid'];
            $conn->begin_transaction();
            try {
                if ($actionReq === 'approve') {
                    $ins = $conn->prepare("INSERT INTO team_members (team_id, uid, role) VALUES (?, ?, 'member')");
                    $ins->bind_param("ii", $team_id, $target_uid);
                    $ins->execute();
                    $ins->close();
                    $upd = $conn->prepare("UPDATE team_requests SET status = 'approved', processed_at = NOW() WHERE id = ?");
                    $upd->bind_param("i", $request_id);
                    $upd->execute();
                    $upd->close();
                    $teamName = $teamInfo['name'] ?? "团队#$team_id";
                    $now = date('Y-m-d H:i:s');
                    $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'team_approved', ?, 0)");
                    $nIns->bind_param("iiiss", $target_uid, $login_uid, $team_id, $teamName, $now);
                    $nIns->execute();
                    $nIns->close();
                    $msg = "申请已批准，用户已加入团队。";
                } else {
                    $upd = $conn->prepare("UPDATE team_requests SET status = 'rejected', processed_at = NOW() WHERE id = ?");
                    $upd->bind_param("i", $request_id);
                    $upd->execute();
                    $upd->close();
                    $teamName = $teamInfo['name'] ?? "团队#$team_id";
                    $now = date('Y-m-d H:i:s');
                    $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, 'team_rejected', ?, 0)");
                    $nIns->bind_param("iiiss", $target_uid, $login_uid, $team_id, $teamName, $now);
                    $nIns->execute();
                    $nIns->close();
                    $msg = "申请已拒绝。";
                }
                $conn->commit();
                header("Location: https://lmtoj.cn/team/$team_id");
                exit;
            } catch (Exception $e) {
                $conn->rollback();
                $error = "操作失败：" . $e->getMessage();
            }
        }
    }
}

// 退出团队
if (isset($_GET['leave'])) {
    if ($teamInfo['banned'] == 1) {
        $error = "该团队已被封禁，无法退出？(请联系管理员)";
    } else {
        if (isTeamOwner($conn, $team_id, $login_uid)) {
            $error = "团队所有者不能直接退出，请先转让所有权。";
        } else {
            $del = $conn->prepare("DELETE FROM team_members WHERE team_id = ? AND uid = ?");
            $del->bind_param("ii", $team_id, $login_uid);
            $del->execute();
            $del->close();
            $msg = "已退出团队。";
            header("Location: https://lmtoj.cn/team");
            exit;
        }
    }
}

// 编辑团队
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_team'])) {
    if (!isTeamOwner($conn, $team_id, $login_uid) && !$is_sqadmin) {
        $error = "您没有权限编辑此团队";
    } else {
        $new_name = trim($_POST['name']);
        $new_announcement = trim($_POST['announcement']);
        $new_allow_join = (int)($_POST['allow_join'] ?? 1);
        $new_join_approval = (int)($_POST['join_approval'] ?? 1);
        $new_min_level = trim($_POST['min_level'] ?? '');
        $new_blacklist = trim($_POST['blacklist'] ?? '');
        // ★ 修复：checkbox 未勾选时为 0
        $new_notify_on_apply = isset($_POST['notify_on_apply']) ? 1 : 0;
        // 清理黑名单
        $blacklist_arr = array_filter(array_map('trim', preg_split('/[\s,]+/', $new_blacklist)));
        $new_blacklist = implode(',', $blacklist_arr);

        if (empty($new_name)) {
            $error = "团队名称不能为空";
        } elseif (strlen($new_name) > 100) {
            $error = "团队名称过长（最大100字符）";
        } else {
            $check = $conn->prepare("SELECT id FROM teams WHERE name = ? AND id != ?");
            $check->bind_param("si", $new_name, $team_id);
            $check->execute();
            if ($check->get_result()->num_rows > 0) {
                $error = "该名称已被其他团队使用";
            } else {
                $upd = $conn->prepare("UPDATE teams SET name = ?, announcement = ?, allow_join = ?, join_approval = ?, min_level = ?, blacklist = ?, notify_on_apply = ? WHERE id = ?");
                $upd->bind_param("ssiisssi", $new_name, $new_announcement, $new_allow_join, $new_join_approval, $new_min_level, $new_blacklist, $new_notify_on_apply, $team_id);
                $upd->execute();
                $upd->close();
                $teamInfo['name'] = $new_name;
                $teamInfo['announcement'] = $new_announcement;
                $teamInfo['allow_join'] = $new_allow_join;
                $teamInfo['join_approval'] = $new_join_approval;
                $teamInfo['min_level'] = $new_min_level;
                $teamInfo['blacklist'] = $new_blacklist;
                $teamInfo['notify_on_apply'] = $new_notify_on_apply;
                $msg = "团队信息已更新。";
                header("Location: https://lmtoj.cn/team/$team_id");
                exit;
            }
            $check->close();
        }
    }
}

// 封禁/解封
if (isset($_GET['toggle_ban']) && $is_admin) {
    $new_ban = $teamInfo['banned'] == 1 ? 0 : 1;
    $upd = $conn->prepare("UPDATE teams SET banned = ? WHERE id = ?");
    $upd->bind_param("ii", $new_ban, $team_id);
    $upd->execute();
    $upd->close();
    $msg = $new_ban ? "团队已被封禁。" : "团队已解封。";
    header("Location: https://lmtoj.cn/team/$team_id");
    exit;
}

// 转让所有权
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['transfer_owner'])) {
    if (!isTeamOwner($conn, $team_id, $login_uid)) {
        $error = "只有所有者可以转让所有权";
    } else {
        $new_owner = (int)$_POST['new_owner'];
        if ($new_owner == $login_uid) {
            $error = "不能转让给自己";
        } else {
            $check = $conn->prepare("SELECT id FROM team_members WHERE team_id = ? AND uid = ?");
            $check->bind_param("ii", $team_id, $new_owner);
            $check->execute();
            if ($check->get_result()->num_rows == 0) {
                $error = "新所有者必须是团队成员";
            } else {
                $conn->begin_transaction();
                try {
                    $upd = $conn->prepare("UPDATE teams SET owner_uid = ? WHERE id = ?");
                    $upd->bind_param("ii", $new_owner, $team_id);
                    $upd->execute();
                    $upd->close();
                    $upd2 = $conn->prepare("UPDATE team_members SET role = 'admin' WHERE team_id = ? AND uid = ?");
                    $upd2->bind_param("ii", $team_id, $new_owner);
                    $upd2->execute();
                    $upd2->close();
                    $conn->commit();
                    $msg = "所有权已转让。";
                    header("Location: https://lmtoj.cn/team/$team_id");
                    exit;
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = "转让失败：" . $e->getMessage();
                }
            }
            $check->close();
        }
    }
}

// 设置成员角色
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_role'])) {
    $target_uid = (int)$_POST['target_uid'];
    $new_role = $_POST['role'] ?? 'member';
    if (!in_array($new_role, ['member', 'admin'])) {
        $error = "无效角色";
    } else {
        $role = getTeamRole($conn, $team_id, $login_uid);
        $isOwner = isTeamOwner($conn, $team_id, $login_uid);
        if (!$isOwner && $role !== 'admin') {
            $error = "您没有权限管理此团队";
        } else {
            $targetRole = getTeamRole($conn, $team_id, $target_uid);
            if (!$targetRole) {
                $error = "目标用户不是团队成员";
            } else {
                if (!$isOwner) {
                    if ($target_uid == $login_uid) {
                        $error = "您不能修改自己的角色";
                    } elseif (isTeamOwner($conn, $team_id, $target_uid) || $targetRole === 'admin') {
                        $error = "管理员不能修改其他管理员或所有者的角色";
                    }
                }
                if (!$error) {
                    $upd = $conn->prepare("UPDATE team_members SET role = ? WHERE team_id = ? AND uid = ?");
                    $upd->bind_param("sii", $new_role, $team_id, $target_uid);
                    $upd->execute();
                    $upd->close();
                    $msg = "角色已更新。";
                    header("Location: https://lmtoj.cn/team/$team_id");
                    exit;
                }
            }
        }
    }
}

// 移除成员
if (isset($_GET['remove'])) {
    $target_uid = (int)$_GET['remove'];
    $isOwner = isTeamOwner($conn, $team_id, $login_uid);
    $role = getTeamRole($conn, $team_id, $login_uid);
    if (!$isOwner && $role !== 'admin') {
        $error = "您没有权限移除成员";
    } else {
        if (isTeamOwner($conn, $team_id, $target_uid)) {
            $error = "不能移除团队所有者";
        } elseif ($target_uid == $login_uid && !$isOwner) {
            $error = "您不能移除自己（请使用退出功能）";
        } else {
            if (!$isOwner && getTeamRole($conn, $team_id, $target_uid) === 'admin') {
                $error = "管理员不能移除其他管理员";
            } else {
                $del = $conn->prepare("DELETE FROM team_members WHERE team_id = ? AND uid = ?");
                $del->bind_param("ii", $team_id, $target_uid);
                $del->execute();
                $del->close();
                $msg = "成员已移除。";
                header("Location: https://lmtoj.cn/team/$team_id");
                exit;
            }
        }
    }
}

// 编辑成员备注
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_note'])) {
    $target_uid = (int)$_POST['target_uid'];
    $new_note = trim($_POST['note'] ?? '');
    if (!canManageTeam($conn, $team_id, $login_uid, $is_sqadmin)) {
        $error = "您没有权限修改备注";
    } else {
        $check = $conn->prepare("SELECT id FROM team_members WHERE team_id = ? AND uid = ?");
        $check->bind_param("ii", $team_id, $target_uid);
        $check->execute();
        if ($check->get_result()->num_rows == 0) {
            $error = "该用户不是团队成员";
        } else {
            $upd = $conn->prepare("UPDATE team_members SET note = ? WHERE team_id = ? AND uid = ?");
            $upd->bind_param("sii", $new_note, $team_id, $target_uid);
            $upd->execute();
            $upd->close();
            $msg = "备注已更新。";
            header("Location: https://lmtoj.cn/team/$team_id");
            exit;
        }
        $check->close();
    }
}

// ========== 新增：讨论区逻辑 ==========
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'members';  // members, discuss, groups
$topic_id = isset($_GET['topic_id']) ? (int)$_GET['topic_id'] : 0;
$isMember = ($userRole !== null);

// 发新话题
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_topic']) && $isMember) {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    if (empty($title) || empty($content)) {
        $error = "标题和内容不能为空";
    } else {
        $ins = $conn->prepare("INSERT INTO team_topics (team_id, uid, title, content) VALUES (?, ?, ?, ?)");
        $ins->bind_param("iiss", $team_id, $login_uid, $title, $content);
        $ins->execute();
        $new_topic_id = $ins->insert_id;
        $ins->close();
        $msg = "话题发布成功！";
        header("Location: https://lmtoj.cn/team/$team_id?tab=discuss&topic_id=$new_topic_id");
        exit;
    }
}

// 回复话题
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_post']) && $isMember && $topic_id > 0) {
    $content = trim($_POST['content']);
    if (!empty($content)) {
        $ins = $conn->prepare("INSERT INTO team_posts (topic_id, uid, content) VALUES (?, ?, ?)");
        $ins->bind_param("iis", $topic_id, $login_uid, $content);
        $ins->execute();
        $ins->close();
        $msg = "回复成功！";
        header("Location: https://lmtoj.cn/team/$team_id?tab=discuss&topic_id=$topic_id");
        exit;
    }
}

// 删除话题（仅管理员、所有者、话题作者）
if (isset($_GET['del_topic']) && $isMember) {
    $del_topic = (int)$_GET['del_topic'];
    $check = $conn->prepare("SELECT uid FROM team_topics WHERE id = ? AND team_id = ?");
    $check->bind_param("ii", $del_topic, $team_id);
    $check->execute();
    $topic_owner = $check->get_result()->fetch_assoc();
    $check->close();
    if ($topic_owner && ($isOwner || $canManage || $topic_owner['uid'] == $login_uid)) {
        $del = $conn->prepare("DELETE FROM team_topics WHERE id = ?");
        $del->bind_param("i", $del_topic);
        $del->execute();
        $del->close();
        $del2 = $conn->prepare("DELETE FROM team_posts WHERE topic_id = ?");
        $del2->bind_param("i", $del_topic);
        $del2->execute();
        $del2->close();
        $msg = "话题已删除。";
    } else {
        $error = "没有权限删除该话题。";
    }
    header("Location: https://lmtoj.cn/team/$team_id?tab=discuss");
    exit;
}

// 删除回复（仅管理员、所有者、回复作者）
if (isset($_GET['del_post']) && $isMember) {
    $del_post = (int)$_GET['del_post'];
    $check = $conn->prepare("SELECT uid FROM team_posts WHERE id = ?");
    $check->bind_param("i", $del_post);
    $check->execute();
    $post_owner = $check->get_result()->fetch_assoc();
    $check->close();
    if ($post_owner && ($isOwner || $canManage || $post_owner['uid'] == $login_uid)) {
        $del = $conn->prepare("DELETE FROM team_posts WHERE id = ?");
        $del->bind_param("i", $del_post);
        $del->execute();
        $del->close();
        $msg = "回复已删除。";
    } else {
        $error = "没有权限删除该回复。";
    }
    header("Location: https://lmtoj.cn/team/$team_id?tab=discuss&topic_id=$topic_id");
    exit;
}

// ========== 新增：分组逻辑 ==========
// 创建分组
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_group']) && $canManage) {
    $group_name = trim($_POST['group_name']);
    if (empty($group_name)) {
        $error = "分组名称不能为空";
    } else {
        $ins = $conn->prepare("INSERT INTO team_groups (team_id, name) VALUES (?, ?)");
        $ins->bind_param("is", $team_id, $group_name);
        if ($ins->execute()) {
            $msg = "分组创建成功！";
        } else {
            $error = "创建失败，可能名称重复。";
        }
        $ins->close();
    }
    header("Location: https://lmtoj.cn/team/$team_id?tab=groups");
    exit;
}

// 删除分组（仅所有者或管理员）
if (isset($_GET['del_group']) && $canManage) {
    $group_id = (int)$_GET['del_group'];
    $del = $conn->prepare("DELETE FROM team_groups WHERE id = ? AND team_id = ?");
    $del->bind_param("ii", $group_id, $team_id);
    $del->execute();
    $del->close();
    // 同时删除成员关联
    $del2 = $conn->prepare("DELETE FROM team_member_groups WHERE group_id = ? AND team_id = ?");
    $del2->bind_param("ii", $group_id, $team_id);
    $del2->execute();
    $del2->close();
    $msg = "分组已删除。";
    header("Location: https://lmtoj.cn/team/$team_id?tab=groups");
    exit;
}

// 分配成员到分组（多对多）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['assign_group']) && $canManage) {
    $target_uid = (int)$_POST['target_uid'];
    $group_id = (int)$_POST['group_id'];
    // 检查目标是否为团队成员
    $check = $conn->prepare("SELECT id FROM team_members WHERE team_id = ? AND uid = ?");
    $check->bind_param("ii", $team_id, $target_uid);
    $check->execute();
    if ($check->get_result()->num_rows == 0) {
        $error = "该用户不是团队成员";
    } else {
        // 检查分组是否存在
        $check2 = $conn->prepare("SELECT id FROM team_groups WHERE id = ? AND team_id = ?");
        $check2->bind_param("ii", $group_id, $team_id);
        $check2->execute();
        if ($check2->get_result()->num_rows == 0) {
            $error = "分组不存在";
        } else {
            // 插入或忽略（防止重复）
            $ins = $conn->prepare("INSERT IGNORE INTO team_member_groups (team_id, uid, group_id) VALUES (?, ?, ?)");
            $ins->bind_param("iii", $team_id, $target_uid, $group_id);
            $ins->execute();
            $ins->close();
            $msg = "成员已分配到该分组。";
        }
        $check2->close();
    }
    $check->close();
    header("Location: https://lmtoj.cn/team/$team_id?tab=groups");
    exit;
}

// 从分组中移除成员
if (isset($_GET['remove_from_group']) && $canManage) {
    $target_uid = (int)$_GET['uid'];
    $group_id = (int)$_GET['group_id'];
    $del = $conn->prepare("DELETE FROM team_member_groups WHERE team_id = ? AND uid = ? AND group_id = ?");
    $del->bind_param("iii", $team_id, $target_uid, $group_id);
    $del->execute();
    $del->close();
    $msg = "已从分组移除。";
    header("Location: https://lmtoj.cn/team/$team_id?tab=groups");
    exit;
}

// 获取分组列表和成员分配情况
$groups = [];
if ($tab === 'groups' || $tab === 'members') {
    $gRes = $conn->query("SELECT * FROM team_groups WHERE team_id = $team_id ORDER BY name");
    while ($g = $gRes->fetch_assoc()) {
        $groups[] = $g;
    }
}
// 获取话题列表（分页）
$topicPage = isset($_GET['topic_page']) ? max(1, (int)$_GET['topic_page']) : 1;
$topicLimit = 15;
$topicOffset = ($topicPage - 1) * $topicLimit;
$topics = [];
$topicTotal = 0;
if ($tab === 'discuss' && $topic_id == 0) {
    $countSql = "SELECT COUNT(*) AS c FROM team_topics WHERE team_id = ?";
    $countStmt = $conn->prepare($countSql);
    $countStmt->bind_param("i", $team_id);
    $countStmt->execute();
    $topicTotal = $countStmt->get_result()->fetch_assoc()['c'];
    $countStmt->close();
    $topicTotalPage = ceil($topicTotal / $topicLimit);
    $tStmt = $conn->prepare("SELECT t.*, u.name FROM team_topics t LEFT JOIN users u ON t.uid = u.uid WHERE t.team_id = ? ORDER BY t.status DESC, t.created_at DESC LIMIT ?, ?");
    $tStmt->bind_param("iii", $team_id, $topicOffset, $topicLimit);
    $tStmt->execute();
    $tRes = $tStmt->get_result();
    while ($row = $tRes->fetch_assoc()) {
        // 获取回复数
        $rc = $conn->query("SELECT COUNT(*) AS cnt FROM team_posts WHERE topic_id = {$row['id']}")->fetch_assoc()['cnt'];
        $row['reply_count'] = $rc;
        $topics[] = $row;
    }
    $tStmt->close();
}

// 话题详情（含回复）
$topicDetail = null;
$topicPosts = [];
if ($topic_id > 0 && $isMember) {
    $td = $conn->prepare("SELECT t.*, u.name FROM team_topics t LEFT JOIN users u ON t.uid = u.uid WHERE t.id = ? AND t.team_id = ?");
    $td->bind_param("ii", $topic_id, $team_id);
    $td->execute();
    $topicDetail = $td->get_result()->fetch_assoc();
    $td->close();
    if ($topicDetail) {
        $postStmt = $conn->prepare("SELECT p.*, u.name FROM team_posts p LEFT JOIN users u ON p.uid = u.uid WHERE p.topic_id = ? ORDER BY p.created_at ASC");
        $postStmt->bind_param("i", $topic_id);
        $postStmt->execute();
        $pRes = $postStmt->get_result();
        while ($row = $pRes->fetch_assoc()) {
            $topicPosts[] = $row;
        }
        $postStmt->close();
    } else {
        $topic_id = 0; // 无效
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= safeContent($teamInfo['name']) ?> - 团队 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it-texmath@0.9.0/texmath.min.js"></script>
    <style>
        /* 样式与之前一致，因篇幅省略，但保留原有样式，此处仅增加少量新增样式 */
        :root { --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6; --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e; --border: #e6e1da; --border-light: #f0ece6; --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef; --danger: #d9534f; --danger-hover: #c0392b; --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease; --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100% { box-shadow:0 0 0 0 rgba(245,83,83,0.5); } 50% { box-shadow:0 0 0 6px rgba(245,83,83,0); } }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); font-weight:500; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:18px; border:1px solid var(--border-light); transition:var(--transition); }
        .card:hover { box-shadow:var(--shadow); }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .card h3 { font-size:16px; font-weight:600; margin-bottom:12px; }
        .btn { padding:8px 18px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:13.5px; font-weight:500; transition:var(--transition); text-decoration:none; display:inline-block; }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); color:#fff; }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:var(--danger-hover); }
        .btn-sm { padding:4px 12px; font-size:12px; }
        .btn-success { background:#2e7d32; }
        .btn-success:hover { background:#1b5e20; }
        .btn-outline { background:transparent; color:var(--accent); border:1.5px solid var(--accent); }
        .btn-outline:hover { background:var(--accent); color:#fff; }
        .alert { padding:12px 16px; border-radius:var(--radius-sm); margin-bottom:16px; }
        .alert-success { background:#e8f5e9; color:#2e7d32; border:1px solid #a5d6a7; }
        .alert-error { background:#fce4ec; color:#c62828; border:1px solid #ef9a9a; }
        .alert-info { background:#e3f2fd; color:#0d47a1; border:1px solid #90caf9; }
        table { width:100%; border-collapse:collapse; }
        th { text-align:left; padding:10px 14px; background:#fafaf8; font-size:13px; color:var(--text-secondary); border-bottom:2px solid var(--border); }
        td { padding:10px 14px; border-bottom:1px solid var(--border-light); font-size:14px; }
        tr:hover td { background:#fdfcf9; }
        .tag { display:inline-block; padding:2px 10px; border-radius:8px; font-size:12px; font-weight:600; }
        .tag-admin { background:#8e44ad; color:#fff; }
        .tag-owner { background:#e67e22; color:#fff; }
        .tag-member { background:#b0a8a0; color:#fff; }
        .tag-pending { background:#f39c12; color:#fff; }
        .tag-banned { background:#e74c3c; color:#fff; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; margin-left:8px; }
        .tag-join-allowed { background:#2e7d32; color:#fff; }
        .tag-join-closed { background:#d9534f; color:#fff; }
        .flex-between { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; }
        select, input[type="text"], input[type="number"], textarea { padding:6px 12px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; outline:none; background:#fdfdfc; transition:var(--transition); width:100%; }
        select:focus, input:focus, textarea:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        textarea { min-height:100px; resize:vertical; }
        .form-group { margin-bottom:12px; }
        .form-group label { display:block; font-weight:500; margin-bottom:4px; font-size:14px; color:var(--text-secondary); }
        .md-content { line-height:1.8; }
        .md-content blockquote { border-left:4px solid var(--accent); padding:8px 14px; margin:8px 0; background:#fafaf8; color:#5a5550; border-radius:0 4px 4px 0; }
        .md-content pre { background:#2b2a27; color:#e8e4dd; padding:14px 16px; border-radius:var(--radius-sm); overflow-x:auto; margin:8px 0; font-family:monospace; font-size:13px; }
        .md-content code { font-family:monospace; background:#f3f0eb; padding:2px 6px; border-radius:3px; }
        .md-content pre code { background:transparent; padding:0; color:inherit; }
        .md-content img { max-width:100%; height:auto; border-radius:4px; margin:6px 0; }
        .team-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; margin-bottom:16px; gap:10px; }
        .team-name { font-size:24px; font-weight:700; color:var(--text); }
        .team-meta-row { display:flex; flex-wrap:wrap; gap:8px 20px; font-size:14px; color:var(--text-secondary); }
        .team-meta-row strong { color:var(--text); }
        .edit-toggle { cursor:pointer; color:var(--accent); font-weight:500; margin-left:12px; }
        .edit-toggle:hover { text-decoration:underline; }
        .banned-notice { background:#fde8e8; border:1px solid #f5c6c6; color:#a94442; padding:12px 16px; border-radius:var(--radius-sm); margin-bottom:16px; }
        .ben-name { font-weight:600; text-decoration:none; font-size:14px; transition:color 0.2s; }
        .ben-name:hover { opacity:0.8; text-decoration:underline; }
        .ben-name.colorful { color: #f1948a; animation: colorful 3s linear infinite; text-shadow: 0 0 10px rgba(0,0,0,0.2); }
        @keyframes colorful { 0% { color: #f1948a; } 17% { color: #f5b041; } 33% { color: #f7dc6f; } 50% { color: #82e0aa; } 67% { color: #85c1e9; } 83% { color: #bb8fce; } 100% { color: #f1948a; } }
        .tag.colorful-bg { animation: colorfulBg 3s linear infinite; }
        @keyframes colorfulBg { 0% { background-color: #f1948a; } 17% { background-color: #f5b041; } 33% { background-color: #f7dc6f; } 50% { background-color: #82e0aa; } 67% { background-color: #85c1e9; } 83% { background-color: #bb8fce; } 100% { background-color: #f1948a; } }
        .note-input { width:100%; max-width:200px; padding:4px 8px; border:1px solid var(--border); border-radius:4px; font-size:13px; }
        .note-input:focus { border-color:var(--accent); outline:none; }
        .tab-nav { display:flex; gap:8px; margin-bottom:16px; border-bottom:2px solid var(--border-light); padding-bottom:6px; }
        .tab-nav a { padding:6px 14px; border-radius:20px; text-decoration:none; color:var(--text-secondary); font-weight:500; transition:var(--transition); }
        .tab-nav a:hover { background:var(--accent-light); color:var(--accent); }
        .tab-nav a.active { background:var(--accent); color:#fff; }
        .topic-item { padding:12px 0; border-bottom:1px solid var(--border-light); }
        .topic-item:last-child { border-bottom:0; }
        .topic-title { font-size:16px; font-weight:600; }
        .topic-title a { color:var(--text); }
        .topic-title a:hover { color:var(--accent); }
        .topic-meta { font-size:13px; color:var(--text-muted); margin-top:4px; }
        .post-item { padding:10px 0; border-bottom:1px solid var(--border-light); }
        .post-meta { font-size:13px; color:var(--text-muted); margin-bottom:6px; }
        .group-list { display:flex; flex-wrap:wrap; gap:10px; margin-top:10px; }
        .group-card { background:var(--accent-light); padding:8px 14px; border-radius:20px; border:1px solid var(--border); }
        @media(max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .navbar { padding:0 14px; height:48px; }
            .note-input { max-width:120px; }
        }
        a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
        a:hover { color:var(--accent-hover); text-decoration:underline; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if ($msg): ?>
            <div class="alert alert-success"><?= safeContent($msg) ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-error"><?= safeContent($error) ?></div>
        <?php endif; ?>

        <?php if ($teamInfo['banned'] == 1 && $is_admin): ?>
            <div class="banned-notice">⚠️ 该团队已被封禁，普通用户无法查看。管理员可在此解封。</div>
        <?php endif; ?>

        <div class="flex-between" style="margin-bottom:16px;">
            <a href="https://lmtoj.cn/team" class="btn btn-sm">← 返回列表</a>
            <div>
                <?php if ($canEditTeam): ?>
                    <a href="#editForm" class="btn btn-sm btn-outline" onclick="document.getElementById('editForm').style.display='block'; return false;">编辑团队</a>
                <?php endif; ?>
                <?php if ($is_admin): ?>
                    <a href="https://lmtoj.cn/team/<?= $team_id ?>?toggle_ban=1" class="btn btn-sm <?= $teamInfo['banned'] == 1 ? 'btn-success' : 'btn-danger' ?>" onclick="return confirm('确定要<?= $teamInfo['banned'] == 1 ? '解封' : '封禁' ?>该团队吗？')">
                        <?= $teamInfo['banned'] == 1 ? '解封团队' : '封禁团队' ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- 编辑表单（默认隐藏） -->
        <?php if ($canEditTeam): ?>
            <div id="editForm" style="display:none; margin-bottom:18px;">
                <div class="card">
                    <h3>编辑团队信息</h3>
                    <form method="post">
                        <input type="hidden" name="edit_team" value="1">
                        <div class="form-group">
                            <label>团队名称</label>
                            <input type="text" name="name" value="<?= safeContent($teamInfo['name']) ?>" required maxlength="100">
                        </div>
                        <div class="form-group">
                            <label>公告（支持 Markdown）</label>
                            <textarea name="announcement" rows="5"><?= safeContent($teamInfo['announcement'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>允许加入</label>
                            <select name="allow_join">
                                <option value="1" <?= $teamInfo['allow_join'] == 1 ? 'selected' : '' ?>>允许</option>
                                <option value="0" <?= $teamInfo['allow_join'] == 0 ? 'selected' : '' ?>>不允许</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>加入审核方式</label>
                            <select name="join_approval">
                                <option value="0" <?= $teamInfo['join_approval'] == 0 ? 'selected' : '' ?>>无需审核（直接加入）</option>
                                <option value="1" <?= $teamInfo['join_approval'] == 1 ? 'selected' : '' ?>>需要审核</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>等级要求</label>
                            <select name="min_level">
                                <option value="" <?= empty($teamInfo['min_level']) ? 'selected' : '' ?>>无限制</option>
                                <option value="brown" <?= $teamInfo['min_level'] == 'brown' ? 'selected' : '' ?>>不可棕名</option>
                                <option value="blue" <?= $teamInfo['min_level'] == 'blue' ? 'selected' : '' ?>>蓝名及以上</option>
                                <option value="green" <?= $teamInfo['min_level'] == 'green' ? 'selected' : '' ?>>绿名及以上</option>
                                <option value="orange" <?= $teamInfo['min_level'] == 'orange' ? 'selected' : '' ?>>橙名及以上</option>
                                <option value="red" <?= $teamInfo['min_level'] == 'red' ? 'selected' : '' ?>>红名及以上</option>
                                <option value="purple" <?= $teamInfo['min_level'] == 'purple' ? 'selected' : '' ?>>仅紫名</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>黑名单（UID 列表，用逗号或换行分隔）</label>
                            <textarea name="blacklist" rows="3" placeholder="输入 UID，例如：123,456,789"><?= safeContent($teamInfo['blacklist'] ?? '') ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>
                                <input type="checkbox" name="notify_on_apply" value="1" <?= $teamInfo['notify_on_apply'] == 1 ? 'checked' : '' ?>>
                                申请免打扰（发送申请后不通知管理员）
                            </label>
                            <span style="font-size:12px;color:var(--text-muted);display:block;margin-top:2px;">开启后，用户申请加入时不会向团内所有者/管理员发送消息通知。</span>
                        </div>
                        <button type="submit" class="btn">保存修改</button>
                        <button type="button" class="btn btn-danger" onclick="document.getElementById('editForm').style.display='none';">取消</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>

        <!-- 团队信息 -->
        <div class="card">
            <div class="team-header">
                <div class="team-name">
                    <?= safeContent($teamInfo['name']) ?>
                    <?php if ($teamInfo['banned'] == 1): ?>
                        <span class="tag-banned">已封禁</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="team-meta-row">
                <span><strong>所有者：</strong><?= safeContent($teamInfo['owner_name']) ?></span>
                <span><strong>成员：</strong><?= count($members) ?> 人</span>
                <span><strong>创建于：</strong><?= date('Y-m-d H:i', strtotime($teamInfo['created_at'])) ?></span>
                <span><strong>加入状态：</strong>
                    <?php if ($teamInfo['allow_join'] == 1): ?>
                        <?php if ($teamInfo['join_approval'] == 0): ?>
                            <span class="tag tag-join-allowed">无需审核</span>
                        <?php else: ?>
                            <span class="tag tag-join-allowed">需要审核</span>
                        <?php endif; ?>
                        <?php if ($teamInfo['notify_on_apply'] == 0): ?>
                            <span style="font-size:12px;color:var(--text-muted);margin-left:4px;">（免通知）</span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="tag tag-join-closed">暂不允许加入</span>
                    <?php endif; ?>
                </span>
                <?php if ($userRole): ?>
                    <span><strong>您的角色：</strong>
                        <?php if ($isOwner): ?>
                            <span class="tag tag-owner">所有者</span>
                        <?php elseif ($userRole === 'admin'): ?>
                            <span class="tag tag-admin">管理员</span>
                        <?php else: ?>
                            <span class="tag tag-member">成员</span>
                        <?php endif; ?>
                    </span>
                <?php else: ?>
                    <?php
                    $checkReq = $conn->prepare("SELECT status FROM team_requests WHERE team_id = ? AND uid = ? ORDER BY id DESC LIMIT 1");
                    $checkReq->bind_param("ii", $team_id, $login_uid);
                    $checkReq->execute();
                    $reqStatus = $checkReq->get_result()->fetch_assoc();
                    $checkReq->close();
                    if ($reqStatus && $reqStatus['status'] === 'pending'): ?>
                        <span class="tag tag-pending">申请中</span>
                    <?php elseif ($reqStatus && $reqStatus['status'] === 'rejected'): ?>
                        <span class="tag" style="background:#e74c3c;color:#fff;">已拒绝</span>
                    <?php else: ?>
                        <?php if ($teamInfo['banned'] == 1): ?>
                            <span style="color:var(--danger);">团队已封禁</span>
                        <?php elseif ($teamInfo['allow_join'] == 0): ?>
                            <span style="color:var(--danger);">暂不允许加入</span>
                        <?php else: ?>
                            <a href="https://lmtoj.cn/team/<?= $team_id ?>?request_join=1" class="btn btn-sm">申请加入</a>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <!-- 公告 -->
            <?php if (!empty($teamInfo['announcement'])): ?>
                <div style="margin-top:16px; padding-top:16px; border-top:1px solid var(--border-light);">
                    <h3 style="font-size:16px; font-weight:600; margin-bottom:8px;">📢 公告</h3>
                    <div class="md-content" id="teamAnnouncement" data-raw="<?= safeContent($teamInfo['announcement']) ?>"></div>
                </div>
            <?php endif; ?>
        </div>

        <!-- 标签导航 -->
        <div class="tab-nav">
            <a href="?id=<?= $team_id ?>&tab=members" class="<?= $tab=='members'?'active':'' ?>">成员列表</a>
            <?php if ($isMember): ?>
                <a href="?id=<?= $team_id ?>&tab=discuss" class="<?= $tab=='discuss'?'active':'' ?>">讨论区</a>
            <?php endif; ?>
            <?php if ($canManage): ?>
                <a href="?id=<?= $team_id ?>&tab=groups" class="<?= $tab=='groups'?'active':'' ?>">分组管理</a>
            <?php endif; ?>
        </div>

        <!-- ========== 成员列表 ========== -->
        <?php if ($tab === 'members'): ?>
        <div class="card">
            <h2>成员列表</h2>
            <table>
                <tr>
                    <th>用户</th>
                    <th>角色</th>
                    <th>备注</th>
                    <?php if ($canManage): ?>
                        <th>操作</th>
                    <?php endif; ?>
                </tr>
                <?php foreach ($members as $m):
                    $display = $m['display'];
                    $isMemberOwner = isTeamOwner($conn, $team_id, $m['uid']);
                    $isTargetAdmin = ($m['role'] === 'admin');
                ?>
                    <tr>
                        <td>
                            <a href="https://lmtoj.cn/user/<?=$m['uid']?>" class="ben-name<?= $display['isColorful']&&$myShowColorful ? ' colorful' : '' ?>" <?= $display['isColorful']&&$myShowColorful ? '' : 'style="color: ' . $display['color'] . ';"' ?>>
                                <?= safeContent($m['name']) ?>
                            </a>
                            <?php if($display['tag']): ?>
                                <span class="tag<?= $display['isColorful']&&$myShowColorful ? ' colorful-bg' : '' ?>" <?= $display['isColorful']&&$myShowColorful ? '' : 'style="background: ' . $display['color'] . ';color:#fff"' ?>>
                                    <?= safeContent($display['tag']) ?>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($isMemberOwner): ?>
                                <span class="tag tag-owner">所有者</span>
                            <?php elseif ($isTargetAdmin): ?>
                                <span class="tag tag-admin">管理员</span>
                            <?php else: ?>
                                <span class="tag tag-member">成员</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($canManage): ?>
                                <form method="post" style="display:flex; gap:4px; align-items:center;">
                                    <input type="hidden" name="target_uid" value="<?= $m['uid'] ?>">
                                    <input type="text" name="note" class="note-input" value="<?= safeContent($m['note']) ?>" placeholder="备注">
                                    <button type="submit" name="edit_note" class="btn btn-sm">保存</button>
                                </form>
                            <?php else: ?>
                                <?= safeContent($m['note'] ?? '') ?>
                            <?php endif; ?>
                        </td>
                        <?php if ($canManage): ?>
                            <td>
                                <?php if (!$isOwner && $m['uid'] == $login_uid): ?>
                                    <!-- 自己不能操作自己（除非所有者） -->
                                <?php elseif ($isMemberOwner && !$isOwner): ?>
                                    <!-- 非所有者不能操作所有者 -->
                                <?php elseif ($m['uid'] == $login_uid && $isOwner): ?>
                                    <!-- 所有者自己，不需操作 -->
                                <?php else: ?>
                                    <?php if ($isTargetAdmin): ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="target_uid" value="<?= $m['uid'] ?>">
                                            <input type="hidden" name="role" value="member">
                                            <button type="submit" name="set_role" class="btn btn-sm">降为成员</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" style="display:inline;">
                                            <input type="hidden" name="target_uid" value="<?= $m['uid'] ?>">
                                            <input type="hidden" name="role" value="admin">
                                            <button type="submit" name="set_role" class="btn btn-sm">设为管理员</button>
                                        </form>
                                    <?php endif; ?>
                                    <a href="https://lmtoj.cn/team/<?= $team_id ?>?remove=<?= $m['uid'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定移除 <?= safeContent($m['name']) ?> 吗？')">移除</a>
                                <?php endif; ?>
                            </td>
                        <?php endif; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php endif; ?>

        <!-- ========== 讨论区 ========== -->
        <?php if ($tab === 'discuss' && $isMember): ?>
            <?php if ($topic_id == 0): ?>
                <!-- 话题列表 -->
                <div class="card">
                    <div class="flex-between">
                        <h2>讨论区</h2>
                        <a href="#newTopic" class="btn btn-sm" onclick="document.getElementById('newTopicForm').style.display='block'; return false;">发布新话题</a>
                    </div>
                    <div id="newTopicForm" style="display:none; margin-top:12px; padding:12px; background:var(--accent-light); border-radius:var(--radius-sm);">
                        <form method="post">
                            <input type="hidden" name="new_topic" value="1">
                            <div class="form-group">
                                <label>标题</label>
                                <input type="text" name="title" placeholder="输入标题" required>
                            </div>
                            <div class="form-group">
                                <label>内容（支持 Markdown）</label>
                                <textarea name="content" rows="6" required></textarea>
                            </div>
                            <button type="submit" class="btn">发布</button>
                            <button type="button" class="btn btn-danger" onclick="document.getElementById('newTopicForm').style.display='none';">取消</button>
                        </form>
                    </div>
                    <?php if (empty($topics)): ?>
                        <p style="color:var(--text-muted);">暂无话题，来发布第一个吧！</p>
                    <?php else: ?>
                        <?php foreach ($topics as $topic): ?>
                            <div class="topic-item">
                                <div class="topic-title">
                                    <a href="?id=<?= $team_id ?>&tab=discuss&topic_id=<?= $topic['id'] ?>">
                                        <?= safeContent($topic['title']) ?>
                                    </a>
                                    <?php if ($topic['status'] == 1): ?>
                                        <span class="tag" style="background:#f39c12;color:#fff;">置顶</span>
                                    <?php endif; ?>
                                    <?php if ($topic['status'] == 2): ?>
                                        <span class="tag" style="background:#95a5a6;color:#fff;">已关闭</span>
                                    <?php endif; ?>
                                </div>
                                <div class="topic-meta">
                                    <?= safeContent($topic['name']) ?> · <?= date('Y-m-d H:i', strtotime($topic['created_at'])) ?>
                                    · 回复 <?= $topic['reply_count'] ?>
                                    <?php if ($isOwner || $canManage || $topic['uid'] == $login_uid): ?>
                                        <a href="?id=<?= $team_id ?>&tab=discuss&del_topic=<?= $topic['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该话题吗？')">删除</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        <?php if ($topicTotal > $topicLimit): ?>
                            <div class="page-bar">
                                <?php if ($topicPage > 1): ?>
                                    <a href="?id=<?= $team_id ?>&tab=discuss&topic_page=<?= $topicPage-1 ?>">上一页</a>
                                <?php endif; ?>
                                <?php for ($i = max(1, $topicPage-2); $i <= min($topicTotalPage, $topicPage+2); $i++): ?>
                                    <a href="?id=<?= $team_id ?>&tab=discuss&topic_page=<?= $i ?>" class="<?= $i==$topicPage?'active':'' ?>"><?= $i ?></a>
                                <?php endfor; ?>
                                <?php if ($topicPage < $topicTotalPage): ?>
                                    <a href="?id=<?= $team_id ?>&tab=discuss&topic_page=<?= $topicPage+1 ?>">下一页</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <!-- 话题详情 -->
                <?php if ($topicDetail): ?>
                <div class="card">
                    <a href="?id=<?= $team_id ?>&tab=discuss" class="btn btn-sm">← 返回话题列表</a>
                    <h2><?= safeContent($topicDetail['title']) ?></h2>
                    <div class="topic-meta">
                        <?= safeContent($topicDetail['name']) ?> · <?= date('Y-m-d H:i', strtotime($topicDetail['created_at'])) ?>
                        <?php if ($topicDetail['status'] == 2): ?>
                            <span class="tag" style="background:#95a5a6;color:#fff;">已关闭</span>
                        <?php endif; ?>
                        <?php if ($isOwner || $canManage || $topicDetail['uid'] == $login_uid): ?>
                            <a href="?id=<?= $team_id ?>&tab=discuss&del_topic=<?= $topic_id ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该话题吗？')">删除话题</a>
                        <?php endif; ?>
                    </div>
                    <div class="md-content" data-raw="<?= safeContent($topicDetail['content']) ?>"></div>
                </div>
                <div class="card">
                    <h3>全部回复</h3>
                    <?php if (empty($topicPosts)): ?>
                        <p style="color:var(--text-muted);">暂无回复</p>
                    <?php else: ?>
                        <?php foreach ($topicPosts as $post): ?>
                            <div class="post-item">
                                <div class="post-meta">
                                    <?= safeContent($post['name']) ?> · <?= date('Y-m-d H:i', strtotime($post['created_at'])) ?>
                                    <?php if ($isOwner || $canManage || $post['uid'] == $login_uid): ?>
                                        <a href="?id=<?= $team_id ?>&tab=discuss&topic_id=<?= $topic_id ?>&del_post=<?= $post['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该回复吗？')">删除</a>
                                    <?php endif; ?>
                                </div>
                                <div class="md-content" data-raw="<?= safeContent($post['content']) ?>"></div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <?php if ($topicDetail['status'] != 2): ?>
                        <div style="margin-top:16px;">
                            <h4>发表回复</h4>
                            <form method="post">
                                <input type="hidden" name="reply_post" value="1">
                                <textarea name="content" rows="5" placeholder="支持 Markdown" required></textarea>
                                <button type="submit" class="btn">提交回复</button>
                            </form>
                        </div>
                    <?php else: ?>
                        <p style="color:var(--text-muted);">此话题已关闭，无法回复。</p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>

        <!-- ========== 分组管理 ========== -->
        <?php if ($tab === 'groups' && $canManage): ?>
            <div class="card">
                <h2>分组管理</h2>
                <div style="margin-bottom:16px;">
                    <form method="post" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                        <input type="hidden" name="create_group" value="1">
                        <input type="text" name="group_name" placeholder="输入新分组名称" required style="width:200px;">
                        <button type="submit" class="btn btn-sm">创建分组</button>
                    </form>
                </div>
                <?php if (empty($groups)): ?>
                    <p style="color:var(--text-muted);">暂无分组，创建第一个吧。</p>
                <?php else: ?>
                    <?php foreach ($groups as $g): ?>
                        <div style="margin-bottom:20px; border:1px solid var(--border); border-radius:var(--radius-sm); padding:12px;">
                            <div class="flex-between">
                                <strong><?= safeContent($g['name']) ?></strong>
                                <a href="?id=<?= $team_id ?>&tab=groups&del_group=<?= $g['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('确定删除该分组吗？')">删除分组</a>
                            </div>
                            <div style="margin-top:8px;">
                                <form method="post" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                    <input type="hidden" name="assign_group" value="1">
                                    <input type="hidden" name="group_id" value="<?= $g['id'] ?>">
                                    <select name="target_uid" required>
                                        <option value="">选择成员</option>
                                        <?php foreach ($members as $m): ?>
                                            <?php
                                            // 检查是否已在该分组中
                                            $check = $conn->query("SELECT 1 FROM team_member_groups WHERE team_id = $team_id AND uid = {$m['uid']} AND group_id = {$g['id']}");
                                            if ($check->num_rows == 0) {
                                                echo '<option value="' . $m['uid'] . '">' . safeContent($m['name']) . '</option>';
                                            }
                                            ?>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="btn btn-sm">加入分组</button>
                                </form>
                                <div style="margin-top:6px;">
                                    <strong>成员：</strong>
                                    <?php
                                    $membersInGroup = $conn->query("SELECT u.name, m.uid FROM team_member_groups mg LEFT JOIN users u ON mg.uid = u.uid WHERE mg.team_id = $team_id AND mg.group_id = {$g['id']}");
                                    if ($membersInGroup->num_rows == 0) {
                                        echo '<span style="color:var(--text-muted);">（无）</span>';
                                    } else {
                                        while ($mg = $membersInGroup->fetch_assoc()) {
                                            echo '<span style="display:inline-block; margin-right:8px;">' . safeContent($mg['name']) . ' <a href="?id=' . $team_id . '&tab=groups&remove_from_group=1&uid=' . $mg['uid'] . '&group_id=' . $g['id'] . '" class="btn btn-sm btn-danger" onclick="return confirm(\'移出分组？\')">✕</a></span>';
                                        }
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- 转让所有权 -->
        <?php if ($isOwner): ?>
            <div class="card">
                <h3>转让所有权</h3>
                <form method="post">
                    <div class="form-group">
                        <label>选择新所有者</label>
                        <select name="new_owner" required>
                            <option value="">-- 选择用户 --</option>
                            <?php foreach ($members as $m): ?>
                                <?php if ($m['uid'] != $login_uid): ?>
                                    <option value="<?= $m['uid'] ?>"><?= safeContent($m['name']) ?></option>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" name="transfer_owner" class="btn">转让所有权</button>
                </form>
            </div>
        <?php endif; ?>

        <!-- 退出团队 -->
        <?php if ($userRole && !$isOwner): ?>
            <div class="card">
                <a href="https://lmtoj.cn/team/<?= $team_id ?>?leave=1" class="btn btn-danger" onclick="return confirm('确定退出该团队吗？')">退出团队</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Markdown 渲染
const md = window.markdownit({ html: false, linkify: true, typographer: true, breaks: true });
md.use(window.texmath.use(window.katex), {
    engine: window.katex,
    delimiters: 'dollars',
    katexOptions: { macros: { "\\RR": "\\mathbb{R}" } }
});

document.querySelectorAll('.md-content').forEach(function(el) {
    var raw = el.dataset.raw;
    if (raw) {
        var textarea = document.createElement('textarea');
        textarea.innerHTML = raw;
        el.innerHTML = md.render(textarea.value);
    }
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>