<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = (int)$_SESSION['uid'];

// 确保 users 表有 star 字段
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'star'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN star INT DEFAULT 0");
}

// Token余额表
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0 COMMENT '持有token数量',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户Token余额表'");

// 头像框持有表（增加 is_active 字段）
$conn->query("CREATE TABLE IF NOT EXISTS user_avatar_frame (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    frame_name VARCHAR(60) NOT NULL,
    frame_img VARCHAR(255) NOT NULL,
    expire_time DATETIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active TINYINT DEFAULT 0 COMMENT '是否当前使用',
    INDEX idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 检查并添加 is_active 字段
$colCheck2 = $conn->query("SHOW COLUMNS FROM user_avatar_frame LIKE 'is_active'");
if ($colCheck2->num_rows == 0) {
    $conn->query("ALTER TABLE user_avatar_frame ADD COLUMN is_active TINYINT DEFAULT 0");
}

// ========== 新建商品表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS shop_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    description TEXT,
    price_star INT NOT NULL DEFAULT 0 COMMENT '所需star数',
    img_url VARCHAR(255) NOT NULL,
    expire_days INT NOT NULL DEFAULT 2 COMMENT '有效天数',
    type VARCHAR(20) DEFAULT 'avatar_frame' COMMENT '商品类型，预留',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商店商品表'");

// 初始化测试商品（如果表为空）
$itemCheck = $conn->query("SELECT id FROM shop_items LIMIT 1");
if ($itemCheck->num_rows == 0) {
    $conn->query("INSERT INTO shop_items (name, description, price_star, img_url, expire_days)
        VALUES ('测试头像框', '这是一个测试头像框，购买后有效期内头像会带上此框。', 5,
        'https://lmtoj.cn/upload/img/2026/07/19_19-08-14_5b75c0b0.webp', 2)");
}

// 初始化用户token
$checkToken = $conn->query("SELECT uid FROM user_token WHERE uid = $login_uid LIMIT 1");
if ($checkToken->num_rows === 0) {
    $conn->query("INSERT INTO user_token (uid, token_num) VALUES ($login_uid, 0)");
}

// 获取用户star 和 admin
$userRow = $conn->query("SELECT name, admin, star, avatar FROM users WHERE uid = $login_uid LIMIT 1")->fetch_assoc();
$current_star = (int)($userRow['star'] ?? 0);
$is_admin = (int)($userRow['admin'] ?? 0);
$user_avatar = $userRow['avatar'] ?? '';

// 获取token
$tokenRow = $conn->query("SELECT token_num FROM user_token WHERE uid = $login_uid LIMIT 1")->fetch_assoc();
$current_token = (int)$tokenRow['token_num'];

$error = '';
$success = '';

// ========== 处理管理员操作 ==========
// 添加商品
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_item']) && $is_admin) {
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = intval($_POST['price_star']);
    $img = trim($_POST['img_url']);
    $days = intval($_POST['expire_days']);
    if ($name && $price >= 0 && $img && $days > 0) {
        $nameE = $conn->real_escape_string($name);
        $descE = $conn->real_escape_string($desc);
        $imgE = $conn->real_escape_string($img);
        $conn->query("INSERT INTO shop_items (name, description, price_star, img_url, expire_days)
            VALUES ('$nameE', '$descE', $price, '$imgE', $days)");
        $success = "商品添加成功";
    } else {
        $error = "请完整填写所有字段（价格≥0，天数>0）";
    }
}

// 编辑商品
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_item']) && $is_admin) {
    $id = intval($_POST['item_id']);
    $name = trim($_POST['name']);
    $desc = trim($_POST['description']);
    $price = intval($_POST['price_star']);
    $img = trim($_POST['img_url']);
    $days = intval($_POST['expire_days']);
    if ($id && $name && $price >= 0 && $img && $days > 0) {
        $nameE = $conn->real_escape_string($name);
        $descE = $conn->real_escape_string($desc);
        $imgE = $conn->real_escape_string($img);
        $conn->query("UPDATE shop_items SET
            name = '$nameE',
            description = '$descE',
            price_star = $price,
            img_url = '$imgE',
            expire_days = $days
            WHERE id = $id");
        $success = "商品更新成功";
    } else {
        $error = "请完整填写所有字段";
    }
}

// 删除商品
if (isset($_GET['delete_item']) && $is_admin) {
    $id = intval($_GET['delete_item']);
    $conn->query("DELETE FROM shop_items WHERE id = $id");
    $success = "商品已删除";
    header("Location: https://lmtoj.cn/store");
    exit;
}
if (isset($_GET['del_success'])) {
    $success = "商品已删除";
}

// ========== 管理员设置用户star ========== (新增功能)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_user_star']) && $is_admin) {
    $target_uid = intval($_POST['target_uid']);
    $new_star = intval($_POST['new_star']);
    if ($target_uid <= 0) {
        $error = "请输入有效的用户UID";
    } elseif ($new_star < 0) {
        $error = "star数量不能为负数";
    } else {
        // 检查用户是否存在
        $userCheck = $conn->query("SELECT uid FROM users WHERE uid = $target_uid LIMIT 1");
        if ($userCheck->num_rows === 0) {
            $error = "用户UID $target_uid 不存在";
        } else {
            $conn->query("UPDATE users SET star = $new_star WHERE uid = $target_uid");
            $success = "已设置用户 UID: $target_uid 的 star 数量为 $new_star";
        }
    }
}
// ========== 管理员设置用户star 结束 ==========

// ========== Token兑换逻辑 ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_token'])) {
    $buy_star = max(1, intval($_POST['buy_star']));
    $gain_token = $buy_star * 5;
    if ($current_star < $buy_star) {
        $error = "star不足！当前{$current_star} star，需要{$buy_star} star兑换";
    } else {
        $new_star = $current_star - $buy_star;
        $conn->query("UPDATE users SET star = $new_star WHERE uid = $login_uid");
        $new_token = $current_token + $gain_token;
        $conn->query("UPDATE user_token SET token_num = $new_token WHERE uid = $login_uid");
        $current_star = $new_star;
        $current_token = $new_token;
        $success = "兑换成功！消耗{$buy_star} star，获得{$gain_token} Token";
    }
}

// ========== 购买头像框（从商品表） ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_item'])) {
    $item_id = intval($_POST['item_id']);
    $item = $conn->query("SELECT * FROM shop_items WHERE id = $item_id LIMIT 1")->fetch_assoc();
    if (!$item) {
        $error = "商品不存在";
    } else {
        $cost = (int)$item['price_star'];
        if ($current_star < $cost) {
            $error = "star不足！该商品需要 {$cost} star，当前 {$current_star} star";
        } else {
            // 扣star
            $new_star = $current_star - $cost;
            $conn->query("UPDATE users SET star = $new_star WHERE uid = $login_uid");
            // 计算到期时间
            $expire = date('Y-m-d H:i:s', strtotime("+" . (int)$item['expire_days'] . " day"));
            // 插入头像框记录，默认 is_active = 0
            $conn->query("INSERT INTO user_avatar_frame (uid, frame_name, frame_img, expire_time, is_active)
                VALUES ($login_uid, '{$item['name']}', '{$item['img_url']}', '$expire', 0)");
            $current_star = $new_star;
            
            // 如果该用户之前没有任何有效头像框，则自动激活这个
            $activeCheck = $conn->query("SELECT id FROM user_avatar_frame WHERE uid = $login_uid AND expire_time > NOW() AND is_active = 1 LIMIT 1");
            if ($activeCheck->num_rows == 0) {
                $newId = $conn->insert_id;
                $conn->query("UPDATE user_avatar_frame SET is_active = 1 WHERE id = $newId");
                $success = "购买成功！「{$item['name']}」已自动设为当前使用，有效期 {$item['expire_days']} 天";
            } else {
                $success = "购买成功！「{$item['name']}」有效期 {$item['expire_days']} 天，请到下方设为使用";
            }
        }
    }
    header("Location: https://lmtoj.cn/store");
}

// ========== 选择头像框（设为使用） ==========
if (isset($_GET['select_frame']) && is_numeric($_GET['select_frame'])) {
    $frame_id = intval($_GET['select_frame']);
    $check = $conn->query("SELECT id FROM user_avatar_frame WHERE id = $frame_id AND uid = $login_uid AND expire_time > NOW()");
    if ($check->num_rows > 0) {
        $conn->query("UPDATE user_avatar_frame SET is_active = 0 WHERE uid = $login_uid");
        $conn->query("UPDATE user_avatar_frame SET is_active = 1 WHERE id = $frame_id");
        $success = "已切换头像框";
    } else {
        $error = "头像框无效或已过期";
    }
    header("Location: https://lmtoj.cn/store");
    exit;
}
if (isset($_GET['select_success'])) {
    $success = "头像框切换成功！";
}

// ========== 删除自己持有的头像框 ==========
if (isset($_GET['del_frame']) && is_numeric($_GET['del_frame'])) {
    $del_fid = intval($_GET['del_frame']);
    // 校验归属：只能删除自己的框
    $ownCheck = $conn->query("SELECT id,is_active FROM user_avatar_frame WHERE id = $del_fid AND uid = $login_uid LIMIT 1");
    if ($ownCheck->num_rows > 0) {
        $row = $ownCheck->fetch_assoc();
        // 删除这条头像框记录
        $conn->query("DELETE FROM user_avatar_frame WHERE id = $del_fid");
        // 如果删除的是当前激活框，自动把剩余有效框里最新的设为激活
        if ($row['is_active'] == 1) {
            $newActive = $conn->query("SELECT id FROM user_avatar_frame WHERE uid = $login_uid AND expire_time > NOW() ORDER BY id DESC LIMIT 1");
            if ($newActive->num_rows > 0) {
                $newAid = $newActive->fetch_assoc()['id'];
                $conn->query("UPDATE user_avatar_frame SET is_active = 1 WHERE id = $newAid");
            }
        }
        $success = "头像框已删除";
    } else {
        $error = "无权删除该头像框";
    }
    header("Location: https://lmtoj.cn/store");
    exit;
}
if (isset($_GET['del_frame_success'])) {
    $success = "头像框删除成功";
}
$conn->query("DELETE FROM user_avatar_frame WHERE expire_time < NOW()");
// 查询当前用户有效头像框（包含 is_active）
$frameList = $conn->query("
    SELECT id, frame_name, frame_img, expire_time, is_active
    FROM user_avatar_frame
    WHERE uid = $login_uid AND expire_time > NOW()
    ORDER BY expire_time ASC
");

// 查询所有商品（用于展示和管理）
$items = $conn->query("SELECT * FROM shop_items ORDER BY id ASC");

// 当前编辑中的商品（用于编辑回显）
$edit_item = null;
if (isset($_GET['edit_id']) && $is_admin) {
    $eid = intval($_GET['edit_id']);
    $edit_item = $conn->query("SELECT * FROM shop_items WHERE id = $eid LIMIT 1")->fetch_assoc();
}

// 获取用户当前激活的头像框（用于预览）
$activeFrame = $conn->query("SELECT frame_img FROM user_avatar_frame WHERE uid = $login_uid AND expire_time > NOW() AND is_active = 1 LIMIT 1")->fetch_assoc();
$activeFrameImg = $activeFrame['frame_img'] ?? '';

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>商店 - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <link rel="stylesheet" href="/css/katex.min.css" />
    <script src="/js/markdown-it.min.js"></script>
    <script src="/js/texmath.min.js"></script>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }

        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a {
            color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
            border-radius:20px; transition:var(--transition);
        }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }

        /* ===== 布局修改开始 ===== */
        .main {
            max-width: 1100px;      /* 适当加宽以容纳侧边栏 */
            margin: 28px auto 40px;
            padding: 0 20px;
        }

        /* 新的 flex 容器 */
        .store-layout {
            display: flex;
            align-items: flex-start;
            gap: 24px;
        }

        /* 侧边栏固定宽度，sticky 定位 */
        .sidebar {
            flex: 0 0 120px;
            position: sticky;
            top: 54px;
            align-self: flex-start;
            border-radius: var(--radius);   /* 圆角恢复 */
            background: #ffffff;            /* 确保背景色 */
            box-shadow: 2px 0 8px rgba(0,0,0,0.04);  /* 可保留原阴影 */
        }

        /* 内容区自适应 */
        .store-content {
            flex: 1;
            min-width: 0;           /* 防止内容溢出 */
        }

        /* 卡片样式保持不变 */
        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:26px 28px;
            margin-bottom:18px; box-shadow:var(--shadow);
        }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        /* ===== 布局修改结束 ===== */

        .form-group { margin-bottom:15px; }
        .form-group label { display:block; font-weight:500; margin-bottom:4px; font-size:14px; }
        .form-control {
            width:100%; padding:10px 14px; border:1.5px solid var(--border);
            border-radius:var(--radius-sm); font-size:14px; outline:none;
            transition:var(--transition); background:#fdfdfc;
        }
        .form-control:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); }
        .btn {
            padding:9px 24px; background:var(--accent); color:#fff; border:none;
            border-radius:20px; cursor:pointer; font-size:14px; font-weight:500;
            transition:var(--transition);
        }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:#c9302c; }

        .msg { padding:12px 16px; border-radius:var(--radius-sm); margin-bottom:15px; }
        .msg-error { background:#fce4ec; border:1px solid #ef9a9a; color:#c62828; }
        .msg-success { background:#e8f5e9; border:1px solid #a5d6a7; color:#2e7d32; }

        .back-link { display:inline-block; margin-top:20px; color:var(--accent); text-decoration:none; font-weight:500; }
        .back-link:hover { text-decoration:underline; }

        .star-display {
            font-size:18px; font-weight:600; color:var(--accent);
            background:var(--accent-light); padding:8px 18px; border-radius:20px;
            display:inline-block; margin-right:12px;
        }
        .token-display {
            font-size:18px; font-weight:600; color:#4a90d9;
            background:#eef5fc; padding:8px 18px; border-radius:20px;
            display:inline-block;
        }

        .frame-preview {
            width:120px; height:120px; object-fit:cover; border-radius:8px; border:2px solid var(--border);
            margin:8px 0;
        }
        .frame-item {
            display:flex; align-items:center; gap:16px; padding:12px 0;
            border-bottom:1px solid var(--border-light);
        }
        .frame-item:last-child { border-bottom:none; }
        .frame-info h4 { font-size:15px; margin-bottom:4px; }
        .frame-info p { color:var(--text-muted); font-size:13px; }
        .frame-actions { margin-left:auto; display:flex; gap:8px; }
        .active-badge {
            background:var(--accent);
            color:#fff;
            padding:2px 14px;
            border-radius:12px;
            font-size:12px;
            font-weight:600;
        }

        .shop-item {
            display:flex; gap:20px; align-items:center; padding:15px 0;
            border-bottom:1px solid var(--border-light);
        }
        .shop-item:last-child { border-bottom:none; }
        .shop-item .item-img { width:100px; height:100px; object-fit:cover; border-radius:8px; border:1px solid var(--border); }
        .shop-item .item-info { flex:1; }
        .shop-item .item-info h3 { margin-bottom:4px; font-size:16px; }
        .shop-item .item-info .desc { color:var(--text-secondary); font-size:14px; margin-bottom:6px; }
        .shop-item .item-info .meta { color:var(--text-muted); font-size:13px; }
        .shop-item .actions { display:flex; gap:8px; flex-wrap:wrap; }

        .admin-panel { background:#fafaf8; padding:16px; border-radius:var(--radius-sm); margin-top:12px; border:1px solid var(--border); }
        .admin-panel h4 { font-size:15px; margin-bottom:10px; }
        .inline-form { display:flex; flex-wrap:wrap; gap:10px; align-items:center; }
        .inline-form .form-group { flex:1 1 150px; margin-bottom:0; }
        .inline-form .form-group label { font-size:13px; }
        .inline-form .form-control { padding:6px 10px; font-size:13px; }
        .inline-form .btn { padding:6px 16px; font-size:13px; }
        .edit-form { background:#fff; padding:12px; border:1px dashed var(--accent); border-radius:var(--radius-sm); margin-top:10px; }

        /* 移动端：侧边栏使用固定定位，布局变为单列 */
        @media (max-width: 768px) {
            .store-layout {
                flex-direction: column;   /* 侧边栏在上，内容在下（但侧边栏会被固定定位覆盖） */
                gap: 0;
            }
            .sidebar {
                position: fixed;
                top: 54px;
                left: 0;
                bottom: 0;
                z-index: 999;
                transform: translateX(-100%);
                transition: transform 0.3s ease;
                flex: none;
                width: 200px;
                background: #fff;
                box-shadow: 2px 0 12px rgba(0,0,0,0.08);
                border-radius: var(--radius);   /* 移动端也加圆角 */
            }
            .sidebar.open {
                transform: translateX(0);
            }
            .store-content {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="main">
    <div class="store-layout">

        <!-- 内容区 -->
        <div class="store-content">
            <div class="card">
                <h2>🏪 商店</h2>
                <div style="margin-bottom:16px;">
                    <span class="star-display">⭐ <?=$current_star?> star</span>
                    <span class="token-display">🔹 <?=$current_token?> token</span>
                    <div style="margin-top:6px;color:var(--text-muted);font-size:14px;">star可打卡获取；1 star = 5 token</div>
                </div>

                <?php if ($error): ?>
                    <div class="msg msg-error"><?=htmlspecialchars($error)?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="msg msg-success"><?=htmlspecialchars($success)?></div>
                <?php endif; ?>

                <!-- Token兑换区域 -->
                <div style="border-bottom:1px solid var(--border-light);padding-bottom:20px;margin-bottom:20px;">
                    <h3 style="font-size:16px;margin-bottom:12px;">🔹 Token兑换</h3>
                    <form method="post">
                        <div class="form-group">
                            <label for="buy_star">消耗star数量（1star兑换5token）</label>
                            <input type="number" id="buy_star" name="buy_star" class="form-control" min="1" value="1" required>
                            <div style="font-size:13px;color:var(--text-muted);margin-top:4px;">输入X，将获得 X * 5 token</div>
                        </div>
                        <button type="submit" name="buy_token" class="btn">兑换Token</button>
                    </form>
                </div>

                <!-- ========== 商品展示与购买 ========== -->
                <h3 style="font-size:16px;margin-bottom:12px;">🖼 头像框商店</h3>
                <?php if ($items && $items->num_rows > 0): ?>
                    <?php while ($item = $items->fetch_assoc()): ?>
                        <div class="shop-item" id="item-<?=$item['id']?>">
                            <img class="item-img" src="<?=htmlspecialchars($item['img_url'])?>" alt="<?=htmlspecialchars($item['name'])?>">
                            <div class="item-info">
                                <h3><?=htmlspecialchars($item['name'])?></h3>
                                <div class="desc" id="desc-<?=$item['id']?>"><?=htmlspecialchars($item['description'])?></div>
                                <div class="meta">
                                    价格：⭐ <?=$item['price_star']?> star ｜ 有效期：<?=$item['expire_days']?> 天
                                </div>
                            </div>
                            <div class="actions">
                                <form method="post">
                                    <input type="hidden" name="item_id" value="<?=$item['id']?>">
                                    <button type="submit" name="buy_item" class="btn" <?=($current_star < $item['price_star'])?'disabled':''?>>
                                        购买
                                    </button>
                                </form>
                                <?php if ($is_admin): ?>
                                    <a href="?edit_id=<?=$item['id']?>" class="btn" style="background:#f0ad4e;">编辑</a>
                                    <a href="?delete_item=<?=$item['id']?>" class="btn btn-danger" onclick="return confirm('确定删除该商品吗？')">删除</a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <!-- 编辑表单（如果edit_id匹配） -->
                        <?php if ($is_admin && isset($_GET['edit_id']) && (int)$_GET['edit_id'] == $item['id']): ?>
                            <div class="edit-form">
                                <h4>编辑商品</h4>
                                <form method="post">
                                    <input type="hidden" name="item_id" value="<?=$item['id']?>">
                                    <div class="form-group">
                                        <label>商品名称</label>
                                        <input type="text" name="name" class="form-control" value="<?=htmlspecialchars($item['name'])?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>描述（支持Markdown）</label>
                                        <textarea name="description" class="form-control" rows="3"><?=htmlspecialchars($item['description'])?></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>价格（star）</label>
                                        <input type="number" name="price_star" class="form-control" value="<?=$item['price_star']?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>图片URL</label>
                                        <input type="url" name="img_url" class="form-control" value="<?=htmlspecialchars($item['img_url'])?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>有效期（天）</label>
                                        <input type="number" name="expire_days" class="form-control" min="1" value="<?=$item['expire_days']?>" required>
                                    </div>
                                    <button type="submit" name="edit_item" class="btn">更新</button>
                                    <a href="?" class="btn" style="background:#ccc;">取消</a>
                                </form>
                            </div>
                        <?php endif; ?>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="color:var(--text-muted);">暂无商品，管理员可添加。</p>
                <?php endif; ?>

                <!-- 管理员添加商品面板 -->
                <?php if ($is_admin): ?>
                    <div class="admin-panel">
                        <h4>🔧 管理员 - 添加新商品</h4>
                        <form method="post">
                            <div class="inline-form">
                                <div class="form-group">
                                    <label>名称</label>
                                    <input type="text" name="name" class="form-control" placeholder="头像框名称" required>
                                </div>
                                <div class="form-group">
                                    <label>描述 (Markdown)</label>
                                    <textarea name="description" class="form-control" rows="2" placeholder="支持Markdown格式"></textarea>
                                </div>
                                <div class="form-group">
                                    <label>价格 (star)</label>
                                    <input type="number" name="price_star" class="form-control" min="0" value="5" required>
                                </div>
                                <div class="form-group">
                                    <label>图片URL</label>
                                    <input type="url" name="img_url" class="form-control" placeholder="https://..." required>
                                </div>
                                <div class="form-group">
                                    <label>有效期(天)</label>
                                    <input type="number" name="expire_days" class="form-control" min="1" value="2" required>
                                </div>
                                <button type="submit" name="add_item" class="btn">添加商品</button>
                            </div>
                        </form>
                    </div>

                    <!-- 新增：管理员设置用户star面板 -->
                    <div class="admin-panel">
                        <h4>⭐ 管理员 - 设置用户Star</h4>
                        <form method="post">
                            <div class="inline-form">
                                <div class="form-group">
                                    <label>用户UID</label>
                                    <input type="number" name="target_uid" class="form-control" placeholder="输入用户UID" min="1" required>
                                </div>
                                <div class="form-group">
                                    <label>新Star数量</label>
                                    <input type="number" name="new_star" class="form-control" placeholder="大于等于0" min="0" value="0" required>
                                </div>
                                <button type="submit" name="set_user_star" class="btn">设置Star</button>
                            </div>
                        </form>
                    </div>
                    <!-- 设置star面板结束 -->

                <?php endif; ?>
            </div>

            <!-- 已持有头像框列表 -->
            <div class="card">
                <h2>🎁 已拥有头像框（有效期内）</h2>
                <?php if ($frameList && $frameList->num_rows > 0): ?>
                    <?php while ($row = $frameList->fetch_assoc()):
                        $remain_sec = strtotime($row['expire_time']) - time();
                        $remain_day = ceil($remain_sec / 86400);
                        $remain_day = max(0, $remain_day);
                        $is_active = (int)$row['is_active'];
                    ?>
                    <div class="frame-item">
                        <img src="<?=htmlspecialchars($row['frame_img'])?>" class="frame-preview" style="width:80px;height:80px;">
                        <div class="frame-info">
                            <h4><?=htmlspecialchars($row['frame_name'])?></h4>
                            <p>剩余 <?=$remain_day?> 天｜到期 <?=date('Y-m-d H:i', strtotime($row['expire_time']))?></p>
                        </div>
                        <div class="frame-actions">
                            <?php if ($is_active): ?>
                                <span class="active-badge">✓ 使用中</span>
                            <?php else: ?>
                                <a href="?select_frame=<?=$row['id']?>" class="btn" style="padding:4px 14px;font-size:13px;">设为使用</a>
                            <?php endif; ?>
                            <a href="?del_frame=<?=$row['id']?>" class="btn btn-danger" style="padding:4px 14px;font-size:13px;" onclick="return confirm('确定永久删除该头像框？删除后无法恢复！')">删除</a>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p style="color:var(--text-muted);font-size:14px;">暂无有效头像框，前往上方购买</p>
                <?php endif; ?>
            </div>

            <a href="https://lmtoj.cn/" class="back-link">← 返回首页</a>
        </div> <!-- /store-content -->
    </div> <!-- /store-layout -->
</div> <!-- /main -->

<script>
    (function() {
        if (typeof window.markdownit !== 'undefined' && typeof window.texmath !== 'undefined' && typeof window.katex !== 'undefined') {
            const md = window.markdownit({});
            md.use(window.texmath.use(window.katex), {engine:window.katex,delimiters:'dollars',katexOptions:{macros:{"\\RR":"\\mathbb{R}"}}});
            document.querySelectorAll('.desc').forEach(function(el) {
                const raw = el.textContent.trim();
                if (raw) {
                    el.innerHTML = md.render(raw);
                }
            });
        }
    })();
</script>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>
<?php
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}
?>