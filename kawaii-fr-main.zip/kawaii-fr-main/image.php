<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';          // 该文件已启动 session
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 验证管理员权限
$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}
$noPermission = !$is_admin;

$target_uid = 0;
$images = null;
$totalCount = 0;
$message = '';
$error = '';
$page = 1;
$limit = 20;
$offset = 0;

if (!$noPermission) {
    // 分页参数
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $target_uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;
    $offset = ($page - 1) * $limit;

    // 处理删除
    if (isset($_GET['del_img']) && is_numeric($_GET['del_img'])) {
        $imgId = (int)$_GET['del_img'];
        $whereUid = ($target_uid > 0) ? " AND uid = {$target_uid}" : "";
        $img = $conn->query("SELECT * FROM user_images WHERE id = {$imgId}{$whereUid}")->fetch_assoc();
        if ($img) {
            $filePath = __DIR__ . $img['path'];
            if (file_exists($filePath)) unlink($filePath);
            $conn->query("DELETE FROM user_images WHERE id = {$imgId}");
            $message = '图片已删除';
        } else {
            $error = '图片不存在或无权限删除';
        }
        // 删除后刷新当前页（保持uid和page）
        $queryParams = http_build_query(['uid' => $target_uid, 'page' => $page]);
        header("Location: image.php?" . $queryParams);
        exit;
    }

    // 获取总数
    if ($target_uid > 0) {
        $userCheck = $conn->query("SELECT uid FROM users WHERE uid = {$target_uid} LIMIT 1");
        if ($userCheck && $userCheck->num_rows > 0) {
            $countRes = $conn->query("SELECT COUNT(*) AS cnt FROM user_images WHERE uid = {$target_uid}");
            $totalCount = (int)$countRes->fetch_assoc()['cnt'];
            $images = $conn->query("SELECT * FROM user_images WHERE uid = {$target_uid} ORDER BY id DESC LIMIT {$offset}, {$limit}");
        } else {
            $error = '用户不存在';
            $target_uid = 0;
            $totalCount = 0;
        }
    } else {
        $countRes = $conn->query("SELECT COUNT(*) AS cnt FROM user_images");
        $totalCount = (int)$countRes->fetch_assoc()['cnt'];
        $images = $conn->query("SELECT * FROM user_images ORDER BY id DESC LIMIT {$offset}, {$limit}");
    }
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员面板 - 图片管理</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .main{max-width:1200px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;position:sticky;top:80px;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:0.15s;border-left:3px solid transparent;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:16px;display:flex;align-items:center;gap:10px;}
        .admin-bar{background:#f5f2ed;padding:18px;border-radius:8px;display:flex;flex-wrap:wrap;align-items:center;gap:12px;}
        .admin-bar label{font-weight:600;color:var(--text-secondary);}
        .admin-bar input{padding:9px 14px;border:1.5px solid var(--border);border-radius:20px;font-size:14px;width:180px;outline:none;background:white;}
        .admin-bar button{padding:9px 24px;background:var(--accent);color:white;border:none;border-radius:20px;font-size:14px;font-weight:500;cursor:pointer;transition:0.15s;}
        .admin-bar button:hover{background:var(--accent-hover);}
        .admin-bar .info{color:var(--text-secondary);font-size:14px;margin-left:auto;}
        .admin-bar .info strong{color:var(--text);}
        .back-link{color:var(--accent);font-weight:500;padding:6px 14px;border-radius:12px;background:rgba(107,138,116,0.1);text-decoration:none;}
        .back-link:hover{background:rgba(107,138,116,0.2);}
        .alert{padding:12px 16px;border-radius:6px;margin-bottom:16px;font-size:14px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;}
        .alert-error{background:#fce4ec;color:#c62828;}
        .toolbar{display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap;}
        .btn-copy{background:var(--accent);color:white;border:none;padding:8px 20px;border-radius:20px;font-size:14px;cursor:pointer;transition:0.15s;}
        .btn-copy:hover{background:var(--accent-hover);}
        .gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:14px;margin-top:12px;}
        .gallery-item{position:relative;border-radius:8px;overflow:hidden;border:1px solid var(--border);background:#fafafa;aspect-ratio:1;cursor:pointer;transition:0.15s;}
        .gallery-item:hover{box-shadow:0 4px 12px rgba(0,0,0,0.12);transform:scale(1.01);}
        .gallery-item img{width:100%;height:100%;object-fit:cover;display:block;}
        .gallery-item .action-btn{position:absolute;bottom:6px;right:6px;background:rgba(0,0,0,0.6);color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;border:none;cursor:pointer;transition:0.15s;z-index:2;pointer-events:auto;}
        .gallery-item .action-btn.copy-btn{right:40px; background:rgba(0,0,0,0.5);}
        .gallery-item .action-btn.copy-btn:hover{background:var(--accent);}
        .gallery-item .del-btn{position:absolute;top:6px;right:6px;background:rgba(0,0,0,0.6);color:#fff;width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;text-decoration:none;line-height:1;transition:0.15s;border:none;cursor:pointer;z-index:2;}
        .gallery-item .del-btn:hover{background:var(--danger);transform:scale(1.1);}
        .gallery-item .uid-tag{position:absolute;bottom:6px;left:6px;background:rgba(0,0,0,0.6);color:#fff;padding:2px 10px;border-radius:12px;font-size:12px;z-index:2;pointer-events:none;}
        .empty-state{color:var(--text-muted);padding:40px;text-align:center;font-size:15px;}
        .total-badge{background:var(--accent);color:white;padding:2px 14px;border-radius:20px;font-size:14px;font-weight:400;}
        .no-permission{text-align:center;padding:60px 20px;color:var(--text-secondary);}
        .no-permission h2{font-size:24px;margin-bottom:10px;color:var(--text);}
        .pagination{display:flex;justify-content:center;gap:8px;margin-top:20px;flex-wrap:wrap;}
        .pagination a, .pagination span{display:inline-block;padding:6px 14px;border-radius:20px;border:1px solid var(--border);color:var(--text);text-decoration:none;font-size:14px;transition:0.15s;background:white;}
        .pagination a:hover{background:var(--accent);color:white;border-color:var(--accent);}
        .pagination .active{background:var(--accent);color:white;border-color:var(--accent);}
        .pagination .disabled{opacity:0.5;pointer-events:none;}
        
        /* 图片放大模态框 */
        .modal {display:none;position:fixed;z-index:999;left:0;top:0;width:100%;height:100%;background:rgba(0,0,0,0.85);align-items:center;justify-content:center;}
        .modal.show {display:flex;}
        .modal img {max-width:90%;max-height:90%;object-fit:contain;border-radius:8px;box-shadow:0 8px 30px rgba(0,0,0,0.5);}
        .modal .close {position:absolute;top:20px;right:30px;font-size:40px;color:white;cursor:pointer;transition:0.2s;}
        .modal .close:hover{color:#ddd;transform:rotate(90deg);}
        
        @media(max-width:600px){.admin-bar{flex-direction:column;align-items:stretch;}.admin-bar input{width:100%;}.admin-bar .info{margin-left:0;}.main{flex-direction:column;padding:0 12px;}.sidebar{width:100%;position:static;display:flex;}.sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; // 顶栏 ?>

<div class="main">
    <?php include 'sidebar.php'; // 侧边栏 ?>
    <div class="content">
        <div class="card">
            <h2>🛠️ 管理员 — 图片管理 <?php if(!$noPermission): ?><span class="total-badge">共 <?=$totalCount?> 张</span><?php endif; ?></h2>
            
            <?php if($noPermission): ?>
                <div class="no-permission">
                    <h2>⛔ 无权限访问</h2>
                    <p>您不是管理员，无法查看此页面。</p>
                </div>
            <?php else: ?>
                <?php if(isset($message)): ?><div class="alert alert-success"><?=safeContent($message)?></div><?php endif; ?>
                <?php if(isset($error)): ?><div class="alert alert-error"><?=safeContent($error)?></div><?php endif; ?>
                
                <div class="admin-bar">
                    <label for="uidInput">🔍 查看特定用户图片：</label>
                    <form method="get" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;flex:1;">
                        <input type="number" name="uid" id="uidInput" placeholder="输入 UID" value="<?=$target_uid>0?$target_uid:''?>">
                        <button type="submit">查看</button>
                        <?php if($target_uid > 0): ?>
                        <a href="admin_sese.php" class="back-link">⬅ 显示全部</a>
                        <?php endif; ?>
                    </form>
                    <span class="info">
                        <?php if($target_uid > 0): ?>
                        当前查看 <strong>UID <?=$target_uid?></strong> 的图片
                        <?php else: ?>
                        显示所有用户的图片
                        <?php endif; ?>
                    </span>
                </div>

                <div class="card">
                    <div class="toolbar">
                        <button class="btn-copy" onclick="copyAllLinks()">📋 复制全部图片链接</button>
                    </div>
                    
                    <h2>📷 图片列表</h2>
                    <?php if(isset($images) && $images->num_rows > 0): ?>
                    <div class="gallery" id="gallery">
                        <?php while($img = $images->fetch_assoc()): 
                            $url = 'https://lmtoj.cn' . $img['path'];
                            $uid = (int)$img['uid'];
                            $deleteUrl = "admin_sese.php?uid={$target_uid}&page={$page}&del_img={$img['id']}";
                        ?>
                        <div class="gallery-item" data-url="<?=$url?>">
                            <img src="<?=$url?>" alt="图片" loading="lazy" onclick="openModal('<?=$url?>')" title="点击放大">
                            <button class="action-btn copy-btn" onclick="event.stopPropagation(); copySingle('<?=$url?>')" title="复制单张图片链接">📋</button>
                            <a href="<?=$deleteUrl?>" class="del-btn" onclick="event.stopPropagation();return confirm('确定要删除这张图片吗？')" title="删除图片">×</a>
                            <?php if($target_uid == 0): ?>
                            <span class="uid-tag">UID <?=$uid?></span>
                            <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                    </div>
                    
                    <!-- 分页 -->
                    <?php if($totalCount > $limit): 
                        $totalPages = ceil($totalCount / $limit);
                        $queryBase = 'image?' . ($target_uid > 0 ? 'uid='.$target_uid.'&' : '');
                    ?>
                    <div class="pagination">
                        <?php if($page > 1): ?>
                            <a href="<?=$queryBase?>page=<?=$page-1?>">« 上一页</a>
                        <?php else: ?>
                            <span class="disabled">« 上一页</span>
                        <?php endif; ?>
                        
                        <?php for($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if($i == $page): ?>
                                <span class="active"><?=$i?></span>
                            <?php else: ?>
                                <a href="<?=$queryBase?>page=<?=$i?>"><?=$i?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if($page < $totalPages): ?>
                            <a href="<?=$queryBase?>page=<?=$page+1?>">下一页 »</a>
                        <?php else: ?>
                            <span class="disabled">下一页 »</span>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php else: ?>
                    <div class="empty-state">📭 暂无图片</div>
                    <?php endif; ?>
                </div>
            <?php endif; // 结束权限判断 ?>
        </div>
    </div>
</div>

<!-- 图片放大模态框 -->
<div id="imageModal" class="modal" onclick="closeModal()">
    <span class="close">&times;</span>
    <img id="modalImg" src="" alt="放大图片">
</div>

<script>
function openModal(src) {
    document.getElementById('modalImg').src = src;
    document.getElementById('imageModal').classList.add('show');
}
function closeModal() {
    document.getElementById('imageModal').classList.remove('show');
}
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeModal();
});

// 复制单张图片
function copySingle(url) {
    navigator.clipboard.writeText(url).then(() => {
        alert('已复制图片链接：' + url);
    }).catch(() => {
        // 降级方案
        const textarea = document.createElement('textarea');
        textarea.value = url;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('已复制图片链接：' + url);
    });
}

// 复制全部链接
function copyAllLinks() {
    const items = document.querySelectorAll('.gallery-item');
    if (items.length === 0) {
        alert('没有图片可复制');
        return;
    }
    let urls = [];
    items.forEach(item => {
        const url = item.getAttribute('data-url');
        if (url) urls.push(url);
    });
    if (urls.length === 0) {
        alert('未找到图片链接');
        return;
    }
    const text = urls.join('\n');
    navigator.clipboard.writeText(text).then(() => {
        alert('已复制 ' + urls.length + ' 个图片链接到剪贴板');
    }).catch(() => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
        alert('已复制 ' + urls.length + ' 个图片链接到剪贴板');
    });
}
</script>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>