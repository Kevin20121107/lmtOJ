<?php
/**
 * LMTOJ · 最后一次提交
 * 对外入口：/decrypt5
 * 物理文件：/qwq.php
 */

require_once 'visit_log.php';
session_start();

error_reporting(E_ALL);
ini_set('display_errors', '1');

date_default_timezone_set('Asia/Shanghai');

if (!isset($_SESSION['uid'])) {
    header('Location: https://lmtoj.cn/login.php');
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset('utf8mb4');

$uid = (int)$_SESSION['uid'];

/* 对外统一入口 */
$SELF = '/decrypt5';


/* =========================================================
   活动时间
   ========================================================= */

$EVENT_START = '2026-09-14 22:15:00';
$EVENT_END   = '2026-09-20 20:00:00';

$now   = new DateTimeImmutable('now');
$start = new DateTimeImmutable($EVENT_START);
$end   = new DateTimeImmutable($EVENT_END);

if ($now < $start) {
    $eventStatus = 'preheat';
} elseif ($now < $end) {
    $eventStatus = 'active';
} else {
    $eventStatus = 'ended';
}


/* =========================================================
   用户
   ========================================================= */

$stmt = $conn->prepare("SELECT name FROM users WHERE uid = ? LIMIT 1");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res  = $stmt->get_result();
$user = $res ? $res->fetch_assoc() : null;
$stmt->close();

if (!$user) exit('用户不存在');

$userName = $user['name'];


/* =========================================================
   CSRF
   ========================================================= */

$csrf = csrf_token();


/* =========================================================
   初始化状态
   ========================================================= */

$stmt = $conn->prepare("
    INSERT IGNORE INTO decrypt5_event_state
    (uid, created_at, updated_at)
    VALUES (?, NOW(), NOW())
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$stmt->close();

$stmt = $conn->prepare("SELECT * FROM decrypt5_event_state WHERE uid = ? LIMIT 1");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res   = $stmt->get_result();
$state = $res ? $res->fetch_assoc() : null;
$stmt->close();

if (!$state) {
    $state = [
        'collapse_triggered' => 0,
        'collapse_count'     => 0,
        'collapse_first_at'  => null,
        'rebirth_triggered'  => 0,
        'rebirth_count'      => 0,
        'rebirth_first_at'   => null,
        'last_event'         => '',
        'last_event_at'      => null,
    ];
}


/* =========================================================
   事件日志
   ========================================================= */

function decrypt5_log_event(
    mysqli $conn,
    int $uid,
    string $eventType,
    string $eventCode = '',
    string $page = '',
    array $metadata = []
): void {
    $metaJson = json_encode(
        $metadata,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    $stmt = $conn->prepare("
        INSERT INTO decrypt5_event_log
        (uid, event_type, event_code, page, metadata, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $stmt->bind_param('issss', $uid, $eventType, $eventCode, $page, $metaJson);
    $stmt->execute();
    $stmt->close();
}


/* =========================================================
   首次访问（速通起点）
   ========================================================= */

$stmt = $conn->prepare("SELECT uid FROM decrypt5_speedrun WHERE uid = ? LIMIT 1");
$stmt->bind_param('i', $uid);
$stmt->execute();
$r = $stmt->get_result();
$hasSpeed = $r ? ($r->num_rows > 0) : false;
$stmt->close();

if (!$hasSpeed) {
    $stmt = $conn->prepare("
        INSERT INTO decrypt5_speedrun
        (uid, start_at, completed, created_at)
        VALUES (?, NOW(), 0, NOW())
    ");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $stmt->close();

    decrypt5_log_event($conn, $uid, 'SPEEDRUN_START', 'FIRST_VISIT', $SELF);
}


/* =========================================================
   GET 版重生（不带 _csrf，绕过全局 POST CSRF）
   ========================================================= */

if (isset($_GET['do_rebirth']) && $_GET['do_rebirth'] === '1') {

    $stmt = $conn->prepare("
        SELECT collapse_triggered, rebirth_triggered
        FROM decrypt5_event_state
        WHERE uid = ? LIMIT 1
    ");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $r   = $stmt->get_result();
    $row = $r ? $r->fetch_assoc() : null;
    $stmt->close();

    if ($row && (int)$row['collapse_triggered']) {

        $already = (int)$row['rebirth_triggered'];
        $first   = ($already === 0);

        $stmt = $conn->prepare("
            UPDATE decrypt5_event_state
            SET rebirth_triggered = 1,
                rebirth_count = rebirth_count + 1,
                rebirth_first_at = CASE
                    WHEN rebirth_first_at IS NULL THEN NOW()
                    ELSE rebirth_first_at
                END,
                last_event = 'rebirth',
                last_event_at = NOW(),
                updated_at = NOW()
            WHERE uid = ?
        ");
        $stmt->bind_param('i', $uid);
        $stmt->execute();
        $stmt->close();

        decrypt5_log_event(
            $conn, $uid,
            'REBIRTH',
            $first ? 'FIRST_REBIRTH' : 'REBIRTH_AGAIN',
            $SELF,
            ['first' => $first]
        );
    }

    header('Location: ' . $SELF);
    exit;
}


/* =========================================================
   卡片
   ========================================================= */

$ownedCards = [];
$stmt = $conn->prepare("SELECT card_key FROM decrypt5_collections WHERE uid = ?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
if ($res) {
    while ($row = $res->fetch_assoc()) $ownedCards[$row['card_key']] = true;
}
$stmt->close();


/* =========================================================
   已完成章节
   ========================================================= */

$completed = [];
$stmt = $conn->prepare("
    SELECT chapter FROM decrypt5_submissions
    WHERE uid = ? AND is_correct = 1
    GROUP BY chapter
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
if ($res) {
    while ($row = $res->fetch_assoc()) $completed[] = (int)$row['chapter'];
}
$stmt->close();


/* =========================================================
   是否进入隐藏阶段 / 是否真结局
   ========================================================= */

$investigateStarted = 0;
$trueEnded = 0;

$stmt = $conn->prepare("
    SELECT event_type FROM decrypt5_event_log
    WHERE uid = ? AND event_type IN ('INVESTIGATE_START','TRUE_ENDING')
");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res = $stmt->get_result();
if ($res) {
    while ($row = $res->fetch_assoc()) {
        if ($row['event_type'] === 'INVESTIGATE_START') $investigateStarted = 1;
        if ($row['event_type'] === 'TRUE_ENDING')       $trueEnded = 1;
    }
}
$stmt->close();


/* =========================================================
   隐藏入口
   ========================================================= */

if (isset($_GET['archive']) && $_GET['archive'] === 'empty') {
    if (!$investigateStarted && in_array(5, $completed, true)) {
        decrypt5_log_event($conn, $uid, 'INVESTIGATE_START', 'URL_ARCHIVE_EMPTY', $SELF . '?archive=empty');
        $investigateStarted = 1;
    }
}


/* =========================================================
   五章 + 隐藏第六章
   ========================================================= */

$chapters = [
    1 => [
        'key' => 'SIGNAL', 'title' => '信号', 'difficulty' => '★☆☆☆☆',
        'description' => '第一份信号。它看起来只是一些数字。',
        'question' => '01001100 01001101 01010100 01001111 01001010',
        'extra' => '', 'answer' => 'LMTOJ',
    ],
    2 => [
        'key' => 'CAESAR', 'title' => '凯撒', 'difficulty' => '★★☆☆☆',
        'description' => '文字被移动了，但位置仍然存在。',
        'question' => 'YLIVVA',
        'extra' => '提示：每个字母向后移动 7 位。',
        'answer' => 'REBOOT',
    ],
    3 => [
        'key' => 'SOURCE', 'title' => '源代码', 'difficulty' => '★★★☆☆',
        'description' => '页面不会告诉你真相。',
        'question' => '<!-- 43 48 45 43 4B 5F 54 48 45 5F 53 4F 55 52 43 45 -->',
        'extra' => '这次不要只看页面上显示出来的文字。',
        'answer' => 'CHECK_THE_SOURCE',
    ],
    4 => [
        'key' => 'UNKNOWN', 'title' => '未知', 'difficulty' => '★★★★☆',
        'description' => '这个提交者不存在于当前名单。',
        'question' => "请计算下面序列中缺失的数字：\n\n2, 6, 12, 20, 30, ?, 56",
        'extra' => '不要猜。寻找每一项与位置之间的关系。',
        'answer' => '42',
    ],
    5 => [
        'key' => 'LAST', 'title' => '最后', 'difficulty' => '★★★★★',
        'description' => '最后一张卡片不会告诉你答案。',
        'question' => "信号 → 凯撒 → 源代码 → 未知\n\n把你获得的四张卡片背面的关键词连接起来。",
        'extra' => '如果你真的完成了前四章，你已经拥有解开它所需要的一切。',
        'answer' => 'SUBMISSION',
    ],
    6 => [
        'key' => 'ECHO', 'title' => '回响', 'difficulty' => '？？？？？',
        'description' => '案件已结。但档案还在回响。',
        'question' =>
            "最后一次提交者没有留下姓名，只留下五个答案。\n" .
            "把它们首字母连起来，你会看到最后的密码。\n\n" .
            "1. ????OJ\n" .
            "2. REBOOT\n" .
            "3. CHECK_THE_????\n" .
            "4. 42\n" .
            "5. ??????????",
        'extra' => '当你看到这句话时，说明你已经知道答案是谁写的了。',
        'answer' => 'LRC4S',
    ],
];


/* =========================================================
   提交答案
   ========================================================= */

$message       = '';
$messageType   = '';
$justCollapsed = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['chapter'])) {

    if ($eventStatus !== 'active') {

        $message = '活动尚未开始或已经结束。';
        $messageType = 'error';

    } else {

        $chapter  = (int)$_POST['chapter'];
        $answer   = trim($_POST['answer'] ?? '');

        $postCsrf = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        $csrfOk = hash_equals($csrf, $postCsrf);

        if ($chapter === 6 && !$investigateStarted) {
            $message = '不存在的档案。';
            $messageType = 'error';
        } elseif (!$csrfOk) {
            $message = '请求验证失败，请刷新页面。';
            $messageType = 'error';
        } elseif (!isset($chapters[$chapter])) {
            $message = '不存在的档案。';
            $messageType = 'error';
        } elseif ($chapter === 5 && count(array_intersect([1,2,3,4], $completed)) < 4) {
            $message = '第五档案尚未开放。';
            $messageType = 'error';
        } else {

            $normalized = strtoupper(preg_replace('/\s+/', '', $answer));
            $correct    = strtoupper(preg_replace('/\s+/', '', $chapters[$chapter]['answer']));
            $isCorrect  = hash_equals($correct, $normalized);
            $ansHash    = hash('sha256', $normalized);
            $isInt      = $isCorrect ? 1 : 0;

            $stmt = $conn->prepare("
                INSERT INTO decrypt5_submissions
                (uid, chapter, answer_hash, is_correct, submitted_at)
                VALUES (?, ?, ?, ?, NOW())
            ");
            $stmt->bind_param('iisi', $uid, $chapter, $ansHash, $isInt);
            $stmt->execute();
            $stmt->close();

            decrypt5_log_event(
                $conn, $uid,
                'CHAPTER_SUBMIT',
                'CHAPTER_' . $chapter . ($isCorrect ? '_CORRECT' : '_WRONG'),
                $SELF,
                ['chapter' => $chapter, 'correct' => $isCorrect]
            );

            if ($isCorrect) {

                $cardKey = $chapters[$chapter]['key'];

                $stmt = $conn->prepare("
                    INSERT IGNORE INTO decrypt5_collections
                    (uid, card_key, obtained_at)
                    VALUES (?, ?, NOW())
                ");
                $stmt->bind_param('is', $uid, $cardKey);
                $stmt->execute();
                $stmt->close();

                if ($chapter === 4) {

                    $stmt = $conn->prepare("SELECT collapse_triggered FROM decrypt5_event_state WHERE uid = ? LIMIT 1");
                    $stmt->bind_param('i', $uid);
                    $stmt->execute();
                    $r   = $stmt->get_result();
                    $row = $r ? $r->fetch_assoc() : null;
                    $stmt->close();

                    $collapsed = $row ? (int)$row['collapse_triggered'] : 0;

                    if (!$collapsed) {
                        $stmt = $conn->prepare("
                            UPDATE decrypt5_event_state
                            SET collapse_triggered = 1,
                                collapse_count = collapse_count + 1,
                                collapse_first_at = NOW(),
                                last_event = 'collapse',
                                last_event_at = NOW(),
                                updated_at = NOW()
                            WHERE uid = ?
                        ");
                        $stmt->bind_param('i', $uid);
                        $stmt->execute();
                        $stmt->close();

                        decrypt5_log_event($conn, $uid, 'COLLAPSE', 'CHAPTER_4_COLLAPSE', $SELF, ['chapter' => 4]);

                        $message       = '正确。……但是系统发生了异常。';
                        $messageType   = 'collapse';
                        $justCollapsed = true;
                    } else {
                        $message     = '档案「未知」已完成。';
                        $messageType = 'success';
                    }

                } elseif ($chapter === 5) {
                    $message     = '正确。案件已经结案。';
                    $messageType = 'success';

                } elseif ($chapter === 6) {
                    $stmt = $conn->prepare("
                        UPDATE decrypt5_speedrun
                        SET finish_at = NOW(),
                            elapsed_sec = TIMESTAMPDIFF(SECOND, start_at, NOW()),
                            completed = 1
                        WHERE uid = ?
                    ");
                    $stmt->bind_param('i', $uid);
                    $stmt->execute();
                    $stmt->close();

                    decrypt5_log_event($conn, $uid, 'TRUE_ENDING', 'CHAPTER_6_CORRECT', $SELF);
                    $trueEnded = 1;

                    $message     = '……你找到了真正的最后一次提交。';
                    $messageType = 'success';

                } else {
                    $message     = '档案解密成功：' . $chapters[$chapter]['title'];
                    $messageType = 'success';
                }

                $completed[] = $chapter;
                $completed   = array_values(array_unique($completed));
                $ownedCards[$cardKey] = true;

            } else {
                $message     = '解密失败。档案拒绝了你的答案。';
                $messageType = 'error';
            }
        }
    }
}


/* =========================================================
   重新读取状态
   ========================================================= */

$stmt = $conn->prepare("SELECT * FROM decrypt5_event_state WHERE uid = ? LIMIT 1");
$stmt->bind_param('i', $uid);
$stmt->execute();
$res    = $stmt->get_result();
$state2 = $res ? $res->fetch_assoc() : null;
$stmt->close();

if ($state2) $state = $state2;

$fourDone = count(array_intersect([1,2,3,4], $completed)) === 4;
$fiveDone = in_array(5, $completed, true);
$sixDone  = in_array(6, $completed, true);

$collapseTriggered = !empty($state['collapse_triggered']);
$rebirthTriggered  = !empty($state['rebirth_triggered']);

$endFake = $fiveDone && !$investigateStarted && !$trueEnded;
$endTrue = $trueEnded || $sixDone;


/* 长期特效 */

$permClass = '';
$permBarText = '';
$permFootText = '';

if ($endTrue) {
    $permClass    = 'decrypt5-perm-true';
    $permBarText  = '[TRUE ENDING] THE ARCHIVE IS EMPTY.';
    $permFootText = '[TRUE ENDING] YOU ARE THE LAST SUBMISSION.';
} elseif ($rebirthTriggered) {
    $permClass    = 'decrypt5-perm-reborn';
    $permBarText  = '[REBORN] 档案状态：已重生';
    $permFootText = '[REBORN] 会话已恢复 · 前世已标记';
} elseif ($collapseTriggered) {
    $permClass    = 'decrypt5-perm-corrupted';
    $permBarText  = '[CORRUPTED] 档案状态：已损坏';
    $permFootText = '[CORRUPTED] 等待重启…';
}


/* =========================================================
   最终档案时间
   ========================================================= */

$finalSubmissionAt = null;
$finalCollapseAt   = $state['collapse_first_at'] ?? null;
$finalRebirthAt    = $state['rebirth_first_at']  ?? null;

if ($fiveDone) {
    $stmt = $conn->prepare("
        SELECT submitted_at FROM decrypt5_submissions
        WHERE uid = ? AND chapter = 5 AND is_correct = 1
        ORDER BY submitted_at ASC LIMIT 1
    ");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $r = $stmt->get_result();
    $row = $r ? $r->fetch_assoc() : null;
    $stmt->close();
    $finalSubmissionAt = $row['submitted_at'] ?? null;
}


/* =========================================================
   速通榜
   ========================================================= */

$board = [];
$stmt = $conn->prepare("
    SELECT s.uid, s.elapsed_sec, s.finish_at, u.name
    FROM decrypt5_speedrun s
    LEFT JOIN users u ON u.uid = s.uid
    WHERE s.completed = 1
    ORDER BY s.elapsed_sec ASC
    LIMIT 20
");
$stmt->execute();
$r = $stmt->get_result();
if ($r) {
    while ($row = $r->fetch_assoc()) $board[] = $row;
}
$stmt->close();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>最后一次提交 · LMTOJ</title>
<style>
* { box-sizing: border-box; }
body {
    margin: 0;
    background: radial-gradient(circle at 50% 0%, rgba(255,255,255,.055), transparent 40%), #080808;
    color: #eee;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif;
}
.decrypt5-page { width: min(1200px, calc(100% - 36px)); margin: auto; padding: 50px 0 100px; }
.decrypt5-hero {
    min-height: 70vh; display: flex; flex-direction: column;
    align-items: center; justify-content: center; text-align: center;
}
.decrypt5-kicker { font-family: monospace; font-size: 11px; letter-spacing: 6px; opacity: .4; margin-bottom: 28px; }
.decrypt5-title { margin: 0; font-size: clamp(45px, 10vw, 115px); line-height: .9; letter-spacing: -2px; font-weight: 900; }
.decrypt5-subtitle { margin-top: 35px; font-family: monospace; font-size: 12px; letter-spacing: 5px; opacity: .45; }
.decrypt5-countdown { width: min(700px, 100%); margin-top: 50px; padding: 25px; border: 1px solid #292929; background: rgba(255,255,255,.02); }
.decrypt5-count-label { font-family: monospace; font-size: 10px; letter-spacing: 4px; opacity: .4; margin-bottom: 12px; }
.decrypt5-count-status { font-size: 14px; font-family: monospace; letter-spacing: 3px; }
.decrypt5-count { margin-top: 15px; font-family: monospace; font-size: clamp(28px, 5vw, 55px); letter-spacing: 4px; }
.decrypt5-section { margin-top: 100px; }
.decrypt5-section-title { margin-bottom: 25px; font-family: monospace; font-size: 11px; letter-spacing: 5px; opacity: .4; }
.decrypt5-story { padding: 30px; border-left: 2px solid #555; background: rgba(255,255,255,.018); line-height: 2; }
.decrypt5-chapters { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 18px; }
.decrypt5-chapter {
    position: relative; padding: 26px; min-height: 340px;
    border: 1px solid #292929;
    background: linear-gradient(145deg, rgba(255,255,255,.04), rgba(255,255,255,.008));
    transition: .25s ease;
}
.decrypt5-chapter:hover { transform: translateY(-5px); border-color: #555; }
.decrypt5-chapter.hidden-chapter {
    border-color: rgba(159,255,178,.35);
    background: linear-gradient(145deg, rgba(159,255,178,.06), rgba(159,255,178,.01));
}
.decrypt5-chapter-number { font-family: monospace; font-size: 10px; letter-spacing: 3px; opacity: .35; }
.decrypt5-chapter h2 { margin: 20px 0; letter-spacing: 3px; font-size: 25px; }
.decrypt5-difficulty { font-family: monospace; font-size: 11px; opacity: .45; }
.decrypt5-description { color: #aaa; line-height: 1.8; min-height: 65px; }
.decrypt5-question {
    white-space: pre-wrap; word-break: break-word;
    margin-top: 25px; padding: 16px;
    background: rgba(0,0,0,.45); border: 1px solid #222;
    font-family: monospace; font-size: 13px; line-height: 1.7;
}
.decrypt5-extra { margin-top: 15px; color: #888; font-size: 12px; line-height: 1.7; }
.decrypt5-form { margin-top: 20px; }
.decrypt5-input {
    width: 100%; padding: 13px 15px;
    background: #0c0c0c; border: 1px solid #333; color: #fff;
    outline: none; font-family: monospace;
}
.decrypt5-input:focus { border-color: #777; }
.decrypt5-button {
    width: 100%; margin-top: 10px; padding: 13px;
    border: 1px solid #444; background: #eee; color: #080808;
    cursor: pointer; font-weight: 700; font-family: monospace; letter-spacing: 2px;
}
.decrypt5-button:hover { background: #fff; }
.decrypt5-solved {
    margin-top: 25px; padding: 15px;
    border: 1px solid rgba(150,255,180,.2);
    background: rgba(100,255,140,.025);
    color: #9fffb2;
    font-family: monospace; font-size: 11px; letter-spacing: 2px;
}
.decrypt5-locked { opacity: .4; }
.decrypt5-lock-message { margin-top: 30px; font-family: monospace; font-size: 11px; opacity: .5; }
.decrypt5-message {
    margin: 25px 0; padding: 20px;
    border: 1px solid #333; background: rgba(255,255,255,.025);
    font-family: monospace; line-height: 1.8;
}
.decrypt5-message.success { border-color: rgba(120,255,150,.3); color: #aaffbd; }
.decrypt5-message.error   { border-color: rgba(255,100,100,.3); color: #ffaaaa; }
.decrypt5-message.collapse { border-color: rgba(255,255,255,.3); animation: glitch .15s infinite; }
@keyframes glitch { 0%{transform:translateX(0);} 50%{transform:translateX(2px);} 100%{transform:translateX(-2px);} }
.decrypt5-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px,1fr)); gap: 18px; }
.decrypt5-card {
    aspect-ratio: 2 / 3; position: relative; overflow: hidden;
    padding: 20px; display: flex; flex-direction: column;
    justify-content: space-between;
    border: 1px solid #3b3b3b;
    background: linear-gradient(145deg, #1b1b1b, #070707);
    font-family: monospace;
}
.decrypt5-card::after {
    content: ""; position: absolute; inset: 10px;
    border: 1px solid rgba(255,255,255,.07); pointer-events: none;
}
.decrypt5-card.locked { opacity: .22; filter: grayscale(1); }
.decrypt5-card.echo { border-color: rgba(159,255,178,.4); }
.decrypt5-card-top { font-size: 9px; letter-spacing: 3px; opacity: .4; }
.decrypt5-card-name { font-size: 22px; letter-spacing: 3px; font-weight: 800; }
.decrypt5-card-bottom { font-size: 9px; letter-spacing: 2px; opacity: .4; }
.decrypt5-final {
    padding: 40px; border: 1px solid #333;
    background: radial-gradient(circle at center, rgba(255,255,255,.04), transparent 65%);
    text-align: center;
}
.decrypt5-final h2 { letter-spacing: 5px; font-size: clamp(25px,5vw,50px); }
.decrypt5-final p { color: #888; line-height: 2; }
.decrypt5-footer {
    margin-top: 100px; padding-top: 25px;
    border-top: 1px solid #222;
    font-family: monospace; font-size: 10px; letter-spacing: 2px; opacity: .25;
}

#decrypt5-perm {
    position: fixed; inset: 0;
    z-index: 2147483600;
    pointer-events: none; display: none;
}
body.decrypt5-perm-corrupted #decrypt5-perm,
body.decrypt5-perm-reborn    #decrypt5-perm,
body.decrypt5-perm-true      #decrypt5-perm { display: block; }

body.decrypt5-perm-corrupted #decrypt5-perm {
    background: repeating-linear-gradient(0deg, rgba(255,60,60,.035) 0, rgba(255,60,60,.035) 1px, transparent 1px, transparent 4px);
    box-shadow: inset 0 0 140px rgba(255,40,40,.18), inset 0 0 40px rgba(255,80,80,.10);
    animation: perm-flicker 5s infinite;
}
@keyframes perm-flicker {
    0%, 92%, 100% { opacity: 1; }
    93%           { opacity: .55; }
    94%           { opacity: 1; }
    97%           { opacity: .7; }
}
body.decrypt5-perm-reborn #decrypt5-perm {
    background: repeating-linear-gradient(0deg, rgba(120,255,160,.025) 0, rgba(120,255,160,.025) 1px, transparent 1px, transparent 4px);
    box-shadow: inset 0 0 120px rgba(120,255,160,.10);
    animation: perm-breathe 7s ease-in-out infinite;
}
@keyframes perm-breathe {
    0%, 100% { opacity: .85; }
    50%      { opacity: 1; }
}
body.decrypt5-perm-true #decrypt5-perm {
    background: repeating-linear-gradient(0deg, rgba(159,255,178,.035) 0, rgba(159,255,178,.035) 1px, transparent 1px, transparent 4px);
    box-shadow: inset 0 0 180px rgba(120,255,160,.14);
    animation: perm-breathe 5s ease-in-out infinite;
}

#decrypt5-perm-bar {
    position: fixed; top: 0; left: 0; right: 0;
    z-index: 2147483610;
    padding: 5px 14px;
    background: #050505;
    color: #d8d8d8;
    font-family: "SFMono-Regular", Consolas, monospace;
    font-size: 11px; letter-spacing: 2px;
    text-align: center;
    border-bottom: 1px solid rgba(255,255,255,.08);
    display: none;
}
body.decrypt5-perm-corrupted #decrypt5-perm-bar,
body.decrypt5-perm-reborn    #decrypt5-perm-bar,
body.decrypt5-perm-true      #decrypt5-perm-bar { display: block; }
body.decrypt5-perm-corrupted #decrypt5-perm-bar { color: #ffaaaa; border-bottom-color: rgba(255,80,80,.3); }
body.decrypt5-perm-reborn    #decrypt5-perm-bar { color: #9fffb2; border-bottom-color: rgba(120,255,160,.25); }
body.decrypt5-perm-true      #decrypt5-perm-bar { color: #9fffb2; border-bottom-color: rgba(159,255,178,.4); }
body.decrypt5-perm-corrupted,
body.decrypt5-perm-reborn,
body.decrypt5-perm-true { padding-top: 26px; }

#decrypt5-perm-foot {
    position: fixed; left: 50%; bottom: 18px;
    transform: translateX(-50%);
    z-index: 2147483610;
    max-width: calc(100vw - 32px);
    padding: 10px 18px;
    background: rgba(5,5,5,.94);
    border: 1px solid rgba(255,255,255,.14);
    color: #ddd;
    font-family: monospace; font-size: 11px; letter-spacing: 2px;
    display: none; text-align: center;
    box-shadow: 0 8px 30px rgba(0,0,0,.5);
}
body.decrypt5-perm-corrupted #decrypt5-perm-foot,
body.decrypt5-perm-reborn    #decrypt5-perm-foot,
body.decrypt5-perm-true      #decrypt5-perm-foot { display: block; }
body.decrypt5-perm-corrupted #decrypt5-perm-foot { color: #ffaaaa; border-color: rgba(255,80,80,.35); }
body.decrypt5-perm-reborn    #decrypt5-perm-foot { color: #9fffb2; border-color: rgba(120,255,160,.3); }
body.decrypt5-perm-true      #decrypt5-perm-foot { color: #9fffb2; border-color: rgba(159,255,178,.5); }

#decrypt5-fx {
    position: fixed; inset: 0; z-index: 2147483647;
    display: none; align-items: center; justify-content: center;
    background: repeating-linear-gradient(0deg, rgba(255,255,255,.025) 0, rgba(255,255,255,.025) 1px, transparent 1px, transparent 4px), #050505;
    color: #fff; font-family: monospace; pointer-events: none;
}
#decrypt5-fx.active { display: flex; }
.decrypt5-fx-inner { width: min(900px, 90vw); text-align: center; }
.decrypt5-fx-system { font-size: 11px; letter-spacing: 5px; opacity: .45; margin-bottom: 30px; }
.decrypt5-fx-title { font-size: clamp(38px, 8vw, 105px); font-weight: 900; line-height: .95; letter-spacing: 8px; }
.decrypt5-fx-subtitle { margin-top: 30px; font-size: 12px; letter-spacing: 4px; opacity: .55; }
.decrypt5-fx-collapse { animation: fx-shake .08s infinite, fx-flicker .12s infinite; }
@keyframes fx-shake {
    0%{transform:translate(0,0);} 20%{transform:translate(-7px,2px);}
    40%{transform:translate(5px,-3px);} 60%{transform:translate(-3px,4px);}
    80%{transform:translate(8px,-2px);} 100%{transform:translate(0,0);}
}
@keyframes fx-flicker { 0%{opacity:1;} 50%{opacity:.25;} 100%{opacity:1;} }
.decrypt5-fx-rebirth { animation: fx-rebirth-in 1s ease forwards; }
@keyframes fx-rebirth-in {
    from { opacity: 0; transform: scale(1.15); filter: blur(15px); }
    to   { opacity: 1; transform: scale(1); filter: blur(0); }
}

.final-archive {
    position: relative; min-height: 100vh;
    display: flex; align-items: center; justify-content: center;
    padding: 60px 20px;
    background: repeating-linear-gradient(0deg, rgba(255,255,255,.018) 0, rgba(255,255,255,.018) 1px, transparent 1px, transparent 4px), radial-gradient(circle at 50% 0%, rgba(255,255,255,.05), transparent 45%), #050505;
    color: #eee;
    font-family: "SFMono-Regular", Consolas, "Liberation Mono", monospace;
    overflow: hidden;
}
.final-archive-inner { width: min(760px, 100%); text-align: left; }
.final-archive-kicker { font-size: 11px; letter-spacing: 6px; opacity: .4; margin-bottom: 40px; }
.final-archive-lines { border-top: 1px solid #222; border-bottom: 1px solid #222; padding: 12px 0; }
.final-line {
    display: flex; justify-content: space-between; align-items: baseline;
    padding: 12px 0; border-bottom: 1px dashed #1c1c1c;
    font-size: 13px; animation: final-in .6s ease both;
}
.final-line:last-child { border-bottom: none; }
.final-key { color: #777; letter-spacing: 3px; }
.final-val { color: #eee; letter-spacing: 2px; }
.final-val-strong { color: #9fffb2; }
.final-archive-quote {
    margin-top: 40px; font-size: 13px; line-height: 2;
    color: #bbb; letter-spacing: 1px;
    animation: final-in 1.2s ease .5s both;
}
.final-archive-actions { margin-top: 45px; text-align: center; animation: final-in 1.4s ease 1s both; }
.final-archive-foot { margin-top: 60px; font-size: 10px; letter-spacing: 4px; opacity: .3; text-align: center; }
@keyframes final-in { from{opacity:0;transform:translateY(6px);} to{opacity:1;transform:translateY(0);} }
.final-archive.hidden { display: none; }
body.final-active .decrypt5-page { display: none; }

.speedrun-board {
    margin-top: 60px;
    border: 1px solid #222;
    background: rgba(255,255,255,.015);
    padding: 25px;
    font-family: monospace;
}
.speedrun-board h3 {
    margin: 0 0 20px; font-size: 12px; letter-spacing: 6px;
    opacity: .5; font-weight: normal; text-transform: uppercase;
}
.speedrun-row {
    display: grid; grid-template-columns: 40px 1fr 110px 160px;
    gap: 10px; padding: 10px 0;
    border-bottom: 1px dashed #1a1a1a; font-size: 12px;
    align-items: baseline;
}
.speedrun-row:last-child { border-bottom: none; }
.speedrun-row .rank { color: #666; }
.speedrun-row .name { color: #ddd; }
.speedrun-row .time { color: #9fffb2; text-align: right; }
.speedrun-row .date { color: #666; text-align: right; font-size: 11px; }
.speedrun-row.top1 .rank { color: #ffe08a; }
.speedrun-row.top1 .time { color: #ffe08a; text-shadow: 0 0 12px rgba(255,224,138,.4); }
.speedrun-row.top2 .rank { color: #ddd; }
.speedrun-row.top3 .rank { color: #d4a373; }
.speedrun-empty { color: #666; font-size: 12px; padding: 20px 0; text-align: center; }

.final-fake .final-archive-kicker { color: #888; }
.final-fake .final-val-strong    { color: #b0b0b0; }
.final-fake .final-archive-foot  { color: #666; }

.final-true {
    background: repeating-linear-gradient(0deg, rgba(160,255,190,.02) 0, rgba(160,255,190,.02) 1px, transparent 1px, transparent 4px), radial-gradient(circle at 50% 0%, rgba(160,255,190,.07), transparent 45%), #050505;
}
.final-true .final-archive-kicker { color: #9fffb2; }
.final-true .final-val-strong     { color: #9fffb2; text-shadow: 0 0 12px rgba(159,255,178,.35); }
.final-true .final-archive-quote  { color: #cfeed8; }
.final-true .final-archive-foot   { color: #7fbf90; }
.final-true .final-line { animation: final-in .8s ease both; }
.final-true .final-line:nth-child(1){animation-delay:.10s;}
.final-true .final-line:nth-child(2){animation-delay:.25s;}
.final-true .final-line:nth-child(3){animation-delay:.40s;}
.final-true .final-line:nth-child(4){animation-delay:.55s;}
.final-true .final-line:nth-child(5){animation-delay:.70s;}
.final-true .final-line:nth-child(6){animation-delay:.85s;}
.final-true .final-line:nth-child(7){animation-delay:1.00s;}

@media (max-width:600px){
    .decrypt5-page { width: calc(100% - 24px); padding-top: 25px; }
    .decrypt5-title { letter-spacing: -1px; }
    .decrypt5-section { margin-top: 70px; }
    .decrypt5-story { padding: 20px; }
    .decrypt5-chapter { min-height: 300px; }
    .final-archive { padding: 40px 16px; }
    .speedrun-row { grid-template-columns: 30px 1fr 90px; }
    .speedrun-row .date { display: none; }
}
</style>
</head>
<body class="<?= htmlspecialchars($permClass, ENT_QUOTES, 'UTF-8') ?>">

<div id="decrypt5-perm"></div>

<?php if ($permBarText !== ''): ?>
<div id="decrypt5-perm-bar"><?= htmlspecialchars($permBarText, ENT_QUOTES, 'UTF-8') ?></div>
<div id="decrypt5-perm-foot"><?= htmlspecialchars($permFootText, ENT_QUOTES, 'UTF-8') ?></div>
<?php endif; ?>

<div id="decrypt5-fx">
    <div class="decrypt5-fx-inner">
        <div class="decrypt5-fx-system" id="decrypt5-fx-system">LMTOJ / 档案 / 000000</div>
        <div class="decrypt5-fx-title"  id="decrypt5-fx-title">系统故障</div>
        <div class="decrypt5-fx-subtitle" id="decrypt5-fx-subtitle">档案已损坏</div>
    </div>
</div>

<?php if ($endTrue): ?>
<div id="final-archive" class="final-archive final-true">
    <div class="final-archive-inner">
        <div class="final-archive-kicker">LMTOJ / 最终提交 / 真结局</div>
        <div class="final-archive-lines">
            <div class="final-line"><span class="final-key">提交者</span><span class="final-val">你自己</span></div>
            <div class="final-line"><span class="final-key">用户名</span><span class="final-val"><?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span></div>
            <div class="final-line"><span class="final-key">状态</span><span class="final-val final-val-strong">已重生</span></div>
            <div class="final-line"><span class="final-key">崩坏时间</span><span class="final-val"><?= $finalCollapseAt ? htmlspecialchars($finalCollapseAt, ENT_QUOTES, 'UTF-8') : '——' ?></span></div>
            <div class="final-line"><span class="final-key">重生时间</span><span class="final-val"><?= $finalRebirthAt ? htmlspecialchars($finalRebirthAt, ENT_QUOTES, 'UTF-8') : '——' ?></span></div>
            <div class="final-line"><span class="final-key">最后提交</span><span class="final-val"><?= $finalSubmissionAt ? htmlspecialchars($finalSubmissionAt, ENT_QUOTES, 'UTF-8') : '——' ?></span></div>
            <div class="final-line"><span class="final-key">档案状态</span><span class="final-val final-val-strong">THE ARCHIVE IS EMPTY.</span></div>
        </div>
        <div class="final-archive-quote">
            「如果你看到这句话，说明我已经提交过了。」<br>
            —— 写下这句话的人，就是你。
        </div>
        <div class="final-archive-actions">
            <button type="button" id="final-toggle" class="decrypt5-button"
                    style="max-width:220px;display:inline-block;margin:0 8px">查看档案</button>
        </div>
        <div class="final-archive-foot">YOU ARE THE LAST SUBMISSION.</div>

        <div class="speedrun-board">
            <h3>SPEEDRUN · 真结局速通榜</h3>
            <?php if (empty($board)): ?>
                <div class="speedrun-empty">还没有人完成真结局。</div>
            <?php else: ?>
                <?php foreach ($board as $i => $row): ?>
                    <?php
                        $rank = $i + 1;
                        $cls  = $rank === 1 ? 'top1' : ($rank === 2 ? 'top2' : ($rank === 3 ? 'top3' : ''));
                        $secs = (int)$row['elapsed_sec'];
                        $h = intdiv($secs, 3600);
                        $m = intdiv($secs % 3600, 60);
                        $s = $secs % 60;
                        $timeStr = sprintf('%02d:%02d:%02d', $h, $m, $s);
                    ?>
                    <div class="speedrun-row <?= $cls ?>">
                        <span class="rank">#<?= $rank ?></span>
                        <span class="name"><?= htmlspecialchars($row['name'] ?? ('UID ' . $row['uid']), ENT_QUOTES, 'UTF-8') ?></span>
                        <span class="time"><?= $timeStr ?></span>
                        <span class="date"><?= htmlspecialchars($row['finish_at'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php elseif ($endFake): ?>
<div id="final-archive" class="final-archive final-fake">
    <div class="final-archive-inner">
        <div class="final-archive-kicker">LMTOJ / 档案 / 案件已结</div>
        <div class="final-archive-lines">
            <div class="final-line"><span class="final-key">提交者</span><span class="final-val">UID <?= str_pad((string)$uid, 6, '0', STR_PAD_LEFT) ?></span></div>
            <div class="final-line"><span class="final-key">用户名</span><span class="final-val"><?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?></span></div>
            <div class="final-line"><span class="final-key">最后提交</span><span class="final-val"><?= $finalSubmissionAt ? htmlspecialchars($finalSubmissionAt, ENT_QUOTES, 'UTF-8') : '——' ?></span></div>
            <div class="final-line"><span class="final-key">档案状态</span><span class="final-val final-val-strong">案件已结 / 档案未空</span></div>
        </div>
        <div class="final-archive-quote">「如果你看到这句话，说明我已经提交过了。」</div>
        <div class="final-archive-actions">
            <button type="button" id="final-toggle" class="decrypt5-button"
                    style="max-width:220px;display:inline-block;margin:0 8px">查看档案</button>
        </div>
        <div class="final-archive-foot">ALL SUBMISSIONS ARE LOGGED. · THE ARCHIVE IS NOT EMPTY.</div>
    </div>
</div>

<!-- 如果你想知道档案里还有什么，试试把 NOT EMPTY 换成 EMPTY。/decrypt5?archive=empty -->

<?php endif; ?>

<div class="decrypt5-page">

<?php if ($investigateStarted && !$endTrue): ?>
<div style="margin:0 0 40px;padding:14px 20px;border:1px solid rgba(159,255,178,.35);background:rgba(159,255,178,.04);font-family:monospace;font-size:11px;letter-spacing:4px;color:#9fffb2;text-align:center;">
    档案 / 000000 / 状态：空
</div>
<?php endif; ?>

<section class="decrypt5-hero">
    <div class="decrypt5-kicker">LMTOJ / 档案 / 000000</div>
    <h1 class="decrypt5-title">最后一次<br>提交</h1>
    <div class="decrypt5-subtitle">五天 · 一个档案 · 最后一次提交</div>

    <div class="decrypt5-countdown">
        <?php if ($eventStatus === 'preheat'): ?>
            <div class="decrypt5-count-label">活动状态</div>
            <div class="decrypt5-count-status">预热中</div>
            <div class="decrypt5-count-label" style="margin-top:22px">正式开始倒计时</div>
            <div id="decrypt5-count" class="decrypt5-count"
                 data-target="<?= htmlspecialchars($EVENT_START, ENT_QUOTES, 'UTF-8') ?>">--</div>
        <?php elseif ($eventStatus === 'active'): ?>
            <div class="decrypt5-count-label">活动状态</div>
            <div class="decrypt5-count-status">进行中</div>
            <div class="decrypt5-count-label" style="margin-top:22px">档案关闭倒计时</div>
            <div id="decrypt5-count" class="decrypt5-count"
                 data-target="<?= htmlspecialchars($EVENT_END, ENT_QUOTES, 'UTF-8') ?>">--</div>
        <?php else: ?>
            <div class="decrypt5-count-label">活动状态</div>
            <div class="decrypt5-count-status">档案已关闭</div>
        <?php endif; ?>
    </div>
</section>

<?php if ($message !== ''): ?>
<div class="decrypt5-message <?= htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8') ?>">
    <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
</div>
<?php endif; ?>

<section class="decrypt5-section">
    <div class="decrypt5-section-title">00 / 序章</div>
    <div class="decrypt5-story">
        <p>五天前，LMTOJ 收到了一次没有署名的提交。</p>
        <p>没有题目。<br>没有代码。<br>没有用户名。</p>
        <p>只有一行：</p>
        <p><strong>「如果你看到这句话，说明我已经提交过了。」</strong></p>
        <p>随后，系统开始出现异常。</p>
        <p>你的任务不是简单地找到一个答案。</p>
        <p>你需要找到五张卡片，然后弄清楚：<strong>最后一次提交究竟是谁留下的。</strong></p>
    </div>
</section>

<section class="decrypt5-section">
    <div class="decrypt5-section-title">01 / 档案</div>
    <div class="decrypt5-chapters">

<?php foreach ($chapters as $number => $chapter): ?>
<?php
if ($number === 6 && !$investigateStarted) continue;
$done = in_array($number, $completed, true);
$locked = $eventStatus !== 'active' || ($number === 5 && !$fourDone && !$done);
?>
<div class="decrypt5-chapter <?= $locked ? 'decrypt5-locked' : '' ?> <?= $number === 6 ? 'hidden-chapter' : '' ?>">
    <div class="decrypt5-chapter-number">
        <?= $number === 6 ? '隐藏档案' : '档案 ' . str_pad($number, 2, '0', STR_PAD_LEFT) ?>
    </div>
    <h2><?= htmlspecialchars($chapter['title'], ENT_QUOTES, 'UTF-8') ?></h2>
    <div class="decrypt5-difficulty">难度：<?= htmlspecialchars($chapter['difficulty'], ENT_QUOTES, 'UTF-8') ?></div>
    <p class="decrypt5-description"><?= htmlspecialchars($chapter['description'], ENT_QUOTES, 'UTF-8') ?></p>

    <?php if ($done): ?>
        <div class="decrypt5-solved">✓ 档案已解密</div>
    <?php elseif ($locked): ?>
        <div class="decrypt5-lock-message">
            <?php if ($eventStatus !== 'active'): ?>档案尚未开放<?php elseif ($number === 5): ?>请先完成档案 01–04<?php endif; ?>
        </div>
    <?php else: ?>
        <div class="decrypt5-question"><?= htmlspecialchars($chapter['question'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php if (!empty($chapter['extra'])): ?>
            <div class="decrypt5-extra"><?= htmlspecialchars($chapter['extra'], ENT_QUOTES, 'UTF-8') ?></div>
        <?php endif; ?>
        <form method="post" action="<?= $SELF ?>" class="decrypt5-form">
            <input type="hidden" name="_csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
            <input type="hidden" name="chapter" value="<?= $number ?>">
            <input type="text" name="answer" class="decrypt5-input" autocomplete="off" spellcheck="false" placeholder="输入答案" required>
            <button type="submit" class="decrypt5-button">提交档案</button>
        </form>
    <?php endif; ?>
</div>
<?php endforeach; ?>

    </div>
</section>

<section class="decrypt5-section">
    <div class="decrypt5-section-title">02 / 我的收藏</div>
    <div class="decrypt5-cards">
    <?php
    $cardKeys = [1=>'SIGNAL',2=>'CAESAR',3=>'SOURCE',4=>'UNKNOWN',5=>'LAST',6=>'ECHO'];
    $cardLabels = [1=>'信号',2=>'凯撒',3=>'源代码',4=>'未知',5=>'最后',6=>'回响'];
    foreach ($cardKeys as $number => $cardKey):
        if ($number === 6 && !$investigateStarted) continue;
        $hasCard = isset($ownedCards[$cardKey]);
        $cardName = $cardLabels[$number];
    ?>
        <div class="decrypt5-card <?= $hasCard ? '' : 'locked' ?> <?= $number === 6 ? 'echo' : '' ?>">
            <div class="decrypt5-card-top">卡片 <?= $number ?></div>
            <div class="decrypt5-card-name">
                <?= $hasCard ? htmlspecialchars($cardName, ENT_QUOTES, 'UTF-8') : '？？？？' ?>
            </div>
            <div class="decrypt5-card-bottom">
                <?= $hasCard ? '已获得' : '未知' ?>
            </div>
        </div>
    <?php endforeach; ?>
    </div>
</section>

<?php if ($collapseTriggered): ?>
<section class="decrypt5-section">
    <div class="decrypt5-section-title">03 / 系统状态</div>
    <div class="decrypt5-story">
        <?php if ($rebirthTriggered): ?>
            <p><strong>会话已恢复。</strong></p>
            <p>你的第一次会话并没有被删除。</p>
            <p>系统只是把它标记成了：</p>
            <p><strong>前世。</strong></p>
        <?php else: ?>
            <p><strong>档案已损坏。</strong></p>
            <p>系统已经记录你的崩坏时刻。</p>
            <p>但重启还没有完成。</p>
            <p style="margin-top:20px">
                <button type="button" id="rebirth-btn" class="decrypt5-button" style="max-width:260px">重启</button>
            </p>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<?php if ($investigateStarted && !$endTrue): ?>
<section class="decrypt5-section">
    <div class="decrypt5-section-title">05 / 调查日志</div>
    <div class="decrypt5-story" style="border-left-color:#9fffb2;">
        <p><strong>你找到了档案里剩下的东西。</strong></p>
        <p>系统没有阻止你。似乎它一直在等你这样做。</p>
        <p>回响档案已经出现。它在等你把五章答案的首字母连起来。</p>
        <p style="color:#7fbf90;font-family:monospace;margin-top:20px;">L / R / C / 4 / S →</p>
    </div>
</section>
<?php endif; ?>

<?php if ($fiveDone): ?>
<section class="decrypt5-section">
    <div class="decrypt5-section-title">04 / 最终档案</div>
    <div class="decrypt5-final">
        <h2>五份档案全部解密</h2>
        <p>你已经获得了所有五张卡片。</p>
        <p>系统认为案件已经结束。</p>
        <p><strong>案件已结。</strong></p>
        <p>……</p>
        <p>但你的卡片背面，并没有这么说。</p>
        <p style="margin-top:40px;font-family:monospace;letter-spacing:4px">档案并不是空的。</p>
    </div>
</section>
<?php endif; ?>

<div class="decrypt5-footer">
    用户：<?= htmlspecialchars($userName, ENT_QUOTES, 'UTF-8') ?>
    &nbsp;·&nbsp;
    活动：2026.09.14 — 2026.09.20
    &nbsp;·&nbsp;
    所有提交都会被记录。
</div>

</div>

<script>
const SELF = <?= json_encode($SELF) ?>;

(function(){
    const box = document.getElementById('decrypt5-count');
    if (!box) return;
    const target = new Date(box.dataset.target.replace(' ', 'T')).getTime();
    function update(){
        const diff = target - Date.now();
        if (diff <= 0) { box.innerText = '00:00:00:00'; setTimeout(() => location.reload(), 1000); return; }
        const s = Math.floor(diff / 1000);
        const d = Math.floor(s / 86400);
        const h = Math.floor((s % 86400) / 3600);
        const m = Math.floor((s % 3600) / 60);
        const ss = s % 60;
        const p = n => String(n).padStart(2, '0');
        box.innerText = p(d) + ':' + p(h) + ':' + p(m) + ':' + p(ss);
    }
    update();
    setInterval(update, 1000);
})();

(function(){
    const fx      = document.getElementById('decrypt5-fx');
    const fxSys   = document.getElementById('decrypt5-fx-system');
    const fxTitle = document.getElementById('decrypt5-fx-title');
    const fxSub   = document.getElementById('decrypt5-fx-subtitle');
    if (!fx) return;

    function playCollapse(){
        fx.classList.add('active');
        fxTitle.className = 'decrypt5-fx-title decrypt5-fx-collapse';
        fxTitle.innerText = '系统故障';
        fxSub.innerText   = '档案已损坏 / 记忆丢失';
        fxSys.innerText   = 'LMTOJ / 档案 / 错误 000000';
        document.body.style.overflow = 'hidden';
        setTimeout(() => { fxSys.innerText = '错误::提交未找到'; }, 450);
        setTimeout(() => { fxSys.innerText = '错误::记忆已损坏'; }, 850);
        setTimeout(() => { fxSys.innerText = '错误::用户会话 000000'; }, 1200);
        setTimeout(playRebirth, 3000);
    }

    function playRebirth(){
        fx.classList.add('active');
        fxTitle.className = 'decrypt5-fx-title decrypt5-fx-rebirth';
        fxTitle.innerText = '重启中';
        fxSub.innerText   = '记忆已恢复 / 主体重生';
        fxSys.innerText   = '系统正在重启……';
        setTimeout(() => { fxSys.innerText = '系统已上线'; }, 900);
        setTimeout(() => { fxSys.innerText = '会话已恢复'; }, 1500);

        /* GET 跳转，不带 _csrf */
        setTimeout(() => {
            location.href = SELF + '?do_rebirth=1';
        }, 2400);
    }

    const playNow = <?= $justCollapsed ? 'true' : 'false' ?>;
    if (playNow) setTimeout(playCollapse, 200);

    const btn = document.getElementById('rebirth-btn');
    if (btn) {
        btn.addEventListener('click', function(){
            btn.disabled = true;
            btn.innerText = '重启中……';
            playRebirth();
        });
    }
})();

(function(){
    const box = document.getElementById('final-archive');
    if (!box) return;
    document.body.classList.add('final-active');
    const btn = document.getElementById('final-toggle');
    if (btn) {
        btn.addEventListener('click', function(){
            document.body.classList.remove('final-active');
            box.classList.add('hidden');
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    }
})();
</script>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>