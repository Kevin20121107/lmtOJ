<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8");

// API配置
define('API_BASE_URL', 'https://oj.xzy404.top');
define('API_KEY', 'moyu_188a68af351be67aabfddfa3c01679af3c0b6807f1ea0326');

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 管理员检查
$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}

$userName = $_SESSION['name'] ?? '用户';

// ---- API函数 ----
function api_request($method, $endpoint, $data = null) {
    $url = API_BASE_URL . $endpoint;
    $headers = [
        'Authorization: Bearer ' . API_KEY,
        'Content-Type: application/json'
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } elseif ($method === 'GET' && $data) {
        $url .= '?' . http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        return json_decode($response, true);
    }
    
    return null;
}

// ---- 辅助函数 ----
function getResultClass($result) {
    $map = [
        'AC' => 'result-ac',
        'WA' => 'result-wa',
        'TLE' => 'result-tle',
        'MLE' => 'result-mle',
        'OLE' => 'result-ole',
        'RE' => 'result-re',
        'CE' => 'result-ce',
        'JE' => 'result-je',
        'SE' => 'result-se',
        'IGN' => 'result-ign',
        'Pending' => 'result-pending',
        'Running' => 'result-running',
        'SystemError' => 'result-system'
    ];
    return $map[$result] ?? 'result-unknown';
}

function getResultText($result) {
    $map = [
        'AC' => 'Accepted',
        'WA' => 'Wrong Answer',
        'TLE' => 'Time Limit Exceeded',
        'MLE' => 'Memory Limit Exceeded',
        'OLE' => 'Output Limit Exceeded',
        'RE' => 'Runtime Error',
        'CE' => 'Compile Error',
        'JE' => 'Judge Error',
        'SE' => 'System Error',
        'IGN' => 'Ignored',
        'Pending' => 'Pending',
        'Running' => 'Running',
        'SystemError' => 'System Error',
        'queued' => 'Queued',
        // 兼容数字状态码
        '0' => 'Waiting',
        '1' => 'Accepted',
        '2' => 'Wrong Answer',
        '3' => 'Time Limit Exceeded',
        '4' => 'Memory Limit Exceeded',
        '5' => 'Runtime Error',
        '6' => 'Compile Error',
        '7' => 'Compile Error',
        '8' => 'Judge Error',
        '9' => 'System Error',
        '10' => 'Ignored',
        '20' => 'Runtime Error',
        '21' => 'Time Limit Exceeded'
    ];
    return $map[$result] ?? $result;
}

function mapApiStatusToLocal($apiStatus) {
    $apiStatus = (int)$apiStatus;
    $statusMap = [
        0 => 'Pending',    // Waiting（等待评测）
        1 => 'AC',         // Accepted（通过）
        2 => 'WA',         // Wrong Answer（答案错误）
        3 => 'TLE',        // Time Limit Exceeded（超时）
        4 => 'MLE',        // Memory Limit Exceeded（超内存）
        5 => 'RE',         // Runtime Error（运行时错误）
        6 => 'CE',         // Compile Error（编译错误）
        7 => 'CE',         // Compile Error（编译错误）- 从测试确认
        8 => 'JE',         // Judge Error（评测机错误）
        9 => 'SE',         // System Error（系统错误）
        10 => 'IGN',       // Ignored（忽略）
        20 => 'RE',        // Runtime Error（运行时错误）- 从测试确认
        21 => 'TLE'        // Time Limit Exceeded（超时）- 从测试确认
    ];
    return $statusMap[$apiStatus] ?? 'SystemError';
}

function formatTime($ms) {
    if ($ms === null || $ms === '') return '-';
    $ms = (float)$ms;
    if ($ms >= 1000) {
        return number_format($ms / 1000, 2) . 's';
    } else {
        return number_format($ms, 0) . 'ms';
    }
}

function formatMemory($kb) {
    if ($kb === null || $kb === '') return '-';
    $kb = (float)$kb;
    if ($kb >= 1024) {
        return number_format($kb / 1024, 2) . 'MB';
    } else {
        return number_format($kb, 0) . 'KB';
    }
}

// ---- 详情模式 ----
$detailMode = false;
$detailData = null;
$detailRemote = null;
$detailError = null;

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $detailMode = true;
    $detail_id = (int)$_GET['id'];

    // 查询提交记录
    $stmt = $conn->prepare("
        SELECT s.*, p.name as problem_name, u.name as username,
               aps.api_rid, aps.api_problem_id, aps.language
        FROM submissions s
        LEFT JOIN problem_desc p ON s.problem_id = p.id
        LEFT JOIN users u ON s.uid = u.uid
        LEFT JOIN api_submissions aps ON s.id = aps.local_submission_id
        WHERE s.id = ?
    ");
    $stmt->bind_param("i", $detail_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) {
        $detailError = "提交记录不存在。";
    } else {
        $detailData = $result->fetch_assoc();
        // 权限检查
        if (!$is_admin && $detailData['uid'] != $login_uid) {
            $detailError = "您没有权限查看此提交记录。";
        } else {
            // 如果有API记录，尝试获取最新状态
            if (!empty($detailData['api_rid'])) {
                $apiStatus = api_request('GET', '/openapi/status', ['rid' => $detailData['api_rid']]);
                
                if ($apiStatus && isset($apiStatus['status'])) {
                    // 转换API状态为本地格式
                    $localStatus = mapApiStatusToLocal((int)$apiStatus['status']);
                    
                    // 确保数据类型正确
                    $apiScore = isset($apiStatus['score']) ? (int)$apiStatus['score'] : 0;
                    $apiTime = isset($apiStatus['time']) ? (float)$apiStatus['time'] : 0;
                    $apiMemory = isset($apiStatus['memory']) ? (int)$apiStatus['memory'] : 0;
                    
                    // 更新数据库
                    $updateStmt = $conn->prepare("
                        UPDATE submissions SET 
                            result = ?,
                            score = ?,
                            time_ms = ?,
                            memory_kb = ?,
                            last_checked = NOW()
                        WHERE id = ?
                    ");
                    $updateStmt->bind_param(
                        "siiii",
                        $localStatus,
                        $apiScore,
                        $apiTime,
                        $apiMemory,
                        $detail_id
                    );
                    $updateStmt->execute();
                    $updateStmt->close();
                    
                    // 更新API提交记录
                    $updateApiStmt = $conn->prepare("
                        UPDATE api_submissions SET 
                            status = ?,
                            score = ?,
                            time_ms = ?,
                            memory_kb = ?,
                            last_checked = NOW()
                        WHERE local_submission_id = ?
                    ");
                    $updateApiStmt->bind_param(
                        "siiii",
                        $localStatus,
                        $apiScore,
                        $apiTime,
                        $apiMemory,
                        $detail_id
                    );
                    $updateApiStmt->execute();
                    $updateApiStmt->close();
                    
                    // 重新获取更新后的数据
                    $detailData['result'] = $localStatus;
                    $detailData['score'] = $apiScore;
                    $detailData['time_ms'] = $apiTime;
                    $detailData['memory_kb'] = $apiMemory;
                    
                    // 构建测试点详情
                    $testDetails = [];
                    
                    // 检查是否有judgeTexts数组
                    if (isset($apiStatus['judgeTexts']) && is_array($apiStatus['judgeTexts']) && !empty($apiStatus['judgeTexts'])) {
                        foreach ($apiStatus['judgeTexts'] as $judgeText) {
                            if (is_array($judgeText)) {
                                // 处理对象格式
                                $message = isset($judgeText['message']) ? $judgeText['message'] : '';
                                if (isset($judgeText['params']) && is_array($judgeText['params'])) {
                                    foreach ($judgeText['params'] as $param) {
                                        $message = str_replace('{0}', $param, $message);
                                        $message = str_replace('{1}', $param, $message);
                                    }
                                }
                                $testDetails[] = [
                                    'status' => $localStatus,
                                    'time' => $apiTime,
                                    'memory' => $apiMemory,
                                    'message' => $message
                                ];
                            } elseif (is_string($judgeText)) {
                                $testDetails[] = [
                                    'status' => $localStatus,
                                    'time' => $apiTime,
                                    'memory' => $apiMemory,
                                    'message' => $judgeText
                                ];
                            }
                        }
                    }
                    
                    // 如果没有解析到测试点，使用总体信息
                    if (empty($testDetails)) {
                        $testDetails[] = [
                            'status' => $localStatus,
                            'time' => $apiTime,
                            'memory' => $apiMemory
                        ];
                    }
                    
                    // 构建远程数据格式
                    $detailRemote = [
                        'result' => $localStatus,
                        'score' => $apiScore,
                        'time' => $apiTime,
                        'memory' => $apiMemory,
                        'test_details' => $testDetails,
                        'passed' => ($localStatus == 'AC') ? count($testDetails) : 0,
                        'total' => count($testDetails)
                    ];
                    
                    // 如果有编译错误信息
                    if ($localStatus == 'CE' && isset($apiStatus['compilerTexts'])) {
                        $compilerMsg = '';
                        if (is_array($apiStatus['compilerTexts'])) {
                            $compilerMsg = implode("\n", array_map('strval', $apiStatus['compilerTexts']));
                        } else {
                            $compilerMsg = (string)$apiStatus['compilerTexts'];
                        }
                        if (!empty($compilerMsg)) {
                            // 清理ANSI转义序列
                            $compilerMsg = preg_replace('/\x1B\[[0-9;]*[mK]/', '', $compilerMsg);
                            $detailRemote['test_details'][0]['message'] = $compilerMsg;
                        }
                    }
                }
            }
        }
    }
    $stmt->close();
}

// ---- 列表模式 ----
$submissionRows = [];
$remoteResults = [];
$totalRecords = 0;
$totalPages = 0;
$problems = null;
$problemFilter = 0;
$resultFilter = '';
$uidFilter = 0;

if (!$detailMode) {
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $perPage = 20;
    $offset = ($page - 1) * $perPage;

    $problemFilter = isset($_GET['problem_id']) ? (int)$_GET['problem_id'] : 0;
    $resultFilter = isset($_GET['result']) ? trim($_GET['result']) : '';
    $uidFilter = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;

    if (!$is_admin) {
        $uidFilter = 0;
    }

    $where = "WHERE 1=1";
    if (!$is_admin) {
        $where .= " AND s.uid = $login_uid";
    }
    if ($problemFilter > 0) {
        $where .= " AND s.problem_id = $problemFilter";
    }
    if (!empty($resultFilter)) {
        $where .= " AND s.result = '" . $conn->real_escape_string($resultFilter) . "'";
    }
    if ($uidFilter > 0 && $is_admin) {
        $where .= " AND s.uid = $uidFilter";
    }

    $countQuery = "SELECT COUNT(*) AS total FROM submissions s $where";
    $countResult = $conn->query($countQuery);
    $totalRecords = $countResult ? (int)$countResult->fetch_assoc()['total'] : 0;
    $totalPages = ceil($totalRecords / $perPage);

    $query = "SELECT s.*, p.name as problem_name, u.name as username,
                     aps.api_rid, aps.api_problem_id
              FROM submissions s
              LEFT JOIN problem_desc p ON s.problem_id = p.id
              LEFT JOIN users u ON s.uid = u.uid
              LEFT JOIN api_submissions aps ON s.id = aps.local_submission_id
              $where
              ORDER BY s.id DESC
              LIMIT $offset, $perPage";
    $submissions = $conn->query($query);

    if ($submissions && $submissions->num_rows > 0) {
        while ($row = $submissions->fetch_assoc()) {
            $submissionRows[$row['id']] = $row;
        }

        // 批量更新API状态
        foreach ($submissionRows as $id => $row) {
            if (!empty($row['api_rid']) && in_array($row['result'], ['Pending', 'Running'])) {
                $apiStatus = api_request('GET', '/openapi/status', ['rid' => $row['api_rid']]);
                
                if ($apiStatus && isset($apiStatus['status'])) {
                    $localStatus = mapApiStatusToLocal((int)$apiStatus['status']);
                    
                    // 确保数据类型正确
                    $apiScore = isset($apiStatus['score']) ? (int)$apiStatus['score'] : 0;
                    $apiTime = isset($apiStatus['time']) ? (float)$apiStatus['time'] : 0;
                    $apiMemory = isset($apiStatus['memory']) ? (int)$apiStatus['memory'] : 0;
                    
                    // 更新数据库
                    $updateStmt = $conn->prepare("
                        UPDATE submissions SET 
                            result = ?,
                            score = ?,
                            time_ms = ?,
                            memory_kb = ?,
                            last_checked = NOW()
                        WHERE id = ?
                    ");
                    $updateStmt->bind_param(
                        "siiii",
                        $localStatus,
                        $apiScore,
                        $apiTime,
                        $apiMemory,
                        $id
                    );
                    $updateStmt->execute();
                    $updateStmt->close();
                    
                    // 更新远程结果缓存
                    $remoteResults[$id] = [
                        'result' => $localStatus,
                        'score' => $apiScore
                    ];
                    
                    // 更新本地行数据
                    $submissionRows[$id]['result'] = $localStatus;
                    $submissionRows[$id]['score'] = $apiScore;
                }
            }
        }
    }

    $problems = $conn->query("SELECT id, name FROM problem_desc ORDER BY id");
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= $detailMode ? '评测详情' : '评测记录' ?> - lmtOJ</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.06);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }
        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a {
            color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
            border-radius:20px; transition:var(--transition); font-weight:500;
        }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar {
            background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
            width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0;
        }
        .sidebar a {
            display:block; padding:13px 22px; text-align:center; background:var(--card-bg);
            color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500;
            transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px;
        }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .sidebar a.active { border-left-color:var(--accent); background:var(--accent-light); }
        .content { flex:1; min-width:0; }
        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:26px 28px;
            margin-bottom:18px; box-shadow:var(--shadow);
        }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .filter-bar {
            display: flex; flex-wrap: wrap; gap: 12px; align-items: center; margin-bottom: 0;
        }
        .filter-bar label { font-size: 13px; font-weight: 500; color: var(--text-secondary); }
        .filter-bar select, .filter-bar input {
            padding: 7px 14px; border: 1.5px solid var(--border); border-radius: var(--radius-sm);
            font-size: 13px; background: #fff; outline: none; font-family: var(--font); transition: var(--transition); min-width: 120px;
        }
        .filter-bar select:focus, .filter-bar input:focus {
            border-color: var(--accent); box-shadow: 0 0 0 3px rgba(107,138,116,0.1);
        }
        .btn {
            padding: 7px 20px; background: var(--accent); color: #fff; border: none;
            border-radius: 20px; cursor: pointer; font-size: 13px; font-weight: 500; transition: var(--transition); font-family: var(--font);
        }
        .btn:hover { background: var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-reset { background: var(--border); color: var(--text-secondary); }
        .btn-reset:hover { background: #d5d0c8; }
        .btn-sm { padding: 4px 12px; font-size: 12px; border-radius: 12px; text-decoration: none; display: inline-block; }
        .table-wrap { overflow-x: auto; margin-top: 16px; }
        table { width: 100%; border-collapse: collapse; }
        thead { background: #f8f7f4; border-bottom: 2px solid var(--border); }
        th {
            text-align: left; padding: 12px 16px; font-size: 12px; font-weight: 600;
            text-transform: uppercase; letter-spacing: 0.5px; color: var(--text-secondary);
        }
        td { padding: 12px 16px; border-bottom: 1px solid var(--border-light); font-size: 14px; vertical-align: middle; }
        tr:hover td { background: #fafaf8; }
        tr:last-child td { border-bottom: none; }
        .result-badge {
            display: inline-block; padding: 2px 12px; border-radius: 12px; font-size: 12px; font-weight: 600; letter-spacing: 0.3px;
        }
        .result-ac { background: #d4edda; color: #155724; }
        .result-wa { background: #f8d7da; color: #721c24; }
        .result-tle { background: #fff3cd; color: #856404; }
        .result-mle { background: #ffe5b4; color: #8b4513; }
        .result-ole { background: #fff3cd; color: #856404; }
        .result-re { background: #e8d5f5; color: #6c3483; }
        .result-ce { background: #fff3cd; color: #856404; }
        .result-je { background: #f8d7da; color: #721c24; }
        .result-se { background: #e2e3e5; color: #383d41; }
        .result-ign { background: #e2e3e5; color: #6c757d; }
        .result-pending { background: #cce5ff; color: #004085; }
        .result-running { background: #e8f5e9; color: #1b5e20; }
        .result-system { background: #e2e3e5; color: #383d41; }
        .result-unknown { background: #e2e3e5; color: #383d41; }
        .problem-link { color: var(--accent); font-weight: 500; }
        .problem-link:hover { text-decoration: underline; }
        .user-link { color: var(--text-secondary); text-decoration: none; }
        .user-link:hover { color: var(--accent); text-decoration: underline; }
        .time-text { font-size: 13px; color: var(--text-muted); }
        .empty-state { text-align: center; padding: 60px 20px; color: var(--text-muted); }
        .empty-state .icon { font-size: 48px; margin-bottom: 12px; }
        .pagination {
            display: flex; justify-content: center; gap: 6px; padding: 20px 0 10px; flex-wrap: wrap;
        }
        .pagination a, .pagination span {
            padding: 6px 14px; border-radius: 20px; font-size: 14px; font-weight: 500;
            color: var(--text-secondary); text-decoration: none; transition: var(--transition); border: 1.5px solid var(--border);
        }
        .pagination a:hover { background: var(--accent-light); color: var(--accent); border-color: var(--accent); }
        .pagination .active { background: var(--accent); color: #fff; border-color: var(--accent); }
        .pagination .disabled { opacity: 0.4; cursor: default; }
        .pagination .ellipsis { border: none; color: var(--text-muted); }

        /* 详情样式 */
        .detail-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
        .detail-header .back-link { color: var(--accent); text-decoration: none; font-weight: 500; font-size: 14px; }
        .detail-header .back-link:hover { text-decoration: underline; }
        .detail-meta { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; background: var(--bg); padding: 16px 20px; border-radius: var(--radius-sm); margin-bottom: 20px; }
        .detail-meta .item { display: flex; flex-direction: column; }
        .detail-meta .item .label { font-size: 12px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.3px; }
        .detail-meta .item .value { font-size: 16px; font-weight: 600; margin-top: 2px; }

        .test-details-table { margin-top: 16px; }
        .test-details-table td { padding: 8px 12px; border-bottom: 1px solid var(--border-light); font-size: 14px; vertical-align: middle; }
        .test-details-table tr:last-child td { border-bottom: none; }
        .test-details-table .test-index { font-weight: 600; color: var(--text-secondary); width: 50px; }
        .test-status { display: inline-block; padding: 2px 10px; border-radius: 10px; font-size: 12px; font-weight: 600; min-width: 50px; text-align: center; }
        .test-status.ac { background: #d4edda; color: #155724; }
        .test-status.wa { background: #f8d7da; color: #721c24; }
        .test-status.tle { background: #fff3cd; color: #856404; }
        .test-status.mle { background: #ffe5b4; color: #8b4513; }
        .test-status.ole { background: #fff3cd; color: #856404; }
        .test-status.re { background: #e8d5f5; color: #6c3483; }
        .test-status.ce { background: #fff3cd; color: #856404; }
        .test-status.je { background: #f8d7da; color: #721c24; }
        .test-status.se { background: #e2e3e5; color: #383d41; }
        .test-status.ign { background: #e2e3e5; color: #6c757d; }
        .test-status.pending { background: #cce5ff; color: #004085; }
        .test-status.running { background: #e8f5e9; color: #1b5e20; }
        .test-status.system { background: #e2e3e5; color: #383d41; }
        .test-time, .test-memory { font-family: monospace; font-size: 13px; color: var(--text-secondary); }
        .ce-message { background: #fff8e7; border-left: 4px solid #e6a700; padding: 12px 16px; border-radius: 4px; margin-top: 12px; font-family: monospace; white-space: pre-wrap; word-break: break-all; }
        .error-box { background: #f8d7da; color: #721c24; padding: 16px 20px; border-radius: var(--radius-sm); border: 1px solid #f5c6cb; }

        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .navbar { padding:0 14px; height:48px; }
            .card { padding:18px 14px; }
            .filter-bar { flex-direction: column; align-items: stretch; }
            .filter-bar select, .filter-bar input { min-width: auto; }
            th, td { padding: 8px 10px; font-size: 13px; }
        }
    </style>
</head>
<body>

<?php include __DIR__ . '/navbar.php'; ?>

<div class="main">
    <?php include 'sidebar.php'; ?>

    <div class="content">
        <?php if ($detailMode): ?>
            <!-- ===== 详情视图 ===== -->
            <?php if ($detailError): ?>
                <div class="card">
                    <div class="error-box"><?= htmlspecialchars($detailError) ?></div>
                    <p style="margin-top:12px;"><a href="https://lmtoj.cn/record" class="back-link">← 返回评测列表</a></p>
                </div>
            <?php elseif ($detailData): ?>
                <div class="card">
                    <div class="detail-header">
                        <h2 style="font-size:20px; font-weight:700;">📝 评测详情 #<?= $detail_id ?></h2>
                        <a href="https://lmtoj.cn/record" class="back-link">← 返回列表</a>
                    </div>

                    <!-- 基本信息 -->
                    <div class="detail-meta">
                        <div class="item">
                            <span class="label">题目</span>
                            <span class="value">
                            <a href="https://lmtoj.cn/problem/<?= $detailData['problem_id'] ?>" class="problem-link">
                                #<?= $detailData['problem_id'] ?> <?= htmlspecialchars($detailData['problem_name'] ?? '') ?>
                            </a>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">用户</span>
                            <span class="value">
                                <a href="https://lmtoj.cn/user/<?= $detailData['uid'] ?>" class="user-link">
                                    <?= htmlspecialchars($detailData['username'] ?? '用户#' . $detailData['uid']) ?>
                                </a>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">语言</span>
                            <span class="value">
                                <?= htmlspecialchars($detailData['language'] ?? 'C++14') ?>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">结果</span>
                            <span class="value">
                                <?php
                                $res = $detailRemote ? $detailRemote['result'] : $detailData['result'];
                                ?>
                                <span class="result-badge <?= getResultClass($res) ?>">
                                    <?= getResultText($res) ?>
                                </span>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">得分</span>
                            <span class="value">
                                <?php
                                if ($detailRemote && isset($detailRemote['score'])) {
                                    $score = (int)$detailRemote['score'];
                                } else {
                                    $score = (int)($detailData['score'] ?? 0);
                                }
                                $color = ($score == 100) ? '#27ae60' : '#e74c3c';
                                echo "<span style=\"font-weight:700; color:$color;\">$score</span>";
                                ?>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">运行时间</span>
                            <span class="value">
                                <?php
                                $timeMs = $detailRemote['time'] ?? $detailData['time_ms'] ?? null;
                                echo formatTime($timeMs);
                                ?>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">内存使用</span>
                            <span class="value">
                                <?php
                                $memKb = $detailRemote['memory'] ?? $detailData['memory_kb'] ?? null;
                                echo formatMemory($memKb);
                                ?>
                            </span>
                        </div>
                        <div class="item">
                            <span class="label">提交时间</span>
                            <span class="value time-text"><?= date('Y-m-d H:i', strtotime($detailData['created_at'])) ?></span>
                        </div>
                    </div>

                    <!-- 测试点详情 -->
                    <?php if ($detailRemote && isset($detailRemote['test_details'])): ?>
                        <?php $testDetails = $detailRemote['test_details']; ?>
                        <div style="margin-top:16px;">
                            <h3 style="font-size:16px; font-weight:600; margin-bottom:10px;">🧪 测试点信息</h3>
                            <div class="table-wrap test-details-table">
                                <table>
                                    <tbody>
                                        <?php $idx = 1; foreach ($testDetails as $td): ?>
                                            <tr>
                                                <td class="test-index">#<?= $idx++ ?></td>
                                                <td>
                                                    <?php
                                                    $status = $td['status'] ?? 'Unknown';
                                                    $statusClass = strtolower($status);
                                                    if (!in_array($statusClass, ['ac','wa','tle','mle','ole','re','ce','je','se','ign','pending','running','system'])) {
                                                        $statusClass = 'system';
                                                    }
                                                    ?>
                                                    <span class="test-status <?= $statusClass ?>">
                                                        <?= htmlspecialchars($status) ?>
                                                    </span>
                                                </td>
                                                <td class="test-time">
                                                    <?php echo formatTime($td['time'] ?? null); ?>
                                                </td>
                                                <td class="test-memory">
                                                    <?php echo formatMemory($td['memory'] ?? null); ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php if (isset($detailRemote['passed'], $detailRemote['total'])): ?>
                                <div style="margin-top:12px; font-size:14px; color:var(--text-secondary);">
                                    通过 <strong><?= $detailRemote['passed'] ?></strong> / 共 <strong><?= $detailRemote['total'] ?></strong> 个测试点
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

                    <!-- 编译错误信息 -->
                    <?php if ($detailRemote && $detailRemote['result'] === 'CE' && isset($detailRemote['test_details'][0]['message'])): ?>
                        <div style="margin-top:16px;">
                            <h3 style="font-size:16px; font-weight:600; margin-bottom:6px;">❌ 编译错误</h3>
                            <div class="ce-message">
                                <?= htmlspecialchars($detailRemote['test_details'][0]['message']) ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- ===== 列表视图 ===== -->
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; flex-wrap:wrap; gap:8px;">
                <h2 style="font-size:20px; font-weight:700;">评测记录</h2>
                <span style="font-size:14px; color:var(--text-muted);">共 <?= $totalRecords ?> 条记录</span>
            </div>

            <div class="card">
                <form method="GET" class="filter-bar">
                    <label for="problem_id">题目</label>
                    <select name="problem_id" id="problem_id">
                        <option value="0">全部题目</option>
                        <?php while ($p = $problems->fetch_assoc()): ?>
                            <option value="<?= $p['id'] ?>" <?= $problemFilter == $p['id'] ? 'selected' : '' ?>>
                                #<?= $p['id'] ?> <?= htmlspecialchars($p['name'] ?? '') ?>
                            </option>
                        <?php endwhile; ?>
                    </select>

                    <label for="result">结果</label>
                    <select name="result" id="result">
                        <option value="">全部结果</option>
                        <option value="AC" <?= $resultFilter == 'AC' ? 'selected' : '' ?>>AC - Accepted</option>
                        <option value="WA" <?= $resultFilter == 'WA' ? 'selected' : '' ?>>WA - Wrong Answer</option>
                        <option value="TLE" <?= $resultFilter == 'TLE' ? 'selected' : '' ?>>TLE - Time Limit Exceeded</option>
                        <option value="MLE" <?= $resultFilter == 'MLE' ? 'selected' : '' ?>>MLE - Memory Limit Exceeded</option>
                        <option value="OLE" <?= $resultFilter == 'OLE' ? 'selected' : '' ?>>OLE - Output Limit Exceeded</option>
                        <option value="RE" <?= $resultFilter == 'RE' ? 'selected' : '' ?>>RE - Runtime Error</option>
                        <option value="CE" <?= $resultFilter == 'CE' ? 'selected' : '' ?>>CE - Compile Error</option>
                        <option value="JE" <?= $resultFilter == 'JE' ? 'selected' : '' ?>>JE - Judge Error</option>
                        <option value="SE" <?= $resultFilter == 'SE' ? 'selected' : '' ?>>SE - System Error</option>
                        <option value="IGN" <?= $resultFilter == 'IGN' ? 'selected' : '' ?>>IGN - Ignored</option>
                        <option value="Pending" <?= $resultFilter == 'Pending' ? 'selected' : '' ?>>Pending</option>
                        <option value="Running" <?= $resultFilter == 'Running' ? 'selected' : '' ?>>Running</option>
                        <option value="SystemError" <?= $resultFilter == 'SystemError' ? 'selected' : '' ?>>System Error</option>
                    </select>

                    <?php if ($is_admin): ?>
                        <label for="uid">用户ID</label>
                        <input type="number" name="uid" id="uid" value="<?= $uidFilter > 0 ? $uidFilter : '' ?>" placeholder="输入用户ID" style="min-width:100px;">
                    <?php endif; ?>

                    <button type="submit" class="btn">筛选</button>
                    <a href="https://lmtoj.cn/record" class="btn btn-reset" style="text-decoration:none;">重置</a>
                </form>
            </div>

            <div class="card" style="padding:0; overflow:hidden;">
                <div class="table-wrap">
                    <?php if (!empty($submissionRows)): ?>
                    <table>
                        <thead>
                            <tr>
                                <th style="width:70px;">ID</th>
                                <th style="width:80px;">题目</th>
                                <th>用户</th>
                                <th style="width:180px;">结果</th>
                                <th style="width:100px;">得分</th>
                                <th style="width:150px;">提交时间</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($submissionRows as $row):
                                $remote = $remoteResults[$row['id']] ?? null;
                                $displayResult = $remote ? $remote['result'] : $row['result'];
                                $displayScore  = $remote ? $remote['score'] : $row['score'];
                            ?>
                            <tr>
                                <td><a href="https://lmtoj.cn/record/<?= $row['id'] ?>" style="color:var(--accent); font-weight:600; text-decoration:none;">#<?= $row['id'] ?></a></td>
                                <td>
                                    <a href="https://lmtoj.cn/problem/<?= $row['problem_id'] ?>" class="problem-link">
                                        #<?= $row['problem_id'] ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="https://lmtoj.cn/user/<?= $row['uid'] ?>" class="user-link">
                                        <?= htmlspecialchars($row['username'] ?? '用户#' . $row['uid']) ?>
                                    </a>
                                </td>
                                <td>
                                    <span class="result-badge <?= getResultClass($displayResult) ?>">
                                        <?= getResultText($displayResult) ?>
                                    </span>
                                </td>
                                <td>
                                    <?php
                                    $scoreValue = (int)$displayScore;
                                    $color = ($scoreValue == 100) ? '#27ae60' : '#e74c3c';
                                    echo "<span style=\"font-weight:600; color:$color;\">$scoreValue</span>";
                                    ?>
                                </td>
                                <td class="time-text"><?= date('Y-m-d H:i', strtotime($row['created_at'])) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div class="empty-state">
                        <div class="icon"></div>
                        <p>暂无评测记录</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($totalPages > 1): ?>
            <div class="pagination">
                <?php
                $queryParams = "problem_id={$problemFilter}&result=" . urlencode($resultFilter);
                $uidParam = ($is_admin && $uidFilter > 0) ? "&uid={$uidFilter}" : "";
                ?>
                <?php if ($page > 1): ?>
                    <a href="?page=<?= $page-1 ?>&<?= $queryParams ?><?= $uidParam ?>">‹ 上一页</a>
                <?php else: ?>
                    <span class="disabled">‹ 上一页</span>
                <?php endif; ?>

                <?php $start = max(1, $page - 2); $end = min($totalPages, $page + 2); if ($start > 1): ?>
                    <a href="?page=1&<?= $queryParams ?><?= $uidParam ?>">1</a>
                    <?php if ($start > 2): ?><span class="ellipsis">…</span><?php endif; ?>
                <?php endif; ?>

                <?php for ($i = $start; $i <= $end; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="active"><?= $i ?></span>
                    <?php else: ?>
                        <a href="?page=<?= $i ?>&<?= $queryParams ?><?= $uidParam ?>"><?= $i ?></a>
                    <?php endif; ?>
                <?php endfor; ?>

                <?php if ($end < $totalPages): ?>
                    <?php if ($end < $totalPages - 1): ?><span class="ellipsis">…</span><?php endif; ?>
                    <a href="?page=<?= $totalPages ?>&<?= $queryParams ?><?= $uidParam ?>"><?= $totalPages ?></a>
                <?php endif; ?>

                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?= $page+1 ?>&<?= $queryParams ?><?= $uidParam ?>">下一页 ›</a>
                <?php else: ?>
                    <span class="disabled">下一页 ›</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>