<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");
$conn->query("SET SESSION SQL_BIG_SELECTS=1");

// ---------- CSRF Token ----------
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
$csrf_token = generateCsrfToken();

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$login_uid = (int)$_SESSION['uid'];
$user = $conn->query("SELECT sqadmin, show_colorful_names FROM users WHERE uid=$login_uid LIMIT 1")->fetch_assoc();
$is_sqadmin = (int)($user['sqadmin'] ?? 0);
$myShowColorful = (int)($user['show_colorful_names'] ?? 1);

$conn->query("CREATE TABLE IF NOT EXISTS ostracism_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    target_uid INT NOT NULL,
    action VARCHAR(50) NOT NULL,
    reason TEXT,
    operator_uid INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(target_uid),
    INDEX(created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$result = $conn->query("SHOW COLUMNS FROM ostracism_log LIKE 'action'");
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (strpos($row['Type'], 'enum') !== false) {
        $conn->query("ALTER TABLE ostracism_log MODIFY action VARCHAR(50) NOT NULL");
    }
}

if (isset($_POST['del_id']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $del_ids = (array)($_POST['del_id'] ?? []);
    if ($is_sqadmin) {
        $ids = array_values(array_filter(array_map('intval', $del_ids)));
        if ($ids) {
            $placeholders = implode(',', array_fill(0, count($ids), '?'));
            $types = str_repeat('i', count($ids));
            $stmt = $conn->prepare("DELETE FROM ostracism_log WHERE id IN ($placeholders)");
            $stmt->bind_param($types, ...$ids);
            $stmt->execute();
            $stmt->close();
        }
    }
    header("Location: https://lmtoj.cn/ostracism");
    exit;
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

$filter_uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;
$where = "1=1";
if ($filter_uid > 0) {
    $where = "l.target_uid = $filter_uid";
}

$page = max(1, (int)($_GET['page'] ?? 1));
$limit = 20;
$offset = ($page - 1) * $limit;
$total = $conn->query("SELECT COUNT(*) AS c FROM ostracism_log l WHERE $where")->fetch_assoc()['c'];
$totalPage = ceil($total / $limit);

$logs = $conn->query("
    SELECT l.*, 
    u.name as target_name, 
    u.admin,
    u.tag,
    u.practice_score,
    u.contribute_score,
    u.contest_score,
    u.cert_type,
    u.cert_level,
    u.username_color,
    u.valuation,
    u.base_credit,
    op.name as operator_name, 
    u.uid as target_uid
    FROM ostracism_log l
    LEFT JOIN users u ON l.target_uid = u.uid
    LEFT JOIN users op ON l.operator_uid = op.uid
    WHERE $where
    ORDER BY l.id DESC
    LIMIT $offset, $limit
");

$rawLogs = [];
while ($l = $logs->fetch_assoc()) {
    $rawLogs[] = $l;
}

// ---------- 聚合：先按 时间 + 原因 + 操作人 分桶 ----------
// 桶内：
//   1) 若所有变更的操作都相同 → 跨多个用户折叠为一行（原有"同权限+同时间+同原因+不同用户"折叠）
//   2) 若存在不同操作         → 按用户拆桶，让"同时间+同用户+同原因"的多个操作折叠为一行
$buckets = [];
$bucketOrder = [];
foreach ($rawLogs as $l) {
    $key = $l['created_at'] . '|' . ($l['reason'] ?? '') . '|' . (int)$l['operator_uid'];
    if (!isset($buckets[$key])) {
        $buckets[$key] = [];
        $bucketOrder[] = $key;
    }
    $buckets[$key][] = $l;
}

/** 把一组记录打包成展示用的分组结构 */
function buildGroup(array $items) {
    $first = $items[0];

    // 操作去重 + 计数（保持出现顺序）
    $actions = [];
    $actionCounts = [];
    foreach ($items as $it) {
        $act = $it['action'];
        if (!isset($actionCounts[$act])) {
            $actionCounts[$act] = 0;
            $actions[] = $act;
        }
        $actionCounts[$act]++;
    }

    // 用户去重（保持出现顺序；同一用户只显示一条）
    $users = [];
    $seen = [];
    foreach ($items as $it) {
        $uid = (int)$it['target_uid'];
        if (!isset($seen[$uid])) {
            $seen[$uid] = true;
            $users[] = $it;
        }
    }

    return [
        'reason'        => $first['reason'],
        'operator_uid'  => $first['operator_uid'],
        'operator_name' => $first['operator_name'],
        'first_time'    => $first['created_at'],
        'items'         => $items,      // 原始记录（用于统计条数、删除 id）
        'users'         => $users,      // 去重后的用户列表
        'ids'           => array_map(function ($x) { return (int)$x['id']; }, $items),
        'actions'       => $actions,    // 去重后的操作列表
        'action_counts' => $actionCounts,
    ];
}

$groupedLogs = [];
foreach ($bucketOrder as $key) {
    $items = $buckets[$key];

    // 桶内不同操作数
    $distinctActions = [];
    foreach ($items as $it) {
        $distinctActions[$it['action']] = true;
    }

    if (count($distinctActions) === 1) {
        // 情况 A：同操作 + 同时间 + 同原因 + 同操作人 → 跨用户折叠
        $groupedLogs[] = buildGroup($items);
    } else {
        // 情况 B：同时间 + 同原因 + 同操作人，但操作不同 → 按用户拆开，每组把多个操作折叠
        $byUser = [];
        foreach ($items as $it) {
            $byUser[(int)$it['target_uid']][] = $it;
        }
        foreach ($byUser as $userItems) {
            $groupedLogs[] = buildGroup($userItems);
        }
    }
}

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }

function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getFirstChar($name) {
    $name = trim($name ?? '?');
    return mb_strlen($name) > 0 ? mb_strtoupper(mb_substr($name, 0, 1)) : '?';
}

$filterUserName = '';
if ($filter_uid > 0) {
    $nameRes = $conn->query("SELECT name FROM users WHERE uid = $filter_uid LIMIT 1");
    if ($nameRes && $nameRes->num_rows > 0) {
        $filterUserName = $nameRes->fetch_assoc()['name'];
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= $filterUserName ? $filterUserName . ' - 陶片放逐' : '陶片放逐' ?> - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;-webkit-font-smoothing:antialiased;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;letter-spacing:0.4px;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);user-select:none;}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);white-space:nowrap;font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .main{max-width:1300px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
        .sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
        .sidebar a{display:block;padding:13px 22px;text-align:center;background:var(--card-bg);color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;white-space:nowrap;transition:var(--transition);border-left:3px solid transparent;letter-spacing:0.3px;}
        .sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
        .sidebar a:first-child{border-radius:var(--radius) var(--radius) 0 0;}
        .sidebar a:last-child{border-radius:0 0 var(--radius) var(--radius);}
        .content{flex:1;min-width:0;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:24px;box-shadow:var(--shadow);margin-bottom:18px;}
        .card h2{font-size:17px;font-weight:600;margin-bottom:14px;}
        table{width:100%;border-collapse:collapse;}
        th{text-align:left;padding:10px 14px;background:#fafaf8;font-size:13px;color:var(--text-secondary);border-bottom:2px solid var(--border);}
        td{padding:10px 14px;border-bottom:1px solid var(--border-light);font-size:14px;vertical-align:top;}
        .action-tag{padding:2px 8px;border-radius:10px;font-size:11px;color:#fff;font-weight:600;}
        .tag-set{background:#5a9e6f;}
        .tag-unset{background:#d4a24e;}
        .tag-jy{background:#d9534f;}
        .tag-rename{background:#8e44ad;}
        .tag-brown{background:#8b6b4d;}
        .tag-self{background:#3498db;}
        .page-bar{display:flex;gap:6px;margin-top:16px;flex-wrap:wrap;}
        .page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;transition:var(--transition);background:#fff;}
        .page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
        .page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);}
        .page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
        .back-link { display:inline-block; margin-bottom:12px; color:var(--accent); text-decoration:none; font-weight:500; }
        .back-link:hover { text-decoration:underline; }
        @media(max-width:768px){
            .main{flex-direction:column;padding:0 12px;margin:18px auto 30px;gap:14px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;border-radius:var(--radius);}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
        }
        .ben-name { font-weight:600; text-decoration:none; font-size:14px; }
        .ben-name:hover { opacity:0.8; text-decoration:underline; }
        .ben-name.colorful {
            color: #f1948a;
            animation: colorful 3s linear infinite;
            text-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        @keyframes colorful {
            0% { color: #f1948a; }
            17% { color: #f5b041; }
            33% { color: #f7dc6f; }
            50% { color: #82e0aa; }
            67% { color: #85c1e9; }
            83% { color: #bb8fce; }
            100% { color: #f1948a; }
        }
        .tag { border-radius:3px; padding:2px 9px; color:#fff; display:inline-block; margin:2px 5px; font-size:11.5px; font-weight:600; }
        .tag.colorful-bg { animation: colorfulBg 3s linear infinite; }
        @keyframes colorfulBg {
            0% { background-color: #f1948a; }
            17% { background-color: #f5b041; }
            33% { background-color: #f7dc6f; }
            50% { background-color: #82e0aa; }
            67% { background-color: #85c1e9; }
            83% { background-color: #bb8fce; }
            100% { background-color: #f1948a; }
        }
        .del-link { color:var(--danger); text-decoration:none; font-weight:600; }
        .del-link:hover { text-decoration:underline; color:var(--danger-hover); }
        .user-chips { display:flex; flex-wrap:wrap; gap:6px 14px; align-items:center; }
        .user-chip { display:inline-flex; align-items:center; gap:4px; white-space:nowrap; }
        .reason-cell { max-width:420px; word-break:break-word; }
        .action-cell { display:flex; flex-wrap:wrap; gap:4px 6px; align-items:center; }
        .action-item { display:inline-flex; align-items:center; gap:3px; }
        .action-count { color:var(--text-muted); font-size:11.5px; font-weight:600; }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <?php if ($filter_uid > 0): ?>
                <a href="https://lmtoj.cn/ostracism" class="back-link">← 返回全部记录</a>
                <h2>陶片放逐记录 - <?= safeContent($filterUserName) ?></h2>
            <?php else: ?>
                <h2>权限变更记录</h2>
            <?php endif; ?>
            <table>
                <tr>
                    <th style="width: 15%;">时间</th>
                    <th style="width: 25%;">用户</th>
                    <th style="width: 15%;">操作</th>
                    <th>原因</th>
                    <?php if ($is_sqadmin): ?>
                        <th style="width: 8%;">操作人</th>
                        <th style="width: 6%;">操作</th>
                    <?php endif; ?>
                </tr>
                <?php
                $labels = [
                    'set_admin'     => '授予 进入后台 权限',
                    'unset_admin'   => '撤销 进入后台 权限',
                    'set_jinyan'    => '授予 自由发言 权限',
                    'unset_jinyan' => '撤销 自由发言 权限',
                    'del_user'      => '撤销 进入主站 权限',
                    'set_sixin'     => '授予 发送私信 权限',
                    'unset_sixin'  => '撤销 发送私信 权限',
                    'ban_user'      => '撤销 进入主站 权限',
                    'unban_user'    => '授予 进入主站 权限',
                    'set_banned'    => '授予 进入主站 权限',
                    'unset_banned'  => '撤销 进入主站 权限',
                    'rename_user'   => '修改用户名',
                    'set_brown'     => '授予 棕名惩罚',
                    'self_unban'    => '自行解封',
                    'set_sqadmin'   => '授予 社区管理 权限',
                    'unset_sqadmin' => '撤销 社区管理 权限',
                    'set_proadmin'  => '授予 题目管理 权限',
                    'unset_proadmin' => '撤销 题目管理 权限',
                    'set_conadmin'  => '授予 比赛管理 权限',
                    'unset_conadmin' => '撤销 比赛管理 权限',
                    'set_artadmin'  => '授予 文章管理 权限',
                    'unset_artadmin' => '撤销 文章管理 权限',
                    'set_devadmin'  => '授予 文件管理 权限',
                    'unset_devadmin' => '撤销 文件管理 权限'
                ];
                $colors = [
                    'set_admin'     => 'tag-set',
                    'unset_admin'   => 'tag-unset',
                    'set_jinyan'    => 'tag-set',
                    'unset_jinyan'  => 'tag-jy',
                    'del_user'      => 'tag-unset',
                    'set_sixin'     => 'tag-set',
                    'unset_sixin'   => 'tag-jy',
                    'ban_user'      => 'tag-unset',
                    'unban_user'    => 'tag-set',
                    'set_banned'    => 'tag-set',
                    'unset_banned'  => 'tag-unset',
                    'rename_user'   => 'tag-rename',
                    'set_brown'     => 'tag-brown',
                    'self_unban'    => 'tag-self',
                    'set_sqadmin'   => 'tag-set',
                    'unset_sqadmin' => 'tag-unset',
                    'set_proadmin'  => 'tag-set',
                    'unset_proadmin' => 'tag-unset',
                    'set_conadmin'  => 'tag-set',
                    'unset_conadmin' => 'tag-unset',
                    'set_artadmin'  => 'tag-set',
                    'unset_artadmin' => 'tag-unset',
                    'set_devadmin'  => 'tag-set',
                    'unset_devadmin' => 'tag-unset'
                ];
                ?>
                <?php foreach ($groupedLogs as $group):
                    $count = count($group['items']);   // 本行折叠的原始记录数
                ?>
                <tr>
                    <td><?=date('Y-m-d H:i', strtotime($group['first_time']))?></td>
                    <td>
                        <div class="user-chips">
                        <?php foreach ($group['users'] as $l):
                            $achievement = min(getAchievementScore($l['cert_type'] ?? '', (int)($l['cert_level'] ?? 0)), 20);
                            $practice = min((int)($l['practice_score'] ?? 0), 20);
                            $contribute = min((int)($l['contribute_score'] ?? 0), 30);
                            $contest = min((int)($l['contest_score'] ?? 0), 20);
                            $base = (int)($l['base_credit'] ?? 10);
                            $valuation = (int)($l['valuation'] ?? 0);
                            $isBrown = ($valuation === -1);
                            $totalScore = $isBrown ? -1 : $base + $achievement + $practice + $contribute + $contest;

                            $targetColorful = ($l['username_color'] ?? 'auto') === 'beautiful' && ($achievement >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
                            $isColorful = ($l['target_uid'] == $login_uid) ? $targetColorful : ($targetColorful && $myShowColorful);
                            $nameColor = getColorByTotalScore($totalScore, $l['admin'] ?? 0);
                        ?>
                            <span class="user-chip">
                                <a href="https://lmtoj.cn/user/<?=$l['target_uid']?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" <?= $isColorful ? '' : 'style="color: ' . $nameColor . ';"' ?>>
                                    <?=safeContent($l['target_name'])?>
                                </a>
                                <?php if($l['tag']):?>
                                    <span class="tag<?= $isColorful ? ' colorful-bg' : '' ?>" <?= $isColorful ? '' : 'style="background: ' . $nameColor . ';"' ?>>
                                        <?=safeContent($l['tag'])?>
                                    </span>
                                <?php endif;?>
                            </span>
                        <?php endforeach; ?>
                        </div>
                    </td>
                    <td>
                        <div class="action-cell">
                            <?php foreach ($group['actions'] as $act):
                                $displayLabel = $labels[$act] ?? $act;
                                $displayColor = $colors[$act] ?? '';
                                $actCount = $group['action_counts'][$act] ?? 1;
                            ?>
                                <span class="action-item">
                                    <span class="action-tag <?=$displayColor?>"><?=$displayLabel?></span>
                                </span>
                            <?php endforeach; ?>
                        </div>
                    </td>
                    <td class="reason-cell"><?=safeContent($group['reason'])?></td>
                    <?php if ($is_sqadmin): ?>
                    <td>
                        <?php if (!empty($group['operator_name'])): ?>
                            <a href="https://lmtoj.cn/user/<?=(int)$group['operator_uid']?>"><?=safeContent($group['operator_name'])?></a>
                        <?php else: ?>
                            系统
                        <?php endif; ?>
                    </td>
                    <td>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定要删除这组记录吗？（共 <?=$count?> 条）')">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <?php foreach ($group['ids'] as $id): ?>
                                <input type="hidden" name="del_id[]" value="<?=$id?>">
                            <?php endforeach; ?>
                            <button type="submit" style="background:none;border:none;color:var(--danger);cursor:pointer;font-weight:600;font-size:14px;padding:0;">删除</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
                <?php endforeach; ?>
                <?php if($total == 0): ?>
                <tr>
                    <td colspan="<?= $is_sqadmin ? 6 : 4 ?>" style="text-align:center;color:var(--text-muted);padding:30px;">
                        <?= $filter_uid > 0 ? '该用户暂无被放逐记录' : '暂无记录' ?>
                    </td>
                </tr>
                <?php endif; ?>
            </table>
            <?php if($totalPage > 1): ?>
            <div class="page-bar">
                <?php if($page > 1): ?><a href="?page=<?=$page-1?><?= $filter_uid ? '&uid='.$filter_uid : '' ?>">上一页</a><?php endif; ?>
                <?php
                $shown = []; $shown[] = 1;
                for($i = max(2, $page-2); $i <= min($totalPage-1, $page+2); $i++) $shown[] = $i;
                if($totalPage > 1) $shown[] = $totalPage;
                $shown = array_unique($shown); sort($shown); $prev = 0;
                foreach($shown as $i):
                    if($i - $prev > 1) echo '<span class="page-ellipsis">...</span>';
                ?><a href="?page=<?=$i?><?= $filter_uid ? '&uid='.$filter_uid : '' ?>" class="<?=$i==$page?'active':''?>"><?=$i?></a><?php $prev = $i; endforeach; ?>
                <?php if($page < $totalPage): ?><a href="?page=<?=$page+1?><?= $filter_uid ? '&uid='.$filter_uid : '' ?>">下一页</a><?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>