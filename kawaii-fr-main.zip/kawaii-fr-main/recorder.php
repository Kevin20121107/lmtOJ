<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 查询当前用户
$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();

// 权限检查：仅 admin=1 可访问，否则跳回主页
if (($userRow['admin'] ?? 0) != 1) {
    header("Location: https://lmtoj.cn/");
    exit;
}

// 创建 /audio 目录
$audioDir = __DIR__ . '/audio';
if (!is_dir($audioDir)) {
    mkdir($audioDir, 0755, true);
}

// 处理录音上传
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['audio'])) {
    $file = $_FILES['audio'];
    $allowedTypes = ['audio/webm', 'audio/wav', 'audio/mp4', 'audio/mpeg', 'audio/ogg', 'audio/m4a'];
    $extMap = [
        'audio/webm' => 'webm',
        'audio/wav' => 'wav',
        'audio/mp4' => 'm4a',
        'audio/mpeg' => 'mp3',
        'audio/ogg' => 'ogg',
        'audio/m4a' => 'm4a'
    ];
    $type = $file['type'] ?? '';
    if (!in_array($type, $allowedTypes)) {
        $type = 'audio/webm'; // 默认
    }
    $ext = $extMap[$type] ?? 'webm';
    $filename = uniqid('rec_', true) . '.' . $ext;
    $target = $audioDir . '/' . $filename;
    if (move_uploaded_file($file['tmp_name'], $target)) {
        $uploadMsg = '录音保存成功！文件名：' . htmlspecialchars($filename);
    } else {
        $uploadMsg = '上传失败，请检查目录权限。';
    }
}

// 处理删除录音（可选）
if (isset($_GET['delete']) && $_GET['delete'] !== '') {
    $deleteFile = basename($_GET['delete']);
    $targetPath = $audioDir . '/' . $deleteFile;
    if (file_exists($targetPath) && is_file($targetPath)) {
        unlink($targetPath);
        header("Location: https://lmtoj.cn/recorder");
        exit;
    }
}

// 获取已有录音文件列表
$audioFiles = [];
if (is_dir($audioDir)) {
    $files = scandir($audioDir);
    foreach ($files as $f) {
        if ($f !== '.' && $f !== '..' && is_file($audioDir . '/' . $f)) {
            $audioFiles[] = $f;
        }
    }
    // 按修改时间降序
    usort($audioFiles, function($a, $b) use ($audioDir) {
        return filemtime($audioDir . '/' . $b) - filemtime($audioDir . '/' . $a);
    });
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>录音器 - lmtOJ</title>
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <style>
        /* 复制原样式（略作精简，保持风格一致） */
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6; --accent: #6b8a74;
            --accent-hover: #55735e; --accent-light: #eef4ef; --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif; color:var(--text); line-height:1.6; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; }
        .navbar h1 { font-size:17px; font-weight:600; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:0.18s; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:0.18s; border-left:3px solid transparent; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .right-sidebar { width:220px; flex-shrink:0; position:sticky; top:80px; }
        .right-card { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); padding:16px; margin-bottom:20px; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; margin-bottom:18px; box-shadow:var(--shadow); }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }
        .btn { padding:9px 20px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:14px; font-weight:500; transition:0.18s; }
        .btn:hover { background:var(--accent-hover); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:#c0392b; }
        .audio-list { margin-top:20px; }
        .audio-item { display:flex; align-items:center; gap:12px; padding:10px 0; border-bottom:1px solid var(--border-light); flex-wrap:wrap; }
        .audio-item:last-child { border-bottom:none; }
        .audio-item audio { width:100%; max-width:300px; }
        .audio-item .delete-link { color:var(--danger); text-decoration:none; font-size:13px; }
        .audio-item .download-link { color:var(--accent); text-decoration:none; font-size:13px; }
        .upload-msg { margin-top:10px; padding:10px; background:var(--accent-light); border-radius:var(--radius-sm); color:var(--accent); font-size:14px; }
        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; }
            .navbar { padding:0 14px; height:48px; }
            .card { padding:18px 14px; }
            .right-sidebar { width:100%; position:static; }
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <div class="card">
            <h2>🎙️ 录音器</h2>
            <?php if (isset($uploadMsg)): ?>
                <div class="upload-msg"><?= $uploadMsg ?></div>
            <?php endif; ?>
            <div style="margin-bottom:20px;">
                <button id="recordBtn" class="btn">开始录音</button>
                <button id="stopBtn" class="btn btn-danger" disabled>停止录音</button>
                <span id="recordingStatus" style="margin-left:12px; color:var(--text-muted); font-size:14px;"></span>
            </div>
            <audio id="audioPreview" controls style="width:100%; display:none;"></audio>
            <div style="margin-top:16px;">
                <button id="uploadBtn" class="btn" disabled>上传录音</button>
            </div>
        </div>

        <div class="card">
            <h2>已保存的录音</h2>
            <?php if (empty($audioFiles)): ?>
                <p style="color:var(--text-muted);">暂无录音文件。</p>
            <?php else: ?>
                <div class="audio-list">
                    <?php foreach ($audioFiles as $file): 
                        $filePath = $audioDir . '/' . $file;
                        $fileSize = file_exists($filePath) ? filesize($filePath) : 0;
                        $sizeStr = $fileSize >= 1048576 ? round($fileSize/1048576,1).' MB' : round($fileSize/1024,1).' KB';
                    ?>
                        <div class="audio-item">
                            <!-- 关键修改：src 使用绝对路径 /audio/文件名 -->
                            <audio controls src="/audio/<?= urlencode($file) ?>"></audio>
                            <a href="/audio/<?= urlencode($file) ?>" download class="download-link">下载</a>
                            <a href="https://lmtoj.cn/recorder?delete=<?= urlencode($file) ?>" class="delete-link" onclick="return confirm('确定删除该录音？')">删除</a>
                            <span style="font-size:12px; color:var(--text-muted);"><?= htmlspecialchars($file) ?> (<?= $sizeStr ?>)</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="right-sidebar">
        <div class="right-card">
            <h3>录音说明</h3>
            <p style="font-size:13px; color:var(--text-secondary);">仅管理员可录音并上传，文件保存至 /audio 目录。</p>
        </div>
    </div>
</div>
<?php include __DIR__ . '/footer.php'; ?>

<script>
let mediaRecorder;
let audioChunks = [];
let audioBlob;

const recordBtn = document.getElementById('recordBtn');
const stopBtn = document.getElementById('stopBtn');
const uploadBtn = document.getElementById('uploadBtn');
const audioPreview = document.getElementById('audioPreview');
const statusSpan = document.getElementById('recordingStatus');

recordBtn.addEventListener('click', async () => {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];

        mediaRecorder.ondataavailable = event => {
            if (event.data.size > 0) audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
            audioBlob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
            const audioUrl = URL.createObjectURL(audioBlob);
            audioPreview.src = audioUrl;
            audioPreview.style.display = 'block';
            uploadBtn.disabled = false;
            statusSpan.textContent = '录音完成，可试听或上传';
        };

        mediaRecorder.start();
        recordBtn.disabled = true;
        stopBtn.disabled = false;
        uploadBtn.disabled = true;
        statusSpan.textContent = '录音中...';
    } catch (err) {
        alert('无法访问麦克风：' + err.message);
    }
});

stopBtn.addEventListener('click', () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
        recordBtn.disabled = false;
        stopBtn.disabled = true;
    }
});

uploadBtn.addEventListener('click', async () => {
    if (!audioBlob) return;
    const formData = new FormData();
    formData.append('audio', audioBlob, 'recording.webm');
    try {
        const response = await fetch('https://lmtoj.cn/recorder', { method: 'POST', body: formData });
        const text = await response.text();
        // 解析上传结果（简单处理）
        if (text.includes('录音保存成功')) {
            alert('上传成功！');
            window.location.reload();
        } else {
            alert('上传失败，请检查服务器权限。');
        }
    } catch (err) {
        alert('上传请求出错：' + err.message);
    }
});
</script>
</body>
</html>