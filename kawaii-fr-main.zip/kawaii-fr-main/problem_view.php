<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
set_time_limit(30);

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

// API配置
define('API_BASE_URL', 'https://oj.xzy404.top');
define('API_RATE_LIMIT', 45); // 45秒内最多提交一次

// 支持的语言列表
$supportedLanguages = [
    'cc.cc14o2' => 'C++14 (O2)',
    'cc.cc17o2' => 'C++17 (O2)',
    'cc.cc20o2' => 'C++20 (O2)',
    'cc.cc11o2' => 'C++11 (O2)',
    'cc.cc98' => 'C++98',
    'py.py3' => 'Python 3',
    'py.py2' => 'Python 2'
];
//$supportedLanguages = [
//    'cc.cc14o2' => 'C++14 (O2)',
//    'cc.cc17o2' => 'C++17 (O2)',
//    'cc.cc20o2' => 'C++20 (O2)',
//    'cc.cc11o2' => 'C++11 (O2)',
//    'cc.cc98' => 'C++98',
//    'c.c11' => 'C11',
//    'c.c99' => 'C99',
//    'py.py3' => 'Python 3',
//    'py.py2' => 'Python 2',
//    'java.jdk17' => 'Java 17',
//    'java.jdk11' => 'Java 11',
//    'go.go120' => 'Go 1.20',
//    'rust.rust170' => 'Rust 1.70',
//    'js.node18' => 'Node.js 18',
//    'php.php8' => 'PHP 8',
//    'rb.ruby3' => 'Ruby 3',
//    'cs.dotnet6' => 'C# .NET 6',
//    'kt.kotlin1' => 'Kotlin 1.9',
//    'swift.swift5' => 'Swift 5',
//    'pas.fpc3' => 'Pascal (FPC 3)',
//];

if (file_exists(__DIR__ . '/.env')) {
    $lines = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos($line, '=') !== false && strpos($line, '#') !== 0) {
            list($key, $value) = explode('=', $line, 2);
            $key = trim($key);
            $value = trim($value);
            $value = trim($value, '"\'');
            $_ENV[$key] = $value;
        }
    }
}

$apiKey = $_ENV['OJ_API_KEY'] ?? (getenv('OJ_API_KEY') ?: '');
define('API_KEY', $apiKey);

$servername = $_ENV['DB_HOST'] ?? getenv('DB_HOST');
$dbuser = $_ENV['DB_USER'] ?? getenv('DB_USER');
$dbpass = $_ENV['DB_PASSWORD'] ?? getenv('DB_PASSWORD');
$dbname = $_ENV['DB_NAME'] ?? getenv('DB_NAME');

$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
$conn->set_charset("utf8");

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== 创建相关表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0 COMMENT '持有token数量',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户Token余额'");

// 创建题目绑定表
$conn->query("CREATE TABLE IF NOT EXISTS problem_bindings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_problem_id INT NOT NULL COMMENT '本地题目ID',
    api_problem_id VARCHAR(50) NOT NULL COMMENT 'API题目ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_local_problem (local_problem_id),
    UNIQUE KEY idx_api_problem (api_problem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='题目绑定关系'");
// ========== 创建相关表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0 COMMENT '持有token数量',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户Token余额'");

// 创建题目绑定表
$conn->query("CREATE TABLE IF NOT EXISTS problem_bindings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_problem_id INT NOT NULL COMMENT '本地题目ID',
    api_problem_id VARCHAR(50) NOT NULL COMMENT 'API题目ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_local_problem (local_problem_id),
    UNIQUE KEY idx_api_problem (api_problem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='题目绑定关系'");

// 创建提交记录表（用于限流）- 包含language字段
$conn->query("CREATE TABLE IF NOT EXISTS api_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_submission_id INT NOT NULL COMMENT '本地提交ID',
    api_rid VARCHAR(100) NOT NULL COMMENT 'API返回的rid',
    uid INT NOT NULL COMMENT '用户UID',
    problem_id INT NOT NULL COMMENT '本地题目ID',
    api_problem_id VARCHAR(50) NOT NULL COMMENT 'API题目ID',
    language VARCHAR(50) DEFAULT 'cc.cc14o2' COMMENT '语言',
    status VARCHAR(20) DEFAULT 'pending' COMMENT '评测状态',
    score INT DEFAULT 0 COMMENT '得分',
    time_ms INT DEFAULT 0 COMMENT '运行时间(ms)',
    memory_kb INT DEFAULT 0 COMMENT '内存(KB)',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_checked TIMESTAMP NULL,
    INDEX idx_uid (uid),
    INDEX idx_rid (api_rid),
    INDEX idx_submission (local_submission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='API提交记录'");

// 检查并添加language字段到api_submissions表（如果表已存在但缺少字段）
$colCheck = $conn->query("SHOW COLUMNS FROM api_submissions LIKE 'language'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE api_submissions ADD COLUMN language VARCHAR(50) DEFAULT 'cc.cc14o2' COMMENT '语言' AFTER api_problem_id");
}

// 确保submissions表有language字段
$conn->query("CREATE TABLE IF NOT EXISTS submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    problem_id INT NOT NULL,
    code TEXT NOT NULL,
    language VARCHAR(50) DEFAULT 'cc.cc14o2',
    result VARCHAR(20) DEFAULT 'Pending',
    score INT DEFAULT 0,
    time_ms INT DEFAULT 0,
    memory_kb INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_checked TIMESTAMP NULL,
    INDEX idx_uid (uid),
    INDEX idx_problem (problem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 检查并更新submissions表的language字段
$colCheck = $conn->query("SHOW COLUMNS FROM submissions LIKE 'language'");
if ($colCheck->num_rows > 0) {
    // 检查字段长度
    $colInfo = $conn->query("SHOW COLUMNS FROM submissions WHERE Field = 'language'")->fetch_assoc();
    if (strpos($colInfo['Type'], 'varchar(50)') === false) {
        $conn->query("ALTER TABLE submissions MODIFY COLUMN language VARCHAR(50) DEFAULT 'cc.cc14o2'");
    }
} else {
    $conn->query("ALTER TABLE submissions ADD COLUMN language VARCHAR(50) DEFAULT 'cc.cc14o2' AFTER code");
}
// 创建提交记录表（用于限流）
$conn->query("CREATE TABLE IF NOT EXISTS api_submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    local_submission_id INT NOT NULL COMMENT '本地提交ID',
    api_rid VARCHAR(100) NOT NULL COMMENT 'API返回的rid',
    uid INT NOT NULL COMMENT '用户UID',
    problem_id INT NOT NULL COMMENT '本地题目ID',
    api_problem_id VARCHAR(50) NOT NULL COMMENT 'API题目ID',
    status VARCHAR(20) DEFAULT 'pending' COMMENT '评测状态',
    score INT DEFAULT 0 COMMENT '得分',
    time_ms INT DEFAULT 0 COMMENT '运行时间(ms)',
    memory_kb INT DEFAULT 0 COMMENT '内存(KB)',
    language VARCHAR(50) DEFAULT 'cc.cc14o2' COMMENT '语言',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_checked TIMESTAMP NULL,
    INDEX idx_uid (uid),
    INDEX idx_rid (api_rid),
    INDEX idx_submission (local_submission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='API提交记录'");

// 检查并添加language字段到submissions表
$colCheck = $conn->query("SHOW COLUMNS FROM submissions LIKE 'language'");
if ($colCheck->num_rows > 0) {
    // 检查字段长度是否需要更新
    $colInfo = $conn->query("SHOW COLUMNS FROM submissions WHERE Field = 'language'")->fetch_assoc();
    if (strpos($colInfo['Type'], 'varchar(50)') === false) {
        $conn->query("ALTER TABLE submissions MODIFY COLUMN language VARCHAR(50) DEFAULT 'cc.cc14o2'");
    }
} else {
    $conn->query("ALTER TABLE submissions ADD COLUMN language VARCHAR(50) DEFAULT 'cc.cc14o2' AFTER code");
}

// ========== 获取用户 Token 余额 ==========
$tokenQuery = $conn->query("SELECT token_num FROM user_token WHERE uid = {$login_uid}");
if ($tokenQuery->num_rows == 0) {
    $conn->query("INSERT INTO user_token (uid, token_num) VALUES ({$login_uid}, 0)");
    $userToken = 0;
} else {
    $userToken = (int)$tokenQuery->fetch_assoc()['token_num'];
}

$is_admin = 0;
$adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($adminRes && $adminRes->num_rows > 0) {
    $is_admin = (int)$adminRes->fetch_assoc()['admin'];
}

$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) {
    $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}

$pid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($pid <= 0) {
    header("Location: /404");
    exit;
}

$from = $_GET['from'] ?? '';
$cid = isset($_GET['cid']) ? (int)$_GET['cid'] : 0;
$backUrl = '';
$backText = '';
if ($cid > 0) {
    $backUrl = "/contest/" . $cid;
    $backText = '返回比赛';
}

// 创建/检查表结构（确保字段齐全）
$conn->query("CREATE TABLE IF NOT EXISTS problem_desc (
    id INT PRIMARY KEY,
    name TEXT,
    difficulty TINYINT UNSIGNED NOT NULL DEFAULT 0,
    background TEXT,
    description TEXT,
    input_format TEXT,
    output_format TEXT,
    samples JSON,
    hint TEXT,
    time_limit INT DEFAULT 1000,
    memory_limit INT DEFAULT 256
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$colCheckDifficulty = $conn->query("SHOW COLUMNS FROM problem_desc LIKE 'difficulty'");
if ($colCheckDifficulty && $colCheckDifficulty->num_rows === 0) {
    $conn->query("ALTER TABLE problem_desc ADD COLUMN difficulty TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER name");
}
if ($colCheckDifficulty) {
    $colCheckDifficulty->free();
}

$colCheck = $conn->query("SHOW COLUMNS FROM problem_desc LIKE 'samples'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE problem_desc ADD COLUMN samples JSON DEFAULT NULL");
}
$colCheckBg = $conn->query("SHOW COLUMNS FROM problem_desc LIKE 'background'");
if ($colCheckBg->num_rows == 0) {
    $conn->query("ALTER TABLE problem_desc ADD COLUMN background TEXT AFTER name");
}

$conn->query("CREATE TABLE IF NOT EXISTS submissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    problem_id INT NOT NULL,
    code TEXT NOT NULL,
    language VARCHAR(50) DEFAULT 'cc.cc14o2',
    result VARCHAR(20) DEFAULT 'Pending',
    score INT DEFAULT 0,
    time_ms INT DEFAULT 0,
    memory_kb INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_checked TIMESTAMP NULL,
    INDEX idx_uid (uid),
    INDEX idx_problem (problem_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$colCheck = $conn->query("SHOW COLUMNS FROM submissions LIKE 'last_checked'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE submissions ADD COLUMN last_checked TIMESTAMP NULL");
}

$message = '';
$error = '';

$problem = $conn->query("SELECT * FROM problem_desc WHERE id = {$pid} LIMIT 1")->fetch_assoc();
if (!$problem) {
    header("Location: https://lmtoj.cn/problem");
    exit;
}

$samples = [];
if (!empty($problem['samples'])) {
    $samples = json_decode($problem['samples'], true);
    if (!is_array($samples)) $samples = [];
}

// ========== API 函数 ==========
function api_request($method, $endpoint, $data = null) {
    if (API_KEY === '') {
        error_log('OJ_API_KEY is not configured');
        return null;
    }

    $url = API_BASE_URL . $endpoint;
    $headers = [
        'Authorization: Bearer ' . API_KEY,
        'Content-Type: application/json'
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    if ($method === 'POST') {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    } elseif ($method === 'GET' && $data) {
        $url .= '?' . http_build_query($data);
        curl_setopt($ch, CURLOPT_URL, $url);
    }
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($httpCode >= 200 && $httpCode < 300) {
        return json_decode($response, true);
    }
    
    return null;
}

function check_rate_limit($conn, $uid) {
    $stmt = $conn->prepare("SELECT created_at FROM api_submissions WHERE uid = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->bind_param("i", $uid);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    if ($result->num_rows > 0) {
        $lastSubmit = strtotime($result->fetch_assoc()['created_at']);
        $timeDiff = time() - $lastSubmit;
        if ($timeDiff < API_RATE_LIMIT) {
            return API_RATE_LIMIT - $timeDiff;
        }
    }
    
    return 0;
}

// ========== 管理员保存编辑 ==========
if ($is_admin && isset($_POST['save_desc'])) {
    $background = $_POST['background'] ?? '';
    $desc = $_POST['description'] ?? '';
    $input = $_POST['input_format'] ?? '';
    $output = $_POST['output_format'] ?? '';
    $hint = $_POST['hint'] ?? '';
    $tlim = (int)($_POST['time_limit'] ?? 1000);
    $mlim = (int)($_POST['memory_limit'] ?? 256);
    $difficulty = filter_var($_POST['difficulty'] ?? null, FILTER_VALIDATE_INT);
    if ($difficulty === false || $difficulty === null || $difficulty < 0 || $difficulty > 10) {
        $error = '难度必须在0至10之间';
    }

    // 处理样例组
    $sampleInputs = $_POST['sample_input'] ?? [];
    $sampleOutputs = $_POST['sample_output'] ?? [];
    $sampleData = [];
    $count = min(count($sampleInputs), count($sampleOutputs));
    for ($i = 0; $i < $count; $i++) {
        $in = trim($sampleInputs[$i]);
        $out = trim($sampleOutputs[$i]);
        if ($in !== '' || $out !== '') {
            $sampleData[] = ['input' => $in, 'output' => $out];
        }
    }
    if (count($sampleData) > 5) {
        $sampleData = array_slice($sampleData, 0, 5);
    }
    $samplesJson = json_encode($sampleData, JSON_UNESCAPED_UNICODE);
    if ($samplesJson === false) {
        $samplesJson = '[]';
    }

    if ($error === '') {
        $stmt = $conn->prepare("UPDATE problem_desc SET 
            background = ?, description = ?, input_format = ?, output_format = ?, samples = ?, hint = ?, time_limit = ?, memory_limit = ?, difficulty = ?
            WHERE id = ?");
        if ($stmt) {
            $stmt->bind_param("ssssssiiii", $background, $desc, $input, $output, $samplesJson, $hint, $tlim, $mlim, $difficulty, $pid);
            if ($stmt->execute()) {
                $message = '题目信息已更新';
            } else {
                $error = '更新失败: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = '准备语句失败: ' . $conn->error;
        }
    }

    // 重新加载数据
    $problem = $conn->query("SELECT * FROM problem_desc WHERE id = {$pid} LIMIT 1")->fetch_assoc();
    if (!empty($problem['samples'])) {
        $samples = json_decode($problem['samples'], true);
        if (!is_array($samples)) $samples = [];
    } else {
        $samples = [];
    }
}

// ========== 管理员绑定题目到API ==========
if ($is_admin && isset($_POST['bind_api_problem'])) {
    $api_problem_id = trim($_POST['api_problem_id'] ?? '');
    
    if (empty($api_problem_id)) {
        $error = '请输入API题目ID';
    } else {
        // 验证API题目是否存在
        $apiProblem = api_request('GET', '/openapi/problem', ['pid' => $api_problem_id]);
        
        if ($apiProblem) {
            // 删除旧绑定
            $stmt = $conn->prepare("DELETE FROM problem_bindings WHERE local_problem_id = ?");
            $stmt->bind_param("i", $pid);
            $stmt->execute();
            $stmt->close();
            
            // 添加新绑定
            $stmt = $conn->prepare("INSERT INTO problem_bindings (local_problem_id, api_problem_id) VALUES (?, ?)");
            $stmt->bind_param("is", $pid, $api_problem_id);
            if ($stmt->execute()) {
                $message = "成功绑定到API题目: {$api_problem_id}";
            } else {
                $error = '绑定失败: ' . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = 'API题目不存在或无法访问: ' . $api_problem_id;
        }
    }
}

// ========== 管理员解除绑定 ==========
if ($is_admin && isset($_GET['unbind_api'])) {
    $stmt = $conn->prepare("DELETE FROM problem_bindings WHERE local_problem_id = ?");
    $stmt->bind_param("i", $pid);
    if ($stmt->execute()) {
        $message = '已解除API题目绑定';
    } else {
        $error = '解除绑定失败: ' . $stmt->error;
    }
    $stmt->close();
}

// ========== 上传测试数据（保留原有功能） ==========
if ($is_admin && isset($_FILES['test_data']) && $_FILES['test_data']['error'] === UPLOAD_ERR_OK) {
    $uploadFile = $_FILES['test_data']['tmp_name'];
    $zip = new ZipArchive();
    if ($zip->open($uploadFile) === true) {
        $targetDir = __DIR__ . "/" . $pid;
        
        if (!is_dir($targetDir)) {
            if (!mkdir($targetDir, 0755, true)) {
                $error = "无法创建目录: {$pid}";
            }
        }
        
        if (empty($error)) {
            if ($zip->extractTo($targetDir)) {
                $message = "上传成功";
            } else {
                $error = "解压 ZIP 文件失败，请检查目录权限";
            }
        }
        $zip->close();
    } else {
        $error = "无效的 ZIP 文件";
    }
}

// ========== 删除测试数据 ==========
if ($is_admin && isset($_GET['del_test'])) {
    $filename = basename($_GET['del_test']);
    $filePath = __DIR__ . "/" . $pid . "/" . $filename;
    if (file_exists($filePath) && is_file($filePath)) {
        if (unlink($filePath)) {
            $message = "已删除: " . $filename;
        } else {
            $error = "删除失败: " . $filename;
        }
    } else {
        $error = "文件不存在";
    }
}

// ========== 提交代码（使用API评测，支持多语言） ==========
if (isset($_POST['submit_code'])) {
    if ($userToken < 3) {
        $error = 'Token 不足！提交题目需要消耗 3 Token，请前往商店兑换。';
    } else {
        // 检查限流
        $waitTime = check_rate_limit($conn, $login_uid);
        if ($waitTime > 0) {
            $error = "提交过于频繁，请在 {$waitTime} 秒后重试";
        } else {
            $code = trim($_POST['code']);
            $language = $_POST['language'] ?? 'cc.cc14o2';
            
            // 验证语言是否支持
            if (!array_key_exists($language, $supportedLanguages)) {
                $language = 'cc.cc14o2'; // 默认语言
            }
            
            if (empty($code)) {
                $error = '代码不能为空';
            } elseif (strlen($code) > 65536) {
                $error = '代码过长（最大64KB）';
            } else {
                // 获取API题目绑定
                $bindingQuery = $conn->query("SELECT api_problem_id FROM problem_bindings WHERE local_problem_id = {$pid} LIMIT 1");
                if ($bindingQuery->num_rows == 0) {
                    $error = '该题目尚未绑定API题目，请联系管理员';
                } else {
                    $apiProblemId = $bindingQuery->fetch_assoc()['api_problem_id'];
                    
                    // 调用API提交代码
                    $apiResult = api_request('POST', '/openapi/submit', [
                        'pid' => $apiProblemId,
                        'lang' => $language,
                        'code' => $code,
                        'domainId' => "lmtoj"
                    ]);
                    
                    if ($apiResult && isset($apiResult['rid'])) {
                        // 扣减Token
                        $conn->query("UPDATE user_token SET token_num = token_num - 3 WHERE uid = {$login_uid}");
                        $userToken -= 3;
                        
                        // 保存本地提交记录
                        $stmt = $conn->prepare("INSERT INTO submissions (uid, problem_id, code, language) VALUES (?, ?, ?, ?)");
                        $stmt->bind_param("iiss", $login_uid, $pid, $code, $language);
                        $stmt->execute();
                        $subId = $conn->insert_id;
                        $stmt->close();
                        
                        // 保存API提交记录
                        $stmt = $conn->prepare("INSERT INTO api_submissions (local_submission_id, api_rid, uid, problem_id, api_problem_id, language) VALUES (?, ?, ?, ?, ?, ?)");
                        $stmt->bind_param("isiiss", $subId, $apiResult['rid'], $login_uid, $pid, $apiProblemId, $language);
                        $stmt->execute();
                        $stmt->close();
                        
                        header("Location: /record/" . $subId);
                        exit;
                    } else {
                        $error = '提交到评测系统失败，请稍后重试';
                    }
                }
            }
        }
    }
}

// ========== 查询评测结果（用于异步更新） ==========
if (isset($_GET['check_status']) && isset($_GET['rid'])) {
    header('Content-Type: application/json');
    $rid = $_GET['rid'];
    $result = api_request('GET', '/openapi/status', ['rid' => $rid]);
    echo json_encode($result);
    exit;
}

if (isset($_GET['msg'])) $message = $_GET['msg'];

// 获取题目绑定信息
$apiBinding = null;
$bindingQuery = $conn->query("SELECT api_problem_id FROM problem_bindings WHERE local_problem_id = {$pid} LIMIT 1");
if ($bindingQuery->num_rows > 0) {
    $apiBinding = $bindingQuery->fetch_assoc()['api_problem_id'];
}

// 获取题目ID文件夹下的测试点文件列表
$testFiles = [];
$testDir = __DIR__ . "/" . $pid;
if (is_dir($testDir)) {
    $files = scandir($testDir);
    $allowedExtensions = ['in', 'out', 'ans', 'txt', 'data'];
    foreach ($files as $f) {
        if ($f === '.' || $f === '..') continue;
        $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
        if (in_array($ext, $allowedExtensions)) {
            $testFiles[] = $f;
        }
    }
    sort($testFiles);
}

function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }

$current_page = basename($_SERVER['SCRIPT_NAME']);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= safeContent($problem['name'] ?: '题目 #' . $pid) ?> - lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --danger: #d9534f; --danger-hover: #c0392b;
            --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', 'Consolas', monospace;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; letter-spacing:0.4px; color:#f0ece6; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); user-select:none; }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);} 50%{box-shadow:0 0 0 6px rgba(245,83,83,0);} }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); white-space:nowrap; font-weight:500; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:20px; }
        .card h2,.card h3 { font-size:18px; font-weight:600; margin-bottom:12px; color:var(--text); }
        h5 { font-size:15px; font-weight:600; margin:16px 0 6px; color:var(--text-secondary); }
        .alert { padding:12px 14px; border-radius:var(--radius-sm); margin-bottom:16px; font-size:14px; }
        .alert-success { background:#e8f5e9; color:#2e7d32; border:1px solid #a5d6a7; }
        .alert-error { background:#fce4ec; color:#c62828; border:1px solid #ef9a9a; }
        .prob-header { display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:16px; }
        .prob-title { font-size:22px; font-weight:700; color:var(--text); }
        .prob-meta { display:flex; gap:14px; flex-wrap:wrap; font-size:13px; color:var(--text-secondary); margin-bottom:20px; padding-bottom:16px; border-bottom:1px solid var(--border-light); }
        .prob-meta span { background:#f5f2ed; padding:5px 14px; border-radius:12px; font-weight:500; }
        .prob-meta .difficulty-badge { border-radius:4px; font-weight:600; }
        .difficulty-undefined { background:#41464b; color:#fff; }
        .difficulty-green { background:#d8f1df; color:#176b32; }
        .difficulty-yellow { background:#fff1b8; color:#785900; }
        .difficulty-orange { background:#ffe0c2; color:#914400; }
        .difficulty-red { background:#f8d0d0; color:#982d2d; }
        .prob-section { margin-bottom:20px; }
        .prob-section h3 { font-size:16px; font-weight:600; margin-bottom:8px; color:var(--text); }
        .md-content { line-height:1.8; font-size:14px; }
        .md-content p { margin:6px 0; }
        .md-content pre { background:#2b2a27; color:#e8e4dd; padding:14px 16px; border-radius:var(--radius-sm); overflow-x:auto; font-family:var(--font-mono); font-size:13px; margin:8px 0; }
        .md-content code { font-family:var(--font-mono); background:#f3f0eb; padding:2px 6px; border-radius:3px; font-size:0.9em; }
        .md-content pre code { background:transparent; padding:0; }
        .md-content img { max-width:100%; height:auto; border-radius:4px; margin:6px 0; }
        .sample-code-block { position:relative; margin:8px 0 16px; }
        .sample-code-block pre { background:#2b2a27; color:#e8e4dd; padding:12px 16px; border-radius:var(--radius-sm); overflow-x:auto; font-family:var(--font-mono); font-size:13px; margin:0; white-space:pre-wrap; word-break:break-all; }
        textarea { width:100%; padding:10px 14px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; outline:none; background:#fdfdfc; font-family:var(--font); resize:vertical; min-height:80px; transition:var(--transition); }
        textarea:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        textarea.code-editor { font-family:var(--font-mono); min-height:300px; tab-size:4; }
        input[type="text"],input[type="number"],input[type="file"],select { width:100%; padding:10px 14px; border:1.5px solid var(--border); border-radius:var(--radius-sm); font-size:14px; outline:none; background:#fdfdfc; font-family:var(--font); margin-bottom:10px; transition:var(--transition); }
        input:focus,select:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        .btn { padding:10px 22px; background:var(--accent); color:#fff; border:none; border-radius:20px; cursor:pointer; font-size:14px; font-weight:500; transition:var(--transition); font-family:var(--font); }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn-sm { padding:6px 14px; font-size:12px; }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:var(--danger-hover); }
        .btn-outline { background:transparent; color:var(--text-secondary); border:1.5px solid var(--border); }
        .btn-outline:hover { background:#f5f2ed; border-color:var(--text-muted); }
        .file-list { display:flex; flex-wrap:wrap; gap:8px; margin-top:10px; }
        .file-tag { background:#f5f2ed; padding:5px 14px; border-radius:12px; font-size:13px; display:flex; align-items:center; gap:8px; }
        .file-tag a { color:var(--danger); text-decoration:none; font-weight:700; font-size:15px; line-height:1; }
        .file-tag a:hover { color:var(--danger-hover); }
        .form-label { display:block; font-size:13px; font-weight:500; color:var(--text-secondary); margin-bottom:5px; margin-top:10px; }
        .sample-group { background:#faf9f7; padding:14px 16px; border-radius:var(--radius-sm); margin-bottom:12px; border:1px solid var(--border-light); }
        .sample-group h5 { margin-top:0; }
        .sample-group .row { display:flex; gap:16px; flex-wrap:wrap; }
        .sample-group .row > div { flex:1; min-width:200px; }
        .sample-group .row textarea { min-height:60px; }
        .token-balance { display:inline-block; margin-left:16px; background:var(--accent-light); padding:4px 14px; border-radius:20px; font-weight:600; color:var(--accent); font-size:14px; }
        .token-warning { color:var(--danger); font-size:13px; }
        .sample-actions { display:flex; gap:10px; margin-top:8px; flex-wrap:wrap; }
        .api-binding { background:#f0f7ff; border:1px solid #b3d9ff; border-radius:var(--radius-sm); padding:12px 16px; margin-bottom:16px; }
        .api-binding .binding-info { display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
        .api-binding .api-id { font-family:var(--font-mono); background:#fff; padding:4px 10px; border-radius:4px; border:1px solid #b3d9ff; }
        .language-selector { display:flex; gap:12px; align-items:center; margin-bottom:12px; flex-wrap:wrap; }
        .language-selector select { width:auto; min-width:200px; margin-bottom:0; }
        .language-selector label { font-size:14px; font-weight:500; color:var(--text-secondary); }
        @media(max-width:768px) {
            .main{flex-direction:column;padding:0 12px;margin:18px auto 30px;}
            .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}
            .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
            .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
            .navbar{padding:0 14px;height:48px;}
            .navbar h1{font-size:15px;}
            .user-info a{font-size:12px;padding:5px 9px;}
            .card{padding:18px 14px;}
            .language-selector { flex-direction:column; align-items:stretch; }
            .language-selector select { width:100%; }
        }
    </style>
    <link rel="stylesheet" href="/css/problem-theme.css">
</head>
<body>
<?php
try {
    if (!$conn->ping()) {
        throw new Exception('Connection lost');
    }
} catch (Exception $e) {
    $servername = $_ENV['DB_HOST'] ?? getenv('DB_HOST');
    $dbuser = $_ENV['DB_USER'] ?? getenv('DB_USER');
    $dbpass = $_ENV['DB_PASSWORD'] ?? getenv('DB_PASSWORD');
    $dbname = $_ENV['DB_NAME'] ?? getenv('DB_NAME');
    $conn = new mysqli($servername, $dbuser, $dbpass, $dbname);
    $conn->set_charset("utf8");
}
include 'navbar.php';
?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if ($cid > 0): ?>
            <a href="<?= $backUrl ?>" style="display:inline-flex;align-items:center;gap:6px;margin-bottom:18px;padding:8px 18px;background:var(--card-bg);color:var(--text);text-decoration:none;border-radius:20px;font-size:13.5px;font-weight:500;border:1px solid var(--border);box-shadow:0 1px 3px rgba(0,0,0,0.04);"><?= $backText ?></a>
        <?php endif; ?>
        <?php if ($message): ?><div class="alert alert-success"><?= safeContent($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-error"><?= safeContent($error) ?></div><?php endif; ?>

        <div class="card">
            <div class="prob-header">
                <div class="prob-title">#<?= $pid ?> <?= safeContent($problem['name'] ?: '未命名') ?></div>
                <div class="token-balance">🪙 <?= $userToken ?></div>
            </div>
            <div class="prob-meta">
                <span>时间限制: <?= $problem['time_limit'] ?: 1000 ?>ms</span>
                <span>内存限制: <?= $problem['memory_limit'] ?: 256 ?>MB</span>
                <?php
                    $difficulty = max(0, min(10, (int)($problem['difficulty'] ?? 0)));
                    $difficultyClass = $difficulty === 0 ? 'difficulty-undefined' : ($difficulty <= 3 ? 'difficulty-green' : ($difficulty <= 5 ? 'difficulty-yellow' : ($difficulty <= 8 ? 'difficulty-orange' : 'difficulty-red')));
                    $difficultyLabel = $difficulty === 0 ? '未定义' : $difficulty . ' 级';
                ?>
                <span class="difficulty-badge <?= $difficultyClass ?>">难度: <?= safeContent($difficultyLabel) ?></span>
                <span>提交消耗: 3 Token</span>
                <span>提交间隔: 45秒</span>
                <span>
                    <a style="color:#938C85;" href="https://lmtoj.cn/problem/solution/<?= htmlspecialchars($pid, ENT_QUOTES, 'UTF-8') ?>">查看题解</a>
                </span>
            </div>

            <?php if ($is_admin): ?>
            <div class="api-binding">
                <?php if ($apiBinding): ?>
                    <div class="binding-info">
                        <strong>API绑定:</strong>
                        <span class="api-id"><?= safeContent($apiBinding) ?></span>
                        <a href="?id=<?= $pid ?>&unbind_api=1" class="btn btn-sm btn-danger" onclick="return confirm('确定解除绑定？')">解除绑定</a>
                    </div>
                <?php else: ?>
                    <form method="post" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
                        <strong>绑定API题目:</strong>
                        <input type="text" name="api_problem_id" placeholder="输入API题目ID" style="width:200px;margin:0;" required>
                        <button type="submit" name="bind_api_problem" class="btn btn-sm">绑定</button>
                    </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($problem['background'])): ?>
                <div class="prob-section"><h3>题目背景</h3><div class="md-content" data-md="<?= safeContent($problem['background']) ?>"></div></div>
            <?php endif; ?>
            <?php if (!empty($problem['description'])): ?>
                <div class="prob-section"><h3>题目描述</h3><div class="md-content" data-md="<?= safeContent($problem['description']) ?>"></div></div>
            <?php endif; ?>
            <?php if (!empty($problem['input_format'])): ?>
                <div class="prob-section"><h3>输入格式</h3><div class="md-content" data-md="<?= safeContent($problem['input_format']) ?>"></div></div>
            <?php endif; ?>
            <?php if (!empty($problem['output_format'])): ?>
                <div class="prob-section"><h3>输出格式</h3><div class="md-content" data-md="<?= safeContent($problem['output_format']) ?>"></div></div>
            <?php endif; ?>

            <?php if (!empty($samples) && is_array($samples)): ?>
                <div class="prob-section">
                    <h3>输入输出样例</h3>
                    <?php foreach ($samples as $idx => $sample): 
                        $inputText = $sample['input'] ?? '';
                        $outputText = $sample['output'] ?? '';
                    ?>
                        <h5>输入 #<?= $idx + 1 ?></h5>
                        <div class="sample-code-block">
                            <pre><code class="sample-code"><?= safeContent($inputText) ?></code></pre>
                            <button type="button" class="copy-btn"><i class="fa fa-clipboard"></i> 复制</button>
                        </div>
                        <h5>输出 #<?= $idx + 1 ?></h5>
                        <div class="sample-code-block">
                            <pre><code class="sample-code"><?= safeContent($outputText) ?></code></pre>
                            <button type="button" class="copy-btn"><i class="fa fa-clipboard"></i> 复制</button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($problem['hint'])): ?>
                <div class="prob-section"><h3>提示 / 说明</h3><div class="md-content" data-md="<?= safeContent($problem['hint']) ?>"></div></div>
            <?php endif; ?>
        </div>

        <div class="card">
            <h3>提交代码</h3>
            <?php if ($userToken < 3): ?>
                <p class="token-warning">Token 不足 (当前 <?= $userToken ?>，需要 3)，请先获取 Token。</p>
            <?php endif; ?>
            <?php if (!$apiBinding && $is_admin): ?>
                <p class="token-warning">⚠️ 该题目尚未绑定API题目，请先在上方完成绑定。</p>
            <?php endif; ?>
            <form method="post">
                <div class="language-selector">
                    <label for="language">选择语言：</label>
                    <select name="language" id="language">
                        <?php foreach ($supportedLanguages as $langCode => $langName): ?>
                            <option value="<?= $langCode ?>" <?= $langCode === 'cc.cc14o2' ? 'selected' : '' ?>>
                                <?= $langName ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <textarea name="code" class="code-editor" placeholder="在此粘贴你的代码..." required></textarea>
                <button type="submit" name="submit_code" class="btn" style="margin-top:12px;<?= ($userToken < 3 || !$apiBinding) ? 'background-color:#BDBDBD;" disabled' : '"' ?>><?= ($userToken < 3 || !$apiBinding) ? '不允许提交' : '提交评测' ?></button>
            </form>
        </div>

        <?php if ($is_admin): ?>
        <div class="card">
            <h3>编辑题目信息</h3>
            <form method="post" id="editForm">
                <span class="form-label">题目背景</span>
                <textarea name="background" style="min-height:80px;"><?= safeContent($problem['background']) ?></textarea>
                <span class="form-label">题目描述</span>
                <textarea name="description" style="min-height:100px;"><?= safeContent($problem['description']) ?></textarea>
                <span class="form-label">输入格式</span>
                <textarea name="input_format" style="min-height:80px;"><?= safeContent($problem['input_format']) ?></textarea>
                <span class="form-label">输出格式</span>
                <textarea name="output_format" style="min-height:80px;"><?= safeContent($problem['output_format']) ?></textarea>

                <span class="form-label">输入输出样例（最多5组）</span>
                <div id="sampleContainer">
                    <?php 
                    $sampleCount = count($samples);
                    if ($sampleCount == 0) $sampleCount = 1;
                    for ($i = 0; $i < $sampleCount; $i++):
                        $s = $samples[$i] ?? ['input' => '', 'output' => ''];
                    ?>
                        <div class="sample-group" data-index="<?= $i ?>">
                            <h5>样例 #<?= $i + 1 ?></h5>
                            <div class="row">
                                <div>
                                    <span class="form-label" style="margin-top:0;">输入</span>
                                    <textarea name="sample_input[]"><?= safeContent($s['input']) ?></textarea>
                                </div>
                                <div>
                                    <span class="form-label" style="margin-top:0;">输出</span>
                                    <textarea name="sample_output[]"><?= safeContent($s['output']) ?></textarea>
                                </div>
                            </div>
                            <button type="button" class="btn btn-sm btn-danger remove-sample" style="margin-top:6px;">删除此组</button>
                        </div>
                    <?php endfor; ?>
                </div>
                <div class="sample-actions">
                    <button type="button" id="addSampleBtn" class="btn btn-sm btn-outline">添加样例组</button>
                    <button type="button" id="removeLastSampleBtn" class="btn btn-sm btn-outline">删除最后一组</button>
                </div>
                <p style="font-size:12px;color:var(--text-muted);margin-top:6px;">当前 <?= $sampleCount ?> 组，最少1组，最多5组。</p>

                <span class="form-label">提示 / 说明</span>
                <textarea name="hint" style="min-height:80px;"><?= safeContent($problem['hint']) ?></textarea>

                <span class="form-label">难度 (0=未定义，1-10级)</span>
                <select name="difficulty" required>
                    <?php for ($level = 0; $level <= 10; $level++): ?>
                        <option value="<?= $level ?>" <?= (int)($problem['difficulty'] ?? 0) === $level ? 'selected' : '' ?>><?= $level === 0 ? '0 - 未定义' : $level . ' 级' ?></option>
                    <?php endfor; ?>
                </select>

                <div style="display:flex;gap:16px;margin-top:8px;">
                    <div style="flex:1;"><span class="form-label">时间限制 (ms)</span><input type="number" name="time_limit" value="<?= $problem['time_limit'] ?: 1000 ?>"></div>
                    <div style="flex:1;"><span class="form-label">内存限制 (MB)</span><input type="number" name="memory_limit" value="<?= $problem['memory_limit'] ?: 256 ?>"></div>
                </div>

                <button type="submit" name="save_desc" class="btn" style="margin-top:14px;">保存所有修改</button>
            </form>
        </div>

        <div class="card">
            <h3>测试数据</h3>
            <form method="post" enctype="multipart/form-data">
                <input type="file" name="test_data" accept=".zip" required>
                <button type="submit" class="btn btn-sm" style="margin-top:8px;">上传 ZIP</button>
            </form>
            <?php if (!empty($testFiles)): ?>
                <div class="file-list">
                    <?php foreach ($testFiles as $f): ?>
                        <span class="file-tag">
                            <?= safeContent($f) ?>
                            <a href="?id=<?= $pid ?>&del_test=<?= urlencode($f) ?>" onclick="return confirm('确定删除？')">&times;</a>
                        </span>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p style="color:var(--text-muted);font-size:13px;margin-top:10px;">暂无测试数据</p>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<script>
const problemMarkdownRenderer = MarkdownRenderer.create({
    markdownOptions: {html: false, linkify: true, typographer: false, breaks: true},
    katexOptions: {macros: {"\\RR": "\\mathbb{R}"}}
});
problemMarkdownRenderer.renderAll({selector: '.md-content', sourceAttribute: 'md'});

// 语言切换时更新代码编辑器提示
document.getElementById('language').addEventListener('change', function() {
    var lang = this.value;
    var placeholder = '在此粘贴你的代码...';
    
    // 根据语言显示不同的占位符
    var placeholders = {
        'cc.cc14o2': '在此粘贴你的 C++14 代码...',
        'cc.cc17o2': '在此粘贴你的 C++17 代码...',
        'cc.cc20o2': '在此粘贴你的 C++20 代码...',
        'py.py3': '在此粘贴你的 Python 3 代码...',
        'java.jdk17': '在此粘贴你的 Java 代码...',
        'go.go120': '在此粘贴你的 Go 代码...',
        'rust.rust170': '在此粘贴你的 Rust 代码...',
        'js.node18': '在此粘贴你的 JavaScript 代码...'
    };
    
    document.querySelector('.code-editor').placeholder = placeholders[lang] || placeholder;
});

(function() {
    var container = document.getElementById('sampleContainer');
    if (!container) return;
    var addBtn = document.getElementById('addSampleBtn');
    var removeLastBtn = document.getElementById('removeLastSampleBtn');
    var MAX_SAMPLES = 5;
    var MIN_SAMPLES = 1;

    function updateGroups() {
        var groups = container.querySelectorAll('.sample-group');
        groups.forEach(function(group, idx) {
            var h5 = group.querySelector('h5');
            if (h5) h5.textContent = '样例 #' + (idx + 1);
            var removeBtn = group.querySelector('.remove-sample');
            if (removeBtn) {
                removeBtn.style.display = (groups.length <= MIN_SAMPLES) ? 'none' : 'inline-block';
            }
        });
        var infoP = document.querySelector('.sample-actions + p');
        if (infoP) infoP.textContent = '当前 ' + groups.length + ' 组，最少1组，最多5组。';
        if (addBtn) addBtn.disabled = (groups.length >= MAX_SAMPLES);
        if (removeLastBtn) removeLastBtn.disabled = (groups.length <= MIN_SAMPLES);
    }

    function addSample(inputVal, outputVal) {
        var groups = container.querySelectorAll('.sample-group');
        if (groups.length >= MAX_SAMPLES) {
            alert('最多只能添加5组样例');
            return;
        }
        var newIndex = groups.length;
        var div = document.createElement('div');
        div.className = 'sample-group';
        div.dataset.index = newIndex;
        div.innerHTML = `
            <h5>样例 #${newIndex + 1}</h5>
            <div class="row">
                <div>
                    <span class="form-label" style="margin-top:0;">输入</span>
                    <textarea name="sample_input[]">${escapeHtml(inputVal)}</textarea>
                </div>
                <div>
                    <span class="form-label" style="margin-top:0;">输出</span>
                    <textarea name="sample_output[]">${escapeHtml(outputVal)}</textarea>
                </div>
            </div>
            <button type="button" class="btn btn-sm btn-danger remove-sample" style="margin-top:6px;">删除此组</button>
        `;
        container.appendChild(div);
        div.querySelector('.remove-sample').addEventListener('click', function(e) {
            if (container.querySelectorAll('.sample-group').length <= MIN_SAMPLES) {
                alert('至少保留一组样例');
                return;
            }
            if (confirm('确定删除该组样例吗？')) {
                div.remove();
                updateGroups();
            }
        });
        updateGroups();
    }

    function escapeHtml(str) {
        if (!str) return '';
        return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    document.querySelectorAll('.remove-sample').forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            var group = this.closest('.sample-group');
            if (container.querySelectorAll('.sample-group').length <= MIN_SAMPLES) {
                alert('至少保留一组样例');
                return;
            }
            if (confirm('确定删除该组样例吗？')) {
                group.remove();
                updateGroups();
            }
        });
    });

    if (addBtn) {
        addBtn.addEventListener('click', function() {
            addSample('', '');
        });
    }
    if (removeLastBtn) {
        removeLastBtn.addEventListener('click', function() {
            var groups = container.querySelectorAll('.sample-group');
            if (groups.length <= MIN_SAMPLES) {
                alert('至少保留一组样例');
                return;
            }
            if (confirm('确定删除最后一组样例吗？')) {
                groups[groups.length - 1].remove();
                updateGroups();
            }
        });
    }

    updateGroups();
})();
</script>
</body>
</html>