<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

session_start();
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 密码验证
$correct_password = 'asoshirena/ll/bx';
$is_authenticated = false;

if (isset($_POST['password']) && $_POST['password'] === $correct_password) {
    $_SESSION['msg_viewer_auth'] = true;
    $is_authenticated = true;
} elseif (isset($_SESSION['msg_viewer_auth']) && $_SESSION['msg_viewer_auth'] === true) {
    $is_authenticated = true;
}

if (isset($_GET['logout'])) {
    unset($_SESSION['msg_viewer_auth']);
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

// 获取要查询的uid
$target_uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;
$current_conv_id = isset($_GET['conv_id']) ? (int)$_GET['conv_id'] : 0;

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>消息记录查看器</title>
    <style>
        :root {
            --bg: #f5f5f5; --card-bg: #ffffff; --text: #333;
            --border: #e0e0e0; --accent: #4a90d9; --accent-hover: #357abd;
            --msg-other: #e8e8e8; --msg-self: #4a90d9;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            background: var(--bg); 
            font-family: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
            color: var(--text); 
            line-height: 1.6;
            padding: 20px;
        }
        .container { max-width: 1000px; margin: 0 auto; }
        .header {
            background: var(--card-bg);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .login-form {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
        }
        .login-form input {
            padding: 10px 15px;
            border: 1.5px solid var(--border);
            border-radius: 6px;
            font-size: 14px;
            margin: 5px;
        }
        .login-form button {
            padding: 10px 20px;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 14px;
        }
        .main { display: flex; gap: 20px; }
        .sidebar {
            background: var(--card-bg);
            border-radius: 8px;
            padding: 15px;
            width: 300px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            max-height: 80vh;
            overflow-y: auto;
        }
        .chat-area {
            flex: 1;
            background: var(--card-bg);
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .user-info {
            padding: 15px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .conv-item {
            display: block;
            padding: 12px;
            border-radius: 6px;
            margin-bottom: 5px;
            cursor: pointer;
            text-decoration: none;
            color: var(--text);
            transition: background 0.2s;
        }
        .conv-item:hover { background: #f0f0f0; }
        .conv-item.active { background: #e3edf7; font-weight: 600; }
        .conv-item .conv-name { font-size: 14px; }
        .conv-item .conv-last { font-size: 12px; color: #888; margin-top: 3px; }
        .chat-header {
            padding: 15px 20px;
            border-bottom: 1px solid var(--border);
            font-weight: 600;
            font-size: 16px;
        }
        .messages {
            padding: 20px;
            max-height: 60vh;
            overflow-y: auto;
        }
        .msg-item {
            margin-bottom: 15px;
            display: flex;
            gap: 8px;
            align-items: flex-start;
        }
        .msg-item.self {
            justify-content: flex-end;
        }
        .msg-item.self .msg-bubble {
            background: var(--msg-self);
            color: white;
            border-radius: 12px 12px 4px 12px;
        }
        .msg-item:not(.self) .msg-bubble {
            background: var(--msg-other);
            border-radius: 12px 12px 12px 4px;
        }
        .msg-bubble {
            padding: 10px 14px;
            max-width: 70%;
            word-wrap: break-word;
            white-space: pre-wrap;
            font-size: 14px;
        }
        .msg-name {
            font-size: 11px;
            color: #888;
            margin-bottom: 3px;
        }
        .msg-time {
            font-size: 10px;
            color: #999;
            margin-top: 4px;
        }
        .empty-state {
            padding: 40px;
            text-align: center;
            color: #999;
        }
        .btn { 
            padding: 8px 16px; 
            border-radius: 4px; 
            border: none; 
            cursor: pointer; 
            font-size: 13px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary { background: var(--accent); color: white; }
        .btn-danger { background: #e74c3c; color: white; }
        input[type="number"] {
            padding: 8px 12px;
            border: 1.5px solid var(--border);
            border-radius: 6px;
            font-size: 14px;
            width: 120px;
        }
    </style>
</head>
<body>
<div class="container">
    <?php if (!$is_authenticated): ?>
        <div class="login-form">
            <h2 style="margin-bottom:20px;">🔐 消息记录查看器</h2>
            <form method="post">
                <input type="password" name="password" placeholder="请输入密码" required>
                <button type="submit">验证</button>
            </form>
        </div>
    <?php else: ?>
        <div class="header">
            <form method="get" style="display:flex;align-items:center;gap:15px;">
                <span style="font-weight:600;">输入用户UID：</span>
                <input type="number" name="uid" value="<?=$target_uid?>" placeholder="UID" min="1" required>
                <button type="submit" class="btn btn-primary">查询</button>
                <a href="?logout=1" class="btn btn-danger" style="margin-left:auto;">退出</a>
            </form>
        </div>

        <?php if ($target_uid > 0): 
            // 获取用户信息
            $userInfo = $conn->query("SELECT uid, name, sixin FROM users WHERE uid = {$target_uid}")->fetch_assoc();
            if ($userInfo):
                // 获取该用户参与的所有会话
                $conversations = $conn->query("
                    SELECT c.id, c.type, c.name,
                           (SELECT content FROM chat_messages 
                            WHERE conversation_id = c.id 
                            AND created_at > IFNULL((SELECT cleared_at FROM chat_members WHERE conversation_id = c.id AND uid = {$target_uid}), '1970-01-01')
                            ORDER BY id DESC LIMIT 1) as last_msg
                    FROM chat_conversations c
                    JOIN chat_members m ON c.id = m.conversation_id AND m.uid = {$target_uid}
                    WHERE (c.type = 'group') OR (c.type = 'private' AND m.hidden = 0)
                    ORDER BY c.updated_at DESC
                ");
                
                // 获取每个会话的未读数
                $unreadCounts = [];
                $unreadRes = $conn->query("
                    SELECT conversation_id,
                           (SELECT COUNT(*) FROM chat_messages 
                            WHERE conversation_id = m.conversation_id 
                            AND created_at > IFNULL((SELECT cleared_at FROM chat_members WHERE conversation_id = m.conversation_id AND uid = {$target_uid}), '1970-01-01')
                            AND id > m.last_read_id) as unread
                    FROM chat_members m
                    WHERE m.uid = {$target_uid}
                ");
                while ($row = $unreadRes->fetch_assoc()) {
                    $unreadCounts[$row['conversation_id']] = (int)$row['unread'];
                }
        ?>
        <div class="main">
            <div class="sidebar">
                <div class="user-info">
                    <div>
                        <strong><?=safeContent($userInfo['name'])?></strong>
                        <span style="font-size:12px;color:#888;"> (UID: <?=$target_uid?>)</span>
                    </div>
                    <span style="font-size:12px;">
                        <?=$conversations->num_rows?> 个会话
                    </span>
                </div>
                <?php if ($conversations->num_rows > 0): 
                    $conversations->data_seek(0);
                    while ($conv = $conversations->fetch_assoc()):
                        $displayName = $conv['name'];
                        if ($conv['type'] == 'private') {
                            $partner = $conn->query("
                                SELECT u.name FROM users u 
                                JOIN chat_members m ON u.uid = m.uid 
                                WHERE m.conversation_id = {$conv['id']} AND m.uid != {$target_uid}
                            ")->fetch_assoc();
                            $displayName = '💬 ' . ($partner['name'] ?? '未知用户');
                        } else {
                            $displayName = '👥 ' . safeContent($conv['name'] ?: '群聊');
                        }
                        $unread = $unreadCounts[$conv['id']] ?? 0;
                ?>
                    <a href="?uid=<?=$target_uid?>&conv_id=<?=$conv['id']?>" 
                       class="conv-item <?=$current_conv_id == $conv['id'] ? 'active' : ''?>">
                        <div class="conv-name">
                            <?=$displayName?>
                            <?php if ($unread > 0): ?>
                                <span style="background:#e74c3c;color:white;padding:1px 6px;border-radius:8px;font-size:11px;"><?=$unread?></span>
                            <?php endif; ?>
                        </div>
                        <div class="conv-last"><?=safeContent(mb_substr($conv['last_msg'] ?? '', 0, 30))?></div>
                    </a>
                <?php endwhile; else: ?>
                    <div class="empty-state">暂无会话</div>
                <?php endif; ?>
            </div>

            <div class="chat-area">
                <?php if ($current_conv_id > 0):
                    // 检查用户是否在该会话中
                    $convCheck = $conn->query("SELECT c.* FROM chat_conversations c JOIN chat_members m ON c.id = m.conversation_id WHERE c.id = {$current_conv_id} AND m.uid = {$target_uid}")->fetch_assoc();
                    if ($convCheck):
                        // 获取该用户的cleared_at
                        $clearTime = $conn->query("SELECT cleared_at FROM chat_members WHERE conversation_id = {$current_conv_id} AND uid = {$target_uid}")->fetch_assoc()['cleared_at'] ?? '1970-01-01';
                        $clearTimeSql = $conn->real_escape_string($clearTime);
                        
                        // 获取消息
                        $messages = $conn->query("
                            SELECT m.*, u.name, u.uid as sender_uid
                            FROM chat_messages m
                            LEFT JOIN users u ON m.uid = u.uid
                            WHERE m.conversation_id = {$current_conv_id}
                            AND m.created_at > '{$clearTimeSql}'
                            ORDER BY m.id ASC
                        ");
                        
                        // 获取会话标题
                        if ($convCheck['type'] == 'private') {
                            $partner = $conn->query("
                                SELECT u.name, u.uid FROM users u 
                                JOIN chat_members m ON u.uid = m.uid 
                                WHERE m.conversation_id = {$current_conv_id} AND m.uid != {$target_uid}
                            ")->fetch_assoc();
                            $chatTitle = '与 ' . safeContent($partner['name'] ?? '未知用户') . ' 的私聊';
                        } else {
                            $chatTitle = safeContent($convCheck['name'] ?: '群聊');
                            // 获取群成员
                            $members = $conn->query("
                                SELECT u.name, u.uid FROM users u 
                                JOIN chat_members m ON u.uid = m.uid 
                                WHERE m.conversation_id = {$current_conv_id}
                            ");
                        }
                ?>
                    <div class="chat-header">
                        <?=$chatTitle?>
                        <?php if ($convCheck['type'] == 'group' && isset($members)): ?>
                            <div style="font-size:12px;color:#888;margin-top:5px;">
                                成员：<?php while($m = $members->fetch_assoc()) echo safeContent($m['name']) . ' '; ?>
                            </div>
                        <?php endif; ?>
                        <?php if ($clearTime != '1970-01-01'): ?>
                            <div style="font-size:11px;color:#f0a040;margin-top:3px;">
                                ℹ️ 该用户在此清空过记录（<?=date('Y-m-d H:i', strtotime($clearTime))?>）
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="messages">
                        <?php if ($messages->num_rows > 0): 
                            while ($msg = $messages->fetch_assoc()):
                                $isSelf = $msg['uid'] == $target_uid;
                        ?>
                            <div class="msg-item <?=$isSelf ? 'self' : ''?>">
                                <div>
                                    <?php if (!$isSelf): ?>
                                        <div class="msg-name"><?=safeContent($msg['name'])?></div>
                                    <?php endif; ?>
                                    <div class="msg-bubble"><?=nl2br(safeContent($msg['content']))?></div>
                                    <div class="msg-time" style="text-align:<?=$isSelf?'right':'left'?>;">
                                        <?=date('m-d H:i', strtotime($msg['created_at']))?>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; else: ?>
                            <div class="empty-state">
                                📭 没有消息记录<br>
                                <small>（该用户清空了记录或还未发送消息）</small>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="chat-header">❌ 会话不存在或无权限</div>
                    <div class="empty-state">该用户不在此会话中</div>
                <?php endif; ?>
                <?php else: ?>
                    <div class="chat-header">消息记录查看器</div>
                    <div class="empty-state">
                        👈 请从左侧选择一个会话查看<br>
                        <small>这是 <?=safeContent($userInfo['name'])?> 的第一视角消息记录</small>
                    </div>
                <?php endif; ?>
            </div>
        </div>
            <?php else: ?>
                <div class="header" style="text-align:center;color:#e74c3c;">
                    ❌ 未找到UID为 <?=$target_uid?> 的用户
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php endif; ?>
</div>
</body>
</html>