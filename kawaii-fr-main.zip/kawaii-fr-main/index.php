<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';

header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 积分颜色辅助函数（与 user.php 一致） ==========
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getUserColor($user, $login_uid, $myShowColorful = 1) {
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    $admin = (int)($user['admin'] ?? 0);
    $color = getColorByTotalScore($total, $admin);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    $isColorful = false;
    if ($user['uid'] == $login_uid) {
        $isColorful = $targetColorful;
    } else {
        $isColorful = $targetColorful && $myShowColorful;
    }
    return ['color' => $color, 'isColorful' => $isColorful];
}

// ========== 创建缓存目录 ==========
if (!is_dir(__DIR__ . '/cache')) {
    mkdir(__DIR__ . '/cache', 0755, true);
}

// ========== 创建 site_settings 表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(50) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== 确保 users 表有 star 字段 ==========
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'star'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN star INT DEFAULT 0");
}

// ========== 确保 users 表有 last_treehole_date / last_echo_date ==========
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'last_treehole_date'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN last_treehole_date DATE DEFAULT NULL");
}
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'last_echo_date'");
if ($colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN last_echo_date DATE DEFAULT NULL");
}

$conn->query("CREATE TABLE IF NOT EXISTS user_bind (
    uid INT PRIMARY KEY,
    bind_type ENUM('luogu','email') NOT NULL,
    bind_value VARCHAR(255) NOT NULL,
    verify_code VARCHAR(32) NOT NULL,
    verified TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    checked_at TIMESTAMP NULL,
    check_count INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== 树洞表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS treehole (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    content TEXT NOT NULL,
    anonymous TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX(uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ========== Token 余额表 ==========
$conn->query("CREATE TABLE IF NOT EXISTS user_token (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '用户UID',
    token_num INT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_uid (uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin, sqadmin, jinyan, avatar, show_colorful_names, base_credit, valuation, username_color, cert_type, cert_level, practice_score, contribute_score, contest_score FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = $userRow['admin'] ?? 0;
$is_sqadmin = $userRow['sqadmin'] ?? 0;
$is_jinyan = $userRow['jinyan'] ?? 0;
$login_name = $userRow['name'] ?? '';
$myShowColorful = $userRow['show_colorful_names'] ?? 1;
$myInterests = array_filter(explode(',', $userRow['interests'] ?? ''));

// 初始化/读取用户token
$tokenCheck = $conn->query("SELECT token_num FROM user_token WHERE uid = {$login_uid} LIMIT 1");
if ($tokenCheck->num_rows === 0) {
    $conn->query("INSERT INTO user_token (uid, token_num) VALUES ({$login_uid}, 0)");
    $userToken = 0;
} else {
    $tkRow = $tokenCheck->fetch_assoc();
    $userToken = (int)$tkRow['token_num'];
}

$bindCheck = $conn->query("SELECT uid, bind_type, bind_value, verified FROM user_bind WHERE uid = {$login_uid} AND verified = 1 LIMIT 1");
$bind = $bindCheck->fetch_assoc();
$is_bound = $bindCheck && $bindCheck->num_rows && $bind['verified'];
$bind_info = $is_bound ? $bind : null;

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== 处理公告更新 ==========
if ($is_admin && isset($_POST['update_announcement'])) {
    $newAnnounce = trim($_POST['announcement_content']);
    if (!empty($newAnnounce)) {
        $stmt = $conn->prepare("INSERT INTO site_settings (setting_key, setting_value) VALUES ('announcement', ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
        $stmt->bind_param("s", $newAnnounce);
        $stmt->execute();
        $stmt->close();
        header("Location: https://lmtoj.cn/");
        exit;
    }
}

// ========== 获取公告内容 ==========
$announceRes = $conn->query("SELECT setting_value FROM site_settings WHERE setting_key='announcement'");
$announcement = $announceRes ? ($announceRes->fetch_assoc()['setting_value'] ?? '请在工单反馈问题。') : '请在工单反馈问题。';

$interestTags = [
    'Minecraft', 'Terraria', 'Stardew Valley', 'Hollow Knight', 'Celeste', 'Undertale', 'Factorio', 'RimWorld',
    'Genshin Impact', 'Honkai: Star Rail', 'Arknights', 'Fate/Grand Order', '原神', '崩坏：星穹铁道', '明日方舟',
    '王者荣耀', '和平精英', '第五人格', '光遇', '崩坏3', '少女前线', '碧蓝航线', '赛马娘', '蔚蓝档案', '绝区零',
    '黑神话：悟空', '永劫无间', 'Dota 2', 'League of Legends', 'CS:GO', 'Valorant', 'Apex Legends', 'Fortnite',
    'Overwatch', 'PUBG', '我的世界', '泰拉瑞亚', '星露谷物语', '空洞骑士', '蔚蓝', '异星工厂', '环世界',
    'C++', 'Python', 'Java', 'JavaScript', '算法竞赛', '信息学奥赛', '机器学习', 'Web开发', '游戏开发', '网络安全',
    '进击的巨人', '鬼灭之刃', '咒术回战', '间谍过家家', '电锯人', '葬送的芙莉莲', '孤独摇滚!', '命运石之门',
    '钢之炼金术师', 'CLANNAD', '紫罗兰永恒花园', '魔法少女小圆', '凉宫春日的忧郁', '新世纪福音战士',
    '刀剑神域', 'Re:从零开始的异世界生活', '辉夜大小姐想让我告白', '关于我转生变成史莱姆这档事',
    '无职转生', '迷宫饭', '异世界舅舅', '更衣人偶坠入爱河', 'Lycoris Recoil', '夏日重现', '青之驱魔师', '未来日记',
    'florr.io', '音游', 'V家', '绘画', '东方Project', '动物森友会', '宝可梦', '火焰纹章', '塞尔达传说', '最终幻想',
    '怪物猎人', '黑暗之魂', '艾尔登法环', '只狼', '血源诅咒', '巫师3', '赛博朋克2077', '荒野大镖客2'
];

function analyzeAndSetInterests($conn, $uid, $presetTags) {
    $recent = $conn->query("SELECT text FROM benben WHERE uid = $uid ORDER BY time DESC, id DESC LIMIT 20");
    if ($recent->num_rows === 0) return;
    $texts = [];
    while ($row = $recent->fetch_assoc()) $texts[] = $row['text'];
    $combined = implode("\n", $texts);

    $presetList = implode(',', $presetTags);
    $prompt = "根据以下用户发布的犇犇内容，从预设标签列表中挑选最多8个最符合的兴趣标签。只能从列表中选择，不要编造。\n列表：$presetList\n内容：\n$combined\n请直接输出逗号分隔的标签，不要其他文字。";

    $apiKey = 'sk-9b23c02f936f4ca8805bb4304ea57f92';
    $url = 'https://api.deepseek.com/v1/chat/completions';
    $payload = [
        'model' => 'deepseek-chat',
        'messages' => [['role' => 'user', 'content' => $prompt]],
        'temperature' => 0.3,
        'max_tokens' => 100
    ];
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Authorization: Bearer ' . $apiKey]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $res = curl_exec($ch);
    curl_close($ch);
    if (!$res) return;
    $data = json_decode($res, true);
    $tags = trim($data['choices'][0]['message']['content'] ?? '');
    $tagsArr = array_map('trim', explode(',', $tags));
    $valid = array_intersect($tagsArr, $presetTags);
    $finalTags = array_slice($valid, 0, 8);
    $interests = implode(',', $finalTags);
    $conn->query("UPDATE users SET interests='" . $conn->real_escape_string($interests) . "' WHERE uid=$uid");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_benben'])) {
    if ($is_jinyan === 1) {
        echo '<script>alert("您已被禁言，无法发布内容");history.go(-1);</script>';
        exit;
    }
    $text = trim($_POST['text']);
    if (!empty($text)) {
        $text = mb_substr($text, 0, 150);
        preg_match_all('/@([\w_\x{4e00}-\x{9fa5}]+)/u', $text, $atMatches);
        $atNames = array_unique($atMatches[1]);

        $now = date('Y-m-d H:i:s');
        $maxId = $conn->query("SELECT MAX(id) AS mid FROM benben")->fetch_assoc()['mid'] ?? 0;
        $newBenId = $maxId + 1;
        $textEscape = $conn->real_escape_string($text);
        
        $conn->query("INSERT INTO benben (id, uid, text, time) VALUES ($newBenId, $login_uid, '$textEscape', '$now')");

        foreach ($atNames as $atName) {
            $atNameEscape = $conn->real_escape_string($atName);
            $targetUser = $conn->query("SELECT uid FROM users WHERE name = '$atNameEscape' LIMIT 1")->fetch_assoc();
            if ($targetUser && $targetUser['uid'] != $login_uid) {
                $targetUid = (int)$targetUser['uid'];
                $conn->query("INSERT INTO notice (uid, atid, tid, topic_title, create_time, is_read) 
                              VALUES ($targetUid, $login_uid, 0, '', '$now', 0)");
            }
        }

        $benCount = $conn->query("SELECT COUNT(*) AS cnt FROM benben WHERE uid = $login_uid")->fetch_assoc()['cnt'];
        if ($benCount % 10 == 0) {
            analyzeAndSetInterests($conn, $login_uid, $interestTags);
        }
    }
    header("Location: https://lmtoj.cn/");
    exit;
}

if (isset($_GET['del_id'])) {
    $del_id = (int)$_GET['del_id'];
    $row = $conn->query("SELECT uid FROM benben WHERE id = $del_id LIMIT 1")->fetch_assoc();
    if ($is_admin || $row['uid'] == $login_uid) {
        $conn->query("DELETE FROM benben WHERE id = $del_id");
    }
    header("Location: https://lmtoj.cn/");
    exit;
}

// ========== 树洞处理 ==========
// 发布树洞：取消每日限制，普通用户扣1token，sqadmin免费
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['post_treehole'])) {
    $content = trim($_POST['content']);
    $anonymous = isset($_POST['anonymous']) ? 1 : 0;

    // ★ 修复：判空改用 trim === ''
    if ($content === '') {
        echo '<script>alert("内容不能为空");history.go(-1);</script>';
        exit;
    }

    // 非sqadmin消耗1token
    if (!$is_sqadmin) {
        if ($userToken < 1) {
            echo '<script>alert("Token不足！发布树洞需要消耗1Token，前往商店兑换");history.go(-1);</script>';
            exit;
        }
        // 扣减token
        $conn->query("UPDATE user_token SET token_num = token_num - 1 WHERE uid = {$login_uid}");
        $userToken -= 1;
    }

    $stmt = $conn->prepare("INSERT INTO treehole (uid, content, anonymous) VALUES (?, ?, ?)");
    $stmt->bind_param("isi", $login_uid, $content, $anonymous);
    $stmt->execute();
    $stmt->close();

    header("Location: https://lmtoj.cn/");
    exit;
}

// 回声：取消每日限制，普通用户扣1token，sqadmin免费
if (isset($_GET['echo'])) {
    // 非管理员扣token
    if (!$is_sqadmin) {
        if ($userToken < 1) {
            echo '<script>alert("Token不足！使用回声需要消耗1Token，前往商店兑换");history.go(-1);</script>';
            exit;
        }
        $conn->query("UPDATE user_token SET token_num = token_num - 1 WHERE uid = {$login_uid}");
        $userToken -= 1;
    }

    // 检查是否有除自己以外的树洞
    $cnt = $conn->query("SELECT COUNT(*) AS cnt FROM treehole WHERE uid != {$login_uid}")->fetch_assoc();
    if ($cnt['cnt'] == 0) {
        echo '<script>alert("暂时没有其他人的树洞消息");history.go(-1);</script>';
        exit;
    }

    // 随机选一条非自己的树洞消息
    $rand = $conn->query("SELECT * FROM treehole WHERE uid != {$login_uid} ORDER BY RAND() LIMIT 1");
    if ($rand->num_rows == 0) {
        echo '<script>alert("树洞还没有消息，快去写一条吧！");history.go(-1);</script>';
        exit;
    }
    $echoMsg = $rand->fetch_assoc();
    $poster = $conn->query("SELECT uid, name, admin, practice_score, contribute_score, contest_score, base_credit, valuation, username_color, cert_type, cert_level FROM users WHERE uid = {$echoMsg['uid']}")->fetch_assoc();
    $displayName = '匿名用户';
    $color = '#666';
    $isColorful = false;
    if ($echoMsg['anonymous'] == 0 || $is_sqadmin) {
        $colorInfo = getUserColor($poster, $login_uid, $myShowColorful);
        $displayName = $poster['name'];
        $color = $colorInfo['color'];
        $isColorful = $colorInfo['isColorful'];
    } else {
        $displayName = '匿名用户';
        $color = '#666';
        $isColorful = false;
    }
    $_SESSION['echo_result'] = [
        'content' => $echoMsg['content'],
        'displayName' => $displayName,
        'color' => $color,
        'isColorful' => $isColorful,
        'time' => $echoMsg['created_at']
    ];
    header("Location: https://lmtoj.cn/");
    exit;
}

// ★★★ 删除树洞（允许作者或管理员）★★★
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['del_treehole'])) {
    header('Content-Type: application/json');
    $id = (int)$_POST['del_treehole'];
    // 先查询该树洞的作者
    $check = $conn->query("SELECT uid FROM treehole WHERE id = $id");
    if ($check->num_rows === 0) {
        echo json_encode(['success' => false, 'msg' => '树洞不存在']);
        exit;
    }
    $author_uid = $check->fetch_assoc()['uid'];
    // 权限判断：作者本人 或 超级管理员
    if ($author_uid != $login_uid && !$is_sqadmin) {
        echo json_encode(['success' => false, 'msg' => '无权限删除此树洞']);
        exit;
    }
    if ($conn->query("DELETE FROM treehole WHERE id = $id")) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => '数据库删除失败：' . $conn->error]);
    }
    exit;
}

// ★★★ 编辑树洞（允许作者或管理员）★★★
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_treehole'])) {
    header('Content-Type: application/json');
    $id = (int)$_POST['id'];
    $content = trim($_POST['content']);
    $anonymous = isset($_POST['anonymous']) ? 1 : 0;
    // ★ 修复判空
    if ($content === '') {
        echo json_encode(['success' => false, 'msg' => '内容不能为空']);
        exit;
    }
    // 先查询作者
    $check = $conn->query("SELECT uid FROM treehole WHERE id = $id");
    if ($check->num_rows === 0) {
        echo json_encode(['success' => false, 'msg' => '树洞不存在']);
        exit;
    }
    $author_uid = $check->fetch_assoc()['uid'];
    if ($author_uid != $login_uid && !$is_sqadmin) {
        echo json_encode(['success' => false, 'msg' => '无权限编辑此树洞']);
        exit;
    }
    $stmt = $conn->prepare("UPDATE treehole SET content = ?, anonymous = ? WHERE id = ?");
    $stmt->bind_param("sii", $content, $anonymous, $id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'msg' => '更新失败：' . $stmt->error]);
    }
    $stmt->close();
    exit;
}

// 管理员添加树洞（仅发布给自己，免费不扣token）
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_add_treehole']) && $is_sqadmin) {
    $content = trim($_POST['content']);
    $anonymous = isset($_POST['anonymous']) ? 1 : 0;
    // ★ 判空统一
    if ($content !== '') {
        $stmt = $conn->prepare("INSERT INTO treehole (uid, content, anonymous) VALUES (?, ?, ?)");
        $stmt->bind_param("isi", $login_uid, $content, $anonymous);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: https://lmtoj.cn/");
    exit;
}

// ========== AJAX 接口：获取树洞列表（JSON） ==========
if (isset($_GET['ajax_treehole'])) {
    header('Content-Type: application/json');
    $page = isset($_GET['th_page']) ? max(1, (int)$_GET['th_page']) : 1;
    $limit = 10;
    $offset = ($page - 1) * $limit;

    $thTotal = 0;
    $query = '';

    // 区分管理员/普通用户
    if ($is_sqadmin) {
        // sqadmin：查全部
        $totalSql = "SELECT COUNT(*) AS cnt FROM treehole";
        $query = "SELECT t.*, u.name, u.admin, u.practice_score, u.contribute_score, u.contest_score, u.base_credit, u.valuation, u.username_color, u.cert_type, u.cert_level
                  FROM treehole t LEFT JOIN users u ON t.uid = u.uid 
                  ORDER BY t.id DESC LIMIT $offset, $limit";
    } else {
        // 普通用户：只查自己
        $totalSql = "SELECT COUNT(*) AS cnt FROM treehole WHERE uid = {$login_uid}";
        $query = "SELECT t.*, u.name, u.admin, u.practice_score, u.contribute_score, u.contest_score, u.base_credit, u.valuation, u.username_color, u.cert_type, u.cert_level
                  FROM treehole t LEFT JOIN users u ON t.uid = u.uid 
                  WHERE t.uid = {$login_uid} 
                  ORDER BY t.id DESC LIMIT $offset, $limit";
    }

    $totalRes = $conn->query($totalSql);
    if (!$totalRes) {
        echo json_encode([
            'code' => -1,
            'msg' => '统计总数SQL错误：' . $conn->error,
            'items' => [],
            'total' => 0,
            'totalPage' => 0,
            'currentPage' => $page
        ]);
        exit;
    }
    $thTotal = $totalRes->fetch_assoc()['cnt'];
    $thTotalPage = ceil($thTotal / $limit);

    $result = $conn->query($query);
    if (!$result) {
        echo json_encode([
            'code' => -1,
            'msg' => '列表查询SQL错误：' . $conn->error,
            'items' => [],
            'total' => 0,
            'totalPage' => 0,
            'currentPage' => $page
        ]);
        exit;
    }

    $items = [];
    while ($row = $result->fetch_assoc()) {
        $displayName = '匿名用户';
        $color = '#666';
        $isColorful = false;
        if ($row['anonymous'] == 0 || $is_sqadmin) {
            $colorInfo = getUserColor($row, $login_uid, $myShowColorful);
            $displayName = $row['name'];
            $color = $colorInfo['color'];
            $isColorful = $colorInfo['isColorful'];
        }
        // ★ 时间修正：加15小时
        $dt = new DateTime($row['created_at']);
        $items[] = [
            'id' => $row['id'],
            'content' => $row['content'],
            'uid' => $row['uid'],
            'anonymous' => (int)$row['anonymous'],
            'created_at' => $dt->format('Y-m-d H:i:s'),
            'displayName' => $displayName,
            'color' => $color,
            'isColorful' => $isColorful,
            'is_sqadmin' => $is_sqadmin,
        ];
    }

    echo json_encode([
        'code' => 0,
        'items' => $items,
        'total' => $thTotal,
        'totalPage' => $thTotalPage,
        'currentPage' => $page
    ]);
    exit;
}

$unreadCount = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0")->fetch_assoc()['cnt'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$total = $conn->query("SELECT COUNT(*) AS cnt FROM benben")->fetch_assoc()['cnt'];
$totalPage = ceil($total / $limit);

$benList = $conn->query("
    SELECT b.id, b.uid, b.text, b.time, u.name, u.admin, u.tag, u.avatar
    FROM benben b 
    LEFT JOIN users u ON b.uid = u.uid 
    ORDER BY b.time DESC, b.id DESC
    LIMIT $offset, $limit
");

$allUserRes = $conn->query("SELECT uid, name FROM users");
$nameToUid = [];
while ($u = $allUserRes->fetch_assoc()) {
    $nameToUid[$u['name']] = $u['uid'];
}

function safeContent($content) {
    $content = $content ?? '';
    return htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
}
function containsEnglish($text) {
    $text = preg_replace('/@[\w_\x{4e00}-\x{9fa5}]+/u', '', $text);
    $text = preg_replace('/```[\s\S]*?```/', '', $text);
    $text = preg_replace('/`[^`]+`/', '', $text);
    $text = preg_replace('/\$[^$]+\$/', '', $text);
    $text = preg_replace('/\$\$[\s\S]*?\$\$/', '', $text);
    $text = preg_replace('/!?\[[^\]]*\]\([^)]+\)/', '', $text);
    return preg_match('/[a-zA-Z]{3,}/', $text);
}
function getFirstChar($name) {
    $name = trim($name ?? '?');
    if (mb_strlen($name) > 0) return mb_strtoupper(mb_substr($name, 0, 1));
    return '?';
}

// 打卡逻辑
$conn->query("CREATE TABLE IF NOT EXISTS daily_checkin (
    uid INT PRIMARY KEY,
    streak INT DEFAULT 0,
    last_checkin DATE NULL,
    score INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$today = date('Y-m-d');
$checkinData = $conn->query("SELECT * FROM daily_checkin WHERE uid = {$login_uid}")->fetch_assoc();
$streak = $checkinData['streak'] ?? 0;
$lastCheckin = $checkinData['last_checkin'] ?? null;
$score = $checkinData['score'] ?? 0;
$checkedToday = ($lastCheckin === $today);

if (isset($_GET['checkin']) && !$checkedToday) {
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    if ($lastCheckin === $yesterday) {
        $streak += 1;
        $score += 1;
    } elseif ($lastCheckin === null) {
        $streak = 1;
        $score = 1;
    } else {
        $diff = max(1, floor((strtotime($today) - strtotime($lastCheckin)) / 86400));
        $score = $score - pow(2, $diff - 1);
        if ($score < 0) $score = 0;
        $score += 1;
        $streak = 1;
    }
    $conn->query("INSERT INTO daily_checkin (uid, streak, last_checkin, score) VALUES ({$login_uid}, {$streak}, '{$today}', {$score}) ON DUPLICATE KEY UPDATE streak={$streak}, last_checkin='{$today}', score={$score}");
    $conn->query("UPDATE users SET star = star + 1 WHERE uid = {$login_uid}");
    header("Location: https://lmtoj.cn/");
    exit;
}

$checkinData = $conn->query("SELECT * FROM daily_checkin WHERE uid = {$login_uid}")->fetch_assoc();
$checkedToday = ($checkinData['last_checkin'] ?? '') === $today;
$streak = $checkinData['streak'] ?? 0;
$score = $checkinData['score'] ?? 0;

// 运势配置
$fortunePool = [
    '大吉' => ['大运势', '#c62828', 2],
    '小吉' => ['小运势', '#e65100', 2],
    '中平' => ['中运势', '#6b8a74', 1],
    '凶' => ['小运势', '#1565c0', 2],
    '大凶' => ['大运势', '#424242', 2]
];

$smallFortunes = [
    '吉' => [
        ['name' => '拍车', 'desc' => '烂天出好货'],
        ['name' => '打音游', 'desc' => '一次收歌'],
        ['name' => '水犇', 'desc' => '放松身心'],
        ['name' => '外出', 'desc' => '看到美丽的风景'],
        ['name' => '追剧', 'desc' => '充个 VIP 谢谢喵'],
        ['name' => '写文章', 'desc' => '文思泉涌'],
        ['name' => '听音乐', 'desc' => '愉悦身心'],
        ['name' => '打 CF', 'desc' => '叉爆全场'],
        ['name' => '打 AT', 'desc' => '获得金 perf'],
    ],
    '凶' => [
        ['name' => '拍车', 'desc' => '快门一按，行车中断'],
        ['name' => '打音游', 'desc' => '您板子断触'],
        ['name' => '水犇', 'desc' => '激情对线'],
        ['name' => '外出', 'desc' => '磕到甲沟炎'],
        ['name' => '追剧', 'desc' => '充个 VIP 谢谢喵'],
        ['name' => '写文章', 'desc' => '浏览器崩了'],
        ['name' => '听音乐', 'desc' => '突然外放'],
        ['name' => '打 CF', 'desc' => '打到一半睡着了'],
        ['name' => '打 AT', 'desc' => '罚时滞销帮帮我们'],
    ]
];

$ccfContest = [
    '吉' => [
        ['name' => '参加 CSP', 'desc' => 'AK rp+=inf!'],
        ['name' => '考试', 'desc' => '考的全会，骗的全对'],
    ]
];

$seed = crc32($today . $login_uid);
srand($seed);
$bigFortune = ['大吉', '小吉', '中平', '凶', '大凶'][rand(0, 4)];
srand($seed + 1);
$smallCount = $bigFortune === '大吉' ? 2 : ($bigFortune === '大凶' ? 2 : ($bigFortune === '中平' ? 3 : 4));
$goodCount = $bigFortune === '大吉' ? 2 : ($bigFortune === '大凶' ? 0 : ($bigFortune === '中平' ? 2 : 2));
$badCount = $smallCount - $goodCount;

$smallResults = [];
for ($i = 0; $i < $goodCount; $i++) $smallResults[] = ['type' => '吉', 'idx' => $i];
for ($i = 0; $i < $badCount; $i++) $smallResults[] = ['type' => '凶', 'idx' => $goodCount + $i];
shuffle($smallResults);

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>lmtOJ</title>
    <link rel="icon" type="image/png" href="https://lmtoj.cn/logo.png">
    <link rel="preconnect" href="https://cdn.jsdelivr.net">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script defer src="https://cdn.jsdelivr.net/combine/npm/markdown-it@13.0.2/dist/markdown-it.min.js,npm/katex@0.16.9/dist/katex.min.js,npm/texmath@4.11.0/texmath.min.js"></script>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --warm-yellow-bg: #fefcf4;
            --warm-yellow-border: #f0e2b0;
            --warm-yellow-text: #8a7020;
            --danger: #d9534f;
            --danger-hover: #c0392b;
            --tag-admin: #8e44ad;
            --tag-user: #e74c3c;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --shadow-md: 0 4px 16px rgba(0,0,0,0.06);
            --radius: 10px;
            --radius-sm: 6px;
            --radius-xs: 4px;
            --transition: 0.18s ease;
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
            --font-mono: 'JetBrains Mono', 'Cascadia Code', 'Consolas', 'SF Mono', monospace;
        }

        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }

        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);} 50%{box-shadow:0 0 0 6px rgba(245,83,83,0);} }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a {
            color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
            border-radius:20px; transition:var(--transition); font-weight:500;
        }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }

        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .right-sidebar { width:220px; flex-shrink:0; position:sticky; top:80px; }
        .right-card { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); padding:16px; margin-bottom:20px; }
        .right-card h3 { font-size:15px; font-weight:600; margin-bottom:16px; color:var(--text); }
        .recommend-item { display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--border-light); }
        .recommend-item:last-child { border-bottom:none; }
        .recommend-item:hover { background:#fafaf8; }
        .rec-avatar { width:36px; height:36px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:600; overflow:hidden; flex-shrink:0; }
        .rec-avatar img { width:100%; height:100%; object-fit:cover; }
        .rec-name { font-size:14px; font-weight:500; color:var(--text); text-decoration:none; }
        .rec-name:hover { text-decoration:underline; color:var(--accent); }
        .rec-tags { font-size:11px; color:var(--text-muted); margin-top:2px; }
        
        .d-avatar { width:60px; height:60px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:700; overflow:hidden; flex-shrink:0; }
        .d-avatar img { width:100%; height:100%; object-fit:cover; }

        .welcome-box {
            background:var(--warm-yellow-bg); border:1px solid var(--warm-yellow-border);
            border-radius:var(--radius); padding:15px 20px; margin-bottom:18px;
            color:var(--warm-yellow-text); font-size:14.5px; font-weight:500; box-shadow:var(--shadow-sm);
        }
        .announce-box {
            background:#fafaf8; border:1px solid #d8d4cc; border-radius:var(--radius);
            padding:16px 20px; margin-bottom:18px; color:#4a4540; box-shadow:var(--shadow-sm); line-height:1.7;
        }

        /* ===== 卡片自适应 ===== */
        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            padding: 26px 28px;
            margin-bottom: 18px;
            box-shadow: var(--shadow);
            overflow: hidden;
        }
        .card h2 { font-size:18px; font-weight:600; margin-bottom:16px; }

        .ben-input {
            width:100%; height:100px; padding:13px 16px; border:1.5px solid var(--border);
            border-radius:var(--radius-sm); margin-bottom:12px; font-size:14px; resize:none;
            outline:none; font-family:var(--font); background:#fdfdfc; transition:var(--transition);
        }
        .ben-input:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        .btn {
            padding:9px 20px; background:var(--accent); color:#fff; border:none; border-radius:20px;
            cursor:pointer; font-size:14px; font-weight:500; transition:var(--transition);
        }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); }
        .btn:disabled { background:#bfbab0; cursor:not-allowed; }
        .tip { color:var(--danger); margin:10px 0; font-size:14px; }

        .ben-item { display:flex; gap:14px; padding:15px 0; border-bottom:1px solid var(--border-light); align-items:flex-start; }
        .ben-item:last-child { border-bottom:none; }
        .ben-avatar { width:44px; height:44px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:700; overflow:hidden; flex-shrink:0; }
        .ben-avatar img { width:100%; height:100%; object-fit:cover; }
        .ben-body { flex:1; min-width:0; }
        .ben-name { font-weight:600; text-decoration:none; font-size:14px; }
        .ben-name:hover { opacity:0.8; text-decoration:underline; }
        .ben-time { font-size:12px; color:var(--text-muted); margin-left:8px; }
        .ben-op { font-size:12px; color:var(--accent); margin-left:10px; cursor:pointer; text-decoration:none; font-weight:500; }
        .ben-op:hover { color:var(--accent-hover); }
        .ben-del { color:var(--danger)!important; }
        .ben-content { word-break:break-word; margin-top:7px; line-height:1.7; font-size:14px; color:#3a3733; }
        .tag { border-radius:3px; padding:2px 9px; color:#fff; display:inline-block; margin:2px 5px; font-size:11.5px; font-weight:600; }

        .page-box { margin-top:20px; padding-top:14px; border-top:1px solid var(--border-light); display:flex; gap:6px; flex-wrap:wrap; }
        .page-box a {
            padding:6px 13px; border:1.5px solid var(--border); border-radius:20px;
            text-decoration:none; color:var(--text); font-size:13.5px; font-weight:500; background:#fff; transition:var(--transition);
        }
        .page-box a:hover { border-color:var(--accent); color:var(--accent); background:var(--accent-light); }
        .page-box a.active-page { background:var(--accent); color:#fff; border-color:var(--accent); font-weight:600; }
        .page-ellipsis { padding:6px 4px; color:var(--text-muted); font-size:13px; }

        .ben-content h1,.ben-content h2,.ben-content h3 { margin:8px 0 6px; font-weight:600; }
        .ben-content blockquote { border-left:4px solid var(--accent); padding:8px 14px; margin:8px 0; background:#fafaf8; color:#5a5550; border-radius:0 var(--radius-xs) var(--radius-xs) 0; }
        .ben-content pre { background:#2b2a27; color:#e8e4dd; padding:14px 16px; border-radius:var(--radius-sm); overflow-x:auto; margin:8px 0; font-family:var(--font-mono); font-size:13px; }
        .ben-content code { font-family:var(--font-mono); background:#f3f0eb; padding:2px 6px; border-radius:3px; }
        .ben-content pre code { background:transparent; padding:0; color:inherit; }
        .ben-content .katex { font-size:1.08em!important; }
        .ben-content img { max-width:100%; border-radius:var(--radius-xs); margin:8px 0; }
        a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
        a:hover { color:var(--accent-hover); text-decoration:underline; }
        .ben-content a { color:var(--accent); border-bottom:1px solid transparent; }
        .ben-content a:hover { border-bottom-color:var(--accent-hover); text-decoration:none; }
        .at-link { color:var(--accent)!important; }

        .unbind-warning {
            background:#fce4ec; border:1px solid #ef9a9a; border-radius:var(--radius);
            padding:14px 18px; margin-bottom:18px; display:flex; align-items:center; gap:10px;
            color:#c62828; font-size:14px; font-weight:500;
        }
        .unbind-warning a { color:#c62828; font-weight:700; text-decoration:underline; }

        .translate-btn {
            font-size:12px; color:var(--accent); cursor:pointer; margin-left:10px; user-select:none; text-decoration:none;
        }
        .translate-btn:hover { text-decoration:underline; }
        .translation-box {
            margin-top:8px; padding:8px 12px; background:#f3f7f3; border-left:3px solid var(--accent);
            border-radius:4px; font-size:13px; color:#4a4a4a; display:none; line-height:1.6;
        }

        /* 树洞样式 */
        .treehole-item { padding:12px 0; border-bottom:1px solid var(--border-light); }
        .treehole-item:last-child { border-bottom:none; }
        .treehole-meta { font-size:12px; color:var(--text-muted); margin-top:4px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
        .treehole-content { font-size:14px; line-height:1.7; }
        .treehole-actions { margin-top:6px; }
        .treehole-actions a { font-size:12px; margin-right:8px; }

        .echo-box {
            background:#f0f7ff; border:1px solid #bbd9ff; border-radius:var(--radius-sm);
            padding:14px 18px; margin-top:12px; color:#1a3a6a;
        }
        .echo-box .echo-content { font-size:14px; line-height:1.7; }
        .echo-box .echo-source { font-size:13px; margin-top:6px; color:var(--text-secondary); }

        /* 彩色名样式 */
        .ben-name.colorful {
            color: #f1948a;
            animation: colorful 3s linear infinite;
            text-shadow: 0 0 10px rgba(0,0,0,0.2);
        }
        @keyframes colorful {
            0% { color: #f1948a; }
            17% { color: #f5b041; }
            33% { color: #f7dc6f; }
            50% { color: #82e0aa; }
            67% { color: #85c1e9; }
            83% { color: #bb8fce; }
            100% { color: #f1948a; }
        }
        .tag.colorful-bg {
            animation: colorfulBg 3s linear infinite;
        }
        @keyframes colorfulBg {
            0% { background-color: #f1948a; }
            17% { background-color: #f5b041; }
            33% { background-color: #f7dc6f; }
            50% { background-color: #82e0aa; }
            67% { background-color: #85c1e9; }
            83% { background-color: #bb8fce; }
            100% { background-color: #f1948a; }
        }

        .token-display {
            background: var(--accent-light);
            border-radius: var(--radius-sm);
            padding: 6px 14px;
            font-weight: 600;
            color: var(--accent);
            display: inline-block;
            font-size: 14px;
        }

        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
            .sidebar { width:100%; position:static; display:flex; flex-wrap:wrap; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .navbar { padding:0 14px; height:48px; }
            .card { padding:18px 14px; }
            .right-sidebar { width:100%; position:static; }
        }
    </style>
</head>
<body>

<?php include 'navbar.php';//页首 ?>

<div class="main">
    <script src="/js/markdown-it.min.js"></script>
    <script src="/js/katex.min.js"></script>
    <script src="/js/texmath.min.js"></script>

    <script>
    const md = window.markdownit({});
    md.use(
        window.texmath.use(window.katex),
        {
            engine: window.katex,
            delimiters: 'dollars',
            katexOptions: { macros: { "\RR": "\mathbb{R}" } }
        }
    );
    function inject_md(id, content) {
        if (content !== null) {
            const html = md.render(content);
            document.getElementById(id).innerHTML = html;
        }
    }
    </script>

    <?php include 'sidebar.php';//侧边栏 ?>

    <div class="content">
        <div class="welcome-box">
            欢迎回来，<?=safeContent($login_name)?>
            <?php if($is_bound): ?>
                <a style="font-size:12px" href="https://lmtoj.cn/bind">（<?=$bind_info['bind_type']=='luogu'?'洛谷':'邮箱'?>绑定）</a>
            <?php endif; ?>
            <span class="token-display">🪙 <?=$userToken?></span>
        </div>

        <?php if(!$is_bound): ?>
        <div class="unbind-warning">
            您尚未绑定洛谷账号，账号若长期不使用可能被清理。
            <a href="https://lmtoj.cn/bind">立即绑定 →</a>
        </div>
        <?php endif; ?>
        
        <!-- ===== 公告框（可编辑） ===== -->
        <div class="announce-box">
            <strong style="color:#5a5044;">📢 公告</strong>
            <p style="margin:8px 0 0 0; line-height:1.7;">
                <?=nl2br(safeContent($announcement))?>
            </p>
            <?php if($is_admin): ?>
                <div style="margin-top:8px;">
                    <button onclick="toggleAnnounceEdit()" class="btn btn-sm" style="padding:4px 12px;font-size:12px;">编辑公告</button>
                    <div id="announceEditForm" style="display:none;margin-top:8px;">
                        <form method="post">
                            <textarea name="announcement_content" rows="3" style="width:100%;padding:8px;border:1px solid var(--border);border-radius:4px;font-family:inherit;"><?=safeContent($announcement)?></textarea>
                            <button type="submit" name="update_announcement" class="btn btn-sm" style="margin-top:4px;">保存公告</button>
                        </form>
                    </div>
                </div>
                <script>
                    function toggleAnnounceEdit() {
                        var form = document.getElementById('announceEditForm');
                        form.style.display = form.style.display === 'none' ? 'block' : 'none';
                    }
                </script>
            <?php endif; ?>
        </div>

<!-- ===== 最近讨论（带颜色） ===== -->
<div class="card">
    <h2>最近讨论</h2>
    <?php if($is_admin): ?>
         <a href="https://lmtoj.cn/discuss/pin" style="font-size:15px;color:#6b8a74;text-decoration:none;font-weight:500;">置顶管理</a>
    <?php endif; ?>
    <a href="https://lmtoj.cn/discuss/cate/02" style="font-size:15px;color:#6b8a74;text-decoration:none;font-weight:500;">查看更多 →</a>
    <div style="margin-top:20px;">
        <?php
        // ========== 直接查询，不缓存 ==========
        $latestDiscussions = $conn->query("
            SELECT d.id, d.title, d.create_time, d.category, d.zhiding, d.uid,
                   u.name, u.avatar, u.tag, u.admin,
                   u.practice_score, u.contribute_score, u.contest_score,
                   u.base_credit, u.valuation, u.username_color,
                   u.cert_type, u.cert_level
            FROM discuss d 
            LEFT JOIN users u ON d.uid = u.uid 
            WHERE d.category IN (1, 2)
            ORDER BY d.zhiding DESC, d.create_time DESC 
            LIMIT 10
        ");
        while($ld = $latestDiscussions->fetch_assoc()):
            $dAvatar = $ld['avatar'] ?? '';
            $colorInfo = getUserColor($ld, $login_uid, $myShowColorful);
        ?>
        <div class="ben-item">
            <div class="d-avatar">
                <?php if($dAvatar): ?>
                    <img src="<?=safeContent($dAvatar)?>" alt="" width="48" height="48">
                <?php else: ?>
                    <?=getFirstChar($ld['name'])?>
                <?php endif; ?>
            </div>
            <div class="ben-body">
                <div>
                    <h3 style="font-size:14px;color:#1e2a3a;font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;"><a href="https://lmtoj.cn/discuss/<?=$ld['id']?>"><?=safeContent($ld['title'])?></a></h3>
                    <div style="display:flex;align-items:center;flex-wrap:wrap;gap:4px;margin-top:2px;">
                        <a href="https://lmtoj.cn/user/<?=$ld['uid']?>" class="ben-name" target="_blank" style="color:<?=$colorInfo['color']?>;<?=$colorInfo['isColorful']?'animation: colorful 3s linear infinite;':''?>font-size:12px;"><?=safeContent($ld['name'])?></a>
                        <?php if($ld['tag']!=""):?><span class="tag" style="background-color:<?=$colorInfo['color']?>;<?=$colorInfo['isColorful']?'animation: colorfulBg 3s linear infinite;':''?>font-size:10px;padding:1px 6px;"><?=safeContent($ld['tag'])?></span><?php endif ?>
                        <a href="https://lmtoj.cn/discuss/cate/0<?=$ld['category']?>" style="font-size:11px;color:var(--text-muted);">In <?=$ld['category']==1?'站务版':'学术版'?></a>
                        <span class="ben-time" style="font-size:11px;margin-left:0;"><?=date("m-d H:i",strtotime($ld['create_time']))?></span>
                        <?php if($ld['zhiding']): ?><span style="background:#fce4ec;color:#c62828;padding:1px 6px;border-radius:3px;font-size:10px;font-weight:600;">置顶</span><?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

        <!-- ===== 树洞（默认收起，点击加载） ===== -->
        <div class="card" id="treehole-card">
            <h2>🌳 树洞</h2>
            <?php
            if (isset($_SESSION['echo_result'])) {
                $echo = $_SESSION['echo_result'];
                // 回声时间已在前端加过，这里不需要再加，但为了统一我们后端再加一次
                $echo_time = date('Y-m-d H:i', strtotime($echo['time'])-15*3600);
                echo '<div class="echo-box">';
                echo '<div class="echo-content">' . safeContent($echo['content']) . '</div>';
                echo '<div class="echo-source">— ' . ($echo['isColorful'] ? '<span class="ben-name colorful" style="font-weight:600;">' : '<span style="color:' . $echo['color'] . ';font-weight:600;">') . safeContent($echo['displayName']) . '</span> · ' . $echo_time . '</div>';
                echo '</div>';
                unset($_SESSION['echo_result']);
            }
            ?>
            <div style="display:flex; gap:10px; margin-bottom:12px;">
                <a href="?echo=1" class="btn btn-sm" style="background:#4a90d9;">🔊 回声（消耗1Token）</a>
            </div>
            <form method="post" style="margin-bottom:16px;">
                <textarea name="content" class="ben-input" style="height:80px;" placeholder="写一条树洞…" required></textarea>
                <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
                    <label><input type="checkbox" name="anonymous" value="1"> 匿名发送</label>
                    <button type="submit" name="post_treehole" class="btn btn-sm">发布树洞（消耗1Token）</button>
                </div>
            </form>

            <?php if ($is_sqadmin): ?>
            <!-- 管理员添加树洞（免费，仅自己） -->
            <div style="margin:16px 0; padding:12px; background:var(--accent-light); border-radius:var(--radius-sm);">
                <h4 style="font-size:14px; margin-bottom:8px;">管理员添加树洞（免费）</h4>
                <form method="post">
                    <div style="display:flex; gap:8px; flex-wrap:wrap;">
                        <input type="text" name="content" placeholder="树洞内容" required style="flex:1; padding:6px 10px; border:1px solid var(--border); border-radius:4px;">
                        <label style="display:flex; align-items:center; gap:4px;"><input type="checkbox" name="anonymous" value="1"> 匿名</label>
                        <button type="submit" name="admin_add_treehole" class="btn btn-sm">添加（免费）</button>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <!-- 树洞列表区域 -->
            <h3 style="font-size:15px; font-weight:600; margin:16px 0 8px;">我的树洞</h3>
            <div id="treehole-list-container">
                <!-- 初始显示：加载按钮 -->
                <div id="treehole-load-btn-wrap" style="text-align:center; padding:20px;">
                    <button id="load-treehole-btn" class="btn">展开树洞</button>
                </div>
                <div id="treehole-content-wrap" style="display:none;">
                    <div id="treehole-list"></div>
                    <div id="treehole-pagination"></div>
                </div>
            </div>
        </div>
        <?php if(env('SHOW_ADS', 0)):
        include 'ads.php';
        endif;//页首 ?>
    </div>

    <div class="right-sidebar">
        <!-- 运势 -->
        <div class="right-card" style="text-align:center;">
            <h3 style="margin-bottom:12px;">今日运势</h3>
            <?php if ($checkedToday): ?>
                <div style="font-size:42px;font-weight:800;color:<?=$fortunePool[$bigFortune][1]?>;margin:8px 0;"><?=$bigFortune?></div>
                <div style="display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin:10px 0;">
                    <?php foreach ($smallResults as $sr): 
                        $isGood = $sr['type'] === '吉';
                        $item = $smallFortunes[$sr['type']][$sr['idx']];
                    ?>
                        <div style="background:<?=$isGood?'#e8f5e9':'#fce4ec'?>;padding:6px 12px;border-radius:12px;font-size:12px;text-align:center;width:150px;">
                            <div style="font-weight:600;color:<?=$isGood?'#2e7d32':'#c62828'?>;"><?=$isGood?'宜':'忌'?> <?=safeContent($item['name'])?></div>
                            <div style="color:var(--text-muted);font-size:11px;"><?=safeContent($item['desc'])?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div style="font-size:12px;color:var(--text-muted);">你已经在 lmtoj 打卡了 <strong><?=$score?></strong> 天</div>
            <?php else: ?>
                <a href="?checkin=1" style="display:inline-block;padding:10px 28px;background:var(--accent);color:#fff;border-radius:20px;text-decoration:none;font-size:14px;font-weight:500;">打卡</a>
            <?php endif; ?>
        </div>

        <!-- 我的 Token -->
        <div class="right-card">
            <h3>我的 Token</h3>
            <div style="font-size:24px; font-weight:700; text-align:center; color:var(--accent);">🪙 <?=$userToken?></div>
            <p style="font-size:12px; color:var(--text-muted); text-align:center; margin-top:6px;">发布树洞或使用回声消耗 1 Token</p>
        </div>
    </div>
</div>

<script>
var nameToUid = <?= json_encode($nameToUid, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
var login_uid = <?= json_encode($login_uid) ?>;

function processUrl(url) {
    if (!url) return '';
    url = url.trim();
    if (/^(javascript|data|vbscript|file):/i.test(url)) return '';
    if (/^https?:\/\//i.test(url)) return url;
    if (/^\/\//.test(url)) return 'https:' + url;
    if (/^\//.test(url)) return 'https://lmtoj.cn' + url;
    return 'https://lmtoj.cn/' + url;
}

function renderContent() {
    var items = document.querySelectorAll('.ben-content');
    for (var i = 0; i < items.length; i++) {
        (function(el) {
            var raw = el.innerHTML || '';
            if (!raw) return;

            raw = raw.replace(/@([\w_\u4e00-\u9fa5]+)/g, function(m, user) {
                if (nameToUid[user]) return '<a class="at-link" href="https://lmtoj.cn/user/'+nameToUid[user]+'" target="_blank">'+m+'</a>';
                return m;
            });
            
            el.innerHTML = raw;
        })(items[i]);
    }
}

// ========== 树洞异步加载 ==========
document.addEventListener('DOMContentLoaded', function() {
    var loadBtn = document.getElementById('load-treehole-btn');
    var loadWrap = document.getElementById('treehole-load-btn-wrap');
    var contentWrap = document.getElementById('treehole-content-wrap');
    var list = document.getElementById('treehole-list');
    var pagination = document.getElementById('treehole-pagination');

    function loadTreehole(page) {
        if (!page) page = 1;
        list.innerHTML = '<p style="color:var(--text-muted);">加载中...</p>';
        pagination.innerHTML = '';
        fetch('?ajax_treehole=1&th_page=' + page)
            .then(response => response.json())
            .then(data => {
                if (data.items.length === 0) {
                    list.innerHTML = '<p style="color:var(--text-muted);">还没有树洞，快来写下第一条吧！</p>';
                } else {
                    var html = '';
                    data.items.forEach(function(item) {
                        var colorStyle = item.isColorful ? 'animation: colorful 3s linear infinite;' : '';
                        var isAuthor = (item.uid == login_uid);
                        var canManage = isAuthor || item.is_sqadmin;
                        html += '<div class="treehole-item">';
                        html += '<div class="treehole-content">' + escapeHtml(item.content) + '</div>';
                        html += '<div class="treehole-meta">';
                        html += '<span style="color:' + item.color + ';' + colorStyle + 'font-weight:600;">' + escapeHtml(item.displayName) + '</span>';
                        html += ' · ' + formatDate(item.created_at);
                        if (canManage) {
                            html += ' <a href="#" class="treehole-del" data-id="' + item.id + '" style="color:#d9534f;font-size:12px;">删除</a>';
                            html += ' <a href="#" class="treehole-edit-toggle" data-id="' + item.id + '" style="font-size:12px;">编辑</a>';
                        }
                        html += '</div>';
                        if (canManage) {
                            html += '<div id="edit_th_' + item.id + '" style="display:none; margin-top:8px;">';
                            html += '<form class="treehole-edit-form" data-id="' + item.id + '" style="display:flex; gap:8px; flex-wrap:wrap;">';
                            html += '<input type="text" name="content" value="' + escapeHtml(item.content) + '" required style="flex:1; padding:6px 10px; border:1px solid var(--border); border-radius:4px;">';
                            html += '<label style="display:flex; align-items:center; gap:4px;"><input type="checkbox" name="anonymous" value="1"' + (item.anonymous ? ' checked' : '') + '> 匿名</label>';
                            html += '<button type="submit" class="btn btn-sm">保存</button>';
                            html += '</form>';
                            html += '</div>';
                        }
                        html += '</div>';
                    });
                    list.innerHTML = html;
                }
                // 分页
                if (data.totalPage > 1) {
                    var phtml = '<div class="page-box">';
                    if (data.currentPage > 1) {
                        phtml += '<a href="#" class="th-page-link" data-page="' + (data.currentPage-1) + '">上一页</a>';
                    }
                    var shown = [1];
                    for (var i = Math.max(2, data.currentPage-2); i <= Math.min(data.totalPage-1, data.currentPage+2); i++) shown.push(i);
                    if (data.totalPage > 1) shown.push(data.totalPage);
                    shown = Array.from(new Set(shown)).sort((a,b)=>a-b);
                    var prev = 0;
                    shown.forEach(function(p) {
                        if (p - prev > 1) phtml += '<span class="page-ellipsis">...</span>';
                        phtml += '<a href="#" class="th-page-link' + (p === data.currentPage ? ' active-page' : '') + '" data-page="' + p + '">' + p + '</a>';
                        prev = p;
                    });
                    if (data.currentPage < data.totalPage) {
                        phtml += '<a href="#" class="th-page-link" data-page="' + (data.currentPage+1) + '">下一页</a>';
                    }
                    phtml += '</div>';
                    pagination.innerHTML = phtml;
                } else {
                    pagination.innerHTML = '';
                }
                // 显示内容，隐藏加载按钮
                loadWrap.style.display = 'none';
                contentWrap.style.display = 'block';
            })
            .catch(err => {
                list.innerHTML = '<p style="color:var(--danger);">加载失败，请重试。</p>';
                console.error(err);
            });
    }

    // 点击加载按钮
    if (loadBtn) {
        loadBtn.addEventListener('click', function() {
            loadTreehole(1);
        });
    }

    // ========== 事件监听：分页、删除、编辑切换（click） ==========
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('th-page-link')) {
            e.preventDefault();
            var page = e.target.dataset.page;
            loadTreehole(page);
        }

        // 删除（POST）
        if (e.target.classList.contains('treehole-del')) {
            e.preventDefault();
            if (confirm('确定删除？')) {
                var id = e.target.dataset.id;
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                    body: 'del_treehole=' + id
                })
                .then(response => {
                    if (!response.ok) throw new Error('HTTP ' + response.status);
                    return response.text();
                })
                .then(text => {
                    try {
                        var data = JSON.parse(text);
                        if (data.success) loadTreehole(1);
                        else alert('删除失败：' + (data.msg || '未知错误'));
                    } catch (e) {
                        alert('服务器返回非 JSON 数据，请检查权限。\n返回内容开头：' + text.substring(0, 100));
                        console.error('返回内容:', text);
                    }
                })
                .catch(err => {
                    alert('请求异常，请查看控制台日志');
                    console.error('删除错误:', err);
                });
            }
        }

        // 编辑切换
        if (e.target.classList.contains('treehole-edit-toggle')) {
            e.preventDefault();
            var id = e.target.dataset.id;
            var editDiv = document.getElementById('edit_th_' + id);
            if (editDiv) {
                editDiv.style.display = (editDiv.style.display === 'none') ? 'block' : 'none';
            }
        }
    });

    // ★★★ 新增：监听编辑表单的 submit 事件（拦截回车和点击） ★★★
    document.addEventListener('submit', function(e) {
        var form = e.target.closest('.treehole-edit-form');
        if (form) {
            e.preventDefault();  // 阻止页面刷新
            var id = form.dataset.id;
            var content = form.querySelector('input[name="content"]').value;
            var anonymous = form.querySelector('input[name="anonymous"]').checked ? 1 : 0;
            fetch(window.location.href, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: 'edit_treehole=1&id=' + id + '&content=' + encodeURIComponent(content) + '&anonymous=' + anonymous
            })
            .then(response => {
                if (!response.ok) throw new Error('HTTP ' + response.status);
                return response.text();
            })
            .then(text => {
                try {
                    var data = JSON.parse(text);
                    if (data.success) loadTreehole(1);
                    else alert('编辑失败：' + (data.msg || '未知错误'));
                } catch (e) {
                    alert('服务器返回非 JSON 数据，请检查权限。\n返回内容开头：' + text.substring(0, 100));
                    console.error('返回内容:', text);
                }
            })
            .catch(err => {
                alert('请求异常，请查看控制台日志');
                console.error('编辑错误:', err);
            });
        }
    });

    // 辅助函数
    function escapeHtml(text) {
        var div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    function formatDate(iso) {
        // 已经由后端修正，直接显示
        if (!iso) return '';
        return iso.replace('T', ' ').slice(0, 16);
    }
});

function init() { renderContent(); setTimeout(renderContent, 200); }
window.addEventListener('DOMContentLoaded', init);
window.addEventListener('load', renderContent);
</script>
<?php require_once __DIR__ . '/event_effect.php'; ?>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>