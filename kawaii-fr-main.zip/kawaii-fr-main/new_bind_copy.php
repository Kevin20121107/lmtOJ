<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 登录检查 ----------
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$login_uid = (int)$_SESSION['uid'];

// ---------- 创建绑定申请表 ----------
$conn->query("CREATE TABLE IF NOT EXISTS bind_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    luogu_uid VARCHAR(20) NOT NULL,
    verify_code VARCHAR(50) NOT NULL,
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    handled_at TIMESTAMP NULL,
    handler_uid INT NULL,
    handler_reason TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 获取当前用户信息 ----------
$userInfo = $conn->query("SELECT uid, name, sqadmin, admin FROM users WHERE uid = $login_uid")->fetch_assoc();
if (!$userInfo) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
$is_admin = (int)($userInfo['admin'] ?? 0);
$is_sqadmin = (int)($userInfo['sqadmin'] ?? 0);
$can_manage = $is_admin || $is_sqadmin;

// ---------- 获取所有 sqadmin 管理员 ----------
$admins = $conn->query("SELECT uid FROM users WHERE sqadmin = 1");

// ---------- 管理员处理逻辑 ----------
if (isset($_GET['action']) && $_GET['action'] === 'handle' && isset($_GET['id']) && $can_manage) {
    $request_id = (int)$_GET['id'];
    $req = $conn->query("
        SELECT r.*, u.name as applicant_name 
        FROM bind_requests r 
        LEFT JOIN users u ON r.uid = u.uid 
        WHERE r.id = $request_id
    ");
    if ($req->num_rows == 0) {
        die("申请不存在");
    }
    $reqData = $req->fetch_assoc();

    // 处理提交
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['handle_bind'])) {
        $action = $_POST['action'] ?? '';
        $reason = trim($_POST['reason'] ?? '');
        if (!in_array($action, ['approve', 'reject'])) {
            $error = "无效操作";
        } else {
            $now = date('Y-m-d H:i:s');
            $status = ($action === 'approve') ? 'approved' : 'rejected';
            $updStmt = $conn->prepare("UPDATE bind_requests SET status = ?, handled_at = ?, handler_uid = ?, handler_reason = ? WHERE id = ?");
            $updStmt->bind_param("siisi", $status, $now, $login_uid, $reason, $request_id);
            $updStmt->execute();
            $updStmt->close();

            // 通知申请人
            $topic = ($action === 'approve') ? '绑定申请已批准' : '绑定申请已拒绝';
            $content_type = ($action === 'approve') ? 'bind_approved' : 'bind_rejected';
            $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, ?, ?, 0)");
            $nIns->bind_param("iiisss", $reqData['uid'], $login_uid, $request_id, $topic, $content_type, $now);
            $nIns->execute();
            $nIns->close();

            $msg = "处理完成！";
            header("Location: https://lmtoj.cn/");
            exit;
        }
    }

    // 显示处理界面
    ?>
    <!DOCTYPE html>
    <html>
    <head><title>处理绑定申请</title>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e;
            --danger: #d9534f; --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);padding:20px;}
        .container{max-width:700px;margin:0 auto;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:28px 32px;box-shadow:var(--shadow);margin-bottom:20px;}
        .btn{padding:9px 22px;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:0.18s ease;display:inline-block;text-decoration:none;}
        .btn-success{background:#2e7d32;color:#fff;}
        .btn-success:hover{background:#1b5e20;}
        .btn-danger{background:var(--danger);color:#fff;}
        .btn-danger:hover{background:#c0392b;}
        .btn-sm{padding:5px 14px;font-size:13px;}
        .alert{padding:14px 18px;border-radius:var(--radius-sm);margin-bottom:16px;}
        .alert-success{background:#e8f5e9;color:#2e7d32;border:1px solid #a5d6a7;}
        .alert-error{background:#fce4ec;color:#c62828;border:1px solid #ef9a9a;}
        .form-group{margin-bottom:16px;}
        .form-group label{display:block;font-weight:500;color:var(--text-secondary);margin-bottom:4px;font-size:13px;}
        textarea{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;resize:vertical;min-height:80px;font-family:var(--font);}
        .back-link{color:var(--accent);text-decoration:none;font-weight:500;}
        .back-link:hover{text-decoration:underline;}
        .mt-16{margin-top:16px;}
        .flex-gap{display:flex;gap:10px;flex-wrap:wrap;}
    </style>
    </head>
    <body>
    <div class="container">
        <div class="card">
            <h2>处理绑定申请</h2>
            <?php if (isset($_GET['msg'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div>
            <?php endif; ?>
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <p><strong>申请人：</strong><?= htmlspecialchars($reqData['applicant_name']) ?> (UID: <?= $reqData['uid'] ?>)</p>
            <p><strong>洛谷 UID：</strong><?= htmlspecialchars($reqData['luogu_uid']) ?></p>
            <p><strong>验证码：</strong><?= htmlspecialchars($reqData['verify_code']) ?></p>
            <p><strong>申请时间：</strong><?= date('Y-m-d H:i', strtotime($reqData['created_at'])) ?></p>
            <p><strong>当前状态：</strong>
                <?php if ($reqData['status'] === 'pending'): ?>
                    <span style="color:#e65100;">待处理</span>
                <?php elseif ($reqData['status'] === 'approved'): ?>
                    <span style="color:#2e7d32;">已通过</span>
                <?php else: ?>
                    <span style="color:#c62828;">已拒绝</span>
                <?php endif; ?>
            </p>

            <?php if ($reqData['status'] === 'pending'): ?>
                <form method="post" class="mt-16">
                    <input type="hidden" name="handle_bind" value="1">
                    <div class="form-group">
                        <label for="reason">处理备注（可选）</label>
                        <textarea name="reason" id="reason" placeholder="填写处理意见..."></textarea>
                    </div>
                    <div class="flex-gap">
                        <button type="submit" name="action" value="approve" class="btn btn-success">批准</button>
                        <button type="submit" name="action" value="reject" class="btn btn-danger">拒绝</button>
                        <a href="https://lmtoj.cn/bind" class="btn" style="background:var(--text-muted);color:#fff;">返回</a>
                    </div>
                </form>
            <?php else: ?>
                <p style="color:var(--text-secondary);">该申请已处理，无需再次操作。</p>
                <div class="mt-16"><a href="https://lmtoj.cn/bind" class="back-link">← 返回</a></div>
            <?php endif; ?>
        </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}

// ---------- 处理提交 ----------
$error = '';
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_bind'])) {
    $luogu_uid = trim($_POST['luogu_uid'] ?? '');
    $verify_code = trim($_POST['verify_code'] ?? '');

    if (empty($luogu_uid) || !ctype_digit($luogu_uid)) {
        $error = "洛谷 UID 必须为数字且不能为空。";
    } elseif (empty($verify_code)) {
        $error = "验证码不能为空。";
    } else {
        // 检查今天是否已提交过
        $today = date('Y-m-d');
        $existing = $conn->query("SELECT id FROM bind_requests WHERE uid = $login_uid AND DATE(created_at) = '$today'")->num_rows;
        if ($existing > 0) {
            $error = "您今天已提交过绑定申请，请明天再试。";
        } else {
            // 插入申请
            $stmt = $conn->prepare("INSERT INTO bind_requests (uid, luogu_uid, verify_code) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $login_uid, $luogu_uid, $verify_code);
            $stmt->execute();
            $insert_id = $stmt->insert_id;
            $stmt->close();

            // 向所有 sqadmin 发送通知，tid 存储申请 ID 以便跳转
            $now = date('Y-m-d H:i:s');
            $content_type = 'bind_request';
            $atid = $login_uid;
            $tid = $insert_id; // 存储申请 ID
            $topic_title = '洛谷绑定申请';

            while ($admin = $admins->fetch_assoc()) {
                $admin_uid = $admin['uid'];
                if ($admin_uid == $login_uid) continue;
                $nIns = $conn->prepare("INSERT INTO notice (uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, ?, ?, 0)");
                $nIns->bind_param("iiisss", $admin_uid, $atid, $tid, $topic_title, $content_type, $now);
                $nIns->execute();
                $nIns->close();
            }

            $success = "绑定申请已提交，管理员将尽快处理。";
        }
    }
}

// ---------- 查询用户最近的申请状态 ----------
$requestStatus = null;
$req = $conn->query("SELECT * FROM bind_requests WHERE uid = $login_uid ORDER BY id DESC LIMIT 1")->fetch_assoc();
if ($req) {
    $requestStatus = $req;
}

// 未读消息数（导航栏用）
$unreadCount = 0;
$msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
function formatTime($ts) {
    return date('Y-m-d H:i', strtotime($ts));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>绑定洛谷账号 - lmtOJ</title>
    <style>
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --text: #2c2a28;
            --text-secondary: #7a736b;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --border-light: #f0ece6;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --accent-light: #eef4ef;
            --danger: #d9534f;
            --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei',system-ui,sans-serif;
        }
        *{margin:0;padding:0;box-sizing:border-box;}
        body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
        .navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
        .navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
        .bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
        .bell-wrap:hover{background:rgba(255,255,255,0.08);}
        .red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
        @keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
        .user-info{display:flex;align-items:center;gap:6px;}
        .user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
        .user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
        .user-info a.admin-link{color:#f5d76e;font-weight:600;}
        .container{max-width:700px;margin:32px auto 48px;padding:0 20px;}
        .card{background:var(--card-bg);border-radius:var(--radius);padding:28px 32px;box-shadow:var(--shadow);margin-bottom:20px;}
        .card h2{font-size:20px;font-weight:600;margin-bottom:16px;}
        .card h3{font-size:17px;font-weight:600;margin-bottom:14px;}
        .alert{background:#fce4ec;border:1px solid #ef9a9a;color:#c62828;padding:14px 18px;border-radius:var(--radius-sm);margin-bottom:16px;font-weight:500;}
        .alert-success{background:#e8f5e9;border-color:#a5d6a7;color:#2e7d32;}
        .alert-info{background:#e3f2fd;border-color:#90caf9;color:#0d47a1;}
        .btn{padding:9px 22px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);font-family:var(--font);display:inline-block;text-decoration:none;}
        .btn:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);}
        .btn-block{width:100%;justify-content:center;}
        .form-group{margin-bottom:16px;}
        .form-group label{display:block;font-weight:500;color:var(--text-secondary);margin-bottom:4px;font-size:13px;}
        input[type="text"], input[type="number"]{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;background:#fdfdfc;transition:var(--transition);}
        input:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
        .text-muted{color:var(--text-muted);font-size:13px;margin-top:4px;}
        .status-tag{display:inline-block;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600;}
        .tag-pending{background:#fff3e0;color:#e65100;}
        .tag-approved{background:#c8e6c9;color:#2e7d32;}
        .tag-rejected{background:#ffcdd2;color:#c62828;}
        .back-link{display:inline-block;margin-top:12px;color:var(--accent);text-decoration:none;font-weight:500;}
        .back-link:hover{text-decoration:underline;}
        @media(max-width:768px){.container{padding:0 12px;margin:20px auto;}.card{padding:18px 14px;}}
    </style>
</head>
<body>
<?php include 'navbar.php'; // 页首导航 ?>

<div class="container">
    <div class="card">
        <h2>🔗 绑定洛谷账号</h2>
        <p style="color:var(--text-secondary);margin-bottom:16px;">提交您的洛谷账号信息，管理员将审核并为您绑定。</p>

        <?php if ($error): ?>
            <div class="alert"><?= safeContent($error) ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success"><?= safeContent($success) ?></div>
        <?php endif; ?>

        <?php if ($requestStatus && $requestStatus['status'] === 'pending'): ?>
            <div class="alert alert-info">
                ⏳ 您已提交过绑定申请，正在等待管理员审核。<br>
                提交时间：<?= formatTime($requestStatus['created_at']) ?>
            </div>
        <?php elseif ($requestStatus && $requestStatus['status'] === 'approved'): ?>
            <div class="alert alert-success">
                ✅ 您的绑定申请已通过！<br>
                处理时间：<?= formatTime($requestStatus['handled_at']) ?>
            </div>
        <?php elseif ($requestStatus && $requestStatus['status'] === 'rejected'): ?>
            <div class="alert">
                ❌ 您的绑定申请被拒绝。<br>
                处理时间：<?= formatTime($requestStatus['handled_at']) ?>
            </div>
        <?php endif; ?>

        <!-- 如果当前没有待处理的申请，且没有被拒绝或已通过，显示表单 -->
        <?php if (!$requestStatus || $requestStatus['status'] !== 'pending'): ?>
            <?php
            $today = date('Y-m-d');
            $hasToday = $conn->query("SELECT id FROM bind_requests WHERE uid = $login_uid AND DATE(created_at) = '$today'")->num_rows > 0;
            if (!$hasToday): ?>
                <form method="post">
                    <div class="form-group">
                        <label for="luogu_uid">洛谷 UID <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="luogu_uid" id="luogu_uid" placeholder="请输入您的洛谷数字 UID" required pattern="[0-9]+">
                        <div class="text-muted">例如：123456（仅数字）</div>
                    </div>
                    <div class="form-group">
                        <label for="verify_code">验证码 <span style="color:var(--danger);">*</span></label>
                        <input type="text" name="verify_code" id="verify_code" placeholder="请输入洛谷的验证码" required>
                        <div class="text-muted">用于确认绑定的验证码（如：abc123）</div>
                    </div>
                    <button type="submit" name="submit_bind" class="btn btn-block">提交绑定申请</button>
                </form>
                <p style="font-size:12px;color:var(--text-muted);margin-top:8px;">注意：每天仅可提交一次申请，请仔细填写。</p>
            <?php else: ?>
                <div class="alert alert-info">您今天已提交过申请，请明天再尝试。</div>
            <?php endif; ?>
        <?php endif; ?>

        <div style="text-align:center;margin-top:20px;">
            <a href="https://lmtoj.cn/" class="back-link">← 返回首页</a>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>