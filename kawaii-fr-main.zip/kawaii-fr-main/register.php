<?php

require_once 'visit_log.php';
require_once __DIR__ . '/database.php';

const IP_REGISTER_LIMIT = 2;
const IP_REGISTER_LIMIT_EXEMPT = '120.225.11.182';
const LOGIN_URL = 'https://lmtoj.cn/login';

function showAlertAndGoBack(string $message): void
{
    $message = json_encode($message, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT);
    echo "<script>alert({$message});history.back();</script>";
    exit;
}

function showAlertAndRedirect(string $message, string $url): void
{
    $message = json_encode($message, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT);
    $url = json_encode($url, JSON_UNESCAPED_SLASHES);
    echo "<script>alert({$message});location.href={$url};</script>";
    exit;
}

function validateRegistrationInput(string $username, string $password, string $passwordConfirmation): ?string
{
    if ($username === '' || $password === '') {
        return '账号密码不能为空';
    }

    if ($password !== $passwordConfirmation) {
        return '两次密码不一致';
    }

    if (strlen($username) > 20) {
        return '用户名过长，最大20位';
    }

    if (!preg_match('/^[A-Za-z0-9_]+$/', $username)) {
        return '用户名仅支持大小写字母、数字、下划线';
    }

    if (preg_match('/^\d+$/', $username)) {
        return '用户名不能为纯数字';
    }

    return null;
}

function usernameExists(mysqli $connection, string $username): bool
{
    $statement = $connection->prepare('SELECT uid FROM users WHERE name = ?');
    $statement->bind_param('s', $username);
    $statement->execute();
    $exists = $statement->get_result()->num_rows > 0;
    $statement->close();

    return $exists;
}

function countAccountsForIp(mysqli $connection, string $ip): int
{
    $statement = $connection->prepare('SELECT COUNT(*) AS account_count FROM users WHERE ip = ?');
    $statement->bind_param('s', $ip);
    $statement->execute();
    $row = $statement->get_result()->fetch_assoc();
    $statement->close();

    return (int) $row['account_count'];
}

function nextUserId(mysqli $connection): int
{
    $result = $connection->query('SELECT MAX(uid) AS max_uid FROM users');
    $row = $result->fetch_assoc();

    return $row['max_uid'] === null ? 1 : (int) $row['max_uid'] + 1;
}

function createUser(mysqli $connection, int $userId, string $username, string $password, string $ip): bool
{
    $passwordHash = password_hash($password, PASSWORD_DEFAULT);
    $statement = $connection->prepare('INSERT INTO users (uid, name, password, ip) VALUES (?, ?, ?, ?)');
    $statement->bind_param('isss', $userId, $username, $passwordHash, $ip);

    return $statement->execute();
}

function addWelcomeNotice(mysqli $connection, int $userId): void
{
    $statement = $connection->prepare('INSERT INTO notice (uid, content, create_time, is_read) VALUES (?, ?, ?, 0)');
    $content = 'register';
    $createdAt = date('Y-m-d H:i:s');
    $statement->bind_param('iss', $userId, $content, $createdAt);
    $statement->execute();
    $statement->close();
}$connection = db();

if ($connection->connect_error) {
    showAlertAndGoBack('数据库连接失败');
}

$connection->set_charset('utf8');

$error = '';
$userIp = $_SERVER['HTTP_X_REAL_IP'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['pwd'] ?? '');
    $passwordConfirmation = trim($_POST['repwd'] ?? '');

    $error = validateRegistrationInput($username, $password, $passwordConfirmation);

    if ($error === null) {
        if (usernameExists($connection, $username)) {
            $error = '用户名已存在';
        } elseif (
            countAccountsForIp($connection, $userIp) >= IP_REGISTER_LIMIT
            && $userIp !== IP_REGISTER_LIMIT_EXEMPT
        ) {
            $error = '每个IP最多注册2个账号';
        } else {
            $userId = nextUserId($connection);

            if (createUser($connection, $userId, $username, $password, $userIp)) {
                addWelcomeNotice($connection, $userId);
                showAlertAndRedirect('注册成功！', LOGIN_URL);
            }

            $error = '注册失败';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>注册 - lmtOJ</title>
    <style>        :root {
            --text: #26332f;
            --text-secondary: #64726c;
            --text-muted: #93a09a;
            --accent: #5f806d;
            --accent-strong: #466656;
            --accent-soft: rgba(95, 128, 109, 0.16);
            --danger: #b44743;
            --danger-soft: rgba(180, 71, 67, 0.10);
            --glass: rgba(255, 255, 255, 0.58);
            --glass-strong: rgba(255, 255, 255, 0.74);
            --stroke: rgba(255, 255, 255, 0.72);
            --nav-glass: rgba(42, 48, 46, 0.74);
            --shadow: 0 24px 70px rgba(53, 64, 61, 0.18);
            --shadow-soft: 0 8px 24px rgba(53, 64, 61, 0.10);
            --radius: 8px;
            --radius-sm: 6px;
            --transition: 0.18s ease;
            --font: "Segoe UI", "PingFang SC", "Microsoft YaHei", system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        html,
        body {
            min-height: 100%;
        }

        body {
            margin: 0;
            min-height: 100vh;
            color: var(--text);
            font-family: var(--font);
            background:
                linear-gradient(120deg, rgba(255, 255, 255, 0.42), transparent 42%),
                linear-gradient(135deg, #dcebe0 0%, #f2ecdf 48%, #d8e5ed 100%);
            background-attachment: fixed;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 84px 20px 24px;
            overflow-x: hidden;
            -webkit-font-smoothing: antialiased;
        }

        body::before {
            content: "";
            position: fixed;
            inset: 0;
            pointer-events: none;
            background-image:
                linear-gradient(rgba(255, 255, 255, 0.28) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.28) 1px, transparent 1px);
            background-size: 32px 32px;
            opacity: 0.22;
        }

        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 56px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: var(--nav-glass);
            border-bottom: 1px solid rgba(255, 255, 255, 0.16);
            box-shadow: 0 1px 16px rgba(0, 0, 0, 0.08);
            backdrop-filter: blur(16px) saturate(130%);
            -webkit-backdrop-filter: blur(16px) saturate(130%);
            z-index: 10;
        }

        .brand {
            color: #ffffff;
            font-size: 17px;
            font-weight: 600;
        }

        .page-shell {
            width: 100%;
            display: flex;
            justify-content: center;
        }

        .glass-card {
            position: relative;
            width: min(420px, 100%);
            padding: 38px 34px;
            background: var(--glass);
            border: 1px solid var(--stroke);
            border-radius: var(--radius);
            box-shadow: var(--shadow), inset 0 1px 0 rgba(255, 255, 255, 0.72);
            backdrop-filter: blur(20px) saturate(150%);
            -webkit-backdrop-filter: blur(20px) saturate(150%);
            animation: float-card 7s ease-in-out infinite;
        }

        @keyframes float-card {
            0%,
            100% {
                transform: translateY(0);
            }

            50% {
                transform: translateY(-6px);
            }
        }

        .title {
            margin: 0 0 26px;
            text-align: center;
            font-size: 23px;
            font-weight: 650;
        }        .field {
            margin-bottom: 16px;
        }

        .field:last-of-type {
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            height: 48px;
            padding: 0 14px;
            border: 1px solid rgba(82, 98, 90, 0.18);
            border-radius: var(--radius-sm);
            background: rgba(255, 255, 255, 0.68);
            color: var(--text);
            font-family: inherit;
            font-size: 14px;
            outline: none;
            transition: var(--transition);
        }

        input::placeholder {
            color: var(--text-muted);
        }

        input:focus {
            border-color: var(--accent);
            background: var(--glass-strong);
            box-shadow: 0 0 0 3px var(--accent-soft);
        }

        button {
            width: 100%;
            height: 46px;
            border: 0;
            border-radius: 999px;
            background: linear-gradient(135deg, var(--accent), var(--accent-strong));
            color: #ffffff;
            font-family: inherit;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            box-shadow: 0 8px 20px rgba(79, 111, 91, 0.25);
            transition: var(--transition);
        }

        button:hover {
            box-shadow: 0 11px 26px rgba(79, 111, 91, 0.30);
            filter: brightness(1.04);
            transform: translateY(-1px);
        }

        button:active {
            transform: translateY(0);
        }

        .tip {
            margin-top: 18px;
            text-align: center;
            color: var(--text-secondary);
            font-size: 14px;
            line-height: 1.6;
        }

        .tip + .tip {
            margin-top: 8px;
        }

        .tip a {
            color: var(--accent);
            font-weight: 600;
            text-decoration: none;
        }

        .tip a:hover {
            color: var(--accent-strong);
            text-decoration: underline;
        }

        .error {
            margin: -6px 0 18px;
            padding: 10px 12px;
            border: 1px solid rgba(180, 71, 67, 0.25);
            border-radius: var(--radius-sm);
            background: var(--danger-soft);
            color: var(--danger);
            text-align: center;
            font-size: 14px;
        }

        .sr-only {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        @media (max-width: 520px) {
            body {
                padding: 78px 16px 20px;
            }

            .glass-card {
                padding: 30px 22px;
            }

            .title {
                font-size: 21px;
            }

            input,
            button {
                height: 46px;
            }
        }

        @media (prefers-reduced-motion: reduce) {
            .glass-card {
                animation: none;
            }

            button,
            input {
                transition: none;
            }
        }
    </style>
</head><body>
    <header class="navbar">
        <span class="brand">lmtOJ</span>
    </header>

    <main class="page-shell">
        <section class="glass-card" aria-labelledby="register-title">
            <h1 class="title" id="register-title">注册账号</h1>

            <?php if ($error !== ''): ?>
                <div class="error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endif; ?>

            <form id="register-form" method="post" autocomplete="on">
                <?= csrf_field() ?>

                <div class="field">
                    <label class="sr-only" for="username">用户名</label>
                    <input id="username" name="username" type="text" placeholder="用户名（字母、数字、下划线，不可纯数字）" required autocomplete="username">
                </div>

                <div class="field">
                    <label class="sr-only" for="pwd">密码</label>
                    <input id="pwd" name="pwd" type="password" placeholder="密码" required autocomplete="new-password">
                </div>

                <div class="field">
                    <label class="sr-only" for="repwd">确认密码</label>
                    <input id="repwd" name="repwd" type="password" placeholder="确认密码" required autocomplete="new-password">
                </div>

                <button type="submit">注册</button>
            </form>

            <div class="tip">注册即代表已阅读并同意我们的 <a href="https://lmtoj.cn/help/rules">用户协议</a></div>
            <div class="tip">已有账号？<a href="<?= htmlspecialchars(LOGIN_URL, ENT_QUOTES, 'UTF-8') ?>">立即登录</a></div>
        </section>
    </main>

    <script>
        (function () {
            const form = document.getElementById('register-form');
            const USERNAME_PATTERN = /^[A-Za-z0-9_]{1,20}$/;
            const NUMERIC_PATTERN = /^\d+$/;

            form.addEventListener('submit', function (event) {
                const username = form.elements.username.value.trim();
                const password = form.elements.pwd.value;
                const confirmation = form.elements.repwd.value;

                if (!USERNAME_PATTERN.test(username)) {
                    event.preventDefault();
                    alert('用户名仅支持大小写字母、数字、下划线，长度1-20位');
                    return;
                }

                if (NUMERIC_PATTERN.test(username)) {
                    event.preventDefault();
                    alert('用户名不能为纯数字');
                    return;
                }

                if (password !== confirmation) {
                    event.preventDefault();
                    alert('两次密码不一致');
                }
            });
        })();
    </script>
</body>
</html>