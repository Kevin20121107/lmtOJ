<?php
require_once __DIR__ . '/database.php';

session_start();
if (!isset($_SESSION['uid'])) {
	header("Location: https://lmtoj.cn/login");
	exit;
}
$login_uid = (int)$_SESSION['uid'];
$user = $db->query("SELECT devadmin, sqadmin FROM users WHERE uid=$login_uid LIMIT 1")->fetch();
if (!$user && (!$user['devadmin'] || !$user['sqadmin'])) {
	header("Location: https://lmtoj.cn/");
	exit;
}

// 获取所有数据库表
$tables = [];
try {
	$tablesStmt = $db->query("SHOW TABLES");
	$tables = $tablesStmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
	$dbError = $e->getMessage();
}

$currentTable = $_GET['table'] ?? '';
$action = $currentTable ? ($_GET['action'] ?? 'data') : ($_GET['action'] ?? 'sql'); // data, structure, sql
$working = $currentTable || $action === 'sql';
$page = (int)($_GET['page'] ?? 1);
$limit = 20;
$offset = ($page - 1) * $limit;

$msg = null;
$error = null;
$tableData = [];
$tableCols = [];
$primaryKey = null;
$totalRows = 0;

// 删除表成功后的提示（重定向带回）
if (isset($_GET['dropped'])) {
	$msg = "数据表 `" . $_GET['dropped'] . "` 已成功删除";
}

// SQL 控制台执行结果
$customSql = $_POST['custom_sql'] ?? '';
$customSqlResult = null;
$customSqlColumns = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exec_custom_sql'])) {
	$sqlToExec = trim($_POST['custom_sql']);
	try {
		$stmt = $db->query($sqlToExec);
		if (preg_match('/^\s*(SELECT|SHOW|DESCRIBE|EXPLAIN)/i', $sqlToExec)) {
			$customSqlResult = $stmt->fetchAll();
			if (!empty($customSqlResult)) {
				$customSqlColumns = array_keys($customSqlResult[0]);
			}
		} else {
			$affected = $stmt->rowCount();
			$msg = "SQL 执行成功，受影响行数: $affected";
		}
	} catch (Exception $e) {
		$error = "SQL 执行错误: " . $e->getMessage();
	}
	$action = 'sql';
}

if ($currentTable) {
	try {
		// 获取表字段结构
		$colStmt = $db->query("DESCRIBE `" . $currentTable . "`");
		$tableCols = $colStmt->fetchAll();
		foreach ($tableCols as $col) {
			if ($col['Key'] === 'PRI') {
				$primaryKey = $col['Field'];
				break;
			}
		}

		// 处理 图形化 POST 请求
		if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['exec_custom_sql'])) {
			$postAction = $_POST['post_action'] ?? '';

			// --- 删除整张表（严格确认：必须手动输入表名） ---
			if ($postAction === 'drop_table') {
				$confirmName = trim($_POST['confirm_table_name'] ?? '');
				if ($confirmName === '' || $confirmName !== $currentTable) {
					$error = "表名确认不匹配，删除操作已取消。";
				} else {
					try {
						$db->query("DROP TABLE `$currentTable`");
						header("Location: ?action=sql&dropped=" . urlencode($currentTable));
						exit;
					} catch (Exception $e) {
						$error = "删除表失败: " . $e->getMessage();
					}
				}
			}

			// --- 修改数据 ---
			elseif ($postAction === 'save_edit') {
				$sets = []; $vals = [];
				foreach ($_POST['fields'] as $f => $v) {
					$sets[] = "`$f` = ?";
					$vals[] = ($v === '') ? null : $v;
				}

				$oldRow = json_decode($_POST['old_row_data'], true);
				$whereClause = [];

				if ($primaryKey && isset($oldRow[$primaryKey])) {
					$whereClause[] = "`$primaryKey` = ?";
					$vals[] = $oldRow[$primaryKey];
				} else {
					foreach ($oldRow as $colName => $colVal) {
						if ($colVal === null) {
							$whereClause[] = "`$colName` IS NULL";
						} else {
							$whereClause[] = "`$colName` = ?";
							$vals[] = $colVal;
						}
					}
				}

				$sql = "UPDATE `$currentTable` SET " . implode(', ', $sets) . " WHERE " . implode(' AND ', $whereClause) . " LIMIT 1";
				$db->query($sql, $vals);
				$msg = "记录修改成功";
			}

			// --- 删除数据 ---
			elseif ($postAction === 'delete_row') {
				$oldRow = json_decode($_POST['old_row_data'], true);
				$whereClause = []; $vals = [];

				if ($primaryKey && isset($oldRow[$primaryKey])) {
					$whereClause[] = "`$primaryKey` = ?";
					$vals[] = $oldRow[$primaryKey];
				} else {
					foreach ($oldRow as $colName => $colVal) {
						if ($colVal === null) {
							$whereClause[] = "`$colName` IS NULL";
						} else {
							$whereClause[] = "`$colName` = ?";
							$vals[] = $colVal;
						}
					}
				}

				$sql = "DELETE FROM `$currentTable` WHERE " . implode(' AND ', $whereClause) . " LIMIT 1";
				$db->query($sql, $vals);
				$msg = "记录删除成功";
			}

			// --- 插入数据 ---
			elseif ($postAction === 'save_add') {
				$fields = []; $placeholders = []; $vals = [];
				foreach ($_POST['fields'] as $f => $v) {
					if ($v !== '') {
						$fields[] = "`$f`"; $placeholders[] = "?"; $vals[] = $v;
					}
				}
				if (!empty($fields)) {
					$sql = "INSERT INTO `$currentTable` (" . implode(',', $fields) . ") VALUES (" . implode(',', $placeholders) . ")";
					$db->query($sql, $vals);
					$msg = "记录添加成功";
				}
			}

			// --- 表结构操作 ---
			elseif ($postAction === 'add_column') {
				$colName = trim($_POST['col_name']);
				$colType = trim($_POST['col_type']);
				$colNull = $_POST['col_null'] === '1' ? 'NULL' : 'NOT NULL';
				$colKey = $_POST['col_key'] ?? '';
				$colDefault = trim($_POST['col_default']);
				$defaultSql = $colDefault !== '' ? "DEFAULT '$colDefault'" : '';

				$keySql = '';
				if ($colKey === 'PRIMARY') {
					$keySql = ' PRIMARY KEY';
				} elseif ($colKey === 'UNIQUE') {
					$keySql = ' UNIQUE';
				} elseif ($colKey === 'INDEX') {
					$keySql = ' INDEX';
				}

				$sql = "ALTER TABLE `$currentTable` ADD `$colName` $colType $colNull $defaultSql$keySql";
				$db->query($sql);
				$msg = "成功添加新列 `$colName`";
			} elseif ($postAction === 'drop_column') {
				$colName = $_POST['col_name'];
				$sql = "ALTER TABLE `$currentTable` DROP COLUMN `$colName`";
				$db->query($sql);
				$msg = "成功删除列 `$colName`";
			} elseif ($postAction === 'modify_column') {
				$oldCol = $_POST['old_col_name'];
				$colName = trim($_POST['col_name']);
				$colType = trim($_POST['col_type']);
				$colNull = $_POST['col_null'] === '1' ? 'NULL' : 'NOT NULL';

				$sql = "ALTER TABLE `$currentTable` CHANGE COLUMN `$oldCol` `$colName` $colType $colNull";
				$db->query($sql);
				$msg = "成功更新列 `$colName` 的结构";
			}

			// 刷新表字段结构
			$colStmt = $db->query("DESCRIBE `" . $currentTable . "`");
			$tableCols = $colStmt->fetchAll();
		}

		// 读取数据
		$countStmt = $db->query("SELECT COUNT(*) FROM `" . $currentTable . "`");
		$totalRows = (int)$countStmt->fetchColumn();

		$dataStmt = $db->query("SELECT * FROM `" . $currentTable . "` LIMIT $limit OFFSET $offset");
		$tableData = $dataStmt->fetchAll();

	} catch (Exception $e) {
		$error = $e->getMessage();
	}
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>SQL 管理器</title>
	<style>
		:root {
			--header-bg: #213651;
			--bg: #f6f8fa;
			--card-bg: #ffffff;
			--border: #d0d7de;
			--text-main: #1F2328;
			--text-muted: #656d76;
			--link: #0969da;
			--btn-bg: #f6f8fa;
			--btn-border: rgba(31,35,40,0.15);
			--btn-hover: #f3f4f6;
			--btn-primary-bg: #088b97;
			--btn-primary-hover: #0897a4;
			--danger: #cf222e;
		}

		* { box-sizing: border-box; margin: 0; padding: 0; }
		body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans", Helvetica, Arial, sans-serif; height: 100vh; display: flex; flex-direction: column; background: var(--bg); color: var(--text-main); font-size: 14px; overflow: hidden; }
		textarea { resize: vertical; }

		.octicon { fill: currentColor; display: inline-block; vertical-align: text-bottom; }

		/* Header Bar */
		.header { height: 48px; background: var(--header-bg); color: white; display: flex; align-items: center; justify-content: space-between; padding: 0 16px; font-weight: 600; font-size: 14px; }
		.header-brand { display: flex; align-items: center; gap: 10px; }

		/* Layout Container */
		.layout { display: flex; flex: 1; overflow: hidden; }

		/* Left Sidebar */
		.sidebar { z-index: 999; height: calc(100% - 48px); width: <?= $working ? '260px' : '100%' ?>; position: fixed; background: var(--card-bg); border-right: 1px solid var(--border); display: flex; flex-direction: column; }
		.sidebar-header { padding: 12px 16px; font-size: 12px; font-weight: 600; color: var(--text-muted); border-bottom: 1px solid var(--border); }
		.table-list { list-style: none; overflow-y: auto; flex: 1; padding: 8px; }
		.table-item { display: flex; align-items: center; justify-content: space-between; padding: 7px 10px; border-radius: 6px; text-decoration: none; color: var(--text-main); font-size: 13px; margin-bottom: 2px; }
		.table-item:hover { background: #f3f4f6; }
		.table-item.active { background: #ddf4ff; color: var(--link); font-weight: 600; }
		.sidebar-toggle { width: 32px; height: 32px; border: none; border-radius: 6px; background: rgba(255,255,255,0.12); color: white; cursor: pointer; display: flex; align-items: center; justify-content: center; }
		.sidebar-toggle:hover { background: rgba(255,255,255,0.2); }

		/* Right Content Area */
		.content { flex: 1; padding: 24px; overflow-y: auto; display: flex; flex-direction: column; gap: 16px; }

		/* Box Card */
		.box { background: var(--card-bg); border: 1px solid var(--border); border-radius: 6px; overflow: hidden; }
		.box-header { padding: 12px 16px; background: #f6f8fa; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }

		/* Navigation Tabs */
		.tabs { display: flex; gap: 4px; border-bottom: 1px solid var(--border); margin-bottom: 16px; }
		.tab { padding: 8px 16px; font-size: 14px; color: var(--text-muted); text-decoration: none; border-bottom: 2px solid transparent; font-weight: 500; }
		.tab:hover { color: var(--text-main); border-bottom-color: var(--border); }
		.tab.active { color: var(--text-main); border-bottom-color: #0bc8a2; font-weight: 600; }

		/* Buttons */
		.btn { font-size: 12px; font-weight: 500; padding: 5px 12px; border-radius: 6px; border: 1px solid var(--btn-border); background: var(--btn-bg); color: var(--text-main); cursor: pointer; display: inline-flex; align-items: center; gap: 4px; line-height: 20px; }
		.btn:hover { background: var(--btn-hover); }
		.btn-primary { background: var(--btn-primary-bg); color: white; border-color: rgba(31,35,40,0.15); font-weight: 600; }
		.btn-primary:hover { background: var(--btn-primary-hover); }
		.btn-danger { color: var(--danger); }
		.btn-danger:hover { background: var(--danger); color: white; }
		.btn:disabled { opacity: 0.5; cursor: not-allowed; }
		.btn-danger:disabled:hover { background: var(--btn-bg); color: var(--danger); }

		/* Tables */
		.table { width: 100%; border-collapse: collapse; font-size: 13px; text-align: left; }
		.table th, .table td { padding: 10px 16px; border-bottom: 1px solid var(--border); white-space: nowrap; }
		.table th { background: #f6f8fa; font-weight: 600; color: var(--text-muted); position: sticky; top: 0; z-index: 2; }
		.table .limit-td { width: auto; max-width: 150px; overflow: hidden; text-overflow: ellipsis; }
		.table tr:hover { background: #f6f8fa; }

		.badge { font-size: 12px; padding: 2px 7px; border-radius: 12px; font-weight: 500; border: 1px solid transparent; }
		.badge-gray { background: #eff1f3; color: var(--text-muted); border-color: var(--border); }
		.badge-blue { background: #ddf4ff; color: #0969da; border-color: #54aeff; }

		.flash { padding: 12px 16px; border-radius: 6px; font-size: 13px; border: 1px solid; margin-bottom: 8px; }
		.flash-success { background: #dafbe1; color: #1a7f37; border-color: #4ac26b; }
		.flash-error { background: #ffebe9; color: #cf222e; border-color: #ff8182; }

		/* Style Modal */
		.modal-backdrop { display: none; position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(14, 18, 22, 0.4); backdrop-filter: blur(1px); justify-content: center; align-items: center; z-index: 999; }
		.modal { background: white; border: 1px solid var(--border); border-radius: 12px; width: 540px; max-width: 92vw; max-height: 85vh; display: flex; flex-direction: column; box-shadow: 0 8px 24px rgba(140,149,159,0.2); overflow: hidden; }
		.modal-header { padding: 14px 16px; background: #f6f8fa; border-bottom: 1px solid var(--border); font-weight: 600; font-size: 14px; display: flex; justify-content: space-between; align-items: center; }
		.modal-body { padding: 16px; overflow-y: auto; flex: 1; max-height: calc(85vh - 110px); }
		.modal-footer { padding: 12px 16px; background: #f6f8fa; border-top: 1px solid var(--border); display: flex; justify-content: flex-end; gap: 8px; }

		/* Form Controls */
		.form-group { margin-bottom: 14px; }
		.form-group label { display: block; font-size: 12px; font-weight: 600; margin-bottom: 6px; color: var(--text-main); }
		.input { width: 100%; padding: 6px 12px; font-size: 13px; border: 1px solid var(--border); border-radius: 6px; outline: none; background: #f6f8fa; font-family: inherit; }
		.input:focus { background: #fff; border-color: #0969da; box-shadow: 0 0 0 3px rgba(9,105,218,0.3); }
		textarea.input { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace; line-height: 1.5; }

		/* Page Navigation */
		.pagination-wrap { width: 100%; overflow-x: auto; -webkit-overflow-scrolling: touch; }
		.pagination { display: inline-flex; gap: 4px; align-items: center; margin-top: 16px; white-space: nowrap; padding: 6px 4px; }
		.pagination a { padding: 5px 10px; font-size: 12px; border: 1px solid var(--border); border-radius: 6px; text-decoration: none; color: var(--text-main); background: #fff; }
		.pagination a.active { background: #0969da; color: white; border-color: #0969da; font-weight: 600; }
	</style>
</head>
<body>

	<!-- Header Navigation Bar -->
	<div class="header">
		<div class="header-brand">
			<?php if ($working): ?>
				<button type="button" class="sidebar-toggle" id="sidebarToggle" aria-expanded="false">☰</button>
			<?php endif; ?>
			<a href="/admin/sql?action=data" style="text-decoration: none; color: #fff;">SQL Terminal</a>
		</div>
	</div>

	<div class="layout">
		<!-- Sidebar -->
		<div class="sidebar" id="sidebar" style="<?= $working ? 'display: none;' : '' ?>">
			<div class="sidebar-header">TABLES (<?php echo count($tables); ?>)</div>
			<ul class="table-list">
				<?php foreach ($tables as $t): ?>
					<a href="?table=<?php echo urlencode($t); ?>" class="table-item <?php echo $t === $currentTable ? 'active' : ''; ?>">
						<span><?php echo htmlspecialchars($t); ?></span>
					</a>
				<?php endforeach; ?>
			</ul>
		</div>

		<!-- Main Content Area -->
		<div class="content">
			<?php if ($msg): ?>
				<div class="flash flash-success"><?php echo htmlspecialchars($msg); ?></div>
			<?php endif; ?>
			<?php if ($error): ?>
				<div class="flash flash-error"><strong>Error:</strong> <?php echo htmlspecialchars($error); ?></div>
			<?php endif; ?>

			<?php if ($currentTable || $action === 'sql'): ?>
				<div>
					<!-- Navigation Tabs (含 SQL 命令行 Tab) -->
					<div class="tabs">
						<a href="?table=<?php echo urlencode($currentTable); ?>&action=data" class="tab <?php echo $action === 'data' ? 'active' : ''; ?>">
							Data
						</a>
						<a href="?table=<?php echo urlencode($currentTable); ?>&action=structure" class="tab <?php echo $action === 'structure' ? 'active' : ''; ?>">
							Structure
						</a>
						<a href="?table=<?php echo urlencode($currentTable); ?>&action=sql" class="tab <?php echo $action === 'sql' ? 'active' : ''; ?>">
							Console
						</a>
					</div>

					<?php if ($action === 'sql'): ?>
						<!-- 手动执行 SQL 界面 -->
						<script src="https://registry.npmmirror.com/monaco-editor/0.52.2/files/min/vs/loader.js"></script>
						<div class="vscode-box" style="border: 1px solid #3c3c3c; border-radius: 6px; overflow: hidden; margin-bottom: 20px; background: #1e1e1e;">
							<div id="monaco-container" style="width: 100%; min-height: 150px;"></div>

							<form id="vscode-sql-form" method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=sql">
								<input type="hidden" name="exec_custom_sql" value="1">
								<textarea name="custom_sql" id="hidden_custom_sql" style="display: none;"><?php echo htmlspecialchars($customSql); ?></textarea>

								<div style="background: #181818; padding: 8px 12px; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #2b2b2b;">
									<button type="submit" style="background: #167a00; color: white; border: none; padding: 5px 14px; border-radius: 2px; font-size: 12px; font-weight: 600; cursor: pointer;">
										<code>? Run (Ctrl Enter / Ctrl B / F5 / F10)</code>
									</button>
								</div>
							</form>
						</div>
						<script>
							require.config({ paths: { 'vs': 'https://registry.npmmirror.com/monaco-editor/0.52.2/files/min/vs' }});
							require(['vs/editor/editor.main', 'vs/basic-languages/sql/sql'], function(_editorMain, sqlLanguage) {
								if (!monaco.languages.getLanguages().some(function(language) { return language.id === 'sql'; })) {
									monaco.languages.register({ id: 'sql' });
								}
								monaco.languages.setMonarchTokensProvider('sql', sqlLanguage.language);
								monaco.languages.setLanguageConfiguration('sql', sqlLanguage.conf);

								const hiddenTextarea = document.getElementById('hidden_custom_sql');
								const form = document.getElementById('vscode-sql-form');
								const container = document.getElementById('monaco-container');

								monaco.editor.defineTheme('sql-admin-green', {
									base: 'vs-dark',
									inherit: true,
									rules: [
										{ token: 'keyword.sql', foreground: '8FE3A4', fontStyle: 'bold' },
										{ token: 'string.sql', foreground: 'F2D28B' },
										{ token: 'number.sql', foreground: 'D1A8FF' },
										{ token: 'comment.sql', foreground: '829B89', fontStyle: 'italic' },
										{ token: 'operator.sql', foreground: 'A8DDB4' },
										{ token: 'predefined.sql', foreground: '83D0DF' },
										{ token: 'identifier.sql', foreground: 'E0EEE3' },
										{ token: 'keyword', foreground: '8BD19D', fontStyle: 'bold' },
										{ token: 'string', foreground: 'E6C98A' },
										{ token: 'number', foreground: 'C6A0F6' },
										{ token: 'comment', foreground: '7F9B86', fontStyle: 'italic' },
										{ token: 'delimiter', foreground: 'C7D8CB' },
										{ token: 'operator', foreground: 'A8D5B2' },
										{ token: 'predefined', foreground: '8CC8D8' },
										{ token: 'identifier', foreground: 'DCE8DE' }
									],
									colors: {
										'editor.background': '#101B13',
										'editorLineNumber.foreground': '#536B59',
										'editorLineNumber.activeForeground': '#C5E8CB',
										'editorCursor.foreground': '#8FE3A4',
										'editor.selectionBackground': '#315F40',
										'editor.lineHighlightBackground': '#FFFFFF0A'
									}
								});
								monaco.editor.setTheme('sql-admin-green');

								const editor = monaco.editor.create(container, {
									value: hiddenTextarea.value || "SELECT * FROM `<?php echo htmlspecialchars($currentTable); ?>`",
									language: 'sql',
									theme: 'sql-admin-green',
									automaticLayout: true,
									fontSize: 13,
									minimap: { enabled: false },
									scrollBeyondLastLine: false,
									scrollbar: {
										vertical: 'hidden',
										handleMouseWheel: false
									}
								});

								// 动态调整高度的逻辑
								const MIN_HEIGHT = 150; // 最小高度(px)

								function updateHeight() {
									const contentHeight = editor.getContentHeight();
									const targetHeight = Math.max(contentHeight, MIN_HEIGHT);

									container.style.height = `${targetHeight}px`;
									editor.updateOptions({
										scrollbar: { vertical: 'hidden', handleMouseWheel: false }
									});
									editor.layout(); // 重新布局
								}

								// 初始化时和内容变化时重新计算高度
								editor.onDidContentSizeChange(updateHeight);
								updateHeight();

								editor.addAction({
									id: 'submit-sql-form',
									label: 'Run',
									keybindings: [
										monaco.KeyCode.F5,
										monaco.KeyCode.F10,
										monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyB,
										monaco.KeyMod.CtrlCmd | monaco.KeyCode.Enter,
									],
									precondition: null,
									keybindingContext: null,
									contextMenuGroupId: 'navigation',
									contextMenuOrder: 1.5,
									run: function(ed) {
										hiddenTextarea.value = ed.getValue();
										if (typeof form.requestSubmit === 'function') {
											form.requestSubmit();
										} else {
											form.submit();
										}
									}
								});

								// 普通按钮提交前同步数据
								form.addEventListener('submit', function() {
									hiddenTextarea.value = editor.getValue();
								});
							});
						</script>

						<!-- 手动 SQL 查询结果列表 -->
						<?php if ($customSqlResult !== null): ?>
							<div class="box">
								<div class="box-header">
									<span>Result (<?php echo count($customSqlResult); ?> rows)</span>
								</div>
								<?php if (!empty($customSqlResult)): ?>
									<div style="overflow-x:auto;">
										<table class="table">
											<thead>
												<tr>
													<?php foreach ($customSqlColumns as $colName): ?>
														<th><?php echo htmlspecialchars($colName); ?></th>
													<?php endforeach; ?>
												</tr>
											</thead>
											<tbody>
												<?php foreach ($customSqlResult as $row): ?>
													<tr>
														<?php foreach ($row as $val): ?>
															<td><?php echo $val === null ? '<span style="color:#8c959f;">NULL</span>' : htmlspecialchars($val); ?></td>
														<?php endforeach; ?>
													</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</div>
								<?php else: ?>
									<div style="padding: 20px; text-align: center; color: var(--text-muted);">Query executed, returned 0 rows.</div>
								<?php endif; ?>
							</div>
						<?php endif; ?>

					<?php else: ?>

						<!-- Box Header Container -->
						<div class="box">
							<div class="box-header">
								<span style="font-weight: 600; font-size:14px;">
									<?= htmlspecialchars($currentTable) ?>
									<span style="font-weight: 400; color:var(--text-muted); font-size:12px;"><?= ($primaryKey ? ' (主键: ' . htmlspecialchars($primaryKey) . ')' : ' <span style="color:var(--danger);">(该表缺少主键，修改时可能出现问题)</span>') ?> (Total <?= $totalRows ?> items)</span>
								</span>
								<div style="display: flex; gap: 8px; align-items: center;">
									<?php if ($action === 'data'): ?>
										<button class="btn btn-primary" onclick="openAddDataModal()">+ 添加行</button>
									<?php else: ?>
										<button class="btn btn-primary" onclick="openAddColModal()">+ 添加列</button>
									<?php endif; ?>
									<button class="btn btn-danger" onclick="openDropTableModal()">删除表</button>
								</div>
							</div>

							<?php if ($action === 'structure'): ?>
								<!-- Structure View -->
								<table class="table">
									<thead>
										<tr>
											<th>Column</th>
											<th>Type</th>
											<th>Null</th>
											<th>Key</th>
											<th>Default</th>
											<th>Actions</th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ($tableCols as $col): ?>
											<tr>
												<td><?php echo htmlspecialchars($col['Field']); ?></td>
												<td><span class="badge badge-gray"><?php echo htmlspecialchars($col['Type']); ?></span></td>
												<td><?php echo $col['Null'] === 'YES' ? 'YES' : '<span style="color:#8c959f;">NO</span>'; ?></td>
												<td>
													<?php if($col['Key'] === 'PRI'): ?>
														<span class="badge badge-blue">Primary</span>
													<?php endif; ?>
												</td>
												<td><?php echo $col['Default'] !== null ? htmlspecialchars($col['Default']) : '<span style="color:#8c959f;">NULL</span>'; ?></td>
												<td>
													<button class="btn" onclick='openEditColModal(<?php echo json_encode($col); ?>)'>编辑</button>
													<button class="btn btn-danger" onclick="dropColumn('<?php echo htmlspecialchars($col['Field']); ?>')">删除</button>
												</td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>
							<?php else: ?>
								<!-- Data View -->
								<?php if (!empty($tableData)): ?>
									<div style="overflow-x:auto; overflow-y:scroll; flex: 1 1 auto; min-width: 0; overflow: auto; max-height: calc(100vh - 300px);">
										<table class="table">
											<thead>
												<tr>
													<th style="width:100px;">Actions</th>
													<?php foreach (array_keys($tableData[0]) as $colName): ?>
														<th><?php echo htmlspecialchars($colName); ?></th>
													<?php endforeach; ?>
												</tr>
											</thead>
											<tbody>
												<?php foreach ($tableData as $row): ?>
													<tr>
														<td>
															<button class="btn" onclick='openEditDataModal(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES); ?>)'>编辑</button>
															<button class="btn btn-danger" onclick='deleteRow(<?php echo htmlspecialchars(json_encode($row), ENT_QUOTES); ?>)'>删除</button>
														</td>
														<?php foreach ($row as $val): ?>
															<td class="limit-td" title="<?php echo htmlspecialchars($val); ?>"><?php echo $val === null ? '<span style="color:#8c959f;">NULL</span>' : htmlspecialchars($val); ?></td>
														<?php endforeach; ?>
													</tr>
												<?php endforeach; ?>
											</tbody>
										</table>
									</div>
								<?php else: ?>
									<div style="text-align:center; color:var(--text-muted); padding:32px;">No data available in this table</div>
								<?php endif; ?>
							<?php endif; ?>
						</div>
						<!-- Pagination -->
						<?php if ($action === 'data' && $totalRows > 0): ?>
							<div class="pagination-wrap">
								<div class="pagination">
									<?php $totalPages = max(1, (int)ceil($totalRows / $limit)); ?>
									<?php for ($i = 1; $i <= $totalPages; $i++): ?>
										<a href="?table=<?php echo urlencode($currentTable); ?>&page=<?php echo $i; ?>" class="<?php echo $i === $page ? 'active' : ''; ?>"><?php echo $i; ?></a>
									<?php endfor; ?>
								</div>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<!-- Modal 1: Add Column -->
	<div class="modal-backdrop" id="addColModal">
		<div class="modal">
			<form method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=structure">
				<input type="hidden" name="post_action" value="add_column">
				<div class="modal-header">
					<span>添加列</span>
					<span style="cursor:pointer;" onclick="closeModal('addColModal')">&times;</span>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label>Name</label>
						<textarea class="input" name="col_name" required rows="1"></textarea>
					</div>
					<div class="form-group">
						<label>Type</label>
						<textarea class="input" name="col_type" required rows="1"></textarea>
					</div>
					<div class="form-group">
						<label>Allow NULL</label>
						<select class="input" name="col_null">
							<option value="1">YES</option>
							<option value="0">NO</option>
						</select>
					</div>
					<div class="form-group">
						<label>Key</label>
						<select class="input" name="col_key">
							<option value="">NONE</option>
							<option value="PRIMARY">PRIMARY KEY</option>
							<option value="UNIQUE">UNIQUE</option>
							<option value="INDEX">INDEX</option>
						</select>
					</div>
					<div class="form-group">
						<label>Default</label>
						<textarea class="input" name="col_default" rows="1"></textarea>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn" onclick="closeModal('addColModal')">取消</button>
					<button type="submit" class="btn btn-primary">确认</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Modal 2: Edit Column -->
	<div class="modal-backdrop" id="editColModal">
		<div class="modal">
			<form method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=structure">
				<input type="hidden" name="post_action" value="modify_column">
				<input type="hidden" name="old_col_name" id="old_col_name">
				<div class="modal-header">
					<span>编辑列</span>
					<span style="cursor:pointer;" onclick="closeModal('editColModal')">&times;</span>
				</div>
				<div class="modal-body">
					<div class="form-group">
						<label>Name</label>
						<textarea class="input" name="col_name" id="edit_col_name" required rows="1"></textarea>
					</div>
					<div class="form-group">
						<label>Type</label>
						<textarea class="input" name="col_type" id="edit_col_type" required rows="1"></textarea>
					</div>
					<div class="form-group">
						<label>Allow NULL</label>
						<select class="input" name="col_null" id="edit_col_null">
							<option value="1">YES</option>
							<option value="0">NO</option>
						</select>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn" onclick="closeModal('editColModal')">取消</button>
					<button type="submit" class="btn btn-primary">确认</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Modal 3: Add Data -->
	<div class="modal-backdrop" id="addDataModal">
		<div class="modal">
			<form method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=data&page=<?php echo $page; ?>">
				<input type="hidden" name="post_action" value="save_add">
				<div class="modal-header">
					<span>添加行</span>
					<span style="cursor:pointer;" onclick="closeModal('addDataModal')">&times;</span>
				</div>
				<div class="modal-body">
					<?php foreach ($tableCols as $col): ?>
						<div class="form-group">
							<label><?php echo htmlspecialchars($col['Field']); ?> <span style="font-weight:normal; color:#8c959f;">(<?php echo $col['Type']; ?>)</span></label>
							<textarea class="input" name="fields[<?php echo htmlspecialchars($col['Field']); ?>]" placeholder="<?php echo $col['Extra'] === 'auto_increment' ? 'auto_increment (leave blank)' : ''; ?>" rows="1"></textarea>
						</div>
					<?php endforeach; ?>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn" onclick="closeModal('addDataModal')">取消</button>
					<button type="submit" class="btn btn-primary">确认</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Modal 4: Edit Data -->
	<div class="modal-backdrop" id="editDataModal">
		<div class="modal">
			<form method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=data&page=<?php echo $page; ?>">
				<input type="hidden" name="post_action" value="save_edit">
				<input type="hidden" name="old_row_data" id="edit_old_row_data">
				<div class="modal-header">
					<span>编辑行</span>
					<span style="cursor:pointer;" onclick="closeModal('editDataModal')">&times;</span>
				</div>
				<div class="modal-body" id="editFormBody">
					<!-- 动态生成数据框 -->
				</div>
				<div class="modal-footer">
					<button type="button" class="btn" onclick="closeModal('editDataModal')">取消</button>
					<button type="submit" class="btn btn-primary">确认</button>
				</div>
			</form>
		</div>
	</div>

	<!-- Modal 5: Drop Table（严格确认：必须手动输入表名） -->
	<?php if ($currentTable): ?>
	<div class="modal-backdrop" id="dropTableModal">
		<div class="modal">
			<form method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=<?php echo htmlspecialchars($action); ?>">
				<input type="hidden" name="post_action" value="drop_table">
				<div class="modal-header">
					<span style="color: var(--danger);">删除表</span>
					<span style="cursor:pointer;" onclick="closeModal('dropTableModal')">&times;</span>
				</div>
				<div class="modal-body">
					<div class="flash flash-error" style="margin-bottom:16px;">
						<strong>危险操作！</strong><br>
						此操作将永久删除数据表 <code><?php echo htmlspecialchars($currentTable); ?></code> 及其中的<strong>全部数据</strong>，且<strong>无法恢复</strong>。
					</div>
					<div class="form-group">
						<label>请输入表名 <code><?php echo htmlspecialchars($currentTable); ?></code> 以确认删除：</label>
						<input class="input" type="text" name="confirm_table_name" id="confirm_table_name"
							autocomplete="off" autocapitalize="off" spellcheck="false" required>
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn" onclick="closeModal('dropTableModal')">取消</button>
					<button type="submit" class="btn btn-danger" id="dropTableSubmit" disabled>永久删除</button>
				</div>
			</form>
		</div>
	</div>
	<?php endif; ?>

	<!-- Hidden Action Form -->
	<form id="actionForm" method="POST" action="?table=<?php echo urlencode($currentTable); ?>&action=<?php echo $action; ?>">
		<input type="hidden" name="post_action" id="form_post_action">
		<input type="hidden" name="col_name" id="form_col_name">
		<input type="hidden" name="old_row_data" id="form_old_row_data">
		<input type="hidden" name="page" id="form_page" value="<?php echo $page; ?>">
	</form>

	<script>
		function closeModal(id) { document.getElementById(id).style.display = 'none'; }
		function openAddDataModal() { document.getElementById('addDataModal').style.display = 'flex'; }
		function openAddColModal() { document.getElementById('addColModal').style.display = 'flex'; }

		const sidebar = document.getElementById('sidebar');
		const sidebarToggle = document.getElementById('sidebarToggle');
		function applySidebarState() {
			const isCollapsed = (sidebar.style.display === 'none');
			sidebarToggle.innerHTML = isCollapsed ? '«' : '☰';
			sidebar.style.display = isCollapsed ? 'flex' : 'none';
		}
		sidebarToggle.addEventListener('click', applySidebarState);

		function openEditColModal(col) {
			document.getElementById('old_col_name').value = col.Field;
			document.getElementById('edit_col_name').value = col.Field;
			document.getElementById('edit_col_type').value = col.Type;
			document.getElementById('edit_col_null').value = col.Null === 'YES' ? '1' : '0';
			document.getElementById('editColModal').style.display = 'flex';
		}

		function openEditDataModal(rowData) {
			document.getElementById('edit_old_row_data').value = JSON.stringify(rowData);

			const formBody = document.getElementById('editFormBody');
			formBody.innerHTML = '';

			for (const f in rowData) {
				const fieldWrapper = document.createElement('div');
				fieldWrapper.className = 'form-group';

				const label = document.createElement('label');
				label.textContent = f;
				fieldWrapper.appendChild(label);

				const textarea = document.createElement('textarea');
				textarea.className = 'input';
				textarea.name = `fields[${f}]`;
				textarea.value = rowData[f] === null ? '' : rowData[f];
				textarea.rows = Math.max(1, (textarea.value.match(/\n/g) || []).length + 1);
				fieldWrapper.appendChild(textarea);

				formBody.appendChild(fieldWrapper);
			}

			document.getElementById('editDataModal').style.display = 'flex';
		}

		function dropColumn(colName) {
			if (confirm(`Drop column \`${colName}\`?`)) {
				document.getElementById('form_post_action').value = 'drop_column';
				document.getElementById('form_col_name').value = colName;
				document.getElementById('actionForm').submit();
			}
		}

		function deleteRow(rowData) {
			if (confirm(`Delete this row?`)) {
				document.getElementById('form_post_action').value = 'delete_row';
				document.getElementById('form_old_row_data').value = JSON.stringify(rowData);
				document.getElementById('actionForm').submit();
			}
		}

		/* ===== 删除表：手动输入表名确认 ===== */
		const DROP_TABLE_NAME = <?php echo json_encode($currentTable); ?>;
		const dropTableModal = document.getElementById('dropTableModal');
		const confirmTableInput = document.getElementById('confirm_table_name');
		const dropTableSubmit = document.getElementById('dropTableSubmit');

		function openDropTableModal() {
			if (!DROP_TABLE_NAME || !dropTableModal) return;
			confirmTableInput.value = '';
			confirmTableInput.placeholder = DROP_TABLE_NAME;
			dropTableSubmit.disabled = true;
			dropTableModal.style.display = 'flex';
			setTimeout(() => confirmTableInput.focus(), 50);
		}

		if (dropTableModal) {
			confirmTableInput.addEventListener('input', function() {
				dropTableSubmit.disabled = (this.value !== DROP_TABLE_NAME);
			});

			// 提交前再校验一次（防止通过回车等方式绕过按钮状态）
			dropTableModal.querySelector('form').addEventListener('submit', function(e) {
				if (confirmTableInput.value !== DROP_TABLE_NAME) {
					e.preventDefault();
					dropTableSubmit.disabled = true;
					return false;
				}
			});
		}
	</script>
</body>
</html>