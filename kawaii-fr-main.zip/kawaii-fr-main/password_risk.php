<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// 登录检查
$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 权限检查：仅开发管理（devadmin=1）可访问
$checkStmt = $conn->prepare("SELECT devadmin, name, username_color, show_colorful_names FROM users WHERE uid = ? LIMIT 1");
$checkStmt->bind_param("i", $login_uid);
$checkStmt->execute();
$me = $checkStmt->get_result()->fetch_assoc();
$checkStmt->close();

if (!$me || $me['devadmin'] != 1) {
    header("Location: https://lmtoj.cn/");
    exit;
}

// 辅助函数：获取用户颜色
function getAchievementScore2($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    if (strtoupper($certType) !== 'OI') return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}
function getColorByTotalScore2($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}
function getUserColor2($user) {
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore2($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    return getColorByTotalScore2($total, (int)($user['admin'] ?? 0));
}
function isColorfulName2($user, $myShowColorful) {
    $achieve = min(getAchievementScore2($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    return $targetColorful && $myShowColorful;
}

// 检查并添加 devadmin 字段（如果不存在）
$colCheck = $conn->query("SHOW COLUMNS FROM users LIKE 'devadmin'");
if ($colCheck && $colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN devadmin TINYINT DEFAULT 0");
}

// 获取当前用户的 show_colorful_names 设置
$myShowColorful = 1;
$showPrefRes = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$login_uid} LIMIT 1");
if ($showPrefRes && $showPrefRes->num_rows > 0) {
    $myShowColorful = (int)($showPrefRes->fetch_assoc()['show_colorful_names']);
}

// 查询所有用户（包含密码哈希和颜色相关字段）
$sql = "SELECT uid, name, password, admin, devadmin, tag,
               practice_score, contribute_score, contest_score,
               base_credit, valuation, username_color, cert_type, cert_level
        FROM users
        ORDER BY uid ASC";
$result = $conn->query($sql);

$users = [];
$grouped = []; // 按密码分组
while ($row = $result->fetch_assoc()) {
    $row['color'] = getUserColor2($row);
    $row['isColorful'] = isColorfulName2($row, $myShowColorful);
    $users[] = $row;
    
    $pwd = $row['password'] ?? '';
    if (!isset($grouped[$pwd])) {
        $grouped[$pwd] = [];
    }
    $grouped[$pwd][] = $row;
}
$result->free();

// 过滤出有重复密码的组（>=2）
$duplicateGroups = [];
foreach ($grouped as $pwd => $members) {
    if (count($members) >= 2) {
        $duplicateGroups[] = [
            'password' => $pwd,
            'members' => $members
        ];
    }
}

// 按成员数量降序排序（方便查看最严重的重复组）
usort($duplicateGroups, function($a, $b) {
    return count($b['members']) - count($a['members']);
});

function safeContent2($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>密码风控 - lmtOJ</title>
<style>
:root {
    --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
    --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
    --border: #e6e1da; --border-light: #f0ece6;
    --accent: #6b8a74; --accent-hover: #55735e; --danger: #d9534f;
    --shadow: 0 2px 10px rgba(0,0,0,0.05); --radius: 10px; --radius-sm: 6px;
    --transition: 0.18s ease;
    --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
.navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
.navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
.user-info{display:flex;align-items:center;gap:6px;}
.user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
.user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
.main{max-width:1200px;margin:28px auto 40px;padding:0 20px;}
.card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
.card h2{font-size:20px;font-weight:600;margin-bottom:16px;}
.card h3{font-size:16px;font-weight:600;margin-bottom:12px;}
table{width:100%;border-collapse:collapse;font-size:14px;}
th{text-align:left;padding:10px 12px;background:#fafaf8;font-weight:500;color:var(--text-secondary);border-bottom:2px solid var(--border);font-size:13px;}
td{padding:10px 12px;border-bottom:1px solid var(--border-light);}
tr:hover{background:#fdfcf9;}
.btn{padding:6px 14px;border:none;border-radius:16px;cursor:pointer;font-size:12.5px;font-weight:500;transition:var(--transition);font-family:var(--font);}
.btn-blue{background:#5a9e6f;color:#fff;}
.btn-blue:hover{background:#4a855c;}
.btn-orange{background:#d4a24e;color:#fff;}
.btn-orange:hover{background:#b8893c;}
.username{font-weight:600;text-decoration:none;}
.username:hover{opacity:0.8;text-decoration:underline;}
.tag { border-radius:3px; padding:2px 9px; color:#fff; display:inline-block; margin:2px 5px; font-size:11.5px; font-weight:600; }
.badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:600;margin-left:6px;}
.badge-dev{background:#8e44ad;color:#fff;}
.badge-admin{background:#f39c12;color:#fff;}
.pwd-hash{font-family:'Consolas','Monaco',monospace;font-size:12px;word-break:break-all;color:#5a4a3a;background:#f3f0eb;padding:2px 6px;border-radius:3px;max-width:200px;display:inline-block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.group-card{border:1.5px solid var(--border);border-radius:var(--radius-sm);padding:16px;margin-bottom:16px;background:#fafaf8;}
.group-header{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;margin-bottom:12px;}
.group-count{font-size:14px;font-weight:600;color:var(--danger);}
.checkbox{width:16px;height:16px;cursor:pointer;accent-color:var(--accent);}
.copy-toast{position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#333;color:#fff;padding:10px 20px;border-radius:20px;font-size:14px;z-index:9999;opacity:0;transition:opacity 0.3s;pointer-events:none;}
@media(max-width:768px){.main{padding:0 12px;}.card{padding:18px 14px;}table{font-size:13px;}th,td{padding:8px 6px;}}
</style>
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <div class="card">
        <h2>🔐 密码风控面板</h2>
        <p style="color:var(--text-secondary);font-size:14px;margin-bottom:10px;">此页面仅开发管理可见。显示所有用户的密码存储文本（哈希值），并按相同密码分组，方便排查弱密码或共用密码风险。</p>
        
        <div style="margin-bottom:16px;">
            <label style="font-weight:500;margin-right:8px;">
                <input type="checkbox" id="selectAllGroups" class="checkbox" style="vertical-align:middle;"> 全选所有重复组
            </label>
            <button class="btn btn-orange" onclick="copySelectedGroups()">📋 复制勾选组的 UID（逗号分隔）</button>
        </div>

        <?php if (empty($duplicateGroups)): ?>
            <p style="color:var(--text-muted);">暂无重复密码组（所有用户密码均不同）。</p>
        <?php else: ?>
            <p style="margin-bottom:16px;color:var(--text-secondary);font-size:13px;">共发现 <strong style="color:var(--danger);"><?=count($duplicateGroups)?></strong> 组重复密码（至少2人共用）。</p>
            
            <?php foreach ($duplicateGroups as $idx => $group): ?>
            <div class="group-card">
                <div class="group-header">
                    <div>
                        <input type="checkbox" class="checkbox group-checkbox" data-group-index="<?=$idx?>" style="vertical-align:middle;margin-right:8px;">
                        <span class="group-count">组 <?=$idx+1?>（<?=count($group['members'])?> 人共用）</span>
                    </div>
                    <button class="btn btn-blue" onclick="copyGroupUids(<?=$idx?>)">📋 复制本组 UID</button>
                </div>
                <div style="margin-bottom:10px;">
                    <span style="font-size:12px;color:var(--text-muted);">密码哈希：</span>
                    <span class="pwd-hash" title="<?=safeContent2($group['password'])?>"><?=safeContent2($group['password'])?></span>
                </div>
                <table>
                    <tr>
                        <th width="80">UID</th>
                        <th>用户名</th>
                        <th>标签</th>
                        <th>权限</th>
                    </tr>
                    <?php foreach ($group['members'] as $member): ?>
                    <tr>
                        <td><?=$member['uid']?></td>
                        <td>
                            <a href="https://lmtoj.cn/user/<?=$member['uid']?>" class="username<?= $member['isColorful'] ? ' colorful' : '' ?>" <?= $member['isColorful'] ? '' : 'style="color: ' . $member['color'] . ';"' ?>>
                                <?=safeContent2($member['name'])?>
                            </a>
                        </td>
                        <td>
                            <?php if($member['tag']): ?>
                                <span class="tag" style="background: <?=$member['color']?>;"><?=safeContent2($member['tag'])?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($member['devadmin'] == 1): ?><span class="badge badge-dev">开发管理</span><?php endif; ?>
                            <?php if($member['admin'] == 1): ?><span class="badge badge-admin">管理员</span><?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="card">
        <h3>📊 全量用户密码存储文本（<?=count($users)?> 人）</h3>
        <table>
            <tr>
                <th width="60">UID</th>
                <th>用户名</th>
                <th>标签</th>
                <th>密码哈希（存储文本）</th>
                <th>权限</th>
            </tr>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?=$u['uid']?></td>
                <td>
                    <a href="https://lmtoj.cn/user/<?=$u['uid']?>" class="username<?= $u['isColorful'] ? ' colorful' : '' ?>" <?= $u['isColorful'] ? '' : 'style="color: ' . $u['color'] . ';"' ?>>
                        <?=safeContent2($u['name'])?>
                    </a>
                </td>
                <td>
                    <?php if($u['tag']): ?>
                        <span class="tag" style="background: <?=$u['color']?>;"><?=safeContent2($u['tag'])?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <span class="pwd-hash" title="<?=safeContent2($u['password'])?>"><?=safeContent2($u['password'])?></span>
                </td>
                <td>
                    <?php if($u['devadmin'] == 1): ?><span class="badge badge-dev">开发管理</span><?php endif; ?>
                    <?php if($u['admin'] == 1): ?><span class="badge badge-admin">管理员</span><?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>

<div class="copy-toast" id="copyToast">✅ 已复制到剪贴板</div>

<script>
// 存储所有组的数据
const duplicateGroups = <?= json_encode($duplicateGroups, JSON_UNESCAPED_UNICODE) ?>;

// 复制文本到剪贴板
function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(() => {
            showToast();
        }).catch(() => {
            fallbackCopy(text);
        });
    } else {
        fallbackCopy(text);
    }
}

function fallbackCopy(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    document.body.appendChild(textarea);
    textarea.select();
    try {
        document.execCommand('copy');
        showToast();
    } catch (e) {
        alert('复制失败，请手动复制：\n' + text);
    }
    document.body.removeChild(textarea);
}

function showToast() {
    const toast = document.getElementById('copyToast');
    toast.style.opacity = '1';
    setTimeout(() => {
        toast.style.opacity = '0';
    }, 2000);
}

// 复制单个组的 UID
function copyGroupUids(groupIndex) {
    const group = duplicateGroups[groupIndex];
    if (!group) return;
    const uids = group.members.map(m => m.uid).join(',');
    copyToClipboard(uids);
}

// 复制所有勾选组的 UID
function copySelectedGroups() {
    const checkboxes = document.querySelectorAll('.group-checkbox:checked');
    if (checkboxes.length === 0) {
        alert('请先勾选要复制的组');
        return;
    }
    const allUids = [];
    checkboxes.forEach(cb => {
        const idx = parseInt(cb.dataset.groupIndex);
        const group = duplicateGroups[idx];
        if (group) {
            group.members.forEach(m => allUids.push(m.uid));
        }
    });
    // 去重
    const uniqueUids = [...new Set(allUids)];
    copyToClipboard(uniqueUids.join(','));
}

// 全选/取消全选
document.getElementById('selectAllGroups').addEventListener('change', function() {
    document.querySelectorAll('.group-checkbox').forEach(cb => {
        cb.checked = this.checked;
    });
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>