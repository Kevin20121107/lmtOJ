<?php
session_start();
require_once __DIR__ . '/security.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

header("Content-Type:text/html;charset=utf-8");

if (!isset($_SESSION['uid'])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

$login_uid = (int)$_SESSION['uid'];
csrf_protect_request($login_uid > 0);
$userRow = $conn->query("SELECT name, admin, jinyan, avatar FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$is_admin = $userRow['admin'] ?? 0;
$login_name = $userRow['name'] ?? '';

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login.php");
    exit;
}

// 查询所有具有任意具体管理权限的用户
$adminList = $conn->query("
    SELECT uid, name, tag, avatar, sqadmin, proadmin, conadmin, artadmin, devadmin
    FROM users
    WHERE sqadmin = 1 OR proadmin = 1 OR conadmin = 1 OR artadmin = 1 OR devadmin = 1
    ORDER BY uid ASC
");

// 定义分类
$categories = [
    'sqadmin'  => '社区管理',
    'proadmin' => '题目管理',
    'conadmin'  => '比赛管理',
    'artadmin' => '文章管理',
    'devadmin' => '文件管理',
];

// 按分类存放用户
$categorized = [];
foreach ($categories as $field => $name) {
    $categorized[$field] = [];
}

while ($admin = $adminList->fetch_assoc()) {
    foreach ($categories as $field => $name) {
        if ($admin[$field] == 1) {
            $categorized[$field][] = $admin;
        }
    }
}

function safeContent($content) {
    $content = $content ?? '';
    return htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
}

function getFirstChar($name) {
    $name = trim($name ?? '?');
    if (mb_strlen($name) > 0) return mb_strtoupper(mb_substr($name, 0, 1));
    return '?';
}

/**
 * 修正图片路径：若为相对路径则补上前导斜杠，若已是完整URL则保留
 */
function getImgUrl($str) {
    $str = safeContent(trim($str));
    if (empty($str)) return '';
    if (strpos($str, 'http') === 0) {
        return $str;
    }
    return '/' . ltrim($str, '/');
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>管理名单 - lmtOJ</title>
    <style>
    :root {
        --bg: #f9f7f4;
        --card-bg: #ffffff;
        --nav-bg: #3d3a37;
        --nav-text: #f0ece6;
        --text: #2c2a28;
        --text-secondary: #7a736b;
        --text-muted: #a0988e;
        --border: #e6e1da;
        --border-light: #f0ece6;
        --accent: #6b8a74;
        --accent-hover: #55735e;
        --shadow: 0 2px 10px rgba(0,0,0,0.05);
        --radius: 10px;
        --transition: 0.18s ease;
        --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
        --tag-admin: #8e44ad;
    }

    * { margin:0; padding:0; box-sizing:border-box; }
    body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }
    a { color:var(--accent); text-decoration:none; font-weight:500; transition:var(--transition); }
    a:hover { color:var(--accent-hover); text-decoration:underline; }

    /* 导航栏 */
    .navbar {
        background:var(--nav-bg); height:54px; display:flex; align-items:center;
        justify-content:space-between; padding:0 28px; color:var(--nav-text);
        position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
    }
    .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
    .navbar h1 a { color:#f0ece6; text-decoration:none; }
    .user-info { display:flex; align-items:center; gap:6px; }
    .user-info a {
        color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px;
        border-radius:20px; transition:var(--transition); font-weight:500;
    }
    .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
    .user-info a.admin-link { color:#f5d76e; font-weight:600; }
    .bell-wrap {
        position:relative; font-size:20px; cursor:pointer; margin-right:20px;
        width:36px; height:36px; display:flex; align-items:center; justify-content:center;
        border-radius:50%; transition:var(--transition);
    }
    .bell-wrap:hover { background:rgba(255,255,255,0.08); }
    .red-dot {
        position:absolute; top:5px; right:5px; width:9px; height:9px;
        background:#f55353; border-radius:50%; border:1.5px solid #3d3a37;
    }

    /* 侧边栏 */
    .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; position:sticky; top:80px; flex-shrink:0; }
    .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px; }
    .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }

    .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
    .content { flex:1; min-width:0; }

    .card {
        background:var(--card-bg);
        border-radius:var(--radius);
        padding:26px 28px;
        margin-bottom:18px;
        box-shadow:var(--shadow);
    }
    .card h2 { font-size:18px; font-weight:600; margin-bottom:18px; color:var(--text); }

    .admin-item {
        display:flex;
        align-items:center;
        gap:14px;
        padding:14px 0;
        border-bottom:1px solid var(--border-light);
    }
    .admin-item:last-child { border-bottom:none; }

    .admin-avatar {
        width:48px;
        height:48px;
        border-radius:50%;
        background:var(--accent);
        color:#fff;
        display:flex;
        align-items:center;
        justify-content:center;
        font-size:20px;
        font-weight:700;
        overflow:hidden;
        flex-shrink:0;
    }
    .admin-avatar img { width:100%; height:100%; object-fit:cover; }

    .admin-info { flex:1; }
    .admin-name { font-size:15px; font-weight:600; text-decoration:none; color: var(--tag-admin); }
    .admin-name:hover { opacity:0.8; text-decoration:underline; }
    .admin-tag {
        display:inline-block;
        background: var(--tag-admin);
        color:#fff;
        font-size:11px;
        padding:2px 8px;
        border-radius:3px;
        font-weight:600;
        margin-left:6px;
    }
    .admin-uid { font-size:12px; color:var(--text-muted); }

    @media (max-width:768px) {
        .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; }
        .sidebar { width:100%; position:static; display:flex; }
        .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
        .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
        .card { padding:18px 14px; }
        .navbar { padding:0 14px; height:48px; }
    }
</style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="main">
    <?php include 'sidebar.php'; ?>

    <div class="content">
        <?php foreach ($categories as $field => $title): ?>
            <?php if (!empty($categorized[$field])): ?>
            <div class="card">
                <h2><?= safeContent($title) ?></h2>
                <?php foreach ($categorized[$field] as $admin): ?>
                <div class="admin-item">
                    <div class="admin-avatar">
                        <?php if(!empty($admin['avatar'])): ?>
                            <img src="<?= getImgUrl($admin['avatar']) ?>" alt="头像">
                        <?php else: ?>
                            <?= getFirstChar($admin['name']) ?>
                        <?php endif; ?>
                    </div>
                    <div class="admin-info">
                        <a href="https://lmtoj.cn/user/<?=$admin['uid']?>" class="admin-name"><?= safeContent($admin['name']) ?></a>
                        <?php if(!empty($admin['tag'])): ?>
                            <span class="admin-tag"><?= safeContent($admin['tag']) ?></span>
                        <?php endif; ?>
                        <div class="admin-uid">UID: <?= $admin['uid'] ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>