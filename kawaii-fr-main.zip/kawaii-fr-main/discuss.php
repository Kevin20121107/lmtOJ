<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- CSRF Token ----------
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function verifyCsrfToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
$csrf_token = generateCsrfToken();

// ---------- 积分颜色辅助函数 ----------
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getColorName($totalScore, $isAdmin) {
    if ($isAdmin) return 'purple';
    if ($totalScore < 0) return 'brown';
    if ($totalScore <= 10) return 'gray';
    if ($totalScore <= 20) return 'blue';
    if ($totalScore <= 45) return 'green';
    if ($totalScore <= 65) return 'orange';
    return 'red';
}

function getUserDisplay($user, $login_uid, $myShowColorful) {
    $uid = (int)($user['uid'] ?? 0);
    $base = (int)($user['base_credit'] ?? 10);
    $achieve = min(getAchievementScore($user['cert_type'] ?? '', (int)($user['cert_level'] ?? 0)), 20);
    $practice = min((int)($user['practice_score'] ?? 0), 20);
    $contribute = min((int)($user['contribute_score'] ?? 0), 30);
    $contest = min((int)($user['contest_score'] ?? 0), 20);
    $valuation = (int)($user['valuation'] ?? 0);
    $isBrown = ($valuation === -1);
    $total = $isBrown ? -1 : ($base + $achieve + $practice + $contribute + $contest);
    $admin = (int)($user['admin'] ?? 0);
    $color = getColorByTotalScore($total, $admin);
    $targetColorful = ($user['username_color'] ?? 'auto') === 'beautiful' && ($achieve >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
    $isColorful = false;
    if ($uid == $login_uid) {
        $isColorful = $targetColorful;
    } else {
        $isColorful = $targetColorful && $myShowColorful;
    }
    return [
        'color'      => $color,
        'isColorful' => $isColorful,
        'tag'        => $user['tag'] ?? '',
        'admin'      => $admin
    ];
}

// ---------- 自动建表/补字段 ----------
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'vote_enabled'");
if ($colCheck && $colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE discuss ADD COLUMN vote_enabled TINYINT DEFAULT 0");
}
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'upvotes'");
if ($colCheck && $colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE discuss ADD COLUMN upvotes INT DEFAULT 0");
}
$colCheck = $conn->query("SHOW COLUMNS FROM discuss LIKE 'downvotes'");
if ($colCheck && $colCheck->num_rows == 0) {
    $conn->query("ALTER TABLE discuss ADD COLUMN downvotes INT DEFAULT 0");
}
$conn->query("CREATE TABLE IF NOT EXISTS discuss_votes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tid INT NOT NULL,
    uid INT NOT NULL,
    vote TINYINT NOT NULL COMMENT '1=upvote, -1=downvote',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_vote (tid, uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 登录检查 ----------
$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// 获取当前用户权限
$is_admin = 0;
$sqadmin = 0;
$userJinyan = 0;
$myShowColorful = 1;
$unreadCount = 0;
if ($login_uid > 0) {
    $stmt = $conn->prepare("SELECT admin, sqadmin, jinyan, show_colorful_names FROM users WHERE uid = ? LIMIT 1");
    $stmt->bind_param("i", $login_uid);
    $stmt->execute();
    $adminRes = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($adminRes) {
        $is_admin = (int)$adminRes['admin'];
        $sqadmin = (int)$adminRes['sqadmin'];
        $userJinyan = (int)$adminRes['jinyan'];
        $myShowColorful = (int)($adminRes['show_colorful_names'] ?? 1);
    }
    $msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
    $msgStmt->bind_param("i", $login_uid);
    $msgStmt->execute();
    $msgRes = $msgStmt->get_result();
    if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
    $msgStmt->close();
}

$tid = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$cate = isset($_GET['cate']) ? (int)$_GET['cate'] : 0;
if ($tid > 0) {
    $sCate = $conn->prepare("SELECT category FROM discuss WHERE id = ?");
    $sCate->bind_param("i", $tid);
    $sCate->execute();
    $ansCate = $sCate->get_result()->fetch_assoc();
    if (isset($ansCate['category'])) $cate = $ansCate['category'];
}
// 工单版重定向
if ($cate == 3) {
    $query = $_SERVER['QUERY_STRING'];
    $newQuery = str_replace('cate=3', '', $query);
    $newQuery = ltrim($newQuery, '&');
    header("Location: https://lmtoj.cn/ticket/?" . $newQuery);
    exit;
}
if (!in_array($cate, [1, 2])) $cate = 2;

// ---------- 获取所有用户（用于 @） ----------
$nameToUid = [];
$uStmt = $conn->prepare("SELECT uid, name FROM users");
$uStmt->execute();
$uRes = $uStmt->get_result();
while ($u = $uRes->fetch_assoc()) {
    $nameToUid[$u['name']] = $u['uid'];
}
$uStmt->close();

// ---------- 辅助函数 ----------
function safeContent($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function getImgUrl($str) {
    $str = safeContent(trim($str));
    if (strpos($str, 'http') === 0) return $str;
    return '/' . ltrim($str, '/');
}
function beijingTime($utcStr) { return empty($utcStr) ? '' : date('Y-m-d H:i:s', strtotime($utcStr)); }
function getFirstChar($name) {
    $name = trim($name ?? '?');
    return mb_strlen($name) > 0 ? mb_strtoupper(mb_substr($name, 0, 1)) : '?';
}

// ========== 处理 AJAX 投票 ==========
if (isset($_GET['vote']) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) {
        echo json_encode(['success' => false, 'msg' => 'CSRF 验证失败']);
        exit;
    }
    if ($userJinyan == 1) {
        echo json_encode(['success' => false, 'msg' => '您已被禁言，无法投票']);
        exit;
    }
    $tid = (int)$_POST['tid'];
    $type = $_POST['type'] ?? '';
    if (!in_array($type, ['up', 'down'])) {
        echo json_encode(['success' => false, 'msg' => '无效的投票类型']);
        exit;
    }
    $vote_value = ($type === 'up') ? 1 : -1;

    // 检查帖子是否存在且启用投票
    $check = $conn->prepare("SELECT id, vote_enabled FROM discuss WHERE id = ? LIMIT 1");
    $check->bind_param("i", $tid);
    $check->execute();
    $topic = $check->get_result()->fetch_assoc();
    $check->close();
    if (!$topic || $topic['vote_enabled'] != 1) {
        echo json_encode(['success' => false, 'msg' => '该帖子未开启投票或不存在']);
        exit;
    }

    // 检查是否已投过票
    $voteStmt = $conn->prepare("SELECT vote FROM discuss_votes WHERE tid = ? AND uid = ?");
    $voteStmt->bind_param("ii", $tid, $login_uid);
    $voteStmt->execute();
    $existing = $voteStmt->get_result()->fetch_assoc();
    $voteStmt->close();

    $conn->begin_transaction();
    try {
        if ($existing) {
            $old_vote = $existing['vote'];
            if ($old_vote == $vote_value) {
                // 相同投票，视为取消投票
                $del = $conn->prepare("DELETE FROM discuss_votes WHERE tid = ? AND uid = ?");
                $del->bind_param("ii", $tid, $login_uid);
                $del->execute();
                $del->close();
                // 更新计数
                if ($vote_value == 1) {
                    $conn->query("UPDATE discuss SET upvotes = upvotes - 1 WHERE id = $tid");
                } else {
                    $conn->query("UPDATE discuss SET downvotes = downvotes - 1 WHERE id = $tid");
                }
                $action = 'removed';
            } else {
                // 更改投票
                $upd = $conn->prepare("UPDATE discuss_votes SET vote = ?, updated_at = NOW() WHERE tid = ? AND uid = ?");
                $upd->bind_param("iii", $vote_value, $tid, $login_uid);
                $upd->execute();
                $upd->close();
                // 更新计数：先减旧，再加新
                if ($old_vote == 1) $conn->query("UPDATE discuss SET upvotes = upvotes - 1 WHERE id = $tid");
                else $conn->query("UPDATE discuss SET downvotes = downvotes - 1 WHERE id = $tid");
                if ($vote_value == 1) $conn->query("UPDATE discuss SET upvotes = upvotes + 1 WHERE id = $tid");
                else $conn->query("UPDATE discuss SET downvotes = downvotes + 1 WHERE id = $tid");
                $action = 'changed';
            }
        } else {
            // 新增投票
            $ins = $conn->prepare("INSERT INTO discuss_votes (tid, uid, vote) VALUES (?, ?, ?)");
            $ins->bind_param("iii", $tid, $login_uid, $vote_value);
            $ins->execute();
            $ins->close();
            if ($vote_value == 1) {
                $conn->query("UPDATE discuss SET upvotes = upvotes + 1 WHERE id = $tid");
            } else {
                $conn->query("UPDATE discuss SET downvotes = downvotes + 1 WHERE id = $tid");
            }
            $action = 'added';
        }
        $conn->commit();

        // 获取最新的计数
        $stats = $conn->query("SELECT upvotes, downvotes FROM discuss WHERE id = $tid")->fetch_assoc();
        echo json_encode([
            'success' => true,
            'upvotes' => (int)$stats['upvotes'],
            'downvotes' => (int)$stats['downvotes'],
            'action' => $action,
            'user_vote' => $action === 'removed' ? 0 : $vote_value
        ]);
    } catch (Exception $e) {
        $conn->rollback();
        echo json_encode(['success' => false, 'msg' => '数据库错误：' . $e->getMessage()]);
    }
    exit;
}

// ========== 处理删除（POST） ==========
if (isset($_POST['del_tid']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $dtid = (int)$_POST['del_tid'];
    $chk = $conn->prepare("SELECT uid FROM discuss WHERE id = ? LIMIT 1");
    $chk->bind_param("i", $dtid);
    $chk->execute();
    $row = $chk->get_result()->fetch_assoc();
    $chk->close();
    if ($row && ($sqadmin || $row['uid'] == $login_uid)) {
        $del = $conn->prepare("DELETE FROM discuss WHERE id = ?");
        $del->bind_param("i", $dtid);
        $del->execute();
        $del->close();
        $del2 = $conn->prepare("DELETE FROM discuss_reply WHERE tid = ?");
        $del2->bind_param("i", $dtid);
        $del2->execute();
        $del2->close();
        $del3 = $conn->prepare("DELETE FROM discuss_votes WHERE tid = ?");
        $del3->bind_param("i", $dtid);
        $del3->execute();
        $del3->close();
    }
    header("Location: https://lmtoj.cn/discuss/cate/0{$cate}");
    exit;
}
if (isset($_POST['del_rid']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $drid = (int)$_POST['del_rid'];
    $chk = $conn->prepare("SELECT uid FROM discuss_reply WHERE id = ? LIMIT 1");
    $chk->bind_param("i", $drid);
    $chk->execute();
    $row = $chk->get_result()->fetch_assoc();
    $chk->close();
    if ($row && ($is_admin || $row['uid'] == $login_uid)) {
        $del = $conn->prepare("DELETE FROM discuss_reply WHERE id = ?");
        $del->bind_param("i", $drid);
        $del->execute();
        $del->close();
    }
    header("Location: https://lmtoj.cn/discuss/{$tid}");
    exit;
}

// ========== 编辑帖子 ==========
if (isset($_POST['edit_tid'], $_POST['edit_title'], $_POST['edit_content']) && verifyCsrfToken($_POST['csrf_token'] ?? '')) {
    $etid = (int)$_POST['edit_tid'];
    $etitle = trim($_POST['edit_title']);
    $econtent = trim($_POST['edit_content']);
    $evote = isset($_POST['edit_vote_enabled']) ? 1 : 0;
    $chk = $conn->prepare("SELECT uid FROM discuss WHERE id = ? LIMIT 1");
    $chk->bind_param("i", $etid);
    $chk->execute();
    $row = $chk->get_result()->fetch_assoc();
    $chk->close();
    if ($row && ($sqadmin || $row['uid'] == $login_uid) && !empty($etitle) && !empty($econtent)) {
        $upd = $conn->prepare("UPDATE discuss SET title = ?, content = ?, vote_enabled = ? WHERE id = ?");
        $upd->bind_param("ssii", $etitle, $econtent, $evote, $etid);
        $upd->execute();
        $upd->close();
    }
    header("Location: https://lmtoj.cn/discuss/{$etid}");
    exit;
}

// ========== 发布新帖 ==========
if ($tid === 0 && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_title'], $_POST['new_content'], $_POST['new_cate'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    $ncate = (int)$_POST['new_cate'];
    $title = trim($_POST['new_title']);
    $content = trim($_POST['new_content']);
    $vote_enabled = isset($_POST['vote_enabled']) ? 1 : 0;
    if (!in_array($ncate, [1,2])) exit;
    if ($ncate == 1 && !$is_admin) exit;
    if ($userJinyan == 1) {
        header("Location: https://lmtoj.cn/discuss/cate/0{$ncate}?error=jinyan");
        exit;
    }
    if (!empty($title) && !empty($content)) {
        $now = date('Y-m-d H:i:s');
        $ins = $conn->prepare("INSERT INTO discuss (uid, title, content, category, vote_enabled, create_time) VALUES (?, ?, ?, ?, ?, ?)");
        $ins->bind_param("issiis", $login_uid, $title, $content, $ncate, $vote_enabled, $now);
        $ins->execute();
        $ins->close();
    }
    header("Location: https://lmtoj.cn/discuss/cate/0{$ncate}");
    exit;
}

// ========== 回复帖子 ==========
if ($tid > 0 && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_content']) && !isset($_POST['edit_tid']) && !isset($_POST['del_tid'])) {
    if (!verifyCsrfToken($_POST['csrf_token'] ?? '')) die('CSRF 验证失败');
    if ($userJinyan == 1) {
        header("Location: https://lmtoj.cn/discuss/{$tid}?error=jinyan");
        exit;
    }
    $reply_content = trim($_POST['reply_content']);
    if (!empty($reply_content)) {
        $nowTime = date('Y-m-d H:i:s');
        $ins = $conn->prepare("INSERT INTO discuss_reply(tid, uid, content, create_time, admin) VALUES (?, ?, ?, ?, ?)");
        $ins->bind_param("iissi", $tid, $login_uid, $reply_content, $nowTime, $is_admin);
        $ins->execute();
        $ins->close();
        preg_match_all('/@([\w_\x{4e00}-\x{9fa5}]+)/u', $reply_content, $atMatches);
        $atNames = array_unique($atMatches[1]);
        $tStmt = $conn->prepare("SELECT title FROM discuss WHERE id = ? LIMIT 1");
        $tStmt->bind_param("i", $tid);
        $tStmt->execute();
        $tRes = $tStmt->get_result()->fetch_assoc();
        $topicTitle = $tRes['title'] ?? "帖子#" . $tid;
        $tStmt->close();
        foreach ($atNames as $atName) {
            $uStmt = $conn->prepare("SELECT uid FROM users WHERE name = ? LIMIT 1");
            $uStmt->bind_param("s", $atName);
            $uStmt->execute();
            $targetUser = $uStmt->get_result()->fetch_assoc();
            $uStmt->close();
            if ($targetUser && $targetUser['uid'] != $login_uid) {
                $nStmt = $conn->prepare("INSERT INTO notice(uid, atid, tid, topic_title, create_time, is_read) VALUES (?, ?, ?, ?, ?, 0)");
                $nStmt->bind_param("iiiss", $targetUser['uid'], $login_uid, $tid, $topicTitle, $nowTime);
                $nStmt->execute();
                $nStmt->close();
            }
        }
    }
    header("Location: https://lmtoj.cn/discuss/{$tid}");
    exit;
}

// ========== 获取数据 ==========
$topicInfo = [];
$replyList = [];
$topicList = [];
$totalPage = 1;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$limit = 15;
$offset = ($page - 1) * $limit;
$errorMsg = '';
if (isset($_GET['error']) && $_GET['error'] === 'jinyan') {
    $errorMsg = '您已被禁言，无法进行此操作。';
}

// 构建帖子数据
if ($tid > 0) {
    // 主帖
    $tStmt = $conn->prepare("SELECT * FROM discuss WHERE id = ? LIMIT 1");
    $tStmt->bind_param("i", $tid);
    $tStmt->execute();
    $tRes = $tStmt->get_result();
    if ($tRes->num_rows === 0) { header("Location: https://lmtoj.cn/discuss/cate/0{$cate}"); exit; }
    $topicInfo = $tRes->fetch_assoc();
    $tStmt->close();

    // 作者信息
    $aStmt = $conn->prepare("SELECT uid, name, admin, tag, avatar, practice_score, contribute_score, contest_score, base_credit, valuation, username_color, cert_type, cert_level FROM users WHERE uid = ? LIMIT 1");
    $aStmt->bind_param("i", $topicInfo['uid']);
    $aStmt->execute();
    $authorInfo = $aStmt->get_result()->fetch_assoc();
    $aStmt->close();
    if (!$authorInfo) {
        $authorInfo = ['uid' => 0, 'name' => '未知用户', 'admin' => 0, 'tag' => '', 'avatar' => '',
            'practice_score' => 0, 'contribute_score' => 0, 'contest_score' => 0,
            'base_credit' => 10, 'valuation' => 0, 'username_color' => 'auto',
            'cert_type' => '', 'cert_level' => 0];
    }
    $authorInfo['uid'] = $topicInfo['uid'];
    $authorDisplay = getUserDisplay($authorInfo, $login_uid, $myShowColorful);
    $authorInfo['display'] = $authorDisplay;

    // 当前用户的投票状态
    $userVote = 0;
    if ($topicInfo['vote_enabled'] == 1) {
        $uv = $conn->prepare("SELECT vote FROM discuss_votes WHERE tid = ? AND uid = ?");
        $uv->bind_param("ii", $tid, $login_uid);
        $uv->execute();
        $voteRow = $uv->get_result()->fetch_assoc();
        $uv->close();
        $userVote = $voteRow ? (int)$voteRow['vote'] : 0;
    }

    // 回复数
    $cStmt = $conn->prepare("SELECT COUNT(*) AS c FROM discuss_reply WHERE tid = ?");
    $cStmt->bind_param("i", $tid);
    $cStmt->execute();
    $replyCount = $cStmt->get_result()->fetch_assoc()['c'];
    $cStmt->close();
    $totalPage = ceil($replyCount / $limit);

    // 回复列表
    $rStmt = $conn->prepare("SELECT r.*, u.name, u.tag, u.admin AS uadmin, u.avatar, u.practice_score, u.contribute_score, u.contest_score, u.base_credit, u.valuation, u.username_color, u.cert_type, u.cert_level FROM discuss_reply r LEFT JOIN users u ON r.uid = u.uid WHERE r.tid = ? ORDER BY r.create_time ASC LIMIT ?, ?");
    $rStmt->bind_param("iii", $tid, $offset, $limit);
    $rStmt->execute();
    $rRes = $rStmt->get_result();
    while ($row = $rRes->fetch_assoc()) {
        if (!$row['name']) {
            $row['name'] = '已注销';
            $row['tag'] = '';
            $row['uadmin'] = 0;
            $row['avatar'] = '';
            $row['practice_score'] = 0;
            $row['contribute_score'] = 0;
            $row['contest_score'] = 0;
            $row['base_credit'] = 10;
            $row['valuation'] = 0;
            $row['username_color'] = 'auto';
            $row['cert_type'] = '';
            $row['cert_level'] = 0;
        }
        $row['display'] = getUserDisplay($row, $login_uid, $myShowColorful);
        $replyList[] = $row;
    }
    $rStmt->close();
} else {
    // 列表
    $where = " d.category = ? ";
    $params = [$cate];
    $types = "i";
    $countStmt = $conn->prepare("SELECT COUNT(*) AS c FROM discuss d WHERE $where");
    $countStmt->bind_param($types, ...$params);
    $countStmt->execute();
    $topicCount = $countStmt->get_result()->fetch_assoc()['c'];
    $countStmt->close();
    $totalPage = ceil($topicCount / $limit);

    $listStmt = $conn->prepare("SELECT d.*, u.name, u.tag, u.admin, u.practice_score, u.contribute_score, u.contest_score, u.base_credit, u.valuation, u.username_color, u.cert_type, u.cert_level FROM discuss d LEFT JOIN users u ON d.uid = u.uid WHERE $where ORDER BY d.create_time DESC LIMIT ?, ?");
    $params[] = $offset;
    $params[] = $limit;
    $types .= "ii";
    $listStmt->bind_param($types, ...$params);
    $listStmt->execute();
    $listRes = $listStmt->get_result();
    while ($row = $listRes->fetch_assoc()) {
        if (!$row['name']) {
            $row['name'] = '已注销';
            $row['tag'] = '';
            $row['admin'] = 0;
            $row['practice_score'] = 0;
            $row['contribute_score'] = 0;
            $row['contest_score'] = 0;
            $row['base_credit'] = 10;
            $row['valuation'] = 0;
            $row['username_color'] = 'auto';
            $row['cert_type'] = '';
            $row['cert_level'] = 0;
        }
        $row['display'] = getUserDisplay($row, $login_uid, $myShowColorful);
        $topicList[] = $row;
    }
    $listStmt->close();
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>讨论区 - lmtOJ</title>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/contrib/auto-render.min.js"></script>
<link rel="stylesheet" href="/css/katex.min.css" />
<style>
/* ---------- 原有样式（保持不变） ---------- */
:root {
    --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
    --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
    --border: #e6e1da; --border-light: #f0ece6;
    --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
    --danger: #d9534f; --danger-hover: #c0392b;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05);
    --radius: 10px; --radius-sm: 6px; --transition: 0.18s ease;
    --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif;
    --font-mono: 'JetBrains Mono', 'Consolas', monospace;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;}
.navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
.navbar h1{font-size:17px;font-weight:600;color:#f0ece6;}
.bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
.bell-wrap:hover{background:rgba(255,255,255,0.08);}
.red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
@keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
.user-info{display:flex;align-items:center;gap:6px;}
.user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
.user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
.user-info a.admin-link{color:#f5d76e;font-weight:600;}
.main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
.sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
.sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;}
.sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
.content{flex:1;min-width:0;}
a{color:var(--accent);text-decoration:none;font-weight:500;}
a:hover{color:var(--accent-hover);text-decoration:underline;}
.back-btn{display:inline-flex;align-items:center;gap:6px;margin-bottom:18px;padding:8px 18px;background:var(--card-bg);color:var(--text);border-radius:20px;font-size:13.5px;font-weight:500;border:1px solid var(--border);box-shadow:var(--shadow-sm);}
.back-btn:hover{background:var(--accent-light);border-color:var(--accent);color:var(--accent);text-decoration:none;}
.card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:20px;}
.card h2,.card h3{font-size:18px;font-weight:600;margin-bottom:20px;}
input[type="text"],select,textarea{width:100%;padding:10px 14px;border:1.5px solid var(--border);border-radius:var(--radius-sm);font-size:14px;outline:none;margin-bottom:16px;background:#fdfdfc;font-family:var(--font);transition:var(--transition);}
input[type="text"]:focus,textarea:focus,select:focus{border-color:var(--accent);box-shadow:0 0 0 3px rgba(107,138,116,0.08);background:#fff;}
.edit-wrap{display:flex;gap:16px;width:100%;}
.edit-box{width:50%;}
.preview-box{width:50%;word-wrap:break-word;word-break:break-all;white-space:normal;}
textarea{min-height:220px;resize:vertical;font-family:var(--font);}
.preview-box{border:1.5px solid var(--border-light);border-radius:var(--radius-sm);padding:14px;min-height:220px;overflow-y:auto;background:#fafaf8;font-size:14px;}
button{padding:9px 22px;background:var(--accent);color:#fff;border:none;border-radius:20px;cursor:pointer;font-size:14px;font-weight:500;transition:var(--transition);}
button:hover{background:var(--accent-hover);box-shadow:0 2px 8px rgba(107,138,116,0.25);}
.btn-sm{padding:4px 10px;font-size:12px;margin:0 4px;border-radius:4px;border:none;cursor:pointer;text-decoration:none;display:inline-block;font-weight:500;}
.btn-danger{background:var(--danger);color:#fff;}
.btn-danger:hover{background:var(--danger-hover);}
.btn-green{background:#5a9e6f;color:#fff;}
.btn-green:hover{background:#4a855c;}
.topic-item{padding:16px 0;border-bottom:1px solid var(--border-light);}
.topic-title{font-size:16px;font-weight:600;margin-bottom:8px;}
.topic-title a{color:var(--text);}
.topic-title a:hover{color:var(--accent);}
.topic-meta{font-size:13px;color:var(--text-muted);}
.md-content{line-height:1.8;color:var(--text);}
.md-content p{margin:8px 0;}
.md-content blockquote{border-left:4px solid var(--accent);padding:8px 14px;margin:12px 0;background:#fafaf8;color:#5a5550;border-radius:0 4px 4px 0;}
.md-content pre{background:#2b2a27;color:#e8e4dd;padding:14px 16px;border-radius:var(--radius-sm);overflow-x:auto;margin:12px 0;font-family:var(--font-mono);font-size:13px;}
.md-content code{font-family:var(--font-mono);background:#f3f0eb;padding:2px 6px;border-radius:3px;color:#5a4a3a;}
.md-content pre code{background:transparent;padding:0;color:inherit;}
.md-content img { max-width: 100%; height: auto; border-radius: 4px; margin: 6px 0; }
.reply-item{padding:16px 0;border-bottom:1px solid var(--border-light);}
.reply-meta{font-size:13px;color:var(--text-muted);margin-bottom:10px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.reply-avatar{width:32px;height:32px;border-radius:50%;background:var(--accent);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;overflow:hidden;flex-shrink:0;}
.reply-avatar img{width:100%;height:100%;object-fit:cover;}
.cat-nav,.filter-line{margin-bottom:20px;display:flex;flex-wrap:wrap;gap:8px;}
.cat-nav a{display:inline-block;padding:7px 16px;background:#f5f2ed;border-radius:20px;text-decoration:none;color:var(--text-secondary);font-size:13.5px;font-weight:500;transition:var(--transition);}
.cat-nav a.active{background:var(--accent);color:#fff;}
.at-user{color:var(--accent);text-decoration:none;font-weight:500;}
.at-user:hover{text-decoration:underline;}
.page-bar{display:flex;align-items:center;gap:6px;margin-top:16px;flex-wrap:wrap;}
.page-bar a{padding:6px 12px;border:1.5px solid var(--border);border-radius:20px;text-decoration:none;color:var(--text);font-size:13px;font-weight:500;background:#fff;}
.page-bar a:hover{border-color:var(--accent);color:var(--accent);background:var(--accent-light);}
.page-bar a.active{background:var(--accent);color:#fff;border-color:var(--accent);}
.page-ellipsis{padding:6px 4px;color:var(--text-muted);font-size:13px;}
.ben-name { font-weight:600; text-decoration:none; font-size:14px; transition:color 0.2s; }
.ben-name:hover { opacity:0.8; text-decoration:underline; }
.ben-name.colorful {
    color: #f1948a;
    animation: colorful 3s linear infinite;
    text-shadow: 0 0 10px rgba(0,0,0,0.2);
}
@keyframes colorful {
    0% { color: #f1948a; }
    17% { color: #f5b041; }
    33% { color: #f7dc6f; }
    50% { color: #82e0aa; }
    67% { color: #85c1e9; }
    83% { color: #bb8fce; }
    100% { color: #f1948a; }
}
.tag {
    border-radius:3px;
    padding:2px 9px;
    color:#fff;
    display:inline-block;
    margin:2px 5px;
    font-size:11.5px;
    font-weight:600;
}
.tag.colorful-bg {
    animation: colorfulBg 3s linear infinite;
}
@keyframes colorfulBg {
    0% { background-color: #f1948a; }
    17% { background-color: #f5b041; }
    33% { background-color: #f7dc6f; }
    50% { background-color: #82e0aa; }
    67% { background-color: #85c1e9; }
    83% { background-color: #bb8fce; }
    100% { background-color: #f1948a; }
}
.error-box{background:#fde8e8;border:1px solid #f5c6c6;color:#a94442;padding:12px 16px;border-radius:var(--radius-sm);margin-bottom:16px;}
/* ===== 投票样式 ===== */
.vote-container {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    margin: 6px 0 12px 0;
    padding: 6px 12px;
    background: var(--bg);
    border-radius: 20px;
    border: 1px solid var(--border);
}
.vote-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 18px;
    padding: 2px 8px;
    border-radius: 4px;
    transition: 0.2s;
    color: var(--text-muted);
}
.vote-btn:hover { background: var(--accent-light); }
.vote-btn.active-up { color: #2e7d32; }
.vote-btn.active-down { color: #c62828; }
.vote-count { font-size: 15px; font-weight: 600; color: var(--text); min-width: 30px; text-align: center; }
.vote-score { font-size: 14px; font-weight: 600; color: var(--text-secondary); margin-left: 4px; }
@media(max-width:768px){
    .main{flex-direction:column;padding:0 12px;}
    .sidebar{width:100%;position:static;display:flex;}
    .sidebar a{flex:1 1 auto;padding:11px 10px;font-size:13px;border-left:none;border-bottom:2px solid transparent;}
    .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
    .edit-wrap{flex-direction:column;}
    .edit-box,.preview-box{width:100%;}
    .card{padding:18px 14px;}
}
</style>
</head>
<body>
<script src="/js/markdown-it.min.js"></script>
<script src="/js/katex.min.js"></script>
<script src="/js/texmath.min.js"></script>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if ($errorMsg): ?>
            <div class="error-box"><?=safeContent($errorMsg)?></div>
        <?php endif; ?>
        <?php if ($tid === 0): ?>
            <!-- 列表页 -->
            <div class="cat-nav">
                <a href="https://lmtoj.cn/discuss/cate/01" class="<?=$cate==1?'active':''?>">站务版</a>
                <a href="https://lmtoj.cn/discuss/cate/02" class="<?=$cate==2?'active':''?>">学术版</a>
            </div>
            <div class="card">
                <h2>发布新帖子</h2>
                <?php if ($userJinyan==1): ?>
                    <p style="color:var(--danger);">您已被禁言</p>
                <?php elseif($cate == 1 && !$is_admin): ?>
                    <p style="color:var(--danger);">站务区仅管理员可发帖</p>
                <?php else: ?>
                    <form method="post" id="newTopicForm">
                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                        <input type="text" name="new_title" placeholder="请输入帖子标题" required>
                        <input type="hidden" name="new_cate" value="<?=$cate?>">
                        <div class="edit-wrap">
                            <div class="edit-box"><textarea id="postEditor" name="new_content" placeholder="支持 Markdown / LaTeX 公式、@用户"></textarea></div>
                            <div class="preview-box" id="postPreview">预览区域</div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <label><input type="checkbox" name="vote_enabled" value="1"> 启用投票（Upvote / Downvote）</label>
                        </div>
                        <button type="submit" id="submitBtn">发布帖子</button>
                    </form>
                <?php endif; ?>
            </div>
            <div class="card">
                <h2><?= $cate==1 ? '站务版列表' : '学术版列表' ?></h2>
                <?php if (empty($topicList)): ?><p style="color:var(--text-muted);">暂无内容</p>
                <?php else: ?>
                    <?php foreach ($topicList as $item):
                        $disp = $item['display'];
                        $uid = $item['uid'] ?? 0;
                    ?>
                        <div class="topic-item">
                            <div class="topic-title">
                                <a href="https://lmtoj.cn/discuss/<?=$item['id']?>"><?=safeContent($item['title'])?></a>
                            </div>
                            <div class="topic-meta">
                                <a href="https://lmtoj.cn/user/<?=$uid?>" class="ben-name<?= $disp['isColorful'] ? ' colorful' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="color: ' . $disp['color'] . ';"' ?>>
                                    <?=safeContent($item['name'])?>
                                </a>
                                <?php if($disp['tag']): ?>
                                    <span class="tag<?= $disp['isColorful'] ? ' colorful-bg' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="background: ' . $disp['color'] . ';"' ?>>
                                        <?=safeContent($disp['tag'])?>
                                    </span>
                                <?php endif; ?>
                                 · <?=beijingTime($item['create_time'])?>
                                <?php if ($sqadmin || $uid == $login_uid): ?>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                                        <input type="hidden" name="del_tid" value="<?=$item['id']?>">
                                        <button type="submit" class="btn-sm btn-danger">删除</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if($totalPage > 1): ?>
                <div class="page-bar">
                    <?php if($page > 1): ?><a href="https://lmtoj.cn/discuss/cate/0<?=$cate?>?page=<?=$page-1?>">上一页</a><?php endif; ?>
                    <?php $shown = [1]; for($i=max(2,$page-2); $i<=min($totalPage-1,$page+2); $i++) $shown[]=$i; if($totalPage>1) $shown[]=$totalPage; $shown=array_unique($shown); sort($shown); $prev=0;
                    foreach($shown as $i): if($i-$prev>1) echo '<span class="page-ellipsis">...</span>'; ?>
                        <a href="https://lmtoj.cn/discuss/cate/0<?=$cate?>?page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a>
                    <?php $prev=$i; endforeach; ?>
                    <?php if($page<$totalPage): ?><a href="https://lmtoj.cn/discuss/cate/0<?=$cate?>?page=<?=$page+1?>">下一页</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <!-- 详情页 -->
            <a href="https://lmtoj.cn/discuss/cate/0<?=$cate?>" class="back-btn">← 返回列表</a>
            <div class="card">
                <?php $canEdit = $sqadmin || $topicInfo['uid'] == $login_uid; ?>
                <?php if ($canEdit): ?>
                    <h2>编辑帖子</h2>
                    <form method="post" id="editForm">
                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                        <input type="hidden" name="edit_tid" value="<?=$topicInfo['id']?>">
                        <input type="text" name="edit_title" value="<?=safeContent($topicInfo['title'])?>" required>
                        <div class="edit-wrap">
                            <div class="edit-box"><textarea id="editEditor" name="edit_content" required><?=safeContent($topicInfo['content'])?></textarea></div>
                            <div class="preview-box" id="editPreview"></div>
                        </div>
                        <div style="margin-bottom:16px;">
                            <label><input type="checkbox" name="edit_vote_enabled" value="1" <?=$topicInfo['vote_enabled']==1?'checked':''?>> 启用投票</label>
                        </div>
                        <button type="submit" id="editSubmitBtn">保存修改</button>
                    </form>
                    <hr style="margin:20px 0;border:0;border-top:1px solid var(--border-light);">
                <?php endif; ?>
                <h2><?=safeContent($topicInfo['title'])?></h2>
                <div class="topic-meta" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                    <span class="reply-avatar">
                        <?php if (!empty($authorInfo['avatar'])): ?>
                            <img src="<?=getImgUrl($authorInfo['avatar'])?>" alt="avatar">
                        <?php else: ?>
                            <?=getFirstChar($authorInfo['name'])?>
                        <?php endif; ?>
                    </span>
                    <a href="https://lmtoj.cn/user/<?=$topicInfo['uid']?>" class="ben-name<?= $authorInfo['display']['isColorful'] ? ' colorful' : '' ?>" <?= $authorInfo['display']['isColorful'] ? '' : 'style="color: ' . $authorInfo['display']['color'] . ';"' ?>>
                        <?=safeContent($authorInfo['name'])?>
                    </a>
                    <?php if($authorInfo['display']['tag']): ?>
                        <span class="tag<?= $authorInfo['display']['isColorful'] ? ' colorful-bg' : '' ?>" <?= $authorInfo['display']['isColorful'] ? '' : 'style="background: ' . $authorInfo['display']['color'] . ';"' ?>>
                            <?=safeContent($authorInfo['display']['tag'])?>
                        </span>
                    <?php endif; ?>
                    · <?=beijingTime($topicInfo['create_time'])?>
                    <?php if ($sqadmin || $topicInfo['uid'] == $login_uid): ?>
                        <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                            <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                            <input type="hidden" name="del_tid" value="<?=$topicInfo['id']?>">
                            <button type="submit" class="btn-sm btn-danger">删除帖子</button>
                        </form>
                    <?php endif; ?>
                </div>
                <?php if ($topicInfo['vote_enabled'] == 1): ?>
                <div class="vote-container" id="vote-container">
                    <button class="vote-btn <?=$userVote==1?'active-up':''?>" id="vote-up" data-tid="<?=$tid?>" data-type="up">👍</button>
                    <span class="vote-count" id="vote-up-count"><?=$topicInfo['upvotes']?></span>
                    <span class="vote-score">·</span>
                    <span class="vote-count" id="vote-down-count"><?=$topicInfo['downvotes']?></span>
                    <button class="vote-btn <?=$userVote==-1?'active-down':''?>" id="vote-down" data-tid="<?=$tid?>" data-type="down">👎</button>
                    <span style="font-size:13px; color:var(--text-muted); margin-left:4px;">
                        净分 <span id="vote-net-score"><?=$topicInfo['upvotes'] - $topicInfo['downvotes']?></span>
                    </span>
                </div>
                <?php endif; ?>
                <div class="md-content" data-raw="<?=safeContent($topicInfo['content'])?>"></div>
            </div>
            <div class="card">
                <h3>全部回复</h3>
                <?php if (empty($replyList)): ?><p style="color:var(--text-muted);">暂无回复</p>
                <?php else: ?>
                    <?php foreach ($replyList as $rep):
                        $disp = $rep['display'];
                        $uid = $rep['uid'] ?? 0;
                    ?>
                        <div class="reply-item">
                            <div class="reply-meta">
                                <span class="reply-avatar">
                                    <?php if (!empty($rep['avatar'])): ?>
                                        <img src="<?=getImgUrl($rep['avatar'])?>" alt="avatar">
                                    <?php else: ?>
                                        <?=getFirstChar($rep['name'])?>
                                    <?php endif; ?>
                                </span>
                                <a href="https://lmtoj.cn/user/<?=$uid?>" class="ben-name<?= $disp['isColorful'] ? ' colorful' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="color: ' . $disp['color'] . ';"' ?>>
                                    <?=safeContent($rep['name'])?>
                                </a>
                                <?php if($disp['tag']): ?>
                                    <span class="tag<?= $disp['isColorful'] ? ' colorful-bg' : '' ?>" <?= $disp['isColorful'] ? '' : 'style="background: ' . $disp['color'] . ';"' ?>>
                                        <?=safeContent($disp['tag'])?>
                                    </span>
                                <?php endif; ?>
                                · <?=beijingTime($rep['create_time'])?>
                                <?php if ($sqadmin || $uid == $login_uid): ?>
                                    <form method="post" style="display:inline;" onsubmit="return confirm('确定删除？');">
                                        <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                                        <input type="hidden" name="del_rid" value="<?=$rep['id']?>">
                                        <button type="submit" class="btn-sm btn-danger">删除</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <div class="md-content" data-raw="<?=safeContent($rep['content'])?>"></div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if($totalPage > 1): ?>
                <div class="page-bar">
                    <?php if($page > 1): ?><a href="https://lmtoj.cn/discuss/<?=$tid?>?page=<?=$page-1?>">上一页</a><?php endif; ?>
                    <?php $shown = [1]; for($i=max(2,$page-2); $i<=min($totalPage-1,$page+2); $i++) $shown[]=$i; if($totalPage>1) $shown[]=$totalPage; $shown=array_unique($shown); sort($shown); $prev=0;
                    foreach($shown as $i): if($i-$prev>1) echo '<span class="page-ellipsis">...</span>'; ?>
                        <a href="https://lmtoj.cn/discuss/<?=$tid?>?page=<?=$i?>" class="<?=$i==$page?'active':''?>"><?=$i?></a>
                    <?php $prev=$i; endforeach; ?>
                    <?php if($page<$totalPage): ?><a href="https://lmtoj.cn/discuss/<?=$tid?>?page=<?=$page+1?>">下一页</a><?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="card">
            <h3>发表回复</h3>
            <?php if ($userJinyan == 1): ?>
                <p style="color:var(--danger);">您已被禁言，无法发表回复。</p>
            <?php else: ?>
                <form method="post" id="replyForm">
                    <input type="hidden" name="csrf_token" value="<?=$csrf_token?>">
                    <div class="edit-wrap">
                        <div class="edit-box"><textarea id="replyEditor" name="reply_content" placeholder="支持 Markdown / LaTeX 公式、@用户名" required></textarea></div>
                        <div class="preview-box" id="replyPreview">预览区域</div>
                    </div>
                    <button type="submit" id="replySubmitBtn">提交回复</button>
                </form>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<script>
const md = window.markdownit({ html: false, linkify: true, typographer: true, breaks: true });
const nameToUid = <?= json_encode($nameToUid, JSON_UNESCAPED_UNICODE) ?>;
const csrfToken = '<?=$csrf_token?>';

function replaceAtUser(text) {
    return text.replace(/(?<![A-Za-z0-9_])@([\w\u4e00-\u9fa5]+)/gu, function(m, userName) {
        if (nameToUid[userName]) return '[@' + userName + '](https://lmtoj.cn/user/' + nameToUid[userName] + ')';
        return m;
    });
}
function renderMdLatex(raw) {
    return md.render(replaceAtUser(raw));
}
function renderAllContent() {
    document.querySelectorAll('.md-content').forEach(function(el) {
        var raw = el.dataset.raw;
        if (!raw) return;
        var textarea = document.createElement('textarea');
        textarea.innerHTML = raw;
        el.innerHTML = renderMdLatex(textarea.value);
    });
    if (typeof renderMathInElement !== 'undefined') {
        renderMathInElement(document.body, {
            delimiters: [
                {left: "$$", right: "$$", display: true},
                {left: "$", right: "$", display: false},
                {left: "\\[", right: "\\]", display: true},
                {left: "\\(", right: "\\)", display: false}
            ],
            throwOnError: false
        });
    }
}
function bindSyncScroll(editor, preview) {
    if (!editor || !preview) return;
    const updatePreview = () => {
        preview.innerHTML = renderMdLatex(editor.value) || "预览区域";
        if (window.renderMathInElement) {
            renderMathInElement(preview, {
                delimiters: [{left:"$$",right:"$$",display:true},{left:"$",right:"$",display:false}],
                throwOnError: false
            });
        }
    };
    updatePreview();
    editor.addEventListener('input', updatePreview);
    editor.addEventListener('scroll', function() {
        if (editor.scrollHeight > editor.clientHeight) {
            preview.scrollTop = (editor.scrollTop / (editor.scrollHeight - editor.clientHeight)) * (preview.scrollHeight - preview.clientHeight);
        }
    });
    preview.addEventListener('scroll', function() {
        if (preview.scrollHeight > preview.clientHeight) {
            editor.scrollTop = (preview.scrollTop / (preview.scrollHeight - preview.clientHeight)) * (editor.scrollHeight - editor.clientHeight);
        }
    });
}

// ========== 投票 AJAX ==========
function vote(tid, type, btn) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', window.location.pathname + '?vote=1', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            try {
                var res = JSON.parse(xhr.responseText);
                if (res.success) {
                    document.getElementById('vote-up-count').textContent = res.upvotes;
                    document.getElementById('vote-down-count').textContent = res.downvotes;
                    document.getElementById('vote-net-score').textContent = res.upvotes - res.downvotes;
                    // 更新按钮状态
                    var upBtn = document.getElementById('vote-up');
                    var downBtn = document.getElementById('vote-down');
                    upBtn.classList.remove('active-up');
                    downBtn.classList.remove('active-down');
                    if (res.user_vote === 1) upBtn.classList.add('active-up');
                    else if (res.user_vote === -1) downBtn.classList.add('active-down');
                } else {
                    alert('投票失败：' + res.msg);
                }
            } catch(e) {
                alert('服务器返回异常');
            }
        } else {
            alert('网络错误');
        }
    };
    xhr.send('csrf_token=' + encodeURIComponent(csrfToken) + '&tid=' + tid + '&type=' + type);
}

window.addEventListener('DOMContentLoaded', function() {
    renderAllContent();
    // 绑定投票按钮
    document.getElementById('vote-up')?.addEventListener('click', function(e) {
        e.preventDefault();
        var tid = this.dataset.tid;
        var type = this.dataset.type;
        vote(tid, type, this);
    });
    document.getElementById('vote-down')?.addEventListener('click', function(e) {
        e.preventDefault();
        var tid = this.dataset.tid;
        var type = this.dataset.type;
        vote(tid, type, this);
    });

    // 编辑器同步
    var editors = [
        { editor: document.getElementById('postEditor'), preview: document.getElementById('postPreview') },
        { editor: document.getElementById('editEditor'), preview: document.getElementById('editPreview') },
        { editor: document.getElementById('replyEditor'), preview: document.getElementById('replyPreview') }
    ];
    editors.forEach(function(pair) {
        if (pair.editor && pair.preview) bindSyncScroll(pair.editor, pair.preview);
    });
});

// 防连点
(function() {
    var forms = [
        { id: 'newTopicForm', btnId: 'submitBtn', text: '发布帖子' },
        { id: 'editForm', btnId: 'editSubmitBtn', text: '保存修改' },
        { id: 'replyForm', btnId: 'replySubmitBtn', text: '提交回复' }
    ];
    forms.forEach(function(item) {
        var f = document.getElementById(item.id);
        var b = document.getElementById(item.btnId);
        if (f && b) {
            f.addEventListener('submit', function() {
                setTimeout(function() {
                    b.disabled = true;
                    b.innerText = '处理中...';
                }, 10);
                setTimeout(function() {
                    b.disabled = false;
                    b.innerText = item.text;
                }, 2000);
            });
        }
    });
})();
</script>
<?php require_once __DIR__ . '/event_effect.php'; ?>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>