<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');

// ===== 1. 用户登录验证 =====
if (!isset($_SESSION['uid'])) {
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ===== 2. 加载数据库连接（修正路径） =====
require_once __DIR__ . '/database.php';   // 改为同级目录
$conn = db();
$conn->set_charset("utf8mb4");

// ===== 3. 自动建表（若不存在） =====
$conn->query("CREATE TABLE IF NOT EXISTS uno_game_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    is_winner TINYINT DEFAULT 0,
    skills VARCHAR(255) DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(uid),
    INDEX(room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 同时保证 uno_rooms 和 uno_room_players 存在（方便独立运行）
$conn->query("CREATE TABLE IF NOT EXISTS uno_rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_code VARCHAR(16) NOT NULL UNIQUE,
    host_uid INT NOT NULL,
    title VARCHAR(100) NOT NULL,
    status VARCHAR(20) DEFAULT 'waiting',
    max_players INT DEFAULT 6,
    game_state LONGTEXT,
    version INT DEFAULT 1,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS uno_room_players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    uid INT NOT NULL,
    is_ready TINYINT DEFAULT 0,
    skills VARCHAR(255) DEFAULT '[]',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_room_user (room_id, uid),
    INDEX (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ===== 4. 获取当前用户信息 =====
$login_uid = (int)$_SESSION['uid'];
$userRow = $conn->query("SELECT name, admin, sqadmin FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
$login_name = $userRow['name'] ?? '玩家';
$is_admin = ((int)($userRow['admin'] ?? 0) == 1 || (int)($userRow['sqadmin'] ?? 0) == 1);

// ===== 5. 数据统计 =====

// 5.1 玩家胜率
$queryPlayer = "
    SELECT 
        u.uid,
        u.name,
        COUNT(r.id) AS total_games,
        SUM(r.is_winner) AS wins,
        SUM(CASE WHEN r.is_winner = 0 THEN 1 ELSE 0 END) AS losses
    FROM uno_game_records r
    LEFT JOIN users u ON r.uid = u.uid
    GROUP BY r.uid
";
$resultPlayer = $conn->query($queryPlayer);
$playerRaw = [];
while ($row = $resultPlayer->fetch_assoc()) {
    $total = (int)$row['total_games'];
    $wins  = (int)$row['wins'];
    $losses = (int)$row['losses'];
    $rate = $total > 0 ? round($wins / $total * 100, 2) : 0;
    $playerRaw[] = [
        'uid'   => $row['uid'],
        'name'  => $row['name'] ?? '未知玩家',
        'total' => $total,
        'wins'  => $wins,
        'losses'=> $losses,
        'rate'  => $rate,
    ];
}
usort($playerRaw, function($a, $b) {
    if ($b['rate'] != $a['rate']) return $b['rate'] <=> $a['rate'];
    return $b['wins'] <=> $a['wins'];
});
$playerData = [];
$rank = 1;
$i = 0;
while ($i < count($playerRaw)) {
    $j = $i;
    $currentRate = $playerRaw[$i]['rate'];
    while ($j < count($playerRaw) && $playerRaw[$j]['rate'] == $currentRate) $j++;
    for ($k = $i; $k < $j; $k++) {
        $playerRaw[$k]['rank'] = $rank;
    }
    $rank += ($j - $i);
    $i = $j;
}
$playerData = $playerRaw;

// 5.2 技能胜率
$querySkills = "SELECT skills, is_winner FROM uno_game_records";
$resultSkills = $conn->query($querySkills);
$skillStats = [];
while ($row = $resultSkills->fetch_assoc()) {
    $skills = json_decode($row['skills'], true);
    if (!is_array($skills)) continue;
    foreach ($skills as $skillId) {
        if (!isset($skillStats[$skillId])) {
            $skillStats[$skillId] = ['total' => 0, 'wins' => 0];
        }
        $skillStats[$skillId]['total']++;
        if ((int)$row['is_winner'] === 1) {
            $skillStats[$skillId]['wins']++;
        }
    }
}
$queryNoSkill = "SELECT is_winner FROM uno_game_records WHERE skills = '[]' OR skills IS NULL";
$resultNoSkill = $conn->query($queryNoSkill);
$noSkillTotal = 0;
$noSkillWins = 0;
while ($row = $resultNoSkill->fetch_assoc()) {
    $noSkillTotal++;
    if ((int)$row['is_winner'] === 1) $noSkillWins++;
}
$skillData = [];
foreach ($skillStats as $skillId => $stat) {
    $skillName = ($skillId === 'qiangchu') ? '抢出' : $skillId;
    $rate = $stat['total'] > 0 ? round($stat['wins'] / $stat['total'] * 100, 2) : 0;
    $skillData[] = [
        'skill_id'   => $skillId,
        'skill_name' => $skillName,
        'total'      => $stat['total'],
        'wins'       => $stat['wins'],
        'losses'     => $stat['total'] - $stat['wins'],
        'rate'       => $rate,
    ];
}
$skillData[] = [
    'skill_id'   => 'none',
    'skill_name' => '无技能',
    'total'      => $noSkillTotal,
    'wins'       => $noSkillWins,
    'losses'     => $noSkillTotal - $noSkillWins,
    'rate'       => $noSkillTotal > 0 ? round($noSkillWins / $noSkillTotal * 100, 2) : 0,
];
usort($skillData, function($a, $b) {
    return $b['rate'] <=> $a['rate'];
});

// 5.3 总体统计
$totalGames = $conn->query("SELECT COUNT(DISTINCT room_id) AS cnt FROM uno_game_records")->fetch_assoc()['cnt'] ?? 0;
$totalPlayers = $conn->query("SELECT COUNT(DISTINCT uid) AS cnt FROM uno_game_records")->fetch_assoc()['cnt'] ?? 0;

// ===== 6. 调试模式 =====
if (isset($_GET['debug']) && $_GET['debug'] == 1) {
    header('Content-Type: application/json');
    echo json_encode([
        'player' => $playerData,
        'skill'  => $skillData,
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// ===== 7. 页面输出 =====
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UNO 数据榜 · 大厅</title>
    <style>
        /* ===== 全局样式 ===== */
        :root {
            --bg: #f9f7f4;
            --card-bg: #ffffff;
            --nav-bg: #3d3a37;
            --nav-text: #f0ece6;
            --text: #2c2a28;
            --text-muted: #a0988e;
            --border: #e6e1da;
            --accent: #6b8a74;
            --accent-hover: #55735e;
            --radius: 12px;
            --shadow: 0 4px 12px rgba(0,0,0,0.06);
            --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', sans-serif;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; }
        .navbar {
            background:var(--nav-bg); height:54px; display:flex; align-items:center;
            justify-content:space-between; padding:0 28px; color:var(--nav-text);
            position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08);
        }
        .navbar h1 { font-size:17px; font-weight:600; }
        .navbar h1 a { color:#f0ece6; text-decoration:none; }
        .user-info { display:flex; align-items:center; gap:8px; font-size:14px; }
        .user-info a { color:#e0dbd3; text-decoration:none; padding:6px 12px; }
        .main { max-width:1320px; margin:20px auto 40px; display:flex; gap:18px; padding:0 14px; }
        .sidebar {
            background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow);
            width:fit-content; min-width:120px; overflow:hidden; position:sticky; top:80px;
            flex-shrink:0; height:fit-content;
        }
        .sidebar a {
            display:block; padding:13px 22px; text-align:center; color:var(--text);
            text-decoration:none; font-size:14px; font-weight:500;
            border-left:3px solid transparent;
        }
        .sidebar a:hover, .sidebar a.active {
            background:#f5f2ed; border-left-color:var(--accent); color:var(--accent);
        }
        .content { flex:1; min-width:0; }
        .card {
            background:var(--card-bg); border-radius:var(--radius); padding:22px;
            margin-bottom:18px; box-shadow:var(--shadow);
        }
        .card-header {
            display:flex; justify-content:space-between; align-items:center;
            margin-bottom:16px;
        }
        .card-header h2 { font-size:20px; }
        .tabs {
            display:flex; gap:8px; margin-bottom:20px; border-bottom:2px solid var(--border);
            padding-bottom:8px; flex-wrap:wrap;
        }
        .tab-btn {
            padding:8px 20px; background:transparent; border:none; font-size:15px;
            font-weight:500; color:var(--text-muted); cursor:pointer;
            border-radius:20px 20px 0 0; transition:0.2s;
        }
        .tab-btn.active {
            color:var(--accent); background:var(--bg); border-bottom:3px solid var(--accent);
        }
        .tab-btn:hover { color:var(--accent); }
        .tab-content { display:none; }
        .tab-content.active { display:block; }

        table { width:100%; border-collapse:collapse; font-size:14px; margin-top:8px; }
        th { background:#3d3a37; color:#f0ece6; padding:10px 12px; text-align:center; font-weight:500; }
        td { padding:9px 12px; text-align:center; border-bottom:1px solid #e6e1da; }
        tr:hover td { background:#f5f2ed; }
        .rate { font-weight:bold; color:#6b8a74; }
        .rank-badge { display:inline-block; background:#eee; border-radius:12px; padding:0 10px; font-weight:bold; }

        .empty-msg { text-align:center; color:#a0988e; padding:30px 0; }
        .stats-summary { display:flex; gap:30px; flex-wrap:wrap; margin-bottom:16px; }
        .stats-summary-item { font-size:14px; }
        .stats-summary-item strong { font-size:20px; color:var(--accent); }

        .btn {
            display:inline-block;
            padding:8px 20px;
            background:var(--accent);
            color:#fff;
            border-radius:20px;
            text-decoration:none;
            transition:0.2s;
        }
        .btn:hover { background:var(--accent-hover); }

        @media (max-width: 768px) {
            .main { flex-direction:column; }
            .sidebar { position:static; width:100%; display:flex; flex-wrap:wrap; justify-content:center; }
            .sidebar a { padding:10px 16px; border-left:none; border-bottom:3px solid transparent; }
            .sidebar a.active { border-bottom-color:var(--accent); }
        }
    </style>
</head>
<body>
<?php 
if (file_exists('navbar.php')) {
    include 'navbar.php';
} else {
?>
<div class="navbar">
    <h1><a href="/">UNO 绝不留情</a></h1>
    <div class="user-info">
        <span>👤 <?=htmlspecialchars($login_name)?></span>
        <a href="/">返回首页</a>
    </div>
</div>
<?php } ?>

<div class="main">
    <div class="sidebar">
        <a href="/">主页</a>
        <a href="/uno">UNO 对战</a>
        <a href="/uno/stats" class="active">🏆 数据榜</a>
    </div>

    <div class="content">
        <div class="card">
            <div class="card-header">
                <h2>📊 UNO 综合数据榜</h2>
                <span style="font-size:13px; color:var(--text-muted);">数据实时更新</span>
            </div>

            <!-- 统计摘要 -->
            <div class="stats-summary">
                <div class="stats-summary-item">🏅 总对局数：<strong><?= $totalGames ?></strong></div>
                <div class="stats-summary-item">👥 参与玩家数：<strong><?= $totalPlayers ?></strong></div>
            </div>

            <div class="tabs">
                <button class="tab-btn active" data-tab="player">🏅 玩家胜率</button>
                <button class="tab-btn" data-tab="skill">⚔️ 技能胜率</button>
            </div>

            <!-- 玩家胜率 -->
            <div id="tab-player" class="tab-content active">
                <?php if (empty($playerData)): ?>
                    <div class="empty-msg">暂无对战记录</div>
                <?php else: ?>
                    <table>
                        <thead><tr>
                            <th>排名</th><th>玩家</th><th>胜率</th><th>总场次</th><th>胜场</th><th>负场</th>
                        </tr></thead>
                        <tbody>
                            <?php foreach ($playerData as $p): ?>
                            <tr>
                                <td><span class="rank-badge">#<?= $p['rank'] ?></span></td>
                                <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
                                <td class="rate"><?= $p['rate'] ?>%</td>
                                <td><?= $p['total'] ?></td>
                                <td><?= $p['wins'] ?></td>
                                <td><?= $p['losses'] ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <!-- 技能胜率 -->
            <div id="tab-skill" class="tab-content">
                <?php if (empty($skillData)): ?>
                    <div class="empty-msg">暂无技能数据</div>
                <?php else: ?>
                    <table>
                        <thead><tr>
                            <th>技能</th><th>使用次数</th><th>胜场</th><th>负场</th><th>胜率</th>
                        </tr></thead>
                        <tbody>
                            <?php foreach ($skillData as $s): ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($s['skill_name']) ?></strong></td>
                                <td><?= $s['total'] ?></td>
                                <td><?= $s['wins'] ?></td>
                                <td><?= $s['losses'] ?></td>
                                <td class="rate"><?= $s['rate'] ?>%</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div style="text-align:center; margin-top:24px;">
                <a href="/uno" class="btn">← 返回对战大厅</a>
            </div>
        </div>
    </div>
</div>

<script>
    // Tab 切换
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
            this.classList.add('active');
            const tabId = this.dataset.tab;
            document.getElementById('tab-' + tabId).classList.add('active');
        });
    });
    // URL hash 打开对应选项卡
    if (window.location.hash) {
        const hash = window.location.hash.replace('#', '');
        const btn = document.querySelector(`.tab-btn[data-tab="${hash}"]`);
        if (btn) btn.click();
    }
</script>

<?php 
if (file_exists('footer.php')) {
    include 'footer.php';
}
?>
</body>
</html>