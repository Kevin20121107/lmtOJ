<?php
require_once __DIR__ . '/config.php';

if (!function_exists('db')) {
    function db(string $charset = 'utf8mb4'): mysqli
    {
        $connection = new mysqli(
            (string) env('DB_HOST'),
            (string) env('DB_USER'),
            (string) env('DB_PASSWORD'),
            (string) env('DB_NAME')
        );

        if ($connection->connect_error) {
            throw new RuntimeException('Database connection failed.');
        }
        $connection->set_charset($charset);
        // 允许插入时使用默认值
        $connection->query("SET SESSION sql_mode = ''");
        return $connection;
    }
}

// Keep the legacy variable names available while pages are gradually refactored.
$servername = (string) env('DB_HOST');
$dbuser = (string) env('DB_USER');
$dbpass = (string) env('DB_PASSWORD');
$dbname = (string) env('DB_NAME');
$host = $servername;
$user = $dbuser;
$pass = $dbpass;
$username = $dbuser;
$dbusername = $dbuser;
$dbpassword = $dbpass;

class dataBase
{
    private $host, $username, $password, $database;
    public $handle;
    
    public function __construct($host = null, $username = null, $password = null, $database = null)
    {
        if ($host !== null) {
            $this->host = $host;
        }
        if ($username !== null) {
            $this->username = $username;
        }
        if ($password !== null) {
            $this->password = $password;
        }
        if ($database !== null) {
            $this->database = $database;
        }
        
        $this->handle = new PDO(
            "mysql:host=" . $this->host . ";dbname=" . $this->database . ";charset=utf8mb4",
            $this->username,
            $this->password,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
        
        // 允许插入时使用默认值
        $this->handle->exec("SET SESSION sql_mode = ''");
    }
    
    public function query($sql, $var = [])
    {
        $stmt = $this->handle->prepare($sql);
        $stmt->execute($var);
        return $stmt;
    }
}

$db = new dataBase(
    (string) env('DB_HOST'),
    (string) env('DB_USER'),
    (string) env('DB_PASSWORD'),
    (string) env('DB_NAME')
);