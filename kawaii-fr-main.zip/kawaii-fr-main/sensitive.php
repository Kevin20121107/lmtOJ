<?php

/**
 * 敏感词检测 - Trie树实现
 * 支持：
 * - 添加敏感词
 * - 检测文本是否包含敏感词（containsSensitive）
 * - 返回命中的敏感词列表（getMatchedWords）
 * - 搜索时自动跳过指定字符（空格、下划线、换行等）
 * - 白名单：指定词语即使存在于词库中也不触发检测
 */
$user = $_SESSION['user'] ?? [];
$isAdmin = isset($user['admin']) && $user['admin'] == 1;
class SensitiveTrie
{
    private $root = [];
    private $skipChars = [' ', '_', '-', '*', '+', '/', '\\', "\n", "\r", "【", "】", "."]; // 搜索时要跳过的字符（含换行）
    private $whitelistMap = []; // 白名单哈希表，key为词语（小写），value为true

    /**
     * 设置需要跳过的字符列表
     */
    public function setSkipChars(array $chars)
    {
        $this->skipChars = $chars;
    }

    /**
     * 添加一个敏感词（自动归一为小写）
     */
    public function addWord($word)
    {
        $word = trim($word);
        if ($word === '') return;
        $word = mb_strtolower($word, 'UTF-8');
        $node = &$this->root;
        $len = mb_strlen($word, 'UTF-8');
        for ($i = 0; $i < $len; $i++) {
            $char = mb_substr($word, $i, 1, 'UTF-8');
            if (!isset($node[$char])) {
                $node[$char] = [];
            }
            $node = &$node[$char];
        }
        $node['__end'] = true;
    }

    /**
     * 批量添加敏感词
     */
    public function addWords(array $words)
    {
        foreach ($words as $word) {
            $this->addWord($word);
        }
    }

    /**
     * 添加白名单词语（这些词即使出现在词库中也不会被检测）
     */
    public function addWhitelist($word)
    {
        $word = trim($word);
        if ($word !== '') {
            $word = mb_strtolower($word, 'UTF-8');
            $this->whitelistMap[$word] = true;
        }
    }

    /**
     * 批量添加白名单词语
     */
    public function addWhitelistWords(array $words)
    {
        foreach ($words as $word) {
            $this->addWhitelist($word);
        }
    }

    /**
     * 检测文本中是否包含敏感词（自动跳过 skipChars，且白名单词不被检测）
     * @return bool
     */
    public function containsSensitive($text)
    {
        return $this->search($text, true) !== false;
    }

    /**
     * 检测并返回命中的敏感词列表（去重），白名单词不返回
     * @return array|false 返回数组或false
     */
    public function getMatchedWords($text)
    {
        return $this->search($text, false);
    }

    /**
     * 内部搜索逻辑
     * @param string $text         待检测文本
     * @param bool   $stopAtFirst  是否找到第一个就停止（返回 true/false）
     * @return array|false
     */
    private function search($text, $stopAtFirst)
    {
        if ($text === '') {
            return $stopAtFirst ? false : false;
        }

        // 归一文本为小写，便于和词库/白名单一致比较
        $text = mb_strtolower($text, 'UTF-8');
        $textLen = mb_strlen($text, 'UTF-8');
        $matched = [];
        $skipChars = $this->skipChars;
        $skipMap = array_flip($skipChars); // 加速跳过字符判断
        $whitelistMap = &$this->whitelistMap;
        $whitelistWords = array_keys($whitelistMap);

        // 辅助：判断从 $start 开始（跳过 skipChars）是否能匹配白名单词 $word
        $matchesWhitelistAt = function($start, $word) use ($text, $textLen, $skipMap) {
            $wlen = mb_strlen($word, 'UTF-8');
            $p = $start;
            $wi = 0;
            while ($wi < $wlen && $p < $textLen) {
                $ch = mb_substr($text, $p, 1, 'UTF-8');
                if (isset($skipMap[$ch])) { $p++; continue; } // 跳过忽略字符
                if ($ch !== mb_substr($word, $wi, 1, 'UTF-8')) return false;
                $wi++; $p++;
            }
            return $wi === $wlen;
        };

        for ($i = 0; $i < $textLen; $i++) {
            $char = mb_substr($text, $i, 1, 'UTF-8');
            // 起始字符如果是跳过字符则跳过该起始位置
            if (isset($skipMap[$char])) {
                continue;
            }

            $node = &$this->root;
            $matchedWord = '';

            for ($j = $i; $j < $textLen; $j++) {
                $ch = mb_substr($text, $j, 1, 'UTF-8');

                // 跳过忽略字符
                if (isset($skipMap[$ch])) {
                    continue;
                }

                // 路径不匹配则终止
                if (!isset($node[$ch])) {
                    break;
                }

                $node = &$node[$ch];
                $matchedWord .= $ch;

                // 到达词尾
                if (isset($node['__end'])) {
                    // 检查是否被白名单覆盖：
                    // 1) 完全相等的白名单词
                    // 2) 当前位置的起点 i 开始能匹配某个白名单词（允许跳过 skipChars），若能则说明命中属于白名单词的子串，应忽略
                    $isWhitelisted = false;
                    if (isset($whitelistMap[$matchedWord])) {
                        $isWhitelisted = true;
                    } else {
                        foreach ($whitelistWords as $w) {
                            if ($w === '') continue;
                            if ($matchesWhitelistAt($i, $w)) {
                                $isWhitelisted = true;
                                break;
                            }
                        }
                    }

                    if ($isWhitelisted) {
                        // 白名单：不记录、不返回，继续尝试匹配更长词（如果有）
                        continue;
                    }

                    if ($stopAtFirst) {
                        return true;
                    }
                    $matched[] = $matchedWord;
                }
            }
        }

        if ($stopAtFirst) {
            return false;
        }
        return array_unique($matched) ?: false;
    }
}

// ========== 初始化（示例，默认不添加任何敏感词，可自行添加） ==========
$sensitive = new SensitiveTrie();

// 可选：添加默认敏感词（如需要可取消注释）
$sensitive->addWords([
// 摄政
//'台湾','台独','反动','国民党','共产党','毛泽东','习近平','td',
// 色情
//'鸡巴','撸管','性虐','操死','草似','草死','byt','避孕套','嫖','娼','淫','妓','私处','性交','裸聊','约炮','小三','骚','下头男','普信女','调教','艾斯','爱慕','fuck','dick','艾嘶爱姆','cum','pussy','cumshot','勾引','dbsm',
// 针对特殊人群
//'gay','男同','女同','内阁','性恋','nigger','黑奴','lesbian','lala',
// 暴力
//'刀','尸体','分尸','杀人','报复','杀','你要死','去死',
// 自杀自残
//'紫砂','自杀','自残','跳楼','跳河','烧炭',
// 毒品
//'冰毒','大麻','海洛因','吸了','尼古丁',
// 赌博
//'下注','筹码','赌博',
// 国骂
//'杂种','傻逼','sb','fxxk','fuck','fk','fck','rape','zyx',
]);

// 可选：添加白名单（即使敏感词库中有这些词，也会被跳过）
 $sensitive->addWhitelistWords([
'sbs','grape','std'
]);

// 返回实例（供其他文件 require 后使用）
return $sensitive;