<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
date_default_timezone_set('Asia/Shanghai');
require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");
require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ---------- 速率限制表创建 ----------
$conn->query("CREATE TABLE IF NOT EXISTS rate_limit (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    request_time INT(11) NOT NULL,
    INDEX(ip, request_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ---------- 辅助函数 ----------
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getColorByTotalScore($totalScore, $isAdmin) {
    if ($isAdmin) return '#8e44ad';
    if ($totalScore < 0) return '#8b6b4d';
    if ($totalScore <= 10) return '#b0a8a0';
    if ($totalScore <= 20) return '#4a90d9';
    if ($totalScore <= 45) return '#28a745';
    if ($totalScore <= 65) return '#e67e22';
    return '#e74c3c';
}

function getFirstChar($name) {
    $name = trim($name ?? '?');
    return mb_strlen($name) > 0 ? mb_strtoupper(mb_substr($name, 0, 1)) : '?';
}

// ---------- 登录检查 ----------
$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
if ($login_uid <= 0) {
    header("Location: https://lmtoj.cn/login");
    exit;
}
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

// ========== ★ 修复速率限制函数 ==========
function checkRateLimit($db) {
    $ip = $_SERVER['REMOTE_ADDR'];
    $now = time();
    $window = 1; // 1秒窗口
    $threshold = 5; // 限制次数

    // 删除过期记录
    $delete_time = $now - $window;
    $stmt = $db->prepare("DELETE FROM rate_limit WHERE request_time < ?");
    $stmt->bind_param("i", $delete_time);
    $stmt->execute();
    $stmt->close();

    // 插入当前请求
    $stmt = $db->prepare("INSERT INTO rate_limit (ip, request_time) VALUES (?, ?)");
    $stmt->bind_param("si", $ip, $now);
    $stmt->execute();
    $stmt->close();

    // 统计该IP在窗口内的请求数
    $stmt = $db->prepare("SELECT COUNT(*) AS cnt FROM rate_limit WHERE ip = ? AND request_time >= ?");
    $stmt->bind_param("si", $ip, $delete_time);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = (int)($row['cnt'] ?? 0);
    $stmt->close();

    if ($count > $threshold) {
        session_destroy();
        header('Content-Type: text/html; charset=utf-8');
        echo <<<'HTML'
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>请求过于频繁</title>
<script>
alert("请求过于频繁，即将关闭页面。");
window.close();
</script>
</head>
<body><p>请求过于频繁，请稍后再试。</p></body>
</html>
HTML;
        exit;
    }
}

// 调用速率限制
checkRateLimit($conn);

$conn->query("CREATE TABLE IF NOT EXISTS articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    content TEXT NOT NULL,
    category VARCHAR(50) NOT NULL,
    is_recommended TINYINT DEFAULT 0,
    recommended_at DATETIME NULL COMMENT '推荐时间', -- 新增此行
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
// 兼容旧数据库自动补字段
$recommendedAtColumn = $conn->query("SHOW COLUMNS FROM articles LIKE 'recommended_at'");
if ($recommendedAtColumn && $recommendedAtColumn->num_rows === 0) {
    $conn->query("ALTER TABLE articles ADD COLUMN recommended_at DATETIME NULL AFTER is_recommended");
}
if ($recommendedAtColumn) {
    $recommendedAtColumn->free();
}

// ---------- 新增：添加管理员提示字段 ----------
$adminNoticeColumn = $conn->query("SHOW COLUMNS FROM articles LIKE 'admin_notice'");
if ($adminNoticeColumn && $adminNoticeColumn->num_rows === 0) {
    $conn->query("ALTER TABLE articles ADD COLUMN admin_notice TEXT NULL AFTER content");
}
if ($adminNoticeColumn) {
    $adminNoticeColumn->free();
}

$conn->query("CREATE TABLE IF NOT EXISTS article_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    article_id INT NOT NULL,
    uid INT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX(article_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// 确保点赞表存在
$conn->query("CREATE TABLE IF NOT EXISTS article_likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    article_id INT NOT NULL,
    UNIQUE KEY(uid, article_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$conn->query("CREATE TABLE IF NOT EXISTS article_dislike (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL COMMENT '操作用户UID',
    article_id INT NOT NULL COMMENT '文章ID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uk_uid_article (uid, article_id),
    INDEX idx_article (article_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='文章点踩记录表'");
// ---------- 权限与消息数 ----------
$is_admin = 0;
$artadmin = 0;
$sqadmin = 0;
$unreadCount = 0;
if ($login_uid > 0) {
    $adminStmt = $conn->prepare("SELECT admin, artadmin, sqadmin FROM users WHERE uid = ? LIMIT 1");
    $adminStmt->bind_param("i", $login_uid);
    $adminStmt->execute();
    $adminRes = $adminStmt->get_result();
    if ($adminRes && $adminRes->num_rows > 0) {
        $row = $adminRes->fetch_assoc();
        $is_admin = (int)$row['admin'];
        $artadmin = (int)$row['artadmin'];
        $sqadmin = (int)$row['sqadmin'];
    }
    $adminStmt->close();

    $msgStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM notice WHERE uid = ? AND is_read = 0");
    $msgStmt->bind_param("i", $login_uid);
    $msgStmt->execute();
    $msgRes = $msgStmt->get_result();
    if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
    $msgStmt->close();
}

// 获取当前登录用户是否想看别人的彩色名
$myShowColorful = 1;
$showPrefStmt = $conn->prepare("SELECT show_colorful_names FROM users WHERE uid = ? LIMIT 1");
$showPrefStmt->bind_param("i", $login_uid);
$showPrefStmt->execute();
$showPrefRes = $showPrefStmt->get_result();
if ($showPrefRes && $showPrefRes->num_rows > 0) {
    $myShowColorful = (int)($showPrefRes->fetch_assoc()['show_colorful_names']);
}
$showPrefStmt->close();

$action = isset($_GET['action']) ? $_GET['action'] : '';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$perPage = 10;
$offset = ($page - 1) * $perPage;
$msg = '';

// ========== 处理评论发布 ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['comment_content']) && $id > 0) {
    $content = trim($_POST['comment_content']);
    if (!empty($content)) {
        if (mb_strlen($content) > 1000) {
            $msg = '评论内容不能超过 1000 字符。';
        }else{
        $now = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("INSERT INTO article_comments (article_id, uid, content, created_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiss", $id, $login_uid, $content, $now);
        $stmt->execute();
        $stmt->close();

        preg_match_all('/@([\w_\x{4e00}-\x{9fa5}]+)/u', $content, $atMatches);
        $atNames = array_unique($atMatches[1]);
        $titleStmt = $conn->prepare("SELECT title FROM articles WHERE id = ?");
        $titleStmt->bind_param("i", $id);
        $titleStmt->execute();
        $titleRes = $titleStmt->get_result();
        $articleTitle = $titleRes->fetch_assoc()['title'] ?? "文章#" . $id;
        $titleStmt->close();
        $noticeContent = 'article_comment';
        foreach ($atNames as $atName) {
            $userStmt = $conn->prepare("SELECT uid FROM users WHERE name = ? LIMIT 1");
            $userStmt->bind_param("s", $atName);
            $userStmt->execute();
            $userRes = $userStmt->get_result();
            $targetUser = $userRes->fetch_assoc();
            $userStmt->close();
            if ($targetUser && $targetUser['uid'] != $login_uid) {
                $stmtN = $conn->prepare("INSERT INTO notice(uid, atid, tid, topic_title, content, create_time, is_read) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmtN->bind_param("iiisssi", $targetUser['uid'], $login_uid, $id, $articleTitle, $noticeContent, $now, 0);
                $stmtN->execute();
                $stmtN->close();
            }
        }
        header("Location: https://lmtoj.cn/article/$id");
        exit;
        }
    }
}

// ========== 处理评论删除 ==========
if ($id > 0 && isset($_GET['del_comment'])) {
    $cid = (int)$_GET['del_comment'];
    $commentStmt = $conn->prepare("SELECT uid FROM article_comments WHERE id = ? AND article_id = ?");
    $commentStmt->bind_param("ii", $cid, $id);
    $commentStmt->execute();
    $comment = $commentStmt->get_result()->fetch_assoc();
    $commentStmt->close();
    if ($comment) {
        $articleStmt = $conn->prepare("SELECT uid FROM articles WHERE id = ?");
        $articleStmt->bind_param("i", $id);
        $articleStmt->execute();
        $article = $articleStmt->get_result()->fetch_assoc();
        $articleStmt->close();
        if ($comment['uid'] == $login_uid || $article['uid'] == $login_uid || $sqadmin || $artadmin) {
            $delStmt = $conn->prepare("DELETE FROM article_comments WHERE id = ?");
            $delStmt->bind_param("i", $cid);
            $delStmt->execute();
            $delStmt->close();
        }
    }
    header("Location: https://lmtoj.cn/article/$id");
    exit;
}

// ========== 新增：处理管理员提示更新（仅 sqadmin） ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_type']) && $_POST['action_type'] === 'update_admin_notice') {
    if ($sqadmin && isset($_POST['article_id']) && isset($_POST['admin_notice'])) {
        $aid = (int)$_POST['article_id'];
        $notice = trim($_POST['admin_notice']);
        $upd = $conn->prepare("UPDATE articles SET admin_notice = ? WHERE id = ?");
        $upd->bind_param("si", $notice, $aid);
        $upd->execute();
        $upd->close();
        header("Location: https://lmtoj.cn/article/$aid");
        exit;
    }
    // 非 sqadmin 忽略
}

// ========== 处理文章发布/编辑 ==========
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['comment_content'])) {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $article_id = isset($_POST['article_id']) ? (int)$_POST['article_id'] : 0;
    if (empty($title) || empty($content) || empty($category)) {
        $msg = '所有字段均为必填';
    } else {
        if ($article_id > 0) {
            $checkStmt = $conn->prepare("SELECT uid FROM articles WHERE id = ?");
            $checkStmt->bind_param("i", $article_id);
            $checkStmt->execute();
            $row = $checkStmt->get_result()->fetch_assoc();
            $checkStmt->close();
            if (!$row || ($row['uid'] != $login_uid && !$artadmin)) {
                $msg = '无权编辑此文章';
            } else {
                $updStmt = $conn->prepare("UPDATE articles SET title=?, content=?, category=?, is_recommended=0 WHERE id=?");
                $updStmt->bind_param("sssi", $title, $content, $category, $article_id);
                $updStmt->execute();
                $updStmt->close();
                header("Location: https://lmtoj.cn/article/$article_id");
                exit;
            }
        } else {
            $insStmt = $conn->prepare("INSERT INTO articles (uid, title, content, category) VALUES (?, ?, ?, ?)");
            $insStmt->bind_param("isss", $login_uid, $title, $content, $category);
            $insStmt->execute();
            $new_id = $insStmt->insert_id;
            $insStmt->close();
            header("Location: https://lmtoj.cn/article/$new_id");
            exit;
        }
    }
}

// 处理点赞切换
if ($id > 0 && isset($_GET['toggle_like'])) {
    $check = $conn->prepare("SELECT id FROM article_likes WHERE uid = ? AND article_id = ?");
    $check->bind_param("ii", $login_uid, $id);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();
    if ($exists) {
        $delLike = $conn->prepare("DELETE FROM article_likes WHERE uid = ? AND article_id = ?");
        $delLike->bind_param("ii", $login_uid, $id);
        $delLike->execute();
        $delLike->close();
    } else {
        $insLike = $conn->prepare("INSERT INTO article_likes (uid, article_id) VALUES (?, ?)");
        $insLike->bind_param("ii", $login_uid, $id);
        $insLike->execute();
        $insLike->close();
    }
    header("Location: https://lmtoj.cn/article/$id");
    exit;
}
// ========== 新增：处理点踩切换 ==========
if ($id > 0 && isset($_GET['toggle_dislike'])) {
    // 查询是否已点踩
    $check = $conn->prepare("SELECT id FROM article_dislike WHERE uid = ? AND article_id = ?");
    $check->bind_param("ii", $login_uid, $id);
    $check->execute();
    $exists = $check->get_result()->num_rows > 0;
    $check->close();

    if ($exists) {
        // 取消点踩
        $delDis = $conn->prepare("DELETE FROM article_dislike WHERE uid = ? AND article_id = ?");
        $delDis->bind_param("ii", $login_uid, $id);
        $delDis->execute();
        $delDis->close();
    } else {
        // 添加点踩
        $insDis = $conn->prepare("INSERT INTO article_dislike (uid, article_id) VALUES (?, ?)");
        $insDis->bind_param("ii", $login_uid, $id);
        $insDis->execute();
        $insDis->close();
    }

    // 自动检测：点踩≥5 且 点踩 > 点赞/2，自动取消全站推荐
    // 统计点赞、点踩总数
    $statStmt = $conn->prepare("
        SELECT
            (SELECT COUNT(*) FROM article_likes WHERE article_id = ?) AS like_cnt,
            (SELECT COUNT(*) FROM article_dislike WHERE article_id = ?) AS dislike_cnt
    ");
    $statStmt->bind_param("ii", $id, $id);
    $statStmt->execute();
    $statRow = $statStmt->get_result()->fetch_assoc();
    $statStmt->close();

    $likeCnt = (int)$statRow['like_cnt'];
    $dislikeCnt = (int)$statRow['dislike_cnt'];

    // 判断规则：点踩>=5 && 点踩 > 点赞 ÷ 2
    if ($dislikeCnt >= 5 && $dislikeCnt > $likeCnt / 2) {
        // 自动撤下推荐
        $autoRec = $conn->prepare("UPDATE articles SET is_recommended = 0, recommended_at = NULL WHERE id = ?");
        $autoRec->bind_param("i", $id);
        $autoRec->execute();
        $autoRec->close();
    }

    header("Location: https://lmtoj.cn/article/$id");
    exit;
}
// 处理推荐切换（管理员）
// 处理推荐切换（管理员）
if ($id > 0 && isset($_GET['toggle_recommend']) && $artadmin) {
    $recStmt = $conn->prepare("SELECT is_recommended FROM articles WHERE id = ?");
    $recStmt->bind_param("i", $id);
    $recStmt->execute();
    $row = $recStmt->get_result()->fetch_assoc();
    $recStmt->close();
    if ($row) {
        $newVal = $row['is_recommended'] ? 0 : 1; // 修复：定义$newVal
        if ($newVal === 1) {
            // 设为推荐时，记录推荐时间为今天
            $now = date('Y-m-d H:i:s');
            $updRec = $conn->prepare("UPDATE articles SET is_recommended = ?, recommended_at = ? WHERE id = ?");
            $updRec->bind_param("isi", $newVal, $now, $id);
        } else {
            // 取消推荐清空时间戳
            $updRec = $conn->prepare("UPDATE articles SET is_recommended = ?, recommended_at = NULL WHERE id = ?");
            $updRec->bind_param("ii", $newVal, $id);
        }
        $updRec->execute();
        $updRec->close();
        header("Location: https://lmtoj.cn/article/$id");
        exit;
    }
}

// 处理删除（管理员或作者）
if ($id > 0 && isset($_GET['delete'])) {
    $checkDel = $conn->prepare("SELECT uid FROM articles WHERE id = ?");
    $checkDel->bind_param("i", $id);
    $checkDel->execute();
    $row = $checkDel->get_result()->fetch_assoc();
    $checkDel->close();
    if ($row && ($row['uid'] == $login_uid || $artadmin)) {
        $delArt = $conn->prepare("DELETE FROM articles WHERE id = ?");
        $delArt->bind_param("i", $id);
        $delArt->execute();
        $delArt->close();
        $delComm = $conn->prepare("DELETE FROM article_comments WHERE article_id = ?");
        $delComm->bind_param("i", $id);
        $delComm->execute();
        $delComm->close();
        header("Location: https://lmtoj.cn/article");
        exit;
    } else {
        $msg = '无权删除';
    }
}

// ========== 获取文章数据 ==========
$article = null;
$isEdit = false;
if ($action === 'edit') {
    $isEdit = true;
    if ($id > 0) {
        $editStmt = $conn->prepare("SELECT * FROM articles WHERE id = ?");
        $editStmt->bind_param("i", $id);
        $editStmt->execute();
        $article = $editStmt->get_result()->fetch_assoc();
        $editStmt->close();
        if (!$article) {
            $msg = '文章不存在';
            $isEdit = false;
            $action = '';
            $id = 0;
        } else {
            if (!$artadmin && $article['uid'] != $login_uid) {
                $msg = '无权编辑此文章';
                $isEdit = false;
                $action = '';
                $id = 0;
            }
        }
    } else {
        $article = ['id' => 0, 'title' => '', 'content' => '', 'category' => ''];
    }
} elseif ($id > 0) {
    $viewStmt = $conn->prepare("SELECT * FROM articles WHERE id = ?");
    $viewStmt->bind_param("i", $id);
    $viewStmt->execute();
    $article = $viewStmt->get_result()->fetch_assoc();
    $viewStmt->close();
    if (!$article) {
        $msg = '文章不存在';
        $id = 0;
    }
}

$categories = ['题解', '科技·工程', '算法·理论', '学习·文化课', '休闲·娱乐', '生活·游记', '站务'];

$filterCategory = isset($_GET['category']) ? trim($_GET['category']) : '';
if ($filterCategory && !in_array($filterCategory, $categories)) {
    $filterCategory = '';
}

$searchKeyword = isset($_GET['search']) ? trim($_GET['search']) : '';
if (strlen($searchKeyword) > 0) {
    $searchKeyword = substr($searchKeyword, 0, 100);
}

$listArticles = [];
$totalPages = 1;
if ($id === 0 && !$isEdit) {
    $whereConditions = [];
    $bindParams = [];
    $types = '';

    if ($filterCategory) {
        $whereConditions[] = "a.category = ?";
        $bindParams[] = $filterCategory;
        $types .= 's';
    }
    if ($searchKeyword !== '') {
        $whereConditions[] = "(a.title LIKE ? OR a.content LIKE ?)";
        $like = '%' . $searchKeyword . '%';
        $bindParams[] = $like;
        $bindParams[] = $like;
        $types .= 'ss';
    }

    if (!$is_admin) {
        array_unshift($bindParams, $login_uid);
        $types = 'i' . $types;
        $permPlaceholder = "(a.uid = ? OR a.is_recommended = 1)";
    } else {
        $permPlaceholder = '1';
    }

    $whereSQL = $permPlaceholder;
    if (!empty($whereConditions)) {
        $whereSQL .= ' AND ' . implode(' AND ', $whereConditions);
    }

    $countSql = "SELECT COUNT(*) AS total FROM articles a WHERE $whereSQL";
    $countStmt = $conn->prepare($countSql);
    if (!empty($bindParams)) {
        $countStmt->bind_param($types, ...$bindParams);
    }
    $countStmt->execute();
    $total = $countStmt->get_result()->fetch_assoc()['total'];
    $countStmt->close();
    $totalPages = ceil($total / $perPage);

$sql = "SELECT a.*, u.name, u.admin, u.tag, u.avatar,
        u.practice_score, u.contribute_score, u.contest_score,
        u.base_credit, u.valuation, u.username_color,
        u.cert_type, u.cert_level,
        (SELECT COUNT(*) FROM article_likes l WHERE l.article_id = a.id) AS likes_count,
        -- 下面这行是新增
        (SELECT COUNT(*) FROM article_dislike d WHERE d.article_id = a.id) AS dislikes_count,
        (SELECT COUNT(*) FROM article_comments c WHERE c.article_id = a.id) AS comment_count
        FROM articles a
        LEFT JOIN users u ON a.uid = u.uid
        WHERE $whereSQL
        ORDER BY likes_count DESC, a.created_at DESC
        LIMIT ?, ?";
    $finalParams = array_merge($bindParams, [$offset, $perPage]);
    $finalTypes = $types . 'ii';

    $stmt = $conn->prepare($sql);
    if (!empty($finalParams)) {
        $stmt->bind_param($finalTypes, ...$finalParams);
    }
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $listArticles[] = $row;
    }
    $stmt->close();
}

$userLiked = false;
$likesCount = 0;
$comments = [];
if ($article && $article['id'] > 0) {
    $likeCntStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM article_likes WHERE article_id = ?");
    $likeCntStmt->bind_param("i", $article['id']);
    $likeCntStmt->execute();
    $likesCount = $likeCntStmt->get_result()->fetch_assoc()['cnt'];
    $likeCntStmt->close();

    $userLikeStmt = $conn->prepare("SELECT id FROM article_likes WHERE uid = ? AND article_id = ?");
    $userLikeStmt->bind_param("ii", $login_uid, $article['id']);
    $userLikeStmt->execute();
    $userLiked = $userLikeStmt->get_result()->num_rows > 0;
    $userLikeStmt->close();
    // 新增：查询总点踩数
    $dislikeCntStmt = $conn->prepare("SELECT COUNT(*) AS cnt FROM article_dislike WHERE article_id = ?");
    $dislikeCntStmt->bind_param("i", $article['id']);
    $dislikeCntStmt->execute();
    $dislikesCount = $dislikeCntStmt->get_result()->fetch_assoc()['cnt'];
    $dislikeCntStmt->close();

    // 新增：判断当前用户有没有点过踩
    $userDisStmt = $conn->prepare("SELECT id FROM article_dislike WHERE uid = ? AND article_id = ?");
    $userDisStmt->bind_param("ii", $login_uid, $article['id']);
    $userDisStmt->execute();
    $userDisliked = $userDisStmt->get_result()->num_rows > 0;
    $userDisStmt->close();
    $commentSql = "SELECT c.*, u.name, u.admin, u.tag, u.avatar,
                   u.practice_score, u.contribute_score, u.contest_score,
                   u.base_credit, u.valuation, u.username_color,
                   u.cert_type, u.cert_level
                   FROM article_comments c
                   LEFT JOIN users u ON c.uid = u.uid
                   WHERE c.article_id = ?
                   ORDER BY c.created_at ASC";
    $commStmt = $conn->prepare($commentSql);
    $commStmt->bind_param("i", $article['id']);
    $commStmt->execute();
    $commentRes = $commStmt->get_result();
    while ($row = $commentRes->fetch_assoc()) {
        $comments[] = $row;
    }
    $commStmt->close();
}

$nameToUid = [];
$uRes = $conn->query("SELECT uid, name FROM users");
while ($u = $uRes->fetch_assoc()) {
    $nameToUid[$u['name']] = $u['uid'];
}

function safeContent($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
function formatTime($ts) {
    return date('Y-m-d H:i', strtotime($ts));
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>文章广场 - lmtOJ</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css" />
<style>
/* ---------- 通用样式 ---------- */
:root {
    --bg: #f9f7f4;
    --card-bg: #ffffff;
    --nav-bg: #3d3a37;
    --nav-text: #f0ece6;
    --text: #2c2a28;
    --text-secondary: #7a736b;
    --text-muted: #a0988e;
    --border: #e6e1da;
    --border-light: #f0ece6;
    --accent: #6b8a74;
    --accent-hover: #55735e;
    --accent-light: #eef4ef;
    --danger: #d9534f;
    --danger-hover: #c0392b;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.04);
    --shadow: 0 2px 10px rgba(0,0,0,0.05);
    --radius: 10px;
    --radius-sm: 6px;
    --transition: 0.18s ease;
    --font: 'Segoe UI', 'PingFang SC', 'Microsoft YaHei', 'Noto Sans SC', system-ui, sans-serif;
}
*{margin:0;padding:0;box-sizing:border-box;}
body{background:var(--bg);font-family:var(--font);color:var(--text);line-height:1.6;font-size:15px;}

/* 导航栏 */
.navbar{background:var(--nav-bg);height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 28px;color:var(--nav-text);position:sticky;top:0;z-index:100;box-shadow:0 1px 4px rgba(0,0,0,0.08);}
.navbar h1{font-size:17px;font-weight:600;color:#f0ece6;letter-spacing:0.4px;}
.bell-wrap{position:relative;font-size:20px;cursor:pointer;margin-right:20px;width:36px;height:36px;display:flex;align-items:center;justify-content:center;border-radius:50%;transition:var(--transition);}
.bell-wrap:hover{background:rgba(255,255,255,0.08);}
.red-dot{position:absolute;top:5px;right:5px;width:9px;height:9px;background:#f55353;border-radius:50%;border:1.5px solid #3d3a37;animation:pulse-dot 2s infinite;}
@keyframes pulse-dot{0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);}50%{box-shadow:0 0 0 6px rgba(245,83,83,0);}}
.user-info{display:flex;align-items:center;gap:6px;}
.user-info a{color:#e0dbd3;text-decoration:none;font-size:13.5px;padding:7px 13px;border-radius:20px;transition:var(--transition);font-weight:500;}
.user-info a:hover{background:rgba(255,255,255,0.1);color:#fff;}
.user-info a.admin-link{color:#f5d76e;font-weight:600;}

/* 主布局 */
.main{max-width:1100px;margin:28px auto 40px;display:flex;gap:22px;padding:0 20px;align-items:flex-start;}
.sidebar{background:var(--card-bg);border-radius:var(--radius);box-shadow:var(--shadow);width:fit-content;min-width:110px;overflow:hidden;position:sticky;top:80px;flex-shrink:0;}
.sidebar a{display:block;padding:13px 22px;text-align:center;color:var(--text);text-decoration:none;font-size:14.5px;font-weight:500;transition:var(--transition);border-left:3px solid transparent;}
.sidebar a:hover{background:#f5f2ed;border-left-color:var(--accent);color:var(--accent);}
.content{flex:1;min-width:0;}
a{color:var(--accent);text-decoration:none;font-weight:500;transition:var(--transition);}
a:hover{color:var(--accent-hover);text-decoration:underline;}

/* 卡片 */
.card{background:var(--card-bg);border-radius:var(--radius);padding:26px 28px;box-shadow:var(--shadow);margin-bottom:18px;border:1px solid var(--border-light);transition:var(--transition);}
.card:hover{box-shadow:var(--shadow);}
.card h2,.card h3{font-size:18px;font-weight:600;margin-bottom:16px;color:var(--text);}

/* 表单 */
input[type="text"], select, textarea {
    width:100%; padding:12px 16px;
    border:1.5px solid var(--border); border-radius:var(--radius-sm);
    font-size:15px; outline:none; margin-bottom:16px;
    background:#fdfdfc; font-family:var(--font);
    transition:var(--transition);
}
input:focus, textarea:focus, select:focus {
    border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff;
}
textarea{min-height:320px;resize:vertical;}
button{padding:10px 26px;background:var(--accent);color:#fff;border:none;border-radius:30px;cursor:pointer;font-size:15px;font-weight:500;transition:var(--transition);}
button:hover{background:var(--accent-hover);box-shadow:0 4px 12px rgba(107,138,116,0.30);transform:translateY(-1px);}

/* 按钮工具类 */
.btn-sm{padding:5px 14px;font-size:13px;border-radius:6px;border:none;cursor:pointer;text-decoration:none;display:inline-block;font-weight:500;transition:var(--transition);}
.btn-sm:hover{transform:translateY(-1px);}
.btn-danger{background:var(--danger);color:#fff;}
.btn-danger:hover{background:var(--danger-hover);}
.btn-green{background:#5a9e6f;color:#fff;}
.btn-green:hover{background:#4a855c;}
.btn-orange{background:#d4a24e;color:#fff;}
.btn-orange:hover{background:#b8893c;}
.btn-like{background:var(--accent-light);color:var(--accent);}
.btn-like:hover{background:var(--accent);color:#fff;}
.btn-liked{background:var(--accent);color:#fff;}

/* 文章列表样式 */
.article-item{padding:18px 0;padding-left:12px;border-bottom:1px solid var(--border-light);}
.article-item:last-child{border-bottom:none;}
.article-title{font-size:18px;font-weight:600;margin-bottom:6px;}
.article-title a{color:var(--text);}
.article-title a:hover{color:var(--accent);}
.article-meta {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 6px 16px;
    font-size: 13px;
    color: var(--text-muted);
    line-height: 1.6;
}
.article-meta > span {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
}
.category-tag {
    display: inline-block;
    background: var(--accent-light);
    color: var(--accent);
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 500;
    white-space: nowrap;
}
.recommend-badge {
    background: #f5d76e;
    color: #7d6b1a;
    padding: 2px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-flex;
    align-items: center;
    gap: 4px;
    white-space: nowrap;
}
.like-badge, .comment-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    font-weight: 500;
}
.like-badge { color: #d9534f; }
.comment-badge { color: #5a9e6f; }

/* 文章内容 Markdown 渲染 */
.article-content{white-space:normal;word-break:break-word;line-height:1.8;font-size:15px;color:var(--text);}
.article-content img{max-width:100%;height:auto;border-radius:4px;margin:6px 0;}
.article-content pre{background:#2b2a27;color:#e8e4dd;padding:14px 16px;border-radius:var(--radius-sm);overflow-x:auto;margin:12px 0;font-family:'JetBrains Mono','Consolas',monospace;font-size:13px;}
.article-content code{font-family:'JetBrains Mono','Consolas',monospace;background:#f3f0eb;padding:2px 6px;border-radius:3px;color:#5a4a3a;}
.article-content pre code{background:transparent;padding:0;color:inherit;}
.article-content blockquote{border-left:4px solid var(--accent);padding:8px 14px;margin:12px 0;background:#fafaf8;color:#5a5550;border-radius:0 4px 4px 0;}
.article-content p{margin:8px 0;}

/* 其他组件 */
.back-btn{display:inline-flex;align-items:center;gap:6px;margin-bottom:20px;padding:8px 20px;background:var(--card-bg);color:var(--text);border-radius:30px;font-size:14px;font-weight:500;border:1px solid var(--border);box-shadow:var(--shadow-sm);transition:var(--transition);}
.back-btn:hover{background:var(--accent-light);border-color:var(--accent);color:var(--accent);text-decoration:none;}
.edit-layout{display:flex;gap:24px;}
.edit-main{flex:1;}
.edit-side{width:240px;flex-shrink:0;}
.edit-side label{font-weight:500;display:block;margin-bottom:6px;color:var(--text-secondary);font-size:14px;}
.edit-side select{padding:12px;width:100%;}
.error-box{background:#fde8e8;border:1px solid #f5c6c6;color:#a94442;padding:14px 18px;border-radius:var(--radius-sm);margin-bottom:20px;font-weight:500;}
.header-actions{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;flex-wrap:wrap;gap:12px;}
.header-actions h2{font-size:22px;font-weight:600;margin:0;}
.btn-create{background:var(--accent);color:#fff;padding:10px 28px;border-radius:30px;font-weight:500;transition:var(--transition);}
.btn-create:hover{background:var(--accent-hover);box-shadow:0 4px 14px rgba(107,138,116,0.30);transform:translateY(-2px);text-decoration:none;color:#fff;}

/* 分类过滤 */
.category-filter {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-bottom: 20px;
    padding: 12px 16px;
    background: var(--card-bg);
    border-radius: var(--radius);
    box-shadow: var(--shadow-sm);
    border: 1px solid var(--border-light);
}
.category-filter a {
    display: inline-block;
    padding: 4px 16px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
    color: var(--text-secondary);
    background: var(--bg);
    border: 1px solid transparent;
    transition: var(--transition);
    text-decoration: none;
}
.category-filter a:hover {
    background: var(--accent-light);
    color: var(--accent);
    border-color: var(--accent);
}
.category-filter a.active {
    background: var(--accent);
    color: #fff;
    border-color: var(--accent);
}

/* 搜索栏 */
.search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}
.search-bar input[type="text"] {
    flex: 1;
    margin-bottom: 0;
}
.search-bar button {
    padding: 12px 24px;
    flex-shrink: 0;
}

/* 分页 */
.pagination {
    display: flex;
    gap: 6px;
    justify-content: center;
    margin-top: 24px;
    flex-wrap: wrap;
}
.pagination a {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 14px;
    font-weight: 500;
    color: var(--text);
    background: var(--card-bg);
    border: 1px solid var(--border);
    text-decoration: none;
    transition: var(--transition);
}
.pagination a:hover {
    border-color: var(--accent);
    background: var(--accent-light);
    color: var(--accent);
}
.pagination a.active {
    background: var(--accent);
    color: #fff;
    border-color: var(--accent);
}

.detail-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:24px;padding-top:20px;border-top:1px solid var(--border-light);}

/* 评论区 */
.comment-item{padding:16px 0;border-bottom:1px solid var(--border-light);}
.comment-meta{font-size:13px;color:var(--text-muted);margin-bottom:8px;display:flex;align-items:center;gap:8px;flex-wrap:wrap;}
.comment-avatar{
    width:32px;height:32px;border-radius:50%;background:var(--accent);color:#fff;
    display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;
    overflow:hidden;flex-shrink:0;
}
.comment-avatar img{width:100%;height:100%;object-fit:cover;max-width: 100%;}
.comment-content{margin-left:42px; white-space: pre-wrap; word-wrap: break-word;}
.comment-content img{max-width:100%;height:auto;border-radius:4px;margin:6px 0;display:block;}
.comment-content pre{overflow-x:auto;max-width:100%;}
.comment-content table{display:block;overflow-x:auto;max-width:100%;}

/* 彩色用户名动画 */
.ben-name {
    font-weight:600;
    text-decoration:none;
    font-size:14px;
    transition:color 0.2s;
}
.ben-name.colorful {
    color: #f1948a;
    animation: colorful 3s linear infinite;
    text-shadow: 0 0 10px rgba(0,0,0,0.2);
}
@keyframes colorful {
    0% { color: #f1948a; }
    17% { color: #f5b041; }
    33% { color: #f7dc6f; }
    50% { color: #82e0aa; }
    67% { color: #85c1e9; }
    83% { color: #bb8fce; }
    100% { color: #f1948a; }
}
.tag {
    border-radius:3px;
    padding:2px 9px;
    color:#fff;
    display:inline-block;
    margin:2px 5px;
    font-size:11.5px;
    font-weight:600;
}
.tag.colorful-bg {
    animation: colorfulBg 3s linear infinite;
}
@keyframes colorfulBg {
    0% { background-color: #f1948a; }
    17% { background-color: #f5b041; }
    33% { background-color: #f7dc6f; }
    50% { background-color: #82e0aa; }
    67% { background-color: #85c1e9; }
    83% { background-color: #bb8fce; }
    100% { background-color: #f1948a; }
}

@media(max-width:768px){
    .main{flex-direction:column;padding:0 12px;margin:20px auto 32px;gap:16px;}
    .sidebar{width:100%;position:static;display:flex;flex-wrap:wrap;}
    .sidebar a{flex:1 1 auto;padding:12px 12px;font-size:13px;border-left:none;border-bottom:2px solid transparent;border-radius:0;}
    .sidebar a:hover{border-left-color:transparent;border-bottom-color:var(--accent);}
    .edit-layout{flex-direction:column;}
    .edit-side{width:100%;}
    .card{padding:18px 16px;}
    .header-actions{flex-direction:column;align-items:flex-start;}
    .comment-content{margin-left:0;}
    .search-bar{flex-direction:column;}
    .search-bar button{width:100%;}
}
</style>

    <!-- 文章页绿玻璃主题（仿 /benben 风格）｜离线交付件
         部署：把 article-theme.css 上传到站点 /css/ 目录即可 -->
    <link rel="stylesheet" href="/css/article-theme.css">
</head>
<body>
<?php include 'navbar.php'; ?>
<div class="main">
    <?php include 'sidebar.php';//侧边栏 ?>
    <div class="content">
        <?php if($msg && $id===0 && !$isEdit): ?>
            <div class="error-box"><?=safeContent($msg)?></div>
        <?php endif; ?>
        <?php if ($isEdit): ?>
            <a href="https://lmtoj.cn/article" class="back-btn">← 返回列表</a>
            <div class="card">
                <h2><?= ($article && $article['id'] > 0) ? '编辑文章' : '创建文章' ?></h2>
                <form method="post">
                    <input type="hidden" name="article_id" value="<?=$article['id']??0?>">
                    <div class="edit-layout">
                        <div class="edit-main">
                            <input type="text" name="title" placeholder="标题" value="<?=safeContent($article['title']??'')?>" required>
                            <textarea name="content" placeholder="正文内容（支持 Markdown 与 Latex）" required><?=safeContent($article['content']??'')?></textarea>
                        </div>
                        <div class="edit-side">
                            <label>分类</label>
                            <select name="category" required>
                                <option value="">--请选择--</option>
                                <?php foreach($categories as $cat): ?>
                                    <option value="<?=$cat?>" <?=(($article['category']??'')==$cat)?'selected':''?>><?=$cat?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" style="margin-top:20px;width:100%;">保存文章</button>
                        </div>
                    </div>
                </form>
            </div>
        <?php elseif ($article && $article['id'] > 0): ?>
            <?php
            $authorData = null;
            if ($article['uid'] > 0) {
                $authStmt = $conn->prepare("SELECT name, admin, tag, avatar, practice_score, contribute_score, contest_score, base_credit, valuation, username_color, cert_type, cert_level FROM users WHERE uid = ?");
                $authStmt->bind_param("i", $article['uid']);
                $authStmt->execute();
                $authorData = $authStmt->get_result()->fetch_assoc();
                $authStmt->close();
            }
            $authorName = $authorData['name'] ?? '未知用户';
            $authorAdmin = (int)($authorData['admin'] ?? 0);
            $authorTag = $authorData['tag'] ?? '';
            $authorAvatar = $authorData['avatar'] ?? '';
            $base = (int)($authorData['base_credit'] ?? 10);
            $achievement = min(getAchievementScore($authorData['cert_type'] ?? '', (int)($authorData['cert_level'] ?? 0)), 20);
            $practice = min((int)($authorData['practice_score'] ?? 0), 20);
            $contribute = min((int)($authorData['contribute_score'] ?? 0), 30);
            $contest = min((int)($authorData['contest_score'] ?? 0), 20);
            $valuation = (int)($authorData['valuation'] ?? 0);
            $isBrown = ($valuation === -1);
            $totalScore = $isBrown ? -1 : ($base + $achievement + $practice + $contribute + $contest);
            $targetColorful = ($authorData['username_color'] ?? 'auto') === 'beautiful' && ($achievement >= 20 || $practice >= 30 || $contribute >= 30 || $contest >= 20);
            $isColorful = false;
            if ($article['uid'] == $login_uid) {
                $isColorful = $targetColorful;
            } else {
                $isColorful = $targetColorful && $myShowColorful;
            }
            $authorColor = getColorByTotalScore($totalScore, $authorAdmin);
            ?>
            <a href="https://lmtoj.cn/article" class="back-btn">← 返回文章列表</a>
            <?php if ($msg): ?>
                <div class="error-box"><?=safeContent($msg)?></div>
            <?php endif; ?>
            <div class="card">
                <h2><?=safeContent($article['title'])?></h2>
                <div class="article-meta">
                    <span>
                        <?php if(!empty($authorAvatar)): ?>
                            <img src="<?=safeContent($authorAvatar)?>" style="width:24px;height:24px;border-radius:50%;object-fit:cover;display:inline-block;vertical-align:middle;">
                        <?php endif; ?>
                        <a href="https://lmtoj.cn/user/<?=$article['uid']?>" class="ben-name<?= $isColorful ? ' colorful' : '' ?>" <?= $isColorful ? '' : 'style="color: ' . $authorColor . ';"' ?>>
                            <?=safeContent($authorName)?>
                        </a>
                        <?php if($authorTag): ?>
                            <span class="tag<?= $isColorful ? ' colorful-bg' : '' ?>" <?= $isColorful ? '' : 'style="background: ' . $authorColor . ';"' ?>>
                                <?=safeContent($authorTag)?>
                            </span>
                        <?php endif; ?>
                    </span>
                    <span class="category-tag"><?=safeContent($article['category'])?></span>
                    <span><?=formatTime($article['created_at'])?></span>
                    <span class="like-badge">赞：<?=$likesCount?></span>
                    <span class="comment-badge">评论：<?=count($comments)?></span>
                </div>

                <!-- ========== 新增：管理员提示红色框（仅 sqadmin 可编辑） ========== -->
                <?php
                $showNotice = $sqadmin || !empty($article['admin_notice']);
                if ($showNotice):
                ?>
                <div class="admin-notice" style="background:#fde8e8;border:2px solid #e74c3c;padding:16px 20px;border-radius:8px;margin-bottom:20px;">
                    <?php if ($sqadmin): ?>
                        <!-- sqadmin 可编辑 -->
                        <form method="post" style="margin:0;">
                            <input type="hidden" name="action_type" value="update_admin_notice">
                            <input type="hidden" name="article_id" value="<?= $article['id'] ?>">
                            <label style="font-weight:600;color:#a94442;display:block;margin-bottom:6px;">管理员提示</label>
                            <textarea name="admin_notice" style="width:100%;min-height:80px;background:#fff;border:1px solid #ccc;border-radius:4px;padding:10px;font-size:14px;resize:vertical;"><?= safeContent($article['admin_notice'] ?? '') ?></textarea>
                            <button type="submit" style="margin-top:10px;padding:6px 20px;background:#c0392b;border:none;border-radius:4px;color:#fff;font-weight:500;cursor:pointer;">保存提示</button>
                        </form>
                    <?php elseif (!empty($article['admin_notice'])): ?>
                        <!-- 普通用户只读显示 -->
                        <div style="color:#a94442;font-weight:500;">📢 管理员提示</div>
                        <div style="margin-top:4px;white-space:pre-wrap;"><?= safeContent($article['admin_notice']) ?></div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="article-content" data-raw="<?=safeContent($article['content'])?>"></div>
                <div class="detail-actions">
                    <a href="https://lmtoj.cn/article/<?=$article['id']?>?toggle_like=1" class="btn-sm <?=$userLiked ? 'btn-liked' : 'btn-like'?>">
                        <?= $userLiked ? '取消点赞' : '点赞' ?>
                    </a>
                    <a href="https://lmtoj.cn/article/<?=$article['id']?>?toggle_dislike=1" class="btn-sm <?= $userDisliked ? 'btn-danger' : '' ?>" style="<?= !$userDisliked ? 'background:#f1f1f1;color:#666;' : '' ?>">
                        <?= $userDisliked ? '取消点踩' : '点踩' ?>（<?=$dislikesCount?>）
                    </a>
                    <?php if ($artadmin || $article['uid'] == $login_uid): ?>
                        <a href="https://lmtoj.cn/article/<?=$article['id']?>/edit" class="btn-sm btn-green">编辑</a>
                    <?php endif; ?>
                    <?php if ($artadmin): ?>
                        <a href="https://lmtoj.cn/article/<?=$article['id']?>?toggle_recommend=1" class="btn-sm <?=$article['is_recommended']?'btn-orange':'btn-green'?>">
                            <?=$article['is_recommended'] ? '取消推荐' : '推荐'?>
                        </a>
                    <?php endif; ?>
                    <?php if ($artadmin || $article['uid'] == $login_uid): ?>
                        <a href="https://lmtoj.cn/article/<?=$article['id']?>?delete=1" class="btn-sm btn-danger" onclick="return confirm('确定删除此文章？')">删除</a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- 评论区 -->
            <div class="card">
                <h3>评论</h3>
                <?php if (empty($comments)): ?>
                    <p style="color:var(--text-muted);">暂无评论</p>
                <?php else: ?>
                    <?php foreach ($comments as $comment):
                        $cBase = (int)($comment['base_credit'] ?? 10);
                        $cAchieve = min(getAchievementScore($comment['cert_type'] ?? '', (int)($comment['cert_level'] ?? 0)), 20);
                        $cPractice = min((int)($comment['practice_score'] ?? 0), 20);
                        $cContribute = min((int)($comment['contribute_score'] ?? 0), 30);
                        $cContest = min((int)($comment['contest_score'] ?? 0), 20);
                        $cValuation = (int)($comment['valuation'] ?? 0);
                        $cIsBrown = ($cValuation === -1);
                        $cTotal = $cIsBrown ? -1 : ($cBase + $cAchieve + $cPractice + $cContribute + $cContest);
                        $cAdmin = (int)($comment['admin'] ?? 0);
                        $cColor = getColorByTotalScore($cTotal, $cAdmin);
                        $cTargetColorful = ($comment['username_color'] ?? 'auto') === 'beautiful' && ($cAchieve >= 20 || $cPractice >= 30 || $cContribute >= 30 || $cContest >= 20);
                        $cIsColorful = false;
                        if ($comment['uid'] == $login_uid) {
                            $cIsColorful = $cTargetColorful;
                        } else {
                            $cIsColorful = $cTargetColorful && $myShowColorful;
                        }
                        $commentAvatar = $comment['avatar'] ?? '';
                        $commentTag = $comment['tag'] ?? '';
                        $canDelete = ($comment['uid'] == $login_uid || $article['uid'] == $login_uid || $sqadmin || $artadmin);
                    ?>
                    <div class="comment-item">
                        <div class="comment-meta">
                            <span class="comment-avatar">
                                <?php if (!empty($commentAvatar)): ?>
                                    <img src="<?=safeContent($commentAvatar)?>" alt="avatar">
                                <?php else: ?>
                                    <?=getFirstChar($comment['name'])?>
                                <?php endif; ?>
                            </span>
                            <a href="https://lmtoj.cn/user/<?=$comment['uid']?>" class="ben-name<?= $cIsColorful ? ' colorful' : '' ?>" <?= $cIsColorful ? '' : 'style="color: ' . $cColor . ';"' ?>>
                                <?=safeContent($comment['name'])?>
                            </a>
                            <?php if($commentTag): ?>
                                <span class="tag<?= $cIsColorful ? ' colorful-bg' : '' ?>" <?= $cIsColorful ? '' : 'style="background: ' . $cColor . ';"' ?>>
                                    <?=safeContent($commentTag)?>
                                </span>
                            <?php endif; ?>
                            · <?=formatTime($comment['created_at'])?>
                            <?php if ($canDelete): ?>
                                <a href="https://lmtoj.cn/article/<?=$article['id']?>?del_comment=<?=$comment['id']?>" onclick="return confirm('确定删除此评论？')" class="btn-sm btn-danger" style="font-size:12px;padding:2px 10px;">删除</a>
                            <?php endif; ?>
                        </div>
                        <div class="comment-content md-content" data-raw="<?=safeContent($comment['content'])?>"></div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
            <!-- 发表评论 -->
            <div class="card">
                <h3>发表评论</h3>
                <form method="post">
                    <div class="edit-wrap" style="display:flex;gap:16px;width:100%;">
                        <div class="edit-box" style="width:50%;">
                            <textarea name="comment_content" id="commentEditor" placeholder="支持 Markdown / LaTeX 公式、@用户" style="min-height:120px;margin-bottom:0;" required></textarea>
                        </div>
                        <div class="preview-box" id="commentPreview" style="width:50%;border:1px solid var(--border-light);border-radius:var(--radius-sm);padding:14px;min-height:120px;overflow-y:auto;background:#fafaf8;font-size:14px;">预览区域</div>
                    </div>
                    <button type="submit" style="margin-top:16px;">发布评论</button>
                </form>
            </div>
        <?php else: ?>
            <!-- 文章列表 -->
            <div class="header-actions">
                <h2>文章广场</h2>
                <a href="https://lmtoj.cn/article/0/edit" class="btn-create">创建文章</a>
            </div>
            <!-- 搜索栏 -->
            <form method="get" class="search-bar" action="https://lmtoj.cn/article">
                <input type="text" name="search" placeholder="搜索文章标题或内容…" value="<?=safeContent($searchKeyword)?>">
                <?php if ($filterCategory): ?>
                    <input type="hidden" name="category" value="<?=safeContent($filterCategory)?>">
                <?php endif; ?>
                <button type="submit">搜索</button>
            </form>
            <div class="category-filter">
                <a href="https://lmtoj.cn/article<?= $searchKeyword ? '?search='.urlencode($searchKeyword) : '' ?>" class="<?= empty($filterCategory) ? 'active' : '' ?>">全部</a>
                <?php foreach ($categories as $cat): ?>
                    <a href="?category=<?=urlencode($cat)?><?= $searchKeyword ? '&search='.urlencode($searchKeyword) : '' ?>" class="<?= ($filterCategory === $cat) ? 'active' : '' ?>"><?=safeContent($cat)?></a>
                <?php endforeach; ?>
            </div>
            <?php if (empty($listArticles)): ?>
                <div class="card"><p style="color:var(--text-muted);font-size:16px;">暂无文章</p></div>
            <?php else: ?>
                <?php foreach ($listArticles as $item):
                    $lBase = (int)($item['base_credit'] ?? 10);
                    $lAchieve = min(getAchievementScore($item['cert_type'] ?? '', (int)($item['cert_level'] ?? 0)), 20);
                    $lPractice = min((int)($item['practice_score'] ?? 0), 20);
                    $lContribute = min((int)($item['contribute_score'] ?? 0), 30);
                    $lContest = min((int)($item['contest_score'] ?? 0), 20);
                    $lValuation = (int)($item['valuation'] ?? 0);
                    $lIsBrown = ($lValuation === -1);
                    $lTotal = $lIsBrown ? -1 : ($lBase + $lAchieve + $lPractice + $lContribute + $lContest);
                    $lAdmin = (int)($item['admin'] ?? 0);
                    $lColor = getColorByTotalScore($lTotal, $lAdmin);
                    $lTargetColorful = ($item['username_color'] ?? 'auto') === 'beautiful' && ($lAchieve >= 20 || $lPractice >= 30 || $lContribute >= 30 || $lContest >= 20);
                    $lIsColorful = false;
                    if ($item['uid'] == $login_uid) {
                        $lIsColorful = $lTargetColorful;
                    } else {
                        $lIsColorful = $lTargetColorful && $myShowColorful;
                    }
                    $commentCount = (int)($item['comment_count'] ?? 0);
                    $dislikesCountList = (int)($item['dislikes_count'] ?? 0);
                    $itemAvatar = $item['avatar'] ?? '';
                ?>
                    <div class="card article-item">
                        <div class="article-title">
                            <a href="https://lmtoj.cn/article/<?=$item['id']?>"><?=safeContent($item['title'])?></a>
                        </div>
                        <div class="article-meta">
                            <span>
                                <?php if(!empty($itemAvatar)): ?>
                                    <img src="<?=safeContent($itemAvatar)?>" style="width:24px;height:24px;border-radius:50%;object-fit:cover;display:inline-block;vertical-align:middle;">
                                <?php endif; ?>
                                <a href="https://lmtoj.cn/user/<?=$item['uid']?>" class="ben-name<?= $lIsColorful ? ' colorful' : '' ?>" <?= $lIsColorful ? '' : 'style="color: ' . $lColor . ';"' ?>>
                                    <?=safeContent($item['name'])?>
                                </a>
                                <?php if($item['tag']): ?>
                                    <span class="tag<?= $lIsColorful ? ' colorful-bg' : '' ?>" <?= $lIsColorful ? '' : 'style="background: ' . $lColor . ';"' ?>>
                                        <?=safeContent($item['tag'])?>
                                    </span>
                                <?php endif; ?>
                            </span>
                            <span class="category-tag"><?=safeContent($item['category'])?></span>
                            <span><?=date("Y-m-d H:i",strtotime($item['created_at']))?></span>
                            <?php if($item['is_recommended']): ?>
                                <span class="recommend-badge">推荐</span>
                            <?php endif; ?>
                            <span class="like-badge">赞：<?= (int)($item['likes_count'] ?? 0) ?></span>
                            <span style="color:var(--danger);display:inline-flex;align-items:center;gap:4px;font-weight:500;">踩：<?=$dislikesCountList?></span>
                            <span class="comment-badge">评论：<?= $commentCount ?></span>
                            <?php if($is_admin): ?>
                                <span style="color:var(--text-muted);font-size:12px;">(UID: <?=$item['uid']?>)</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
                <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php
                        $baseUrl = '?';
                        if ($searchKeyword) $baseUrl .= 'search=' . urlencode($searchKeyword) . '&';
                        if ($filterCategory) $baseUrl .= 'category=' . urlencode($filterCategory) . '&';
                    ?>
                    <?php if ($page > 1): ?>
                        <a href="<?=$baseUrl?>page=<?=$page-1?>">上一页</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="<?=$baseUrl?>page=<?=$i?>" class="<?= $i == $page ? 'active' : '' ?>"><?=$i?></a>
                    <?php endfor; ?>
                    <?php if ($page < $totalPages): ?>
                        <a href="<?=$baseUrl?>page=<?=$page+1?>">下一页</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<script>
// ---------- Markdown 渲染 ----------
const nameToUid = <?= json_encode($nameToUid, JSON_UNESCAPED_UNICODE) ?>;
const markdownRenderer = MarkdownRenderer.create({
    nameToUid,
    markdownOptions: { html: false, linkify: true, typographer: true, breaks: true },
    katexOptions: { macros: { "\\RR": "\\mathbb{R}" } }
});
document.addEventListener('DOMContentLoaded', function() {
    markdownRenderer.renderAll({selector: '.article-content, .comment-content'});
    var commentEditor = document.getElementById('commentEditor');
    var commentPreview = document.getElementById('commentPreview');
    if (commentEditor && commentPreview) markdownRenderer.bindPreview(commentEditor, commentPreview, {syncScroll: true});
    var postEditor = document.getElementById('postEditor');
    var postPreview = document.getElementById('postPreview');
    if (postEditor && postPreview) markdownRenderer.bindPreview(postEditor, postPreview, {syncScroll: true});
    var editEditor = document.getElementById('editEditor');
    var editPreview = document.getElementById('editPreview');
    if (editEditor && editPreview) markdownRenderer.bindPreview(editEditor, editPreview, {syncScroll: true});
});
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>