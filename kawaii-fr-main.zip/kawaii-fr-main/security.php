<?php

if (!function_exists('csrf_token')) {
    function csrf_token(): string
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            throw new RuntimeException('CSRF protection requires an active session.');
        }

        $token = $_SESSION['csrf_token'] ?? '';
        if (!is_string($token) || !preg_match('/^[a-f0-9]{64}$/', $token)) {
            $token = bin2hex(random_bytes(32));
            $_SESSION['csrf_token'] = $token;
        }

        return $token;
    }

    function csrf_field(): string
    {
        return '<input type="hidden" name="_csrf" value="'
            . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')
            . '">';
    }

    function csrf_request_token(): string
    {
        $token = $_POST['_csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        return is_string($token) ? $token : '';
    }

    function csrf_token_is_valid(?string $token = null): bool
    {
        $expected = $_SESSION['csrf_token'] ?? '';
        $provided = $token ?? csrf_request_token();

        return is_string($expected)
            && $expected !== ''
            && is_string($provided)
            && hash_equals($expected, $provided);
    }

    function csrf_reject(): void
    {
        http_response_code(403);
        header('Content-Type: text/plain; charset=utf-8');
        exit('请求已被拒绝：安全令牌无效或页面已过期，请刷新页面后重试。');
    }

    function csrf_is_same_origin_request(): bool
    {
        $fetchSite = strtolower(trim((string) ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
        if ($fetchSite !== '') {
            return $fetchSite === 'same-origin';
        }

        $source = (string) ($_SERVER['HTTP_ORIGIN'] ?? ($_SERVER['HTTP_REFERER'] ?? ''));
        if ($source === '') {
            return false;
        }

        $sourceHost = parse_url($source, PHP_URL_HOST);
        $sourcePort = parse_url($source, PHP_URL_PORT);
        if (!is_string($sourceHost) || $sourceHost === '') {
            return false;
        }

        $requestHost = strtolower((string) ($_SERVER['HTTP_HOST'] ?? ''));
        $sourceAuthority = strtolower($sourceHost . ($sourcePort ? ':' . $sourcePort : ''));
        return hash_equals($requestHost, $sourceAuthority);
    }

    function csrf_get_changes_state(): bool
    {
        $mutationKeys = [
            'logout', 'rename_user', 'ban_user', 'unban_user', 'ban_users',
            'unban_users', 'del_user', 'set_brown', 'unset_brown', 'set_admins',
            'unset_admins', 'set_jinyans', 'cancel_jinyans', 'del_users',
            'cancel_sixin', 'set_sixin', 'del_visit', 'del_cert', 'del_comment',
            'toggle_like', 'toggle_recommend', 'verify_id', 'del_bind_id',
            'del_id', 'checkin', 'del_tid', 'del_rid', 'kick_uid', 'toggle_mute',
            'delete_conv', 'clear_group', 'del_img', 'del_test', 'self_unban',
            'handle', 'set_ws', 'quick_reply', 'unzhiding', 'delete', 'clear'
        ];

        foreach ($mutationKeys as $key) {
            if (array_key_exists($key, $_GET)) {
                return true;
            }
        }

        $action = strtolower((string) ($_GET['action'] ?? ''));
        return in_array($action, [
            'delete', 'handle', 'analyze_interests', 'sync_push_all',
            'sync_pull_all', 'sync_db'
        ], true);
    }

    function csrf_protect_request(bool $authenticated): void
    {
        if (!$authenticated) {
            return;
        }

        csrf_token();
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

        if ($method === 'POST' && !csrf_token_is_valid()) {
            csrf_reject();
        }

        $getToken = $_GET['_csrf'] ?? '';
        if ($method === 'GET' && csrf_get_changes_state()
            && !(is_string($getToken) && csrf_token_is_valid($getToken))
            && !csrf_is_same_origin_request()) {
            csrf_reject();
        }
    }
}
