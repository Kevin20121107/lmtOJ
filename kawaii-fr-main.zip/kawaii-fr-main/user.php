<?php
error_reporting(E_ALL);
ini_set('display_errors', 0); // 生产环境关闭错误显示
date_default_timezone_set('Asia/Shanghai');

ob_start(); // 开启输出缓冲

require_once 'visit_log.php';
header("Content-Type:text/html;charset=utf-8");

if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: https://lmtoj.cn/login");
    exit;
}

require_once __DIR__ . '/database.php';
$conn = db();
$conn->set_charset("utf8mb4");

// ========== 提前定义估值相关函数 ==========
function getAchievementScore($certType, $certLevel) {
    if (empty($certType) || $certLevel <= 0) return 0;
    $validTypes = ['OI', 'ICPC'];
    if (!in_array(strtoupper($certType), $validTypes)) return 0;
    $map = [3=>2, 4=>3, 5=>5, 6=>10, 7=>13, 8=>15, 9=>18, 10=>20];
    return $map[$certLevel] ?? 0;
}

function getValuationColor($value, $isAdmin = false) {
    if ($isAdmin) return 'purple';
    if ($value < 0) return 'brown';
    if ($value <= 10) return 'gray';
    if ($value <= 20) return 'blue';
    if ($value <= 45) return 'green';
    if ($value <= 65) return 'orange';
    return 'red';
}

$colorMap = [
    'gray'   => '#b0a8a0',
    'blue'   => '#4a90d9',
    'green'  => '#28a745',
    'orange' => '#e67e22',
    'red'    => '#e74c3c',
    'brown'  => '#8b6b4d',
    'purple' => '#8e44ad'
];
$colorNames = [
    'gray'   => 'Gray',
    'blue'   => 'Blue',
    'green'  => 'Green',
    'orange' => 'Orange',
    'red'    => 'Red',
    'brown'  => 'Brown',
    'purple' => 'Purple'
];

$visit_uid = isset($_GET['uid']) ? (int)$_GET['uid'] : 0;
if ($visit_uid < 0) {
    header("Location: index.php");
    exit;
}

$login_uid = isset($_SESSION['uid']) ? (int)$_SESSION['uid'] : 0;
$is_admin = 0;
$unreadCount = 0;
$isSelf = ($login_uid === $visit_uid);

// ==================== AJAX 处理（必须提前，保证纯净 JSON）====================
if (isset($_GET['action'])) {
    // 清除之前可能产生的任何输出，关闭错误显示
    ob_clean();
    ini_set('display_errors', 0);
    header('Content-Type: application/json');

    // ========== 关注/取消关注 ==========
    if ($_GET['action'] === 'toggle_follow' && $login_uid > 0 && isset($_GET['target_uid'])) {
        $targetUid = (int)$_GET['target_uid'];
        if ($targetUid > 0 && $targetUid != $login_uid) {
            $banRes = $conn->query("SELECT banned FROM users WHERE uid = {$targetUid}")->fetch_assoc();
            $res = $conn->query("SELECT id FROM follow WHERE follower_uid = {$login_uid} AND following_uid = {$targetUid} LIMIT 1");
            if ($res->num_rows > 0) {
                $conn->query("DELETE FROM follow WHERE follower_uid = {$login_uid} AND following_uid = {$targetUid}");
                $isFollowingNow = false;
            } else {
                $conn->query("INSERT INTO follow (follower_uid, following_uid) VALUES ({$login_uid}, {$targetUid})");
                $isFollowingNow = true;
            }
            $fCount = $conn->query("SELECT COUNT(*) as cnt FROM follow WHERE following_uid = {$targetUid}")->fetch_assoc()['cnt'];
            $mutualRes = $conn->query("SELECT 1 FROM follow WHERE follower_uid = {$targetUid} AND following_uid = {$login_uid} LIMIT 1");
            $mutual = $mutualRes->num_rows > 0;

            echo json_encode([
                'success'        => true,
                'is_following'   => $isFollowingNow,
                'follower_count' => (int)$fCount,
                'mutual'         => $mutual
            ]);
            ob_end_flush(); exit;
        } else {
            echo json_encode(['success' => false, 'message' => '无效目标']);
            ob_end_flush(); exit;
        }
    }

    // ========== 关注/粉丝列表 ==========
    if ($_GET['action'] === 'follow_list' && isset($_GET['type']) && isset($_GET['uid'])) {
        $type = $_GET['type'];
        $listUid = (int)$_GET['uid'];
        if ($listUid <= 0) {
            echo json_encode(['html'=>'', 'total_pages'=>0, 'current_page'=>1]);
            ob_end_flush(); exit;
        }

        $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
        $perPage = 10;
        $offset = ($page - 1) * $perPage;

        if ($type === 'following') {
            $countSql = "SELECT COUNT(*) as total FROM follow WHERE follower_uid = {$listUid}";
            $dataSql  = "SELECT u.uid, u.name, u.avatar, u.base_credit, u.cert_type, u.cert_level, 
                                u.practice_score, u.contribute_score, u.contest_score, u.valuation, u.admin
                         FROM users u JOIN follow f ON u.uid = f.following_uid 
                         WHERE f.follower_uid = {$listUid} 
                         ORDER BY f.created_at DESC 
                         LIMIT {$perPage} OFFSET {$offset}";
        } elseif ($type === 'followers') {
            $countSql = "SELECT COUNT(*) as total FROM follow WHERE following_uid = {$listUid}";
            $dataSql  = "SELECT u.uid, u.name, u.avatar, u.base_credit, u.cert_type, u.cert_level, 
                                u.practice_score, u.contribute_score, u.contest_score, u.valuation, u.admin
                         FROM users u JOIN follow f ON u.uid = f.follower_uid 
                         WHERE f.following_uid = {$listUid} 
                         ORDER BY f.created_at DESC 
                         LIMIT {$perPage} OFFSET {$offset}";
        } else {
            echo json_encode(['html'=>'', 'total_pages'=>0, 'current_page'=>1]);
            ob_end_flush(); exit;
        }

        $totalRes = $conn->query($countSql);
        $total = $totalRes->fetch_assoc()['total'];
        $totalPages = ceil($total / $perPage);
        $dataRes = $conn->query($dataSql);
        $users = [];
        while ($row = $dataRes->fetch_assoc()) $users[] = $row;

        $followedUids = [];
        $uids = [];
        if ($login_uid > 0 && !empty($users)) {
            $uids = array_filter(array_map(function($u) use ($login_uid) {
                return $u['uid'] != $login_uid ? (int)$u['uid'] : null;
            }, $users));
            if (!empty($uids)) {
                $uidsStr = implode(',', $uids);
                $fRes = $conn->query("SELECT following_uid FROM follow WHERE follower_uid = {$login_uid} AND following_uid IN ({$uidsStr})");
                while ($fr = $fRes->fetch_assoc()) $followedUids[(int)$fr['following_uid']] = true;
            }
        }

        // 互相关注查询
        $mutualUids = [];
        if ($login_uid > 0 && !empty($uids)) {
            $uidsStr = implode(',', $uids);
            $mRes = $conn->query("SELECT follower_uid FROM follow WHERE following_uid = {$login_uid} AND follower_uid IN ({$uidsStr})");
            while ($mr = $mRes->fetch_assoc()) $mutualUids[(int)$mr['follower_uid']] = true;
        }

        $items = '';
        foreach ($users as $row) {
            $uid = (int)$row['uid'];
            $achievementScore = min(getAchievementScore($row['cert_type'] ?? '', (int)($row['cert_level'] ?? 0)), 20);
            $practiceScore   = min((int)($row['practice_score'] ?? 0), 20);
            $contributeScore = min((int)($row['contribute_score'] ?? 0), 30);
            $contestScore    = min((int)($row['contest_score'] ?? 0), 20);
            $baseCredit      = (int)($row['base_credit'] ?? 10);
            $totalScore      = $baseCredit + $achievementScore + $practiceScore + $contributeScore + $contestScore;
            $isBrown         = ((int)($row['valuation'] ?? 0) === -1);
            $colorKey        = $isBrown ? 'brown' : getValuationColor($totalScore, (int)($row['admin'] ?? 0) == 1);
            $colorHex        = $colorMap[$colorKey] ?? '#b0a8a0';

            $avatarHtml = !empty($row['avatar'])
                ? '<img src="'.getImgUrl($row['avatar']).'" style="width:100%;height:100%;object-fit:cover;">'
                : getFirstChar($row['name']);

            $followBtnHtml = '';
            if ($login_uid > 0 && $uid != $login_uid) {
                $isFollowed = isset($followedUids[$uid]);
                $btnStyle   = $isFollowed ? 'background:var(--text-muted);' : '';
                $btnText = '关注';
                if ($isFollowed) {
                    $btnText = isset($mutualUids[$uid]) ? '互相关注' : '已关注';
                }
                $followBtnHtml = '<button class="btn btn-sm" style="margin-left:auto; '.$btnStyle.'" 
                    onclick="toggleFollowFromList(this, '.$uid.', \''.$type.'\')">'.$btnText.'</button>';
            }

            $items .= '<div class="follow-list-item" style="display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--border-light);">
                <div class="user-avatar" style="width:36px;height:36px;font-size:16px;border-radius:50%;background:var(--accent);color:#fff;display:flex;align-items:center;justify-content:center;overflow:hidden;flex-shrink:0;">
                    '.$avatarHtml.'
                </div>
                <a href="/user/'.$uid.'" style="text-decoration:none; color:'.$colorHex.'; font-weight:600;">'.safeContent($row['name']).'</a>
                '.$followBtnHtml.'
            </div>';
        }

        $paginationHtml = '';
        if ($totalPages > 1) {
            $paginationHtml = '<div style="margin-top:12px; display:flex; justify-content:center; gap:6px;">';
            for ($i = 1; $i <= $totalPages; $i++) {
                $active = ($i == $page) ? 'background:var(--accent); color:#fff;' : 'background:#f0ece6; color:var(--text);';
                $paginationHtml .= '<button class="btn btn-sm" style="'.$active.'" onclick="showFollowList(\''.$type.'\', '.$listUid.', '.$i.')">'.$i.'</button>';
            }
            $paginationHtml .= '</div>';
        }

        $resultHtml = ($items ?: '<p style="color:var(--text-muted);">暂无数据</p>') . $paginationHtml;
        echo json_encode([
            'html' => $resultHtml,
            'total_pages' => $totalPages,
            'current_page' => $page
        ]);
        ob_end_flush(); exit;
    }
}

// ==================== 以下是页面主体（非 AJAX 请求时执行）====================

// ========== 自动建表与修复字符集 ==========
$conn->query("CREATE TABLE IF NOT EXISTS user_ip_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    uid INT NOT NULL,
    ip VARCHAR(45) NOT NULL,
    last_seen TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    count INT DEFAULT 1,
    UNIQUE KEY uid_ip (uid, ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS ip_cache (
    ip VARCHAR(45) PRIMARY KEY,
    city VARCHAR(100) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("CREATE TABLE IF NOT EXISTS follow (
    id INT AUTO_INCREMENT PRIMARY KEY,
    follower_uid INT NOT NULL,
    following_uid INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_follow (follower_uid, following_uid),
    INDEX idx_follower (follower_uid),
    INDEX idx_following (following_uid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$tableStatus = $conn->query("SHOW TABLE STATUS LIKE 'users'")->fetch_assoc();
if ($tableStatus && stripos($tableStatus['Collation'] ?? '', 'utf8mb4') === false) {
    $conn->query("ALTER TABLE users CONVERT TO CHARACTER SET utf8mb4");
}

$ipFields = [
    'frequent_ip' => "VARCHAR(45) DEFAULT ''",
    'location'    => "VARCHAR(100) DEFAULT ''",
    'last_ip_check' => "DATETIME NULL"
];
foreach ($ipFields as $col => $type) {
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col'");
    if ($check->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN $col $type");
    }
}

$fields = [
    'avatar'           => "VARCHAR(500) DEFAULT ''",
    'signature'        => "TEXT",
    'homepage_content' => "TEXT",
    'interests'        => "VARCHAR(500) DEFAULT ''",
    'last_username_change' => "DATETIME NULL",
    'background_image' => "VARCHAR(500) DEFAULT ''",
    'valuation'        => "INT DEFAULT 0",
    'last_valuation_decay' => "DATETIME NULL",
    'cert_type'        => "VARCHAR(20) DEFAULT ''",
    'cert_level'       => "INT DEFAULT 0",
    'practice_score'   => "INT DEFAULT 0",
    'contribute_score' => "INT DEFAULT 0",
    'contest_score'    => "INT DEFAULT 0",
    'username_color'   => "VARCHAR(20) DEFAULT 'auto'",
    'show_colorful_names' => "TINYINT DEFAULT 1",
    'base_credit'      => "INT DEFAULT 10"
];
foreach ($fields as $col => $type) {
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col'");
    if ($check->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN $col $type");
    }
}

$luoguFields = [
    'last_luogu_fetch' => "DATETIME NULL",
    'luogu_ccf'        => "INT DEFAULT 0"
];
foreach ($luoguFields as $col => $type) {
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col'");
    if ($check->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN $col $type");
    }
}

$autoFields = [
    'last_auto_cert_check' => "DATETIME NULL"
];
foreach ($autoFields as $col => $type) {
    $check = $conn->query("SHOW COLUMNS FROM users LIKE '$col'");
    if ($check->num_rows === 0) {
        $conn->query("ALTER TABLE users ADD COLUMN $col $type");
    }
}

$checkBan = $conn->query("SHOW COLUMNS FROM users LIKE 'banned'");
if ($checkBan->num_rows == 0) {
    $conn->query("ALTER TABLE users ADD COLUMN banned TINYINT DEFAULT 0");
}

function getUserIP() {
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        foreach ($ips as $ip) {
            $ip = trim($ip);
            if (filter_var($ip, FILTER_VALIDATE_IP) !== false) {
                return $ip;
            }
        }
    }
    $remoteAddr = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    return filter_var($remoteAddr, FILTER_VALIDATE_IP) !== false ? $remoteAddr : '0.0.0.0';
}

// ========== 原有主逻辑 ==========
if ($login_uid > 0) {
    $currentIP = getUserIP();
    $stmt = $conn->prepare("INSERT INTO user_ip_history (uid, ip) VALUES (?, ?) ON DUPLICATE KEY UPDATE count = count + 1, last_seen = NOW()");
    $stmt->bind_param("is", $login_uid, $currentIP);
    $stmt->execute();
    $stmt->close();
}

if ($login_uid > 0) {
    $adminRes = $conn->query("SELECT admin FROM users WHERE uid = {$login_uid} LIMIT 1");
    if ($adminRes && $adminRes->num_rows > 0) $is_admin = (int)$adminRes->fetch_assoc()['admin'];
    $msgRes = $conn->query("SELECT COUNT(*) AS cnt FROM notice WHERE uid = {$login_uid} AND is_read = 0");
    if ($msgRes) $unreadCount = (int)$msgRes->fetch_assoc()['cnt'];
}

if ($is_admin && isset($_GET['del_cert']) && $visit_uid > 0) {
    $conn->query("UPDATE users SET cert_type = '', cert_level = 0 WHERE uid = {$visit_uid}");
    header("Location: /user/{$visit_uid}");
    exit;
}

// ========== 查询用户信息 ==========
$userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
if (!$userInfo) {
    header("Location: index.php");
    exit;
}

if ($userInfo['admin'] == 1 && (int)$userInfo['contribute_score'] != 30) {
    $conn->query("UPDATE users SET contribute_score = 30 WHERE uid = {$visit_uid}");
    $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
}

// ========== IP属地更新 ==========
$shouldUpdate = false;
if (empty($userInfo['last_ip_check']) || strtotime($userInfo['last_ip_check']) < time() - 7*24*3600) {
    $shouldUpdate = true;
}
if ($shouldUpdate) {
    $freqIP = $conn->query("SELECT ip FROM user_ip_history WHERE uid = {$visit_uid} ORDER BY count DESC, last_seen DESC LIMIT 1")->fetch_assoc()['ip'] ?? '';
    if ($freqIP && filter_var($freqIP, FILTER_VALIDATE_IP) !== false) {
        $cacheStmt = $conn->prepare("SELECT city FROM ip_cache WHERE ip = ? AND updated_at > DATE_SUB(NOW(), INTERVAL 1 DAY)");
        $cacheStmt->bind_param("s", $freqIP);
        $cacheStmt->execute();
        $cached = $cacheStmt->get_result()->fetch_assoc();
        $cacheStmt->close();
        if ($cached) {
            $city = $cached['city'];
        } else {
            $city = getCityByIP($freqIP);
            if ($city) {
                $stmt = $conn->prepare("INSERT INTO ip_cache (ip, city) VALUES (?, ?) ON DUPLICATE KEY UPDATE city = VALUES(city), updated_at = NOW()");
                $stmt->bind_param("ss", $freqIP, $city);
                $stmt->execute();
                $stmt->close();
            }
        }
        $city = $city ?: '未知';
        $updateLocationStmt = $conn->prepare("UPDATE users SET frequent_ip = ?, location = ?, last_ip_check = NOW() WHERE uid = ?");
        $updateLocationStmt->bind_param("ssi", $freqIP, $city, $visit_uid);
        $updateLocationStmt->execute();
        $updateLocationStmt->close();
        $userInfo['frequent_ip'] = $freqIP;
        $userInfo['location'] = $city;
    } else {
        $conn->query("UPDATE users SET last_ip_check = NOW() WHERE uid = {$visit_uid}");
        $userInfo['location'] = '未知';
    }
}

function getCityByIP($ip) {
    if (filter_var($ip, FILTER_VALIDATE_IP) === false) return '未知';
    if ($ip === '127.0.0.1' || $ip === '::1' || strpos($ip, '192.168.') === 0) return '本地';
    $url = "http://ip-api.com/json/" . rawurlencode($ip) . "?fields=city,regionName,country&lang=zh-CN";
    $json = @file_get_contents($url);
    if (!$json) {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 3);
        $json = curl_exec($ch);
        curl_close($ch);
    }
    if ($json) {
        $data = json_decode($json, true);
        if (isset($data['city']) && $data['city']) return $data['city'];
        if (isset($data['regionName'])) return $data['regionName'];
        if (isset($data['country'])) return $data['country'];
    }
    return '未知';
}

function fetchLuoguCCF($luoguUid) {
    $url = "https://www.luogu.com.cn/user/{$luoguUid}";
    $ctx = stream_context_create([
        'http' => [
            'timeout' => 10,
            'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36\r\n"
                        . "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n"
                        . "Accept-Language: zh-CN,zh;q=0.9\r\n"
        ]
    ]);
    $html = @file_get_contents($url, false, $ctx);
    if (!$html) return null;
    if (!preg_match('/<script id="lentille-context"[^>]*>(.*?)<\/script>/s', $html, $m)) return null;
    $json = json_decode($m[1], true);
    if (!$json || !isset($json['data']['user'])) return null;
    return (int)($json['data']['user']['ccfLevel'] ?? 0);
}

$lgBind = $conn->query("SELECT bind_value FROM user_bind WHERE uid = {$visit_uid} AND bind_type='luogu' LIMIT 1")->fetch_assoc();
if ($lgBind && !empty($lgBind['bind_value'])) {
    $luoguUid = $lgBind['bind_value'];
    $lastFetch = strtotime($userInfo['last_luogu_fetch'] ?? '');
    if (!$lastFetch || (time() - $lastFetch) > 24 * 3600) {
        $ccf = fetchLuoguCCF($luoguUid);
        if ($ccf !== null) {
            $stmt = $conn->prepare("UPDATE users SET luogu_ccf = ?, last_luogu_fetch = NOW() WHERE uid = ?");
            $stmt->bind_param("ii", $ccf, $visit_uid);
            $stmt->execute();
            $stmt->close();
            $userInfo['luogu_ccf'] = $ccf;
        }
    }
}

function autoDetectCertFromCCF($uid, $userInfo, $conn) {
    if (empty($uid) || empty($userInfo)) return false;
    $lastCheck = $userInfo['last_auto_cert_check'] ?? null;
    if ($lastCheck && strtotime($lastCheck) > time() - 24 * 3600) {
        return false;
    }

    $ccf = (int)($userInfo['luogu_ccf'] ?? 0);
    $newCertType = '';
    $newCertLevel = 0;
    if ($ccf >= 9) { $newCertType = 'OI'; $newCertLevel = 9; }
    elseif ($ccf >= 7) { $newCertType = 'OI'; $newCertLevel = 7; }
    elseif ($ccf >= 5) { $newCertType = 'OI'; $newCertLevel = 5; }
    elseif ($ccf >= 3) { $newCertType = 'OI'; $newCertLevel = 3; }
    elseif ($ccf >= 2) { $newCertType = 'OI'; $newCertLevel = 2; }

    $currentLevel = (int)($userInfo['cert_level'] ?? 0);
    $currentType  = $userInfo['cert_type'] ?? '';
    if (!empty($currentType) && $currentLevel > $newCertLevel) {
        $newCertType  = $currentType;
        $newCertLevel = $currentLevel;
    }

    $escType = $conn->real_escape_string($newCertType);
    $stmt = $conn->prepare("UPDATE users SET cert_type=?, cert_level=?, last_auto_cert_check=NOW() WHERE uid=?");
    $stmt->bind_param("sii", $escType, $newCertLevel, $uid);
    $stmt->execute();
    $stmt->close();

    return ['cert_type' => $newCertType, 'cert_level' => $newCertLevel];
}

if (($isSelf || $is_admin) && $visit_uid > 0) {
    $autoResult = autoDetectCertFromCCF($visit_uid, $userInfo, $conn);
    if ($autoResult) {
        $userInfo['cert_type']  = $autoResult['cert_type'];
        $userInfo['cert_level'] = $autoResult['cert_level'];
    }
}

$followingCount = $conn->query("SELECT COUNT(*) as cnt FROM follow WHERE follower_uid = {$visit_uid}")->fetch_assoc()['cnt'];
$followerCount = $conn->query("SELECT COUNT(*) as cnt FROM follow WHERE following_uid = {$visit_uid}")->fetch_assoc()['cnt'];
$isFollowing = false;
$isMutual = false;
if ($login_uid > 0 && $login_uid != $visit_uid) {
    $checkFollow = $conn->query("SELECT 1 FROM follow WHERE follower_uid = {$login_uid} AND following_uid = {$visit_uid} LIMIT 1");
    $isFollowing = $checkFollow->num_rows > 0;
    if ($isFollowing) {
        $checkMutual = $conn->query("SELECT 1 FROM follow WHERE follower_uid = {$visit_uid} AND following_uid = {$login_uid} LIMIT 1");
        $isMutual = $checkMutual->num_rows > 0;
    }
}

$benList = $conn->query("SELECT id, text, time FROM benben WHERE uid = {$visit_uid} ORDER BY time DESC, id DESC LIMIT 20");
$lgUid = $conn->query("SELECT bind_value, verified FROM user_bind WHERE uid = {$visit_uid} AND bind_type='luogu' LIMIT 1")->fetch_assoc();

$allUserRes = $conn->query("SELECT uid, name FROM users");
$nameToUid = [];
while ($u = $allUserRes->fetch_assoc()) {
    $nameToUid[$u['name']] = $u['uid'];
}

$tipMsg = '';

$del_id = isset($_GET['del_id']) ? (int)$_GET['del_id'] : 0;
if ($del_id>1) {
    $conn->query("DELETE FROM benben WHERE id = $del_id AND uid = $visit_uid");
    $tipMsg = '删除成功';
    header("Location: /user/{$visit_uid}");
    exit;
}

if (($isSelf || $is_admin) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'batch_delete') {
    $ids = $_POST['ben_ids'] ?? [];
    if (!empty($ids)) {
        $ids = array_map('intval', $ids);
        $idsStr = implode(',', $ids);
        $conn->query("DELETE FROM benben WHERE id IN ($idsStr) AND uid = $visit_uid");
        $tipMsg = '批量删除成功';
    }
    header("Location: /user/{$visit_uid}");
    exit;
}

if ($is_admin && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'admin_set_cert') {
    $certType  = trim($_POST['cert_type'] ?? '');
    $certLevel = (int)($_POST['cert_level'] ?? 0);
    $conn->query("UPDATE users SET cert_type='{$conn->real_escape_string($certType)}', cert_level={$certLevel}, last_auto_cert_check=NOW() WHERE uid={$visit_uid}");
    $tipMsg = '认证信息已更新';
    $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
}

if (($_SERVER['REQUEST_METHOD'] === 'POST') && isset($_POST['action']) && $_POST['action'] === 'edit_profile') {
    if ($is_admin || $isSelf) {
        $newSig  = trim($_POST['signature'] ?? '');
        $newHome = trim($_POST['homepage_content'] ?? '');
        $s = $conn->real_escape_string($newSig);
        $h = $conn->real_escape_string($newHome);
        $tagUpdate = '';
        $usernameColor = trim($_POST['username_color'] ?? 'auto');
        if (!in_array($usernameColor, ['auto', 'beautiful'])) {
            $usernameColor = 'auto';
        }
        if ($usernameColor === 'beautiful') {
            $ach = getAchievementScore($userInfo['cert_type'] ?? '', (int)($userInfo['cert_level'] ?? 0));
            $pra = (int)($userInfo['practice_score'] ?? 0);
            $con = (int)($userInfo['contribute_score'] ?? 0);
            $cte = (int)($userInfo['contest_score'] ?? 0);
            if (!($ach >= 20 || $pra >= 30 || $con >= 30 || $cte >= 20)) {
                $usernameColor = 'auto';
            }
        }
        $colorEsc = $conn->real_escape_string($usernameColor);
        if ($is_admin) {
            $newTag = trim($_POST['usertag'] ?? '');
            $t = $conn->real_escape_string($newTag);
            $tagUpdate = ", tag='{$t}'";
        }
        $showColorfulNames = 1;
        if ($isSelf) {
            $showColorfulNames = isset($_POST['show_colorful_names']) ? 1 : 0;
        } else {
            $cur = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$visit_uid}")->fetch_assoc();
            $showColorfulNames = $cur ? (int)$cur['show_colorful_names'] : 1;
        }
        $showEsc = (int)$showColorfulNames;

        $conn->query("UPDATE users SET signature='{$s}', homepage_content='{$h}', username_color='{$colorEsc}', show_colorful_names={$showEsc} {$tagUpdate} WHERE uid={$visit_uid}");
        $tipMsg = '资料修改成功';
        $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
    } else {
        $tipMsg = '你没有权限修改此用户资料';
    }
}

if (($isSelf||$is_admin) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_pwd') {
    $oldPwd = trim($_POST['old_pwd'] ?? '');
    $newPwd = trim($_POST['new_pwd'] ?? '');
    $rePwd  = trim($_POST['re_pwd'] ?? '');
    if (empty($oldPwd) || empty($newPwd) || empty($rePwd)) {
        $tipMsg = '请填写完整密码表单';
    } elseif ($newPwd !== $rePwd) {
        $tipMsg = '两次新密码不一致';
    } elseif (strlen($newPwd) < 6) {
        $tipMsg = '密码长度至少6位';
    } else {
        if (!password_verify($oldPwd, $userInfo['password'])&&!$is_admin) {
            $tipMsg = '原密码错误';
        } else {
            $newHash = password_hash($newPwd, PASSWORD_DEFAULT);
            $conn->query("UPDATE users SET password='{$newHash}' WHERE uid={$visit_uid}");
            $tipMsg = '密码修改成功';
        }
    }
}

if ($isSelf && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_username') {
    $newUsername = trim($_POST['new_username'] ?? '');
    $confirmPwd = trim($_POST['confirm_pwd'] ?? '');
    if (empty($newUsername) || empty($confirmPwd)) {
        $tipMsg = '请填写完整信息';
    } else {
        if (!password_verify($confirmPwd, $userInfo['password'])) {
            $tipMsg = '当前密码错误';
        } else {
            if (preg_match('/^[A-Za-z0-9_]{3,20}$/', $newUsername) === 0) {
                $tipMsg = '用户名仅允许英文、数字、下划线，且长度3-20位';
            } else {
                if ($newUsername === $userInfo['name']) {
                    $tipMsg = '新用户名与当前用户名相同，无需修改';
                } else {
                    $checkSame = $conn->query("SELECT uid FROM users WHERE name = '{$conn->real_escape_string($newUsername)}' AND uid != {$login_uid}");
                    if ($checkSame->num_rows > 0) {
                        $tipMsg = '该用户名已被占用';
                    } else {
                        $lastChange = $userInfo['last_username_change'] ?? null;
                        if ($lastChange !== null) {
                            $diff = time() - strtotime($lastChange);
                            if ($diff < 365 * 24 * 3600) {
                                $remaining = ceil((365 * 24 * 3600 - $diff) / 3600);
                                $tipMsg = "距离上次修改用户名不足365天，请等待 {$remaining} 小时后再试";
                                goto end_username;
                            }
                        }
                        $conn->query("UPDATE users SET name = '{$conn->real_escape_string($newUsername)}', last_username_change = NOW() WHERE uid = {$login_uid}");
                        $tipMsg = '用户名修改成功！';
                        $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
                    }
                }
            }
        }
    }
    end_username:
}

if ($isSelf && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_avatar') {
    $avatarUrl = trim($_POST['avatar_url'] ?? '');
    if (!empty($avatarUrl)) {
        $conn->query("UPDATE users SET avatar='" . $conn->real_escape_string($avatarUrl) . "' WHERE uid=$login_uid");
        $tipMsg = '头像已更新';
    } else {
        $tipMsg = '请填写图片链接';
    }
    $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
}

if ($isSelf && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_background') {
    $bgUrl = trim($_POST['bg_url'] ?? '');
    if (!empty($bgUrl)) {
        $conn->query("UPDATE users SET background_image='" . $conn->real_escape_string($bgUrl) . "' WHERE uid=$login_uid");
        $tipMsg = '主页背景已更新';
    } else {
        $tipMsg = '请填写图片链接';
    }
    $userInfo = $conn->query("SELECT *, banned, valuation, last_valuation_decay, cert_type, cert_level, practice_score, contribute_score, contest_score, username_color, base_credit, last_luogu_fetch, luogu_ccf FROM users WHERE uid = {$visit_uid} LIMIT 1")->fetch_assoc();
}

$showColorfulNames = 1;
if ($login_uid > 0) {
    $curPref = $conn->query("SELECT show_colorful_names FROM users WHERE uid = {$login_uid} LIMIT 1")->fetch_assoc();
    if ($curPref) {
        $showColorfulNames = (int)$curPref['show_colorful_names'];
    }
}

$myInterests = array_filter(explode(',', $userInfo['interests'] ?? ''));
$recommendedUsers = [];
if (!empty($myInterests)) {
    $escapedInterests = array_map([$conn, 'real_escape_string'], $myInterests);
    $likeConditions = [];
    foreach ($escapedInterests as $tag) {
        $likeConditions[] = "interests LIKE '%{$tag}%'";
    }
    $where = implode(' OR ', $likeConditions);
    $sql = "SELECT uid, name, avatar, interests FROM users WHERE uid != {$visit_uid} AND ({$where}) ORDER BY RAND() LIMIT 5";
    $recRes = $conn->query($sql);
    while ($row = $recRes->fetch_assoc()) {
        $row['common_tags'] = array_intersect(
            $myInterests,
            array_filter(explode(',', $row['interests'] ?? ''))
        );
        $recommendedUsers[] = $row;
    }
} else {
    $recRes = $conn->query("SELECT uid, name, avatar, interests FROM users WHERE uid != {$visit_uid} ORDER BY RAND() LIMIT 5");
    while ($row = $recRes->fetch_assoc()) {
        $row['common_tags'] = [];
        $recommendedUsers[] = $row;
    }
}

function safeContent($content) { return htmlspecialchars($content ?? '', ENT_QUOTES, 'UTF-8'); }
function formatTime($timeStr) { return empty($timeStr) ? '' : date('Y-m-d H:i:s', strtotime($timeStr)); }
function getFirstChar($name) {
    $name = trim($name ?? '?');
    if (mb_strlen($name) > 0) return mb_strtoupper(mb_substr($name, 0, 1));
    return '?';
}

$baseCredit = (int)($userInfo['base_credit'] ?? 10);
$achievementScore = min(getAchievementScore($userInfo['cert_type'] ?? '', (int)($userInfo['cert_level'] ?? 0)), 20);
$practiceScore   = min((int)($userInfo['practice_score'] ?? 0), 20);
$contributeScore = min((int)($userInfo['contribute_score'] ?? 0), 30);
$contestScore    = min((int)($userInfo['contest_score'] ?? 0), 20);

$totalScore = $baseCredit + $achievementScore + $practiceScore + $contributeScore + $contestScore;

$isBrown = (isset($userInfo['valuation']) && (int)$userInfo['valuation'] === -1);
if ($isBrown) {
    $totalScore = -1;
    $colorKey = 'brown';
} else {
    $colorKey = getValuationColor($totalScore, $userInfo['admin'] == 1);
}

$canColorful = ($achievementScore >= 20 || $practiceScore >= 30 || $contributeScore >= 30 || $contestScore >= 20);
$targetUserColorful = ($userInfo['username_color'] === 'beautiful' && $canColorful);
$actualColorful = $isSelf ? $targetUserColorful : ($targetUserColorful && $showColorfulNames);

$colorHex = $colorMap[$colorKey] ?? '#b0a8a0';
$colorLabel = $colorNames[$colorKey] ?? 'Gray';

$certType = $userInfo['cert_type'] ?? '';
$certLevel = (int)($userInfo['cert_level'] ?? 0);
$showCert = !empty($certType) && $certLevel > 0;

function getImgUrl($str) {
    $str = safeContent(trim($str));
    if (strpos($str, 'http') === 0) {
        return $str;
    }
    else {
        return '/' . ltrim($str, '/');
    }
}

$defaultTab = isset($_GET['view']) && $_GET['view'] === 'benben' ? 'benben' : 'home';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title><?= safeContent($userInfo['name']) ?> - 个人主页 · lmtOJ</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.css">
    <script src="https://cdn.jsdelivr.net/npm/katex@0.16.9/dist/katex.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/markdown-it@14.1.0/dist/markdown-it.min.js"></script>
    <style>
        :root {
            --bg: #f9f7f4; --card-bg: #ffffff; --nav-bg: #3d3a37; --nav-text: #f0ece6;
            --text: #2c2a28; --text-secondary: #7a736b; --text-muted: #a0988e;
            --border: #e6e1da; --border-light: #f0ece6;
            --accent: #6b8a74; --accent-hover: #55735e; --accent-light: #eef4ef;
            --warm-yellow: #b8860b; --danger: #d9534f; --danger-hover: #c0392b;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.04); --shadow: 0 2px 10px rgba(0,0,0,0.05);
            --radius: 10px; --radius-sm: 6px; --radius-xs: 4px; --transition: 0.18s ease;
            --font: 'Segoe UI','PingFang SC','Microsoft YaHei','Noto Sans SC',system-ui,sans-serif;
            --font-mono: 'JetBrains Mono','Cascadia Code','Consolas','SF Mono',monospace;
        }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { background:var(--bg); font-family:var(--font); color:var(--text); line-height:1.6; -webkit-font-smoothing:antialiased; }
        .navbar { background:var(--nav-bg); height:54px; display:flex; align-items:center; justify-content:space-between; padding:0 28px; color:var(--nav-text); position:sticky; top:0; z-index:100; box-shadow:0 1px 4px rgba(0,0,0,0.08); }
        .navbar h1 { font-size:17px; font-weight:600; color:#f0ece6; letter-spacing:0.4px; }
        .bell-wrap { position:relative; font-size:20px; cursor:pointer; margin-right:20px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; border-radius:50%; transition:var(--transition); user-select:none; }
        .bell-wrap:hover { background:rgba(255,255,255,0.08); }
        .red-dot { position:absolute; top:5px; right:5px; width:9px; height:9px; background:#f55353; border-radius:50%; border:1.5px solid #3d3a37; animation:pulse-dot 2s infinite; }
        @keyframes pulse-dot { 0%,100%{box-shadow:0 0 0 0 rgba(245,83,83,0.5);} 50%{box-shadow:0 0 0 6px rgba(245,83,83,0);} }
        .user-info { display:flex; align-items:center; gap:6px; }
        .user-info a { color:#e0dbd3; text-decoration:none; font-size:13.5px; padding:7px 13px; border-radius:20px; transition:var(--transition); white-space:nowrap; font-weight:500; }
        .user-info a:hover { background:rgba(255,255,255,0.1); color:#fff; }
        .user-info a.admin-link { color:#f5d76e; font-weight:600; }
        .main { max-width:1100px; margin:28px auto 40px; display:flex; gap:22px; padding:0 20px; align-items:flex-start; }
        .sidebar { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); width:fit-content; min-width:110px; overflow:hidden; flex-shrink:0; }
        .sidebar a { display:block; padding:13px 22px; text-align:center; background:var(--card-bg); color:var(--text); text-decoration:none; font-size:14.5px; font-weight:500; transition:var(--transition); border-left:3px solid transparent; letter-spacing:0.3px; }
        .sidebar a:hover { background:#f5f2ed; border-left-color:var(--accent); color:var(--accent); }
        .content { flex:1; min-width:0; }
        .right-sidebar { width:220px; flex-shrink:0; }
        .right-card { background:var(--card-bg); border-radius:var(--radius); box-shadow:var(--shadow); padding:16px; margin-bottom:20px; }
        .right-card h3 { font-size:15px; font-weight:600; margin-bottom:16px; color:var(--text); }
        .recommend-item { display:flex; align-items:center; gap:10px; padding:8px 0; border-bottom:1px solid var(--border-light); }
        .recommend-item:last-child { border-bottom:none; }
        .recommend-item:hover { background:#fafaf8; }
        .rec-avatar { width:36px; height:36px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:600; overflow:hidden; flex-shrink:0; }
        .rec-avatar img { width:100%; height:100%; object-fit:cover; }
        .rec-name { font-size:14px; font-weight:500; color:var(--text); text-decoration:none; }
        .rec-name:hover { text-decoration:underline; color:var(--accent); }
        .rec-tags { font-size:11px; color:var(--text-muted); margin-top:2px; }

        a { color:var(--accent); text-decoration:none; transition:var(--transition); font-weight:500; }
        a:hover { color:var(--accent-hover); text-decoration:underline; }
        .back-btn { display:inline-flex; align-items:center; gap:6px; margin-bottom:18px; padding:8px 18px; background:var(--card-bg); color:var(--text); border-radius:20px; font-size:13.5px; font-weight:500; border:1px solid var(--border); box-shadow:var(--shadow-sm); text-decoration:none; }
        .back-btn:hover { background:var(--accent-light); border-color:var(--accent); color:var(--accent); text-decoration:none; }
        .card { background:var(--card-bg); border-radius:var(--radius); padding:26px 28px; box-shadow:var(--shadow); margin-bottom:20px; }
        .card h3 { font-size:17px; font-weight:600; margin-bottom:20px; color:var(--text); letter-spacing:0.3px; }
        .tip-text { color:var(--warm-yellow); margin:10px 0 16px; font-size:14px; font-weight:500; padding:10px 14px; background:#fef9e7; border:1px solid #f0d78c; border-radius:var(--radius-xs); }

        .user-card {
            background:var(--card-bg);
            border-radius:var(--radius);
            padding:28px 30px;
            box-shadow:var(--shadow);
            margin-bottom:20px;
            display:flex;
            align-items:center;
            gap:12px;
            flex-wrap:wrap;
            position: relative;
            overflow: hidden;
            min-height: 120px;
        }
        .profile-bg {
            position: absolute;
            top: 0; left: 0; right: 0; bottom: 0;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            -webkit-mask-image: linear-gradient(to bottom, black 0%, transparent 100%);
            mask-image: linear-gradient(to bottom, black 0%, transparent 100%);
            border-radius: var(--radius);
            pointer-events: none;
            z-index: 0;
        }
        .user-card > *:not(.profile-bg) {
            position: relative;
            z-index: 1;
        }

        .user-avatar { width:60px; height:60px; border-radius:50%; background:var(--accent); color:#fff; display:flex; align-items:center; justify-content:center; font-size:28px; font-weight:700; overflow:hidden; flex-shrink:0; user-select:none; }
        .user-avatar img { width:100%; height:100%; object-fit:cover; }
        .username-display {
            font-size:22px;
            font-weight:700;
            color: #ffffff;
            text-shadow: 0 1px 4px rgba(0,0,0,0.5);
        }

        .tag {
            display:inline-block;
            border-radius:4px;
            padding:3px 10px;
            color:#ffffff;
            font-size:12.5px;
            font-weight:600;
            letter-spacing:0.3px;
            margin-left:6px;
        }
        .tag.colorful-bg {
            animation: colorfulBg 3s linear infinite;
        }
        @keyframes colorfulBg {
            0% { background-color: #e74c3c; }
            17% { background-color: #e67e22; }
            33% { background-color: #f1c40f; }
            50% { background-color: #28a745; }
            67% { background-color: #4a90d9; }
            83% { background-color: #8e44ad; }
            100% { background-color: #e74c3c; }
        }

        .cert-badge { display:inline-block; border-radius:12px; padding:2px 12px; font-size:12px; font-weight:600; margin-left:6px; background:var(--accent-light); color:var(--accent); border:1px solid var(--accent); }
        .cert-del-link { color:var(--danger); margin-left:4px; font-size:12px; cursor:pointer; text-decoration:none; }
        .cert-del-link:hover { text-decoration:underline; }
        .bind-badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:600; margin-left:6px; }
        .bind-luogu { background:#fff3e0; color:#e65100; }
        .signature-text {
            color: var(--text-secondary);
            font-size: 14px;
            margin-top: 8px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 100%;
        }
        .interest-tags { display:flex; flex-wrap:wrap; gap:6px; margin-top:10px; }
        .interest-tag { background:var(--accent-light); color:var(--accent); padding:4px 12px; border-radius:20px; font-size:13px; }
        .ben-item { padding:14px 0; border-bottom:1px solid var(--border-light); transition:background 0.15s ease; }
        .ben-item:last-child { border-bottom:none; }
        .ben-item:hover { background:#fdfcf9; }
        .ben-time { font-size:12px; color:var(--text-muted); margin-top:8px; letter-spacing:0.2px; }
        .ben-content { word-break:break-word; white-space:normal; line-height:1.7; font-size:14px; color:#3a3733; }
        .ben-content blockquote { border-left:4px solid var(--accent); padding:8px 14px; margin:8px 0; background:#fafaf8; color:#5a5550; border-radius:0 var(--radius-xs) var(--radius-xs) 0; }
        .ben-content pre { background:#2b2a27; color:#e8e4dd; padding:14px 16px; border-radius:var(--radius-sm); overflow-x:auto; margin:8px 0; font-family:var(--font-mono); font-size:13px; }
        .ben-content code { font-family:var(--font-mono); background:#f3f0eb; padding:2px 6px; border-radius:3px; color:#5a4a3a; }
        .ben-content pre code { background:transparent; padding:0; color:inherit; }
        .ben-content .at-link { color:var(--accent); text-decoration:none; font-weight:500; }
        .ben-content .at-link:hover { text-decoration:underline; color:var(--accent-hover); }
        .ben-content img { max-width: 100%; height: auto; border-radius: 4px; margin: 6px 0; }
        .form-group { margin-bottom:16px; }
        .form-group label { display:block; margin-bottom:6px; font-size:13px; color:var(--text-secondary); font-weight:500; }
        input[type="text"], input[type="password"], input[type="file"], textarea {
            width:100%; max-width:420px; padding:9px 14px; margin:4px 0;
            border:1.5px solid var(--border); border-radius:var(--radius-xs); font-size:14px;
            font-family:var(--font); outline:none; transition:var(--transition); background:#fdfdfc;
        }
        textarea { resize:vertical; min-height:80px; }
        input:focus, textarea:focus { border-color:var(--accent); box-shadow:0 0 0 3px rgba(107,138,116,0.08); background:#fff; }
        .btn { padding:9px 20px; border:none; border-radius:20px; cursor:pointer; color:#fff; font-size:14px; font-weight:500; transition:var(--transition); font-family:var(--font); letter-spacing:0.3px; display:inline-flex; align-items:center; gap:6px; background:var(--accent); }
        .btn:hover { background:var(--accent-hover); box-shadow:0 2px 8px rgba(107,138,116,0.25); transform:translateY(-1px); }
        .btn:active { transform:translateY(0); }
        .btn-danger { background:var(--danger); }
        .btn-danger:hover { background:var(--danger-hover); }
        .btn-sm { padding:4px 10px; font-size:12px; }
        .tab-buttons { margin-bottom:20px; display:flex; }
        .tab-btn { border-radius:0 !important; background:var(--card-bg); color:var(--text); border:1px solid var(--border); }
        .tab-btn:first-child { border-radius:20px 0 0 20px !important; }
        .tab-btn:last-child { border-radius:0 20px 20px 0 !important; }
        .tab-btn.active { background:var(--accent) !important; color:#fff !important; border-color:var(--accent) !important; }
        .checkbox-label { display:flex; align-items:center; gap:8px; }
        .batch-bar { display:flex; align-items:center; gap:10px; margin-top:15px; flex-wrap:wrap; }
        .batch-bar .selected-count { font-size:13px; color:var(--text-muted); }
        @media (max-width:768px) {
            .main { flex-direction:column; padding:0 12px; margin:18px auto 30px; gap:14px; }
            .sidebar { width:100%; position:static; display:flex; }
            .sidebar a { flex:1 1 auto; padding:11px 10px; font-size:13px; border-left:none; border-bottom:2px solid transparent; }
            .sidebar a:hover { border-left-color:transparent; border-bottom-color:var(--accent); }
            .card { padding:18px 14px; }
            .user-card { padding:20px; }
            input, textarea { max-width:100%; }
            .right-sidebar { width:100%; position:static; }
        }

        .score-item {
            display: flex;
            justify-content: space-between;
            font-size: 13px;
            padding: 3px 0;
            border-bottom: 1px dashed var(--border-light);
        }
        .score-item:last-child { border-bottom: none; }
        .score-total {
            font-weight: 700;
            margin-top: 6px;
            padding-top: 6px;
            border-top: 2px solid var(--border);
            font-size: 15px;
        }
        .score-label { color: var(--text-secondary); }
        .score-value { font-weight: 600; }

        select[name="username_color"] {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            background: #fdfdfc url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%236b8a74' stroke-width='1.5' fill='none'/%3E%3C/svg%3E") no-repeat right 12px center;
            background-size: 12px 8px;
            padding-right: 36px;
            border: 1.5px solid var(--border);
            border-radius: var(--radius-sm);
            padding: 8px 14px;
            font-size: 14px;
            font-family: var(--font);
            outline: none;
            transition: var(--transition);
            background-color: #fdfdfc;
            width: 100%;
            max-width: 300px;
            cursor: pointer;
        }
        select[name="username_color"]:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(107,138,116,0.08);
        }
    </style>
</head>
<body>
<?php include 'navbar.php'; ?>

<div class="main">
    <?php include 'sidebar.php'; ?>
    <div class="content">
        <?php if($tipMsg): ?><div class="tip-text"><?=safeContent($tipMsg)?></div><?php endif; ?>
        <div class="user-card">
            <?php if (!empty($userInfo['background_image'])): ?>
                <div class="profile-bg" style="background-image: url('<?=getImgUrl($userInfo['background_image'])?>');"></div>
            <?php endif; ?>
            <div class="user-avatar">
                <?php if (!empty($userInfo['avatar'])): ?>
                    <img src="<?=getImgUrl($userInfo['avatar'])?>" alt="头像">
                <?php else: ?>
                    <?=getFirstChar($userInfo['name'])?>
                <?php endif; ?>
            </div>
            <div>
                <span class="username-display"><?=safeContent($userInfo['name'])?></span>
                <?php if(!empty($userInfo['tag'])): ?>
                    <span class="tag<?= $actualColorful ? ' colorful-bg' : '' ?>" <?= $actualColorful ? '' : 'style="background: ' . $colorHex . ';"' ?>>
                        <?=safeContent($userInfo['tag'])?>
                    </span>
                <?php endif; ?>
                <?php if($showCert): ?>
                    <span class="cert-badge">
                        <?=safeContent($certType)?> 等级 <?=$certLevel?>
                        <?php if($is_admin): ?>
                            <a href="?uid=<?=$visit_uid?>&del_cert=1" class="cert-del-link" onclick="return confirm('确定删除该用户的奖项认证吗？')">[删除]</a>
                        <?php endif; ?>
                    </span>
                <?php endif; ?>
                <?php if($userInfo['banned']): ?>
                    <div style="margin-top:6px; color:var(--danger); font-weight:600; font-size:14px;">⚠️ 此用户已被封禁</div>
                <?php endif; ?>

                <div class="follow-info" style="display:flex; gap:15px; align-items:center; margin-top:8px;">
                    <span style="font-size:13px; color:var(--text-secondary);">
                        关注 <a href="javascript:void(0)" onclick="showFollowList('following', <?=$visit_uid?>)" style="font-weight:600; color:var(--accent);"><?=$followingCount?></a>
                    </span>
                    <span style="font-size:13px; color:var(--text-secondary);">
                        粉丝 <a href="javascript:void(0)" onclick="showFollowList('followers', <?=$visit_uid?>)" style="font-weight:600; color:var(--accent);" id="followerCountLink"><?=$followerCount?></a>
                    </span>
                    <?php if ($login_uid > 0 && $login_uid != $visit_uid): ?>
                        <button id="followBtn" class="btn btn-sm" onclick="toggleFollow()" style="margin-left:auto; <?= $isFollowing ? 'background:var(--text-muted);' : '' ?>">
                            <?= $isFollowing ? ($isMutual ? '互相关注' : '已关注') : '关注' ?>
                        </button>
                    <?php endif; ?>
                </div>

                <?php if(!empty($userInfo['signature'])): ?>
                    <div class="signature-text" title="<?=safeContent($userInfo['signature'])?>"><?=safeContent($userInfo['signature'])?></div>
                <?php endif; ?>
            </div>
        </div>

        <div class="tab-buttons">
            <button onclick="switchTab('home')" id="tab-home-btn" class="btn tab-btn <?= $defaultTab === 'home' ? 'active' : '' ?>">主页</button>
            <button onclick="switchTab('benben')" id="tab-benben-btn" class="btn tab-btn <?= $defaultTab === 'benben' ? 'active' : '' ?>">犇犇</button>
        </div>

        <div id="tab-home" style="display:<?= $defaultTab === 'home' ? 'block' : 'none' ?>;">
            <?php
            $interests = array_filter(explode(',', $userInfo['interests'] ?? ''));
            $hasLuogu = ($lgUid && $lgUid['verified']);
            if(!empty($interests) || $hasLuogu):
            ?>
            <div class="card">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                    <span style="font-size:17px; font-weight:600; color:var(--text);">标签</span>
                    <?php if($hasLuogu): ?>
                        <a href="https://www.luogu.com.cn/user/<?=$lgUid['bind_value']?>" target="_blank">
                            <span class="bind-badge bind-luogu">洛谷：<?=$lgUid['bind_value']?></span>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!empty($userInfo['homepage_content'])): ?>
                <div class="card">
                    <h3>个人主页</h3>
                    <div class="ben-content" id="homepage-content"><?=safeContent($userInfo['homepage_content'])?></div>
                </div>
            <?php endif; ?>

            <?php if($isSelf || $is_admin): ?>
                <button onclick="toggleEdit()" class="btn" style="margin-bottom:12px;">修改信息</button>
                <div id="edit-section" style="display:none;">
                    <div class="card"><h3>编辑资料</h3>
                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="edit_profile">
                            <?php if($is_admin): ?>
                                <div class="form-group"><label>标签</label><input type="text" name="usertag" value="<?=safeContent($userInfo['tag']??'')?>"></div>
                            <?php endif; ?>
                            <div class="form-group"><label>个人签名</label><textarea name="signature" style="height:60px;"><?=safeContent($userInfo['signature']??'')?></textarea></div>
                            <div class="form-group"><label>个人主页（支持Markdown/LaTeX）</label><textarea name="homepage_content" style="height:120px;"><?=safeContent($userInfo['homepage_content']??'')?></textarea></div>
                            <div class="form-group">
                                <label>名字颜色选择</label>
                                <select name="username_color" style="width:100%;max-width:300px;">
                                    <option value="auto" <?=$userInfo['username_color']=='auto'?'selected':''?>>根据估值决定</option>
                                    <?php if ($canColorful): ?>
                                        <option value="beautiful" <?=$userInfo['username_color']=='beautiful'?'selected':''?>>彩色名</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" name="show_colorful_names" value="1" <?= $showColorfulNames ? 'checked' : '' ?>>
                                    显示其他用户的彩色名
                                </label>
                                <p style="font-size:12px; color:var(--text-muted);">开启后，其他用户的彩色标签会以动画效果显示；关闭则统一显示为估值的纯色。</p>
                            </div>
                            <button type="submit" class="btn">保存</button>
                        </form>
                    </div>

                    <div class="card"><h3>修改用户名</h3>
                        <form method="post">
                            <input type="hidden" name="action" value="change_username">
                            <div class="form-group"><label>新用户名（3~20个英文字母、数字或下划线）</label>
                                <input type="text" name="new_username" required pattern="[A-Za-z0-9_]{3,20}" title="仅允许英文字母、数字、下划线，长度3-20">
                            </div>
                            <div class="form-group"><label>当前密码确认</label>
                                <input type="password" name="confirm_pwd" required>
                            </div>
                            <button type="submit" class="btn">修改用户名</button>
                            <?php if(!empty($userInfo['last_username_change'])): ?>
                                <p style="margin-top:8px; font-size:13px; color:var(--text-muted);">
                                    上次修改时间：<?=formatTime($userInfo['last_username_change'])?>
                                    （365天内仅可修改一次）
                                </p>
                            <?php endif; ?>
                        </form>
                    </div>

                    <div class="card"><h3>修改头像</h3>
                        <form method="post">
                            <input type="hidden" name="action" value="update_avatar">
                            <div class="form-group"><label>图片URL</label><input type="text" name="avatar_url" placeholder="https://..."></div>
                            <p style="font-size:13px; color:var(--text-muted);">请上传至 <a href="https://lmtoj.cn/image_host">图床</a> 后填写链接或直接填写外部链接。</p></br>
                            <button type="submit" class="btn">更新头像</button>
                        </form>
                    </div>

                    <div class="card"><h3>修改主页背景</h3>
                        <form method="post">
                            <input type="hidden" name="action" value="update_background">
                            <div class="form-group"><label>图片URL</label><input type="text" name="bg_url" placeholder="https://..."></div>
                            <p style="font-size:13px; color:var(--text-muted);">请上传至 <a href="https://lmtoj.cn/image_host">图床</a> 后填写链接或直接填写外部链接。</p></br>
                            <button type="submit" class="btn">更新背景</button>
                        </form>
                    </div>

                    <div class="card"><h3>修改登录密码</h3>
                        <form method="post">
                            <input type="hidden" name="action" value="change_pwd">
                            <div class="form-group"><label>原密码</label><input type="password" name="old_pwd" required></div>
                            <div class="form-group"><label>新密码</label><input type="password" name="new_pwd" required></div>
                            <div class="form-group"><label>确认新密码</label><input type="password" name="re_pwd" required></div>
                            <button type="submit" class="btn">确认修改</button>
                        </form>
                    </div>

                    <?php if($is_admin): ?>
                    <div class="card"><h3>管理员设置认证</h3>
                        <form method="post">
                            <input type="hidden" name="action" value="admin_set_cert">
                            <div class="form-group">
                                <label>认证类型</label>
                                <select name="cert_type">
                                    <option value="">无</option>
                                    <option value="OI" <?=($userInfo['cert_type']??'')=='OI'?'selected':''?>>OI</option>
                                    <option value="ICPC" <?=($userInfo['cert_type']??'')=='ICPC'?'selected':''?>>ICPC</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>认证等级 (1-10)</label>
                                <input type="number" name="cert_level" min="0" max="10" value="<?=(int)($userInfo['cert_level']??0)?>">
                            </div>
                            <button type="submit" class="btn">保存认证</button>
                        </form>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>

        <div id="tab-benben" style="display:<?= $defaultTab === 'benben' ? 'block' : 'none' ?>;">
            <div class="card">
                <h3><?=$isSelf?'我的犇犇':'TA 的犇犇'?></h3>
                <?php if($benList->num_rows <= 0): ?>
                    <p class="empty-text">暂无犇犇</p>
                <?php else: ?>
                    <form method="post" id="batchDelForm">
                        <input type="hidden" name="action" value="batch_delete">
                        <?php while($ben = $benList->fetch_assoc()): ?>
                            <div class="ben-item">
                                <label class="checkbox-label">
                                    <?php if($isSelf): ?>
                                        <input type="checkbox" name="ben_ids[]" value="<?=$ben['id']?>" onchange="updateBatchCount()">
                                    <?php endif; ?>
                                    <div class="ben-content" data-md="<?=safeContent($ben['text'])?>"></div>
                                </label>
                                <div class="ben-time">
                                    <?=formatTime($ben['time'])?>
                                    <?php if($isSelf || $is_admin): ?>
                                        <a href="?uid=<?=$visit_uid?>&del_id=<?=$ben['id']?>" onclick="return confirm('确定删除？')" style="color:var(--danger);margin-left:10px;">删除</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                        <?php if($isSelf): ?>
                            <div class="batch-bar">
                                <span class="selected-count" id="selectedCount">已选 0 / <?=$benList->num_rows?></span>
                                <button type="button" onclick="selectAll()" class="btn">全选/取消</button>
                                <button type="submit" class="btn btn-danger" onclick="return confirm('确定要批量删除选中的犇犇吗？')">批量删除选中</button>
                            </div>
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="right-sidebar">
        <div class="right-card">
            <h3>估值</h3>
            <?php if ($isBrown): ?>
                <div style="font-size:14px; color:#8b6b4d; font-weight:600; margin-bottom:8px;">已棕名</div>
            <?php endif; ?>
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                <span style="font-size:20px; font-weight:700;"><?= $totalScore ?></span>
                <span style="display:inline-block; padding:2px 12px; border-radius:20px; font-weight:600; background:<?= $colorHex ?>; color:#fff;">
                    <?= $colorLabel ?>
                </span>
            </div>
            <div style="margin-top:6px;">
                <div class="score-item"><span class="score-label">信用分</span><span class="score-value"><?= $baseCredit ?></span></div>
                <div class="score-item"><span class="score-label">成就分</span><span class="score-value"><?= $achievementScore ?></span></div>
                <div class="score-item"><span class="score-label">练习分</span><span class="score-value"><?= $practiceScore ?></span></div>
                <div class="score-item"><span class="score-label">贡献分</span><span class="score-value"><?= $contributeScore ?></span></div>
                <div class="score-item"><span class="score-label">比赛分</span><span class="score-value"><?= $contestScore ?></span></div>
                <div class="score-item score-total"><span class="score-label">总和</span><span class="score-value"><?= $totalScore ?></span></div>
            </div>
            <?php if ($userInfo['admin'] == 1): ?>
                <div style="font-size:12px; color:#8e44ad; margin-top:4px;">管理员</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- 关注/粉丝列表模态框 -->
<div id="followModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000; justify-content:center; align-items:center;">
    <div style="background:var(--card-bg); border-radius:var(--radius); max-width:400px; width:90%; max-height:80vh; overflow-y:auto; padding:20px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <h3 id="followModalTitle" style="font-size:17px;">列表</h3>
            <button onclick="closeFollowModal()" style="background:none; border:none; font-size:20px; cursor:pointer; color:var(--text-secondary);">&times;</button>
        </div>
        <div id="followModalContent"></div>
    </div>
</div>

<script>
window.visitUid = <?= $visit_uid ?? 0 ?>;
window.loginUid = <?= $login_uid ?? 0 ?>;

function switchTab(tab) {
    document.getElementById('tab-home').style.display = (tab === 'home') ? 'block' : 'none';
    document.getElementById('tab-benben').style.display = (tab === 'benben') ? 'block' : 'none';
    document.getElementById('tab-home-btn').classList.toggle('active', tab === 'home');
    document.getElementById('tab-benben-btn').classList.toggle('active', tab === 'benben');
    var url = new URL(window.location.href);
    var path = url.pathname;
    if (tab === 'benben') {
        if (!path.endsWith('/benben')) path = path.replace(/\/$/, '') + '/benben';
    } else {
        if (path.endsWith('/benben')) path = path.slice(0, -7);
        if (path === '') path = '/';
    }
    url.pathname = path;
    window.history.replaceState(null, '', url.toString());
}

function selectAll() {
    const cbs = document.querySelectorAll('#batchDelForm input[type="checkbox"]');
    const all = Array.from(cbs).every(cb => cb.checked);
    cbs.forEach(cb => cb.checked = !all);
    updateBatchCount();
}
function updateBatchCount() {
    const total = document.querySelectorAll('#batchDelForm input[type="checkbox"]').length;
    const checked = document.querySelectorAll('#batchDelForm input[type="checkbox"]:checked').length;
    document.getElementById('selectedCount').textContent = `已选 ${checked} / ${total}`;
}
function toggleEdit() {
    var section = document.getElementById('edit-section');
    var btn = event.target;
    if (section.style.display === 'none') {
        section.style.display = 'block';
        btn.textContent = '收起修改信息';
    } else {
        section.style.display = 'none';
        btn.textContent = '修改信息';
    }
}

function showFollowList(type, uid, page = 1) {
    const modal = document.getElementById('followModal');
    const content = document.getElementById('followModalContent');
    const title = document.getElementById('followModalTitle');
    title.textContent = type === 'following' ? '关注列表' : '粉丝列表';
    content.innerHTML = '加载中...';
    modal.style.display = 'flex';
    fetch(`?action=follow_list&type=${type}&uid=${uid}&page=${page}`)
        .then(res => res.json())
        .then(data => {
            content.innerHTML = data.html || '暂无数据';
        })
        .catch(err => {
            content.innerHTML = '加载失败';
        });
}

function closeFollowModal() {
    document.getElementById('followModal').style.display = 'none';
}

window.addEventListener('click', function(e) {
    if (e.target === document.getElementById('followModal')) closeFollowModal();
});

function toggleFollow() {
    const btn = document.getElementById('followBtn');
    const targetUid = window.visitUid;
    fetch(`?action=toggle_follow&target_uid=${targetUid}`)
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.is_following) {
                    if (data.mutual) {
                        btn.textContent = '互相关注';
                    } else {
                        btn.textContent = '已关注';
                    }
                    btn.style.background = 'var(--text-muted)';
                } else {
                    btn.textContent = '关注';
                    btn.style.background = '';
                }
                document.getElementById('followerCountLink').textContent = data.follower_count;
            } else {
                alert(data.message || '操作失败');
            }
        });
}

function toggleFollowFromList(btn, targetUid, listType) {
    const originalText = btn.textContent;
    btn.textContent = '...';
    btn.disabled = true;
    fetch(`?action=toggle_follow&target_uid=${targetUid}`)
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                if (data.is_following) {
                    if (data.mutual) {
                        btn.textContent = '互相关注';
                    } else {
                        btn.textContent = '已关注';
                    }
                    btn.style.background = 'var(--text-muted)';
                } else {
                    btn.textContent = '关注';
                    btn.style.background = '';
                }
                if (listType === 'following' && !data.is_following) {
                    const row = btn.closest('.follow-list-item');
                    if (row) row.remove();
                }
                if (targetUid === window.visitUid) {
                    const link = document.getElementById('followerCountLink');
                    if (link) link.textContent = data.follower_count;
                }
            } else {
                alert(data.message || '操作失败');
                btn.textContent = originalText;
            }
        })
        .catch(err => {
            alert('网络错误');
            btn.textContent = originalText;
        })
        .finally(() => {
            btn.disabled = false;
        });
}

const md = markdownit({html:false, linkify:true, typographer:true, breaks:true});
const nameToUid = <?=json_encode($nameToUid, JSON_UNESCAPED_UNICODE)?>;
function htmlDecode(str) { const div = document.createElement('div'); div.innerHTML = str; return div.textContent; }
function renderContent(raw) {
    let text = raw;
    text = text.replace(/<(https?:\/\/[^>\s]+)>/g, '[$1]($1)');
    let html = md.render(text);
    html = html.replace(/\$\$([\s\S]*?)\$\$/g, (m, math) => {
        try { return '<div style="text-align:center;">' + katex.renderToString(math, {displayMode:true, throwOnError:false}) + '</div>'; } catch(e) { return m; }
    });
    html = html.replace(/\$([^$]+?)\$/g, (m, math) => {
        try { return katex.renderToString(math, {throwOnError:false}); } catch(e) { return m; }
    });
    html = html.replace(/@([\w_\u4e00-\u9fa5]+)/g, (m, user) => {
        if (nameToUid[user]) return '<a class="at-link" href="/user/' + nameToUid[user] + '" target="_blank">' + m + '</a>';
        return m;
    });
    return html;
}
function renderAll() {
    document.querySelectorAll('.ben-content').forEach(el => {
        if (el.dataset.md) el.innerHTML = renderContent(el.dataset.md);
    });
    const homeDiv = document.getElementById('homepage-content');
    if (homeDiv) homeDiv.innerHTML = renderContent(htmlDecode(homeDiv.textContent));
}
window.addEventListener('DOMContentLoaded', () => { renderAll(); updateBatchCount(); });
</script>
<?php include __DIR__ . '/footer.php'; ?>
</body>
</html>